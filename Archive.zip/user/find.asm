
user/_find:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <fmtname>:
#include "../kernel/fcntl.h"
#include "user.h"


char* fmtname(char *path)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	1000                	addi	s0,sp,32
   a:	84aa                	mv	s1,a0
  char *p;
  for(p=path+strlen(path); p >= path && *p != '/'; p--);
   c:	2f4000ef          	jal	300 <strlen>
  10:	1502                	slli	a0,a0,0x20
  12:	9101                	srli	a0,a0,0x20
  14:	9526                	add	a0,a0,s1
  16:	02f00713          	li	a4,47
  1a:	00956963          	bltu	a0,s1,2c <fmtname+0x2c>
  1e:	00054783          	lbu	a5,0(a0)
  22:	00e78563          	beq	a5,a4,2c <fmtname+0x2c>
  26:	157d                	addi	a0,a0,-1
  28:	fe957be3          	bgeu	a0,s1,1e <fmtname+0x1e>
  p++;
  return p;

}
  2c:	0505                	addi	a0,a0,1
  2e:	60e2                	ld	ra,24(sp)
  30:	6442                	ld	s0,16(sp)
  32:	64a2                	ld	s1,8(sp)
  34:	6105                	addi	sp,sp,32
  36:	8082                	ret

0000000000000038 <find>:


void find(char *path, char *filename, char *files[], int *i)
{
  38:	d8010113          	addi	sp,sp,-640
  3c:	26113c23          	sd	ra,632(sp)
  40:	26813823          	sd	s0,624(sp)
  44:	27213023          	sd	s2,608(sp)
  48:	25313c23          	sd	s3,600(sp)
  4c:	25513423          	sd	s5,584(sp)
  50:	25613023          	sd	s6,576(sp)
  54:	0500                	addi	s0,sp,640
  56:	8aaa                	mv	s5,a0
  58:	892e                	mv	s2,a1
  5a:	89b2                	mv	s3,a2
  5c:	8b36                	mv	s6,a3
  char buf[512], *p;
  int fd;
  struct dirent de;
  struct stat st;
  
  if((fd = open(path, O_RDONLY)) < 0)
  5e:	4581                	li	a1,0
  60:	536000ef          	jal	596 <open>
  64:	06054063          	bltz	a0,c4 <find+0x8c>
  68:	26913423          	sd	s1,616(sp)
  6c:	84aa                	mv	s1,a0
  {
    fprintf(2, "ls: cannot open %s\n", path);
    return;
  }
  
  if(fstat(fd, &st) < 0)
  6e:	d8840593          	addi	a1,s0,-632
  72:	53c000ef          	jal	5ae <fstat>
  76:	06054063          	bltz	a0,d6 <find+0x9e>
    fprintf(2, "ls: cannot stat %s\n", path);
    close(fd);
    return;
  }
  
  switch(st.type)
  7a:	d9041783          	lh	a5,-624(s0)
  7e:	4705                	li	a4,1
  80:	0ce78b63          	beq	a5,a4,156 <find+0x11e>
  84:	37f9                	addiw	a5,a5,-2
  86:	17c2                	slli	a5,a5,0x30
  88:	93c1                	srli	a5,a5,0x30
  8a:	00f76963          	bltu	a4,a5,9c <find+0x64>
  {
    case T_DEVICE:
    case T_FILE:
    {
      if (!strcmp(fmtname(path), filename))
  8e:	8556                	mv	a0,s5
  90:	f71ff0ef          	jal	0 <fmtname>
  94:	85ca                	mv	a1,s2
  96:	23a000ef          	jal	2d0 <strcmp>
  9a:	cd21                	beqz	a0,f2 <find+0xba>
      }
      break;

    }
  }
  close(fd);
  9c:	8526                	mv	a0,s1
  9e:	4e0000ef          	jal	57e <close>
  a2:	26813483          	ld	s1,616(sp)
}
  a6:	27813083          	ld	ra,632(sp)
  aa:	27013403          	ld	s0,624(sp)
  ae:	26013903          	ld	s2,608(sp)
  b2:	25813983          	ld	s3,600(sp)
  b6:	24813a83          	ld	s5,584(sp)
  ba:	24013b03          	ld	s6,576(sp)
  be:	28010113          	addi	sp,sp,640
  c2:	8082                	ret
    fprintf(2, "ls: cannot open %s\n", path);
  c4:	8656                	mv	a2,s5
  c6:	00001597          	auipc	a1,0x1
  ca:	a8a58593          	addi	a1,a1,-1398 # b50 <malloc+0xf4>
  ce:	4509                	li	a0,2
  d0:	0ab000ef          	jal	97a <fprintf>
    return;
  d4:	bfc9                	j	a6 <find+0x6e>
    fprintf(2, "ls: cannot stat %s\n", path);
  d6:	8656                	mv	a2,s5
  d8:	00001597          	auipc	a1,0x1
  dc:	a9058593          	addi	a1,a1,-1392 # b68 <malloc+0x10c>
  e0:	4509                	li	a0,2
  e2:	099000ef          	jal	97a <fprintf>
    close(fd);
  e6:	8526                	mv	a0,s1
  e8:	496000ef          	jal	57e <close>
    return;
  ec:	26813483          	ld	s1,616(sp)
  f0:	bf5d                	j	a6 <find+0x6e>
  f2:	25413823          	sd	s4,592(sp)
  f6:	23713c23          	sd	s7,568(sp)
        int len = strlen(path) + 1;                    
  fa:	8556                	mv	a0,s5
  fc:	204000ef          	jal	300 <strlen>
 100:	2505                	addiw	a0,a0,1
 102:	8baa                	mv	s7,a0
        files[*i] = (char*)malloc(len);
 104:	000b2783          	lw	a5,0(s6)
 108:	078e                	slli	a5,a5,0x3
 10a:	00f98a33          	add	s4,s3,a5
 10e:	14f000ef          	jal	a5c <malloc>
 112:	00aa3023          	sd	a0,0(s4)
        if (files[*i] == 0) 
 116:	000b2783          	lw	a5,0(s6)
 11a:	078e                	slli	a5,a5,0x3
 11c:	97ce                	add	a5,a5,s3
 11e:	6388                	ld	a0,0(a5)
 120:	cd19                	beqz	a0,13e <find+0x106>
        memmove(files[*i], path, len);
 122:	865e                	mv	a2,s7
 124:	85d6                	mv	a1,s5
 126:	352000ef          	jal	478 <memmove>
        (*i)++;
 12a:	000b2783          	lw	a5,0(s6)
 12e:	2785                	addiw	a5,a5,1
 130:	00fb2023          	sw	a5,0(s6)
 134:	25013a03          	ld	s4,592(sp)
 138:	23813b83          	ld	s7,568(sp)
 13c:	b785                	j	9c <find+0x64>
          fprintf(2, "find: malloc failed\n");
 13e:	00001597          	auipc	a1,0x1
 142:	a4258593          	addi	a1,a1,-1470 # b80 <malloc+0x124>
 146:	4509                	li	a0,2
 148:	033000ef          	jal	97a <fprintf>
          break; 
 14c:	25013a03          	ld	s4,592(sp)
 150:	23813b83          	ld	s7,568(sp)
 154:	b7a1                	j	9c <find+0x64>
      if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
 156:	8556                	mv	a0,s5
 158:	1a8000ef          	jal	300 <strlen>
 15c:	2541                	addiw	a0,a0,16
 15e:	20000793          	li	a5,512
 162:	00a7f963          	bgeu	a5,a0,174 <find+0x13c>
        printf("ls: path too long\n");
 166:	00001517          	auipc	a0,0x1
 16a:	a3250513          	addi	a0,a0,-1486 # b98 <malloc+0x13c>
 16e:	037000ef          	jal	9a4 <printf>
        break;
 172:	b72d                	j	9c <find+0x64>
 174:	25413823          	sd	s4,592(sp)
      strcpy(buf, path);
 178:	85d6                	mv	a1,s5
 17a:	db040513          	addi	a0,s0,-592
 17e:	132000ef          	jal	2b0 <strcpy>
      p = buf + strlen(buf);
 182:	db040513          	addi	a0,s0,-592
 186:	17a000ef          	jal	300 <strlen>
 18a:	1502                	slli	a0,a0,0x20
 18c:	9101                	srli	a0,a0,0x20
 18e:	db040793          	addi	a5,s0,-592
 192:	00a78733          	add	a4,a5,a0
 196:	8a3a                	mv	s4,a4
      *p++ = '/';
 198:	00170793          	addi	a5,a4,1
 19c:	8abe                	mv	s5,a5
 19e:	02f00793          	li	a5,47
 1a2:	00f70023          	sb	a5,0(a4)
      while(read(fd, &de, sizeof(de)) == sizeof(de))
 1a6:	4641                	li	a2,16
 1a8:	da040593          	addi	a1,s0,-608
 1ac:	8526                	mv	a0,s1
 1ae:	3c0000ef          	jal	56e <read>
 1b2:	47c1                	li	a5,16
 1b4:	04f51763          	bne	a0,a5,202 <find+0x1ca>
        if(de.inum == 0)
 1b8:	da045783          	lhu	a5,-608(s0)
 1bc:	d7ed                	beqz	a5,1a6 <find+0x16e>
        memmove(p, de.name, DIRSIZ);
 1be:	4639                	li	a2,14
 1c0:	da240593          	addi	a1,s0,-606
 1c4:	8556                	mv	a0,s5
 1c6:	2b2000ef          	jal	478 <memmove>
        p[DIRSIZ] = 0;
 1ca:	000a07a3          	sb	zero,15(s4)
        if(!strcmp(de.name, ".") || !strcmp(de.name, ".."))
 1ce:	00001597          	auipc	a1,0x1
 1d2:	9e258593          	addi	a1,a1,-1566 # bb0 <malloc+0x154>
 1d6:	da240513          	addi	a0,s0,-606
 1da:	0f6000ef          	jal	2d0 <strcmp>
 1de:	d561                	beqz	a0,1a6 <find+0x16e>
 1e0:	00001597          	auipc	a1,0x1
 1e4:	9d858593          	addi	a1,a1,-1576 # bb8 <malloc+0x15c>
 1e8:	da240513          	addi	a0,s0,-606
 1ec:	0e4000ef          	jal	2d0 <strcmp>
 1f0:	d95d                	beqz	a0,1a6 <find+0x16e>
        find(buf, filename, files, i);
 1f2:	86da                	mv	a3,s6
 1f4:	864e                	mv	a2,s3
 1f6:	85ca                	mv	a1,s2
 1f8:	db040513          	addi	a0,s0,-592
 1fc:	e3dff0ef          	jal	38 <find>
 200:	b75d                	j	1a6 <find+0x16e>
 202:	25013a03          	ld	s4,592(sp)
 206:	bd59                	j	9c <find+0x64>

0000000000000208 <main>:




int main(int argc, char *argv[])
{
 208:	ca010113          	addi	sp,sp,-864
 20c:	34113c23          	sd	ra,856(sp)
 210:	34813823          	sd	s0,848(sp)
 214:	1680                	addi	s0,sp,864
  if(argc != 3)
 216:	470d                	li	a4,3
 218:	02e50463          	beq	a0,a4,240 <main+0x38>
 21c:	34913423          	sd	s1,840(sp)
 220:	35213023          	sd	s2,832(sp)
 224:	33313c23          	sd	s3,824(sp)
 228:	33413823          	sd	s4,816(sp)
  {
    fprintf(2, "Usage: find <path> <filename>\n");
 22c:	00001597          	auipc	a1,0x1
 230:	99458593          	addi	a1,a1,-1644 # bc0 <malloc+0x164>
 234:	4509                	li	a0,2
 236:	744000ef          	jal	97a <fprintf>
    exit(1);
 23a:	4505                	li	a0,1
 23c:	31a000ef          	jal	556 <exit>
 240:	34913423          	sd	s1,840(sp)
 244:	35213023          	sd	s2,832(sp)
 248:	33313c23          	sd	s3,824(sp)
 24c:	33413823          	sd	s4,816(sp)
 250:	87ae                	mv	a5,a1
  }
  
    char *found_files[100];
    int file_index = 0;
 252:	ca042623          	sw	zero,-852(s0)
      
    find(argv[1], argv[2], found_files, &file_index);
 256:	cac40693          	addi	a3,s0,-852
 25a:	cb040613          	addi	a2,s0,-848
 25e:	698c                	ld	a1,16(a1)
 260:	6788                	ld	a0,8(a5)
 262:	dd7ff0ef          	jal	38 <find>
  
    for (int j = 0; j < file_index; j++) 
 266:	cac42783          	lw	a5,-852(s0)
 26a:	02f05863          	blez	a5,29a <main+0x92>
 26e:	cb040493          	addi	s1,s0,-848
 272:	4901                	li	s2,0
    {
        fprintf(1, "%s\n", found_files[j]);
 274:	00001a17          	auipc	s4,0x1
 278:	8eca0a13          	addi	s4,s4,-1812 # b60 <malloc+0x104>
 27c:	4985                	li	s3,1
 27e:	6090                	ld	a2,0(s1)
 280:	85d2                	mv	a1,s4
 282:	854e                	mv	a0,s3
 284:	6f6000ef          	jal	97a <fprintf>
        free(found_files[j]); 
 288:	6088                	ld	a0,0(s1)
 28a:	74c000ef          	jal	9d6 <free>
    for (int j = 0; j < file_index; j++) 
 28e:	2905                	addiw	s2,s2,1
 290:	04a1                	addi	s1,s1,8
 292:	cac42783          	lw	a5,-852(s0)
 296:	fef944e3          	blt	s2,a5,27e <main+0x76>
    }
  
    exit(0);
 29a:	4501                	li	a0,0
 29c:	2ba000ef          	jal	556 <exit>

00000000000002a0 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 2a0:	1141                	addi	sp,sp,-16
 2a2:	e406                	sd	ra,8(sp)
 2a4:	e022                	sd	s0,0(sp)
 2a6:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 2a8:	f61ff0ef          	jal	208 <main>
  exit(r);
 2ac:	2aa000ef          	jal	556 <exit>

00000000000002b0 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 2b0:	1141                	addi	sp,sp,-16
 2b2:	e406                	sd	ra,8(sp)
 2b4:	e022                	sd	s0,0(sp)
 2b6:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 2b8:	87aa                	mv	a5,a0
 2ba:	0585                	addi	a1,a1,1
 2bc:	0785                	addi	a5,a5,1
 2be:	fff5c703          	lbu	a4,-1(a1)
 2c2:	fee78fa3          	sb	a4,-1(a5)
 2c6:	fb75                	bnez	a4,2ba <strcpy+0xa>
    ;
  return os;
}
 2c8:	60a2                	ld	ra,8(sp)
 2ca:	6402                	ld	s0,0(sp)
 2cc:	0141                	addi	sp,sp,16
 2ce:	8082                	ret

00000000000002d0 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 2d0:	1141                	addi	sp,sp,-16
 2d2:	e406                	sd	ra,8(sp)
 2d4:	e022                	sd	s0,0(sp)
 2d6:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 2d8:	00054783          	lbu	a5,0(a0)
 2dc:	cb91                	beqz	a5,2f0 <strcmp+0x20>
 2de:	0005c703          	lbu	a4,0(a1)
 2e2:	00f71763          	bne	a4,a5,2f0 <strcmp+0x20>
    p++, q++;
 2e6:	0505                	addi	a0,a0,1
 2e8:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2ea:	00054783          	lbu	a5,0(a0)
 2ee:	fbe5                	bnez	a5,2de <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 2f0:	0005c503          	lbu	a0,0(a1)
}
 2f4:	40a7853b          	subw	a0,a5,a0
 2f8:	60a2                	ld	ra,8(sp)
 2fa:	6402                	ld	s0,0(sp)
 2fc:	0141                	addi	sp,sp,16
 2fe:	8082                	ret

0000000000000300 <strlen>:

uint
strlen(const char *s)
{
 300:	1141                	addi	sp,sp,-16
 302:	e406                	sd	ra,8(sp)
 304:	e022                	sd	s0,0(sp)
 306:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 308:	00054783          	lbu	a5,0(a0)
 30c:	cf91                	beqz	a5,328 <strlen+0x28>
 30e:	00150793          	addi	a5,a0,1
 312:	86be                	mv	a3,a5
 314:	0785                	addi	a5,a5,1
 316:	fff7c703          	lbu	a4,-1(a5)
 31a:	ff65                	bnez	a4,312 <strlen+0x12>
 31c:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 320:	60a2                	ld	ra,8(sp)
 322:	6402                	ld	s0,0(sp)
 324:	0141                	addi	sp,sp,16
 326:	8082                	ret
  for(n = 0; s[n]; n++)
 328:	4501                	li	a0,0
 32a:	bfdd                	j	320 <strlen+0x20>

000000000000032c <memset>:

void*
memset(void *dst, int c, uint n)
{
 32c:	1141                	addi	sp,sp,-16
 32e:	e406                	sd	ra,8(sp)
 330:	e022                	sd	s0,0(sp)
 332:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 334:	ca19                	beqz	a2,34a <memset+0x1e>
 336:	87aa                	mv	a5,a0
 338:	1602                	slli	a2,a2,0x20
 33a:	9201                	srli	a2,a2,0x20
 33c:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 340:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 344:	0785                	addi	a5,a5,1
 346:	fee79de3          	bne	a5,a4,340 <memset+0x14>
  }
  return dst;
}
 34a:	60a2                	ld	ra,8(sp)
 34c:	6402                	ld	s0,0(sp)
 34e:	0141                	addi	sp,sp,16
 350:	8082                	ret

0000000000000352 <strchr>:

char*
strchr(const char *s, char c)
{
 352:	1141                	addi	sp,sp,-16
 354:	e406                	sd	ra,8(sp)
 356:	e022                	sd	s0,0(sp)
 358:	0800                	addi	s0,sp,16
  for(; *s; s++)
 35a:	00054783          	lbu	a5,0(a0)
 35e:	cf81                	beqz	a5,376 <strchr+0x24>
    if(*s == c)
 360:	00f58763          	beq	a1,a5,36e <strchr+0x1c>
  for(; *s; s++)
 364:	0505                	addi	a0,a0,1
 366:	00054783          	lbu	a5,0(a0)
 36a:	fbfd                	bnez	a5,360 <strchr+0xe>
      return (char*)s;
  return 0;
 36c:	4501                	li	a0,0
}
 36e:	60a2                	ld	ra,8(sp)
 370:	6402                	ld	s0,0(sp)
 372:	0141                	addi	sp,sp,16
 374:	8082                	ret
  return 0;
 376:	4501                	li	a0,0
 378:	bfdd                	j	36e <strchr+0x1c>

000000000000037a <gets>:

char*
gets(char *buf, int max)
{
 37a:	711d                	addi	sp,sp,-96
 37c:	ec86                	sd	ra,88(sp)
 37e:	e8a2                	sd	s0,80(sp)
 380:	e4a6                	sd	s1,72(sp)
 382:	e0ca                	sd	s2,64(sp)
 384:	fc4e                	sd	s3,56(sp)
 386:	f852                	sd	s4,48(sp)
 388:	f456                	sd	s5,40(sp)
 38a:	f05a                	sd	s6,32(sp)
 38c:	ec5e                	sd	s7,24(sp)
 38e:	e862                	sd	s8,16(sp)
 390:	1080                	addi	s0,sp,96
 392:	8baa                	mv	s7,a0
 394:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 396:	892a                	mv	s2,a0
 398:	4481                	li	s1,0
    cc = read(0, &c, 1);
 39a:	faf40b13          	addi	s6,s0,-81
 39e:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 3a0:	8c26                	mv	s8,s1
 3a2:	0014899b          	addiw	s3,s1,1
 3a6:	84ce                	mv	s1,s3
 3a8:	0349d463          	bge	s3,s4,3d0 <gets+0x56>
    cc = read(0, &c, 1);
 3ac:	8656                	mv	a2,s5
 3ae:	85da                	mv	a1,s6
 3b0:	4501                	li	a0,0
 3b2:	1bc000ef          	jal	56e <read>
    if(cc < 1)
 3b6:	00a05d63          	blez	a0,3d0 <gets+0x56>
      break;
    buf[i++] = c;
 3ba:	faf44783          	lbu	a5,-81(s0)
 3be:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 3c2:	0905                	addi	s2,s2,1
 3c4:	ff678713          	addi	a4,a5,-10
 3c8:	c319                	beqz	a4,3ce <gets+0x54>
 3ca:	17cd                	addi	a5,a5,-13
 3cc:	fbf1                	bnez	a5,3a0 <gets+0x26>
    buf[i++] = c;
 3ce:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 3d0:	9c5e                	add	s8,s8,s7
 3d2:	000c0023          	sb	zero,0(s8)
  return buf;
}
 3d6:	855e                	mv	a0,s7
 3d8:	60e6                	ld	ra,88(sp)
 3da:	6446                	ld	s0,80(sp)
 3dc:	64a6                	ld	s1,72(sp)
 3de:	6906                	ld	s2,64(sp)
 3e0:	79e2                	ld	s3,56(sp)
 3e2:	7a42                	ld	s4,48(sp)
 3e4:	7aa2                	ld	s5,40(sp)
 3e6:	7b02                	ld	s6,32(sp)
 3e8:	6be2                	ld	s7,24(sp)
 3ea:	6c42                	ld	s8,16(sp)
 3ec:	6125                	addi	sp,sp,96
 3ee:	8082                	ret

00000000000003f0 <stat>:

int
stat(const char *n, struct stat *st)
{
 3f0:	1101                	addi	sp,sp,-32
 3f2:	ec06                	sd	ra,24(sp)
 3f4:	e822                	sd	s0,16(sp)
 3f6:	e04a                	sd	s2,0(sp)
 3f8:	1000                	addi	s0,sp,32
 3fa:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3fc:	4581                	li	a1,0
 3fe:	198000ef          	jal	596 <open>
  if(fd < 0)
 402:	02054263          	bltz	a0,426 <stat+0x36>
 406:	e426                	sd	s1,8(sp)
 408:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 40a:	85ca                	mv	a1,s2
 40c:	1a2000ef          	jal	5ae <fstat>
 410:	892a                	mv	s2,a0
  close(fd);
 412:	8526                	mv	a0,s1
 414:	16a000ef          	jal	57e <close>
  return r;
 418:	64a2                	ld	s1,8(sp)
}
 41a:	854a                	mv	a0,s2
 41c:	60e2                	ld	ra,24(sp)
 41e:	6442                	ld	s0,16(sp)
 420:	6902                	ld	s2,0(sp)
 422:	6105                	addi	sp,sp,32
 424:	8082                	ret
    return -1;
 426:	57fd                	li	a5,-1
 428:	893e                	mv	s2,a5
 42a:	bfc5                	j	41a <stat+0x2a>

000000000000042c <atoi>:

int
atoi(const char *s)
{
 42c:	1141                	addi	sp,sp,-16
 42e:	e406                	sd	ra,8(sp)
 430:	e022                	sd	s0,0(sp)
 432:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 434:	00054683          	lbu	a3,0(a0)
 438:	fd06879b          	addiw	a5,a3,-48
 43c:	0ff7f793          	zext.b	a5,a5
 440:	4625                	li	a2,9
 442:	02f66963          	bltu	a2,a5,474 <atoi+0x48>
 446:	872a                	mv	a4,a0
  n = 0;
 448:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 44a:	0705                	addi	a4,a4,1
 44c:	0025179b          	slliw	a5,a0,0x2
 450:	9fa9                	addw	a5,a5,a0
 452:	0017979b          	slliw	a5,a5,0x1
 456:	9fb5                	addw	a5,a5,a3
 458:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 45c:	00074683          	lbu	a3,0(a4)
 460:	fd06879b          	addiw	a5,a3,-48
 464:	0ff7f793          	zext.b	a5,a5
 468:	fef671e3          	bgeu	a2,a5,44a <atoi+0x1e>
  return n;
}
 46c:	60a2                	ld	ra,8(sp)
 46e:	6402                	ld	s0,0(sp)
 470:	0141                	addi	sp,sp,16
 472:	8082                	ret
  n = 0;
 474:	4501                	li	a0,0
 476:	bfdd                	j	46c <atoi+0x40>

0000000000000478 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 478:	1141                	addi	sp,sp,-16
 47a:	e406                	sd	ra,8(sp)
 47c:	e022                	sd	s0,0(sp)
 47e:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 480:	02b57563          	bgeu	a0,a1,4aa <memmove+0x32>
    while(n-- > 0)
 484:	00c05f63          	blez	a2,4a2 <memmove+0x2a>
 488:	1602                	slli	a2,a2,0x20
 48a:	9201                	srli	a2,a2,0x20
 48c:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 490:	872a                	mv	a4,a0
      *dst++ = *src++;
 492:	0585                	addi	a1,a1,1
 494:	0705                	addi	a4,a4,1
 496:	fff5c683          	lbu	a3,-1(a1)
 49a:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 49e:	fee79ae3          	bne	a5,a4,492 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 4a2:	60a2                	ld	ra,8(sp)
 4a4:	6402                	ld	s0,0(sp)
 4a6:	0141                	addi	sp,sp,16
 4a8:	8082                	ret
    while(n-- > 0)
 4aa:	fec05ce3          	blez	a2,4a2 <memmove+0x2a>
    dst += n;
 4ae:	00c50733          	add	a4,a0,a2
    src += n;
 4b2:	95b2                	add	a1,a1,a2
 4b4:	fff6079b          	addiw	a5,a2,-1
 4b8:	1782                	slli	a5,a5,0x20
 4ba:	9381                	srli	a5,a5,0x20
 4bc:	fff7c793          	not	a5,a5
 4c0:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 4c2:	15fd                	addi	a1,a1,-1
 4c4:	177d                	addi	a4,a4,-1
 4c6:	0005c683          	lbu	a3,0(a1)
 4ca:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 4ce:	fef71ae3          	bne	a4,a5,4c2 <memmove+0x4a>
 4d2:	bfc1                	j	4a2 <memmove+0x2a>

00000000000004d4 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 4d4:	1141                	addi	sp,sp,-16
 4d6:	e406                	sd	ra,8(sp)
 4d8:	e022                	sd	s0,0(sp)
 4da:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 4dc:	c61d                	beqz	a2,50a <memcmp+0x36>
 4de:	1602                	slli	a2,a2,0x20
 4e0:	9201                	srli	a2,a2,0x20
 4e2:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 4e6:	00054783          	lbu	a5,0(a0)
 4ea:	0005c703          	lbu	a4,0(a1)
 4ee:	00e79863          	bne	a5,a4,4fe <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 4f2:	0505                	addi	a0,a0,1
    p2++;
 4f4:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4f6:	fed518e3          	bne	a0,a3,4e6 <memcmp+0x12>
  }
  return 0;
 4fa:	4501                	li	a0,0
 4fc:	a019                	j	502 <memcmp+0x2e>
      return *p1 - *p2;
 4fe:	40e7853b          	subw	a0,a5,a4
}
 502:	60a2                	ld	ra,8(sp)
 504:	6402                	ld	s0,0(sp)
 506:	0141                	addi	sp,sp,16
 508:	8082                	ret
  return 0;
 50a:	4501                	li	a0,0
 50c:	bfdd                	j	502 <memcmp+0x2e>

000000000000050e <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 50e:	1141                	addi	sp,sp,-16
 510:	e406                	sd	ra,8(sp)
 512:	e022                	sd	s0,0(sp)
 514:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 516:	f63ff0ef          	jal	478 <memmove>
}
 51a:	60a2                	ld	ra,8(sp)
 51c:	6402                	ld	s0,0(sp)
 51e:	0141                	addi	sp,sp,16
 520:	8082                	ret

0000000000000522 <sbrk>:

char *
sbrk(int n) {
 522:	1141                	addi	sp,sp,-16
 524:	e406                	sd	ra,8(sp)
 526:	e022                	sd	s0,0(sp)
 528:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 52a:	4585                	li	a1,1
 52c:	0b2000ef          	jal	5de <sys_sbrk>
}
 530:	60a2                	ld	ra,8(sp)
 532:	6402                	ld	s0,0(sp)
 534:	0141                	addi	sp,sp,16
 536:	8082                	ret

0000000000000538 <sbrklazy>:

char *
sbrklazy(int n) {
 538:	1141                	addi	sp,sp,-16
 53a:	e406                	sd	ra,8(sp)
 53c:	e022                	sd	s0,0(sp)
 53e:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 540:	4589                	li	a1,2
 542:	09c000ef          	jal	5de <sys_sbrk>
}
 546:	60a2                	ld	ra,8(sp)
 548:	6402                	ld	s0,0(sp)
 54a:	0141                	addi	sp,sp,16
 54c:	8082                	ret

000000000000054e <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 54e:	4885                	li	a7,1
 ecall
 550:	00000073          	ecall
 ret
 554:	8082                	ret

0000000000000556 <exit>:
.global exit
exit:
 li a7, SYS_exit
 556:	4889                	li	a7,2
 ecall
 558:	00000073          	ecall
 ret
 55c:	8082                	ret

000000000000055e <wait>:
.global wait
wait:
 li a7, SYS_wait
 55e:	488d                	li	a7,3
 ecall
 560:	00000073          	ecall
 ret
 564:	8082                	ret

0000000000000566 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 566:	4891                	li	a7,4
 ecall
 568:	00000073          	ecall
 ret
 56c:	8082                	ret

000000000000056e <read>:
.global read
read:
 li a7, SYS_read
 56e:	4895                	li	a7,5
 ecall
 570:	00000073          	ecall
 ret
 574:	8082                	ret

0000000000000576 <write>:
.global write
write:
 li a7, SYS_write
 576:	48c1                	li	a7,16
 ecall
 578:	00000073          	ecall
 ret
 57c:	8082                	ret

000000000000057e <close>:
.global close
close:
 li a7, SYS_close
 57e:	48d5                	li	a7,21
 ecall
 580:	00000073          	ecall
 ret
 584:	8082                	ret

0000000000000586 <kill>:
.global kill
kill:
 li a7, SYS_kill
 586:	4899                	li	a7,6
 ecall
 588:	00000073          	ecall
 ret
 58c:	8082                	ret

000000000000058e <exec>:
.global exec
exec:
 li a7, SYS_exec
 58e:	489d                	li	a7,7
 ecall
 590:	00000073          	ecall
 ret
 594:	8082                	ret

0000000000000596 <open>:
.global open
open:
 li a7, SYS_open
 596:	48bd                	li	a7,15
 ecall
 598:	00000073          	ecall
 ret
 59c:	8082                	ret

000000000000059e <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 59e:	48c5                	li	a7,17
 ecall
 5a0:	00000073          	ecall
 ret
 5a4:	8082                	ret

00000000000005a6 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 5a6:	48c9                	li	a7,18
 ecall
 5a8:	00000073          	ecall
 ret
 5ac:	8082                	ret

00000000000005ae <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 5ae:	48a1                	li	a7,8
 ecall
 5b0:	00000073          	ecall
 ret
 5b4:	8082                	ret

00000000000005b6 <link>:
.global link
link:
 li a7, SYS_link
 5b6:	48cd                	li	a7,19
 ecall
 5b8:	00000073          	ecall
 ret
 5bc:	8082                	ret

00000000000005be <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 5be:	48d1                	li	a7,20
 ecall
 5c0:	00000073          	ecall
 ret
 5c4:	8082                	ret

00000000000005c6 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 5c6:	48a5                	li	a7,9
 ecall
 5c8:	00000073          	ecall
 ret
 5cc:	8082                	ret

00000000000005ce <dup>:
.global dup
dup:
 li a7, SYS_dup
 5ce:	48a9                	li	a7,10
 ecall
 5d0:	00000073          	ecall
 ret
 5d4:	8082                	ret

00000000000005d6 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 5d6:	48ad                	li	a7,11
 ecall
 5d8:	00000073          	ecall
 ret
 5dc:	8082                	ret

00000000000005de <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 5de:	48b1                	li	a7,12
 ecall
 5e0:	00000073          	ecall
 ret
 5e4:	8082                	ret

00000000000005e6 <pause>:
.global pause
pause:
 li a7, SYS_pause
 5e6:	48b5                	li	a7,13
 ecall
 5e8:	00000073          	ecall
 ret
 5ec:	8082                	ret

00000000000005ee <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 5ee:	48b9                	li	a7,14
 ecall
 5f0:	00000073          	ecall
 ret
 5f4:	8082                	ret

00000000000005f6 <kmemfree>:
.global kmemfree
kmemfree:
 li a7, SYS_kmemfree
 5f6:	48d9                	li	a7,22
 ecall
 5f8:	00000073          	ecall
 ret
 5fc:	8082                	ret

00000000000005fe <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 5fe:	1101                	addi	sp,sp,-32
 600:	ec06                	sd	ra,24(sp)
 602:	e822                	sd	s0,16(sp)
 604:	1000                	addi	s0,sp,32
 606:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 60a:	4605                	li	a2,1
 60c:	fef40593          	addi	a1,s0,-17
 610:	f67ff0ef          	jal	576 <write>
}
 614:	60e2                	ld	ra,24(sp)
 616:	6442                	ld	s0,16(sp)
 618:	6105                	addi	sp,sp,32
 61a:	8082                	ret

000000000000061c <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 61c:	715d                	addi	sp,sp,-80
 61e:	e486                	sd	ra,72(sp)
 620:	e0a2                	sd	s0,64(sp)
 622:	f84a                	sd	s2,48(sp)
 624:	f44e                	sd	s3,40(sp)
 626:	0880                	addi	s0,sp,80
 628:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 62a:	c6d1                	beqz	a3,6b6 <printint+0x9a>
 62c:	0805d563          	bgez	a1,6b6 <printint+0x9a>
    neg = 1;
    x = -xx;
 630:	40b005b3          	neg	a1,a1
    neg = 1;
 634:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 636:	fb840993          	addi	s3,s0,-72
  neg = 0;
 63a:	86ce                	mv	a3,s3
  i = 0;
 63c:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 63e:	00000817          	auipc	a6,0x0
 642:	5aa80813          	addi	a6,a6,1450 # be8 <digits>
 646:	88ba                	mv	a7,a4
 648:	0017051b          	addiw	a0,a4,1
 64c:	872a                	mv	a4,a0
 64e:	02c5f7b3          	remu	a5,a1,a2
 652:	97c2                	add	a5,a5,a6
 654:	0007c783          	lbu	a5,0(a5)
 658:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 65c:	87ae                	mv	a5,a1
 65e:	02c5d5b3          	divu	a1,a1,a2
 662:	0685                	addi	a3,a3,1
 664:	fec7f1e3          	bgeu	a5,a2,646 <printint+0x2a>
  if(neg)
 668:	00030c63          	beqz	t1,680 <printint+0x64>
    buf[i++] = '-';
 66c:	fd050793          	addi	a5,a0,-48
 670:	00878533          	add	a0,a5,s0
 674:	02d00793          	li	a5,45
 678:	fef50423          	sb	a5,-24(a0)
 67c:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 680:	02e05563          	blez	a4,6aa <printint+0x8e>
 684:	fc26                	sd	s1,56(sp)
 686:	377d                	addiw	a4,a4,-1
 688:	00e984b3          	add	s1,s3,a4
 68c:	19fd                	addi	s3,s3,-1
 68e:	99ba                	add	s3,s3,a4
 690:	1702                	slli	a4,a4,0x20
 692:	9301                	srli	a4,a4,0x20
 694:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 698:	0004c583          	lbu	a1,0(s1)
 69c:	854a                	mv	a0,s2
 69e:	f61ff0ef          	jal	5fe <putc>
  while(--i >= 0)
 6a2:	14fd                	addi	s1,s1,-1
 6a4:	ff349ae3          	bne	s1,s3,698 <printint+0x7c>
 6a8:	74e2                	ld	s1,56(sp)
}
 6aa:	60a6                	ld	ra,72(sp)
 6ac:	6406                	ld	s0,64(sp)
 6ae:	7942                	ld	s2,48(sp)
 6b0:	79a2                	ld	s3,40(sp)
 6b2:	6161                	addi	sp,sp,80
 6b4:	8082                	ret
  neg = 0;
 6b6:	4301                	li	t1,0
 6b8:	bfbd                	j	636 <printint+0x1a>

00000000000006ba <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 6ba:	711d                	addi	sp,sp,-96
 6bc:	ec86                	sd	ra,88(sp)
 6be:	e8a2                	sd	s0,80(sp)
 6c0:	e4a6                	sd	s1,72(sp)
 6c2:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 6c4:	0005c483          	lbu	s1,0(a1)
 6c8:	22048363          	beqz	s1,8ee <vprintf+0x234>
 6cc:	e0ca                	sd	s2,64(sp)
 6ce:	fc4e                	sd	s3,56(sp)
 6d0:	f852                	sd	s4,48(sp)
 6d2:	f456                	sd	s5,40(sp)
 6d4:	f05a                	sd	s6,32(sp)
 6d6:	ec5e                	sd	s7,24(sp)
 6d8:	e862                	sd	s8,16(sp)
 6da:	8b2a                	mv	s6,a0
 6dc:	8a2e                	mv	s4,a1
 6de:	8bb2                	mv	s7,a2
  state = 0;
 6e0:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 6e2:	4901                	li	s2,0
 6e4:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 6e6:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 6ea:	06400c13          	li	s8,100
 6ee:	a00d                	j	710 <vprintf+0x56>
        putc(fd, c0);
 6f0:	85a6                	mv	a1,s1
 6f2:	855a                	mv	a0,s6
 6f4:	f0bff0ef          	jal	5fe <putc>
 6f8:	a019                	j	6fe <vprintf+0x44>
    } else if(state == '%'){
 6fa:	03598363          	beq	s3,s5,720 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 6fe:	0019079b          	addiw	a5,s2,1
 702:	893e                	mv	s2,a5
 704:	873e                	mv	a4,a5
 706:	97d2                	add	a5,a5,s4
 708:	0007c483          	lbu	s1,0(a5)
 70c:	1c048a63          	beqz	s1,8e0 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 710:	0004879b          	sext.w	a5,s1
    if(state == 0){
 714:	fe0993e3          	bnez	s3,6fa <vprintf+0x40>
      if(c0 == '%'){
 718:	fd579ce3          	bne	a5,s5,6f0 <vprintf+0x36>
        state = '%';
 71c:	89be                	mv	s3,a5
 71e:	b7c5                	j	6fe <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 720:	00ea06b3          	add	a3,s4,a4
 724:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 728:	1c060863          	beqz	a2,8f8 <vprintf+0x23e>
      if(c0 == 'd'){
 72c:	03878763          	beq	a5,s8,75a <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 730:	f9478693          	addi	a3,a5,-108
 734:	0016b693          	seqz	a3,a3
 738:	f9c60593          	addi	a1,a2,-100
 73c:	e99d                	bnez	a1,772 <vprintf+0xb8>
 73e:	ca95                	beqz	a3,772 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 740:	008b8493          	addi	s1,s7,8
 744:	4685                	li	a3,1
 746:	4629                	li	a2,10
 748:	000bb583          	ld	a1,0(s7)
 74c:	855a                	mv	a0,s6
 74e:	ecfff0ef          	jal	61c <printint>
        i += 1;
 752:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 754:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 756:	4981                	li	s3,0
 758:	b75d                	j	6fe <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 75a:	008b8493          	addi	s1,s7,8
 75e:	4685                	li	a3,1
 760:	4629                	li	a2,10
 762:	000ba583          	lw	a1,0(s7)
 766:	855a                	mv	a0,s6
 768:	eb5ff0ef          	jal	61c <printint>
 76c:	8ba6                	mv	s7,s1
      state = 0;
 76e:	4981                	li	s3,0
 770:	b779                	j	6fe <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 772:	9752                	add	a4,a4,s4
 774:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 778:	f9460713          	addi	a4,a2,-108
 77c:	00173713          	seqz	a4,a4
 780:	8f75                	and	a4,a4,a3
 782:	f9c58513          	addi	a0,a1,-100
 786:	18051363          	bnez	a0,90c <vprintf+0x252>
 78a:	18070163          	beqz	a4,90c <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 78e:	008b8493          	addi	s1,s7,8
 792:	4685                	li	a3,1
 794:	4629                	li	a2,10
 796:	000bb583          	ld	a1,0(s7)
 79a:	855a                	mv	a0,s6
 79c:	e81ff0ef          	jal	61c <printint>
        i += 2;
 7a0:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 7a2:	8ba6                	mv	s7,s1
      state = 0;
 7a4:	4981                	li	s3,0
        i += 2;
 7a6:	bfa1                	j	6fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 7a8:	008b8493          	addi	s1,s7,8
 7ac:	4681                	li	a3,0
 7ae:	4629                	li	a2,10
 7b0:	000be583          	lwu	a1,0(s7)
 7b4:	855a                	mv	a0,s6
 7b6:	e67ff0ef          	jal	61c <printint>
 7ba:	8ba6                	mv	s7,s1
      state = 0;
 7bc:	4981                	li	s3,0
 7be:	b781                	j	6fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7c0:	008b8493          	addi	s1,s7,8
 7c4:	4681                	li	a3,0
 7c6:	4629                	li	a2,10
 7c8:	000bb583          	ld	a1,0(s7)
 7cc:	855a                	mv	a0,s6
 7ce:	e4fff0ef          	jal	61c <printint>
        i += 1;
 7d2:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7d4:	8ba6                	mv	s7,s1
      state = 0;
 7d6:	4981                	li	s3,0
 7d8:	b71d                	j	6fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7da:	008b8493          	addi	s1,s7,8
 7de:	4681                	li	a3,0
 7e0:	4629                	li	a2,10
 7e2:	000bb583          	ld	a1,0(s7)
 7e6:	855a                	mv	a0,s6
 7e8:	e35ff0ef          	jal	61c <printint>
        i += 2;
 7ec:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7ee:	8ba6                	mv	s7,s1
      state = 0;
 7f0:	4981                	li	s3,0
        i += 2;
 7f2:	b731                	j	6fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 7f4:	008b8493          	addi	s1,s7,8
 7f8:	4681                	li	a3,0
 7fa:	4641                	li	a2,16
 7fc:	000be583          	lwu	a1,0(s7)
 800:	855a                	mv	a0,s6
 802:	e1bff0ef          	jal	61c <printint>
 806:	8ba6                	mv	s7,s1
      state = 0;
 808:	4981                	li	s3,0
 80a:	bdd5                	j	6fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 80c:	008b8493          	addi	s1,s7,8
 810:	4681                	li	a3,0
 812:	4641                	li	a2,16
 814:	000bb583          	ld	a1,0(s7)
 818:	855a                	mv	a0,s6
 81a:	e03ff0ef          	jal	61c <printint>
        i += 1;
 81e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 820:	8ba6                	mv	s7,s1
      state = 0;
 822:	4981                	li	s3,0
 824:	bde9                	j	6fe <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 826:	008b8493          	addi	s1,s7,8
 82a:	4681                	li	a3,0
 82c:	4641                	li	a2,16
 82e:	000bb583          	ld	a1,0(s7)
 832:	855a                	mv	a0,s6
 834:	de9ff0ef          	jal	61c <printint>
        i += 2;
 838:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 83a:	8ba6                	mv	s7,s1
      state = 0;
 83c:	4981                	li	s3,0
        i += 2;
 83e:	b5c1                	j	6fe <vprintf+0x44>
 840:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 842:	008b8793          	addi	a5,s7,8
 846:	8cbe                	mv	s9,a5
 848:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 84c:	03000593          	li	a1,48
 850:	855a                	mv	a0,s6
 852:	dadff0ef          	jal	5fe <putc>
  putc(fd, 'x');
 856:	07800593          	li	a1,120
 85a:	855a                	mv	a0,s6
 85c:	da3ff0ef          	jal	5fe <putc>
 860:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 862:	00000b97          	auipc	s7,0x0
 866:	386b8b93          	addi	s7,s7,902 # be8 <digits>
 86a:	03c9d793          	srli	a5,s3,0x3c
 86e:	97de                	add	a5,a5,s7
 870:	0007c583          	lbu	a1,0(a5)
 874:	855a                	mv	a0,s6
 876:	d89ff0ef          	jal	5fe <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 87a:	0992                	slli	s3,s3,0x4
 87c:	34fd                	addiw	s1,s1,-1
 87e:	f4f5                	bnez	s1,86a <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 880:	8be6                	mv	s7,s9
      state = 0;
 882:	4981                	li	s3,0
 884:	6ca2                	ld	s9,8(sp)
 886:	bda5                	j	6fe <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 888:	008b8493          	addi	s1,s7,8
 88c:	000bc583          	lbu	a1,0(s7)
 890:	855a                	mv	a0,s6
 892:	d6dff0ef          	jal	5fe <putc>
 896:	8ba6                	mv	s7,s1
      state = 0;
 898:	4981                	li	s3,0
 89a:	b595                	j	6fe <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 89c:	008b8993          	addi	s3,s7,8
 8a0:	000bb483          	ld	s1,0(s7)
 8a4:	cc91                	beqz	s1,8c0 <vprintf+0x206>
        for(; *s; s++)
 8a6:	0004c583          	lbu	a1,0(s1)
 8aa:	c985                	beqz	a1,8da <vprintf+0x220>
          putc(fd, *s);
 8ac:	855a                	mv	a0,s6
 8ae:	d51ff0ef          	jal	5fe <putc>
        for(; *s; s++)
 8b2:	0485                	addi	s1,s1,1
 8b4:	0004c583          	lbu	a1,0(s1)
 8b8:	f9f5                	bnez	a1,8ac <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 8ba:	8bce                	mv	s7,s3
      state = 0;
 8bc:	4981                	li	s3,0
 8be:	b581                	j	6fe <vprintf+0x44>
          s = "(null)";
 8c0:	00000497          	auipc	s1,0x0
 8c4:	32048493          	addi	s1,s1,800 # be0 <malloc+0x184>
        for(; *s; s++)
 8c8:	02800593          	li	a1,40
 8cc:	b7c5                	j	8ac <vprintf+0x1f2>
        putc(fd, '%');
 8ce:	85be                	mv	a1,a5
 8d0:	855a                	mv	a0,s6
 8d2:	d2dff0ef          	jal	5fe <putc>
      state = 0;
 8d6:	4981                	li	s3,0
 8d8:	b51d                	j	6fe <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 8da:	8bce                	mv	s7,s3
      state = 0;
 8dc:	4981                	li	s3,0
 8de:	b505                	j	6fe <vprintf+0x44>
 8e0:	6906                	ld	s2,64(sp)
 8e2:	79e2                	ld	s3,56(sp)
 8e4:	7a42                	ld	s4,48(sp)
 8e6:	7aa2                	ld	s5,40(sp)
 8e8:	7b02                	ld	s6,32(sp)
 8ea:	6be2                	ld	s7,24(sp)
 8ec:	6c42                	ld	s8,16(sp)
    }
  }
}
 8ee:	60e6                	ld	ra,88(sp)
 8f0:	6446                	ld	s0,80(sp)
 8f2:	64a6                	ld	s1,72(sp)
 8f4:	6125                	addi	sp,sp,96
 8f6:	8082                	ret
      if(c0 == 'd'){
 8f8:	06400713          	li	a4,100
 8fc:	e4e78fe3          	beq	a5,a4,75a <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 900:	f9478693          	addi	a3,a5,-108
 904:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 908:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 90a:	4701                	li	a4,0
      } else if(c0 == 'u'){
 90c:	07500513          	li	a0,117
 910:	e8a78ce3          	beq	a5,a0,7a8 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 914:	f8b60513          	addi	a0,a2,-117
 918:	e119                	bnez	a0,91e <vprintf+0x264>
 91a:	ea0693e3          	bnez	a3,7c0 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 91e:	f8b58513          	addi	a0,a1,-117
 922:	e119                	bnez	a0,928 <vprintf+0x26e>
 924:	ea071be3          	bnez	a4,7da <vprintf+0x120>
      } else if(c0 == 'x'){
 928:	07800513          	li	a0,120
 92c:	eca784e3          	beq	a5,a0,7f4 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 930:	f8860613          	addi	a2,a2,-120
 934:	e219                	bnez	a2,93a <vprintf+0x280>
 936:	ec069be3          	bnez	a3,80c <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 93a:	f8858593          	addi	a1,a1,-120
 93e:	e199                	bnez	a1,944 <vprintf+0x28a>
 940:	ee0713e3          	bnez	a4,826 <vprintf+0x16c>
      } else if(c0 == 'p'){
 944:	07000713          	li	a4,112
 948:	eee78ce3          	beq	a5,a4,840 <vprintf+0x186>
      } else if(c0 == 'c'){
 94c:	06300713          	li	a4,99
 950:	f2e78ce3          	beq	a5,a4,888 <vprintf+0x1ce>
      } else if(c0 == 's'){
 954:	07300713          	li	a4,115
 958:	f4e782e3          	beq	a5,a4,89c <vprintf+0x1e2>
      } else if(c0 == '%'){
 95c:	02500713          	li	a4,37
 960:	f6e787e3          	beq	a5,a4,8ce <vprintf+0x214>
        putc(fd, '%');
 964:	02500593          	li	a1,37
 968:	855a                	mv	a0,s6
 96a:	c95ff0ef          	jal	5fe <putc>
        putc(fd, c0);
 96e:	85a6                	mv	a1,s1
 970:	855a                	mv	a0,s6
 972:	c8dff0ef          	jal	5fe <putc>
      state = 0;
 976:	4981                	li	s3,0
 978:	b359                	j	6fe <vprintf+0x44>

000000000000097a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 97a:	715d                	addi	sp,sp,-80
 97c:	ec06                	sd	ra,24(sp)
 97e:	e822                	sd	s0,16(sp)
 980:	1000                	addi	s0,sp,32
 982:	e010                	sd	a2,0(s0)
 984:	e414                	sd	a3,8(s0)
 986:	e818                	sd	a4,16(s0)
 988:	ec1c                	sd	a5,24(s0)
 98a:	03043023          	sd	a6,32(s0)
 98e:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 992:	8622                	mv	a2,s0
 994:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 998:	d23ff0ef          	jal	6ba <vprintf>
}
 99c:	60e2                	ld	ra,24(sp)
 99e:	6442                	ld	s0,16(sp)
 9a0:	6161                	addi	sp,sp,80
 9a2:	8082                	ret

00000000000009a4 <printf>:

void
printf(const char *fmt, ...)
{
 9a4:	711d                	addi	sp,sp,-96
 9a6:	ec06                	sd	ra,24(sp)
 9a8:	e822                	sd	s0,16(sp)
 9aa:	1000                	addi	s0,sp,32
 9ac:	e40c                	sd	a1,8(s0)
 9ae:	e810                	sd	a2,16(s0)
 9b0:	ec14                	sd	a3,24(s0)
 9b2:	f018                	sd	a4,32(s0)
 9b4:	f41c                	sd	a5,40(s0)
 9b6:	03043823          	sd	a6,48(s0)
 9ba:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 9be:	00840613          	addi	a2,s0,8
 9c2:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 9c6:	85aa                	mv	a1,a0
 9c8:	4505                	li	a0,1
 9ca:	cf1ff0ef          	jal	6ba <vprintf>
}
 9ce:	60e2                	ld	ra,24(sp)
 9d0:	6442                	ld	s0,16(sp)
 9d2:	6125                	addi	sp,sp,96
 9d4:	8082                	ret

00000000000009d6 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 9d6:	1141                	addi	sp,sp,-16
 9d8:	e406                	sd	ra,8(sp)
 9da:	e022                	sd	s0,0(sp)
 9dc:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 9de:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9e2:	00000797          	auipc	a5,0x0
 9e6:	61e7b783          	ld	a5,1566(a5) # 1000 <freep>
 9ea:	a039                	j	9f8 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9ec:	6398                	ld	a4,0(a5)
 9ee:	00e7e463          	bltu	a5,a4,9f6 <free+0x20>
 9f2:	00e6ea63          	bltu	a3,a4,a06 <free+0x30>
{
 9f6:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9f8:	fed7fae3          	bgeu	a5,a3,9ec <free+0x16>
 9fc:	6398                	ld	a4,0(a5)
 9fe:	00e6e463          	bltu	a3,a4,a06 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 a02:	fee7eae3          	bltu	a5,a4,9f6 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 a06:	ff852583          	lw	a1,-8(a0)
 a0a:	6390                	ld	a2,0(a5)
 a0c:	02059813          	slli	a6,a1,0x20
 a10:	01c85713          	srli	a4,a6,0x1c
 a14:	9736                	add	a4,a4,a3
 a16:	02e60563          	beq	a2,a4,a40 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 a1a:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 a1e:	4790                	lw	a2,8(a5)
 a20:	02061593          	slli	a1,a2,0x20
 a24:	01c5d713          	srli	a4,a1,0x1c
 a28:	973e                	add	a4,a4,a5
 a2a:	02e68263          	beq	a3,a4,a4e <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 a2e:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 a30:	00000717          	auipc	a4,0x0
 a34:	5cf73823          	sd	a5,1488(a4) # 1000 <freep>
}
 a38:	60a2                	ld	ra,8(sp)
 a3a:	6402                	ld	s0,0(sp)
 a3c:	0141                	addi	sp,sp,16
 a3e:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 a40:	4618                	lw	a4,8(a2)
 a42:	9f2d                	addw	a4,a4,a1
 a44:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 a48:	6398                	ld	a4,0(a5)
 a4a:	6310                	ld	a2,0(a4)
 a4c:	b7f9                	j	a1a <free+0x44>
    p->s.size += bp->s.size;
 a4e:	ff852703          	lw	a4,-8(a0)
 a52:	9f31                	addw	a4,a4,a2
 a54:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 a56:	ff053683          	ld	a3,-16(a0)
 a5a:	bfd1                	j	a2e <free+0x58>

0000000000000a5c <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 a5c:	7139                	addi	sp,sp,-64
 a5e:	fc06                	sd	ra,56(sp)
 a60:	f822                	sd	s0,48(sp)
 a62:	f04a                	sd	s2,32(sp)
 a64:	ec4e                	sd	s3,24(sp)
 a66:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a68:	02051993          	slli	s3,a0,0x20
 a6c:	0209d993          	srli	s3,s3,0x20
 a70:	09bd                	addi	s3,s3,15
 a72:	0049d993          	srli	s3,s3,0x4
 a76:	2985                	addiw	s3,s3,1
 a78:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 a7a:	00000517          	auipc	a0,0x0
 a7e:	58653503          	ld	a0,1414(a0) # 1000 <freep>
 a82:	c905                	beqz	a0,ab2 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a84:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a86:	4798                	lw	a4,8(a5)
 a88:	09377663          	bgeu	a4,s3,b14 <malloc+0xb8>
 a8c:	f426                	sd	s1,40(sp)
 a8e:	e852                	sd	s4,16(sp)
 a90:	e456                	sd	s5,8(sp)
 a92:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 a94:	8a4e                	mv	s4,s3
 a96:	6705                	lui	a4,0x1
 a98:	00e9f363          	bgeu	s3,a4,a9e <malloc+0x42>
 a9c:	6a05                	lui	s4,0x1
 a9e:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 aa2:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 aa6:	00000497          	auipc	s1,0x0
 aaa:	55a48493          	addi	s1,s1,1370 # 1000 <freep>
  if(p == SBRK_ERROR)
 aae:	5afd                	li	s5,-1
 ab0:	a83d                	j	aee <malloc+0x92>
 ab2:	f426                	sd	s1,40(sp)
 ab4:	e852                	sd	s4,16(sp)
 ab6:	e456                	sd	s5,8(sp)
 ab8:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 aba:	00000797          	auipc	a5,0x0
 abe:	55678793          	addi	a5,a5,1366 # 1010 <base>
 ac2:	00000717          	auipc	a4,0x0
 ac6:	52f73f23          	sd	a5,1342(a4) # 1000 <freep>
 aca:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 acc:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 ad0:	b7d1                	j	a94 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 ad2:	6398                	ld	a4,0(a5)
 ad4:	e118                	sd	a4,0(a0)
 ad6:	a899                	j	b2c <malloc+0xd0>
  hp->s.size = nu;
 ad8:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 adc:	0541                	addi	a0,a0,16
 ade:	ef9ff0ef          	jal	9d6 <free>
  return freep;
 ae2:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 ae4:	c125                	beqz	a0,b44 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ae6:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 ae8:	4798                	lw	a4,8(a5)
 aea:	03277163          	bgeu	a4,s2,b0c <malloc+0xb0>
    if(p == freep)
 aee:	6098                	ld	a4,0(s1)
 af0:	853e                	mv	a0,a5
 af2:	fef71ae3          	bne	a4,a5,ae6 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 af6:	8552                	mv	a0,s4
 af8:	a2bff0ef          	jal	522 <sbrk>
  if(p == SBRK_ERROR)
 afc:	fd551ee3          	bne	a0,s5,ad8 <malloc+0x7c>
        return 0;
 b00:	4501                	li	a0,0
 b02:	74a2                	ld	s1,40(sp)
 b04:	6a42                	ld	s4,16(sp)
 b06:	6aa2                	ld	s5,8(sp)
 b08:	6b02                	ld	s6,0(sp)
 b0a:	a03d                	j	b38 <malloc+0xdc>
 b0c:	74a2                	ld	s1,40(sp)
 b0e:	6a42                	ld	s4,16(sp)
 b10:	6aa2                	ld	s5,8(sp)
 b12:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 b14:	fae90fe3          	beq	s2,a4,ad2 <malloc+0x76>
        p->s.size -= nunits;
 b18:	4137073b          	subw	a4,a4,s3
 b1c:	c798                	sw	a4,8(a5)
        p += p->s.size;
 b1e:	02071693          	slli	a3,a4,0x20
 b22:	01c6d713          	srli	a4,a3,0x1c
 b26:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 b28:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 b2c:	00000717          	auipc	a4,0x0
 b30:	4ca73a23          	sd	a0,1236(a4) # 1000 <freep>
      return (void*)(p + 1);
 b34:	01078513          	addi	a0,a5,16
  }
}
 b38:	70e2                	ld	ra,56(sp)
 b3a:	7442                	ld	s0,48(sp)
 b3c:	7902                	ld	s2,32(sp)
 b3e:	69e2                	ld	s3,24(sp)
 b40:	6121                	addi	sp,sp,64
 b42:	8082                	ret
 b44:	74a2                	ld	s1,40(sp)
 b46:	6a42                	ld	s4,16(sp)
 b48:	6aa2                	ld	s5,8(sp)
 b4a:	6b02                	ld	s6,0(sp)
 b4c:	b7f5                	j	b38 <malloc+0xdc>
