
user/_find_variant:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <fmtname>:
#include "../kernel/param.h"
#include "user.h"


char* fmtname(char *path)
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	e426                	sd	s1,8(sp)
   8:	1000                	addi	s0,sp,32
   a:	84aa                	mv	s1,a0
  char *p;
  for(p=path+strlen(path); p >= path && *p != '/'; p--);
   c:	3b4000ef          	jal	3c0 <strlen>
  10:	1502                	slli	a0,a0,0x20
  12:	9101                	srli	a0,a0,0x20
  14:	9526                	add	a0,a0,s1
  16:	02f00713          	li	a4,47
  1a:	00956963          	bltu	a0,s1,2c <fmtname+0x2c>
  1e:	00054783          	lbu	a5,0(a0)
  22:	00e78563          	beq	a5,a4,2c <fmtname+0x2c>
  26:	157d                	addi	a0,a0,-1
  28:	fe957be3          	bgeu	a0,s1,1e <fmtname+0x1e>
  p++;
  return p;

}
  2c:	0505                	addi	a0,a0,1
  2e:	60e2                	ld	ra,24(sp)
  30:	6442                	ld	s0,16(sp)
  32:	64a2                	ld	s1,8(sp)
  34:	6105                	addi	sp,sp,32
  36:	8082                	ret

0000000000000038 <find>:


void find(char *path, char *filename, char *files[], int *i, int use_exec, char *exec_args[], int exec_argc)
{
  38:	d7010113          	addi	sp,sp,-656
  3c:	28113423          	sd	ra,648(sp)
  40:	28813023          	sd	s0,640(sp)
  44:	27313423          	sd	s3,616(sp)
  48:	27413023          	sd	s4,608(sp)
  4c:	25513c23          	sd	s5,600(sp)
  50:	25613823          	sd	s6,592(sp)
  54:	25713423          	sd	s7,584(sp)
  58:	25813023          	sd	s8,576(sp)
  5c:	23913c23          	sd	s9,568(sp)
  60:	0d00                	addi	s0,sp,656
  62:	8aaa                	mv	s5,a0
  64:	89ae                	mv	s3,a1
  66:	8c32                	mv	s8,a2
  68:	8b36                	mv	s6,a3
  6a:	8a3a                	mv	s4,a4
  6c:	8bbe                	mv	s7,a5
  6e:	8cc2                	mv	s9,a6
  char buf[512], *p;
  int fd;
  struct dirent de;
  struct stat st;
  
  if((fd = open(path, O_RDONLY)) < 0)
  70:	4581                	li	a1,0
  72:	5e4000ef          	jal	656 <open>
  76:	06054163          	bltz	a0,d8 <find+0xa0>
  7a:	26913c23          	sd	s1,632(sp)
  7e:	84aa                	mv	s1,a0
  {
    fprintf(2, "ls: cannot open %s\n", path);
    return;
  }
  
  if(fstat(fd, &st) < 0)
  80:	d7840593          	addi	a1,s0,-648
  84:	5ea000ef          	jal	66e <fstat>
  88:	06054163          	bltz	a0,ea <find+0xb2>
    fprintf(2, "ls: cannot stat %s\n", path);
    close(fd);
    return;
  }
  
  switch(st.type)
  8c:	d8041783          	lh	a5,-640(s0)
  90:	4705                	li	a4,1
  92:	0ee78563          	beq	a5,a4,17c <find+0x144>
  96:	37f9                	addiw	a5,a5,-2
  98:	17c2                	slli	a5,a5,0x30
  9a:	93c1                	srli	a5,a5,0x30
  9c:	18f76e63          	bltu	a4,a5,238 <find+0x200>
  a0:	27213823          	sd	s2,624(sp)
  {
    case T_DEVICE:
    case T_FILE:
    {
      if (!strcmp(fmtname(path), filename))
  a4:	8556                	mv	a0,s5
  a6:	f5bff0ef          	jal	0 <fmtname>
  aa:	85ce                	mv	a1,s3
  ac:	2e4000ef          	jal	390 <strcmp>
  b0:	18051263          	bnez	a0,234 <find+0x1fc>
      {
        if (use_exec)
  b4:	060a0a63          	beqz	s4,128 <find+0xf0>
        {
          exec_args[exec_argc] = path;
  b8:	003c9793          	slli	a5,s9,0x3
  bc:	97de                	add	a5,a5,s7
  be:	0157b023          	sd	s5,0(a5)
          exec_args[exec_argc + 1] = 0;
  c2:	0007b423          	sd	zero,8(a5)
          int c = fork();
  c6:	548000ef          	jal	60e <fork>
          if (c == 0)
  ca:	cd15                	beqz	a0,106 <find+0xce>
            fprintf(2, "find: exec %s failed\n", exec_args[0]);
            exit(1);
          }
          else 
          {
            wait(0);
  cc:	4501                	li	a0,0
  ce:	550000ef          	jal	61e <wait>
  d2:	27013903          	ld	s2,624(sp)
  d6:	a28d                	j	238 <find+0x200>
    fprintf(2, "ls: cannot open %s\n", path);
  d8:	8656                	mv	a2,s5
  da:	00001597          	auipc	a1,0x1
  de:	b3658593          	addi	a1,a1,-1226 # c10 <malloc+0xf4>
  e2:	4509                	li	a0,2
  e4:	157000ef          	jal	a3a <fprintf>
    return;
  e8:	aaa9                	j	242 <find+0x20a>
    fprintf(2, "ls: cannot stat %s\n", path);
  ea:	8656                	mv	a2,s5
  ec:	00001597          	auipc	a1,0x1
  f0:	b3c58593          	addi	a1,a1,-1220 # c28 <malloc+0x10c>
  f4:	4509                	li	a0,2
  f6:	145000ef          	jal	a3a <fprintf>
    close(fd);
  fa:	8526                	mv	a0,s1
  fc:	542000ef          	jal	63e <close>
    return;
 100:	27813483          	ld	s1,632(sp)
 104:	aa3d                	j	242 <find+0x20a>
            exec(exec_args[0], exec_args);
 106:	85de                	mv	a1,s7
 108:	000bb503          	ld	a0,0(s7)
 10c:	542000ef          	jal	64e <exec>
            fprintf(2, "find: exec %s failed\n", exec_args[0]);
 110:	000bb603          	ld	a2,0(s7)
 114:	00001597          	auipc	a1,0x1
 118:	b2c58593          	addi	a1,a1,-1236 # c40 <malloc+0x124>
 11c:	4509                	li	a0,2
 11e:	11d000ef          	jal	a3a <fprintf>
            exit(1);
 122:	4505                	li	a0,1
 124:	4f2000ef          	jal	616 <exit>
          }
        }
        else
        {
          int len = strlen(path) + 1;                    
 128:	8556                	mv	a0,s5
 12a:	296000ef          	jal	3c0 <strlen>
 12e:	2505                	addiw	a0,a0,1
 130:	8baa                	mv	s7,a0
          files[*i] = (char*)malloc(len);
 132:	000b2783          	lw	a5,0(s6)
 136:	078e                	slli	a5,a5,0x3
 138:	00fc0a33          	add	s4,s8,a5
 13c:	1e1000ef          	jal	b1c <malloc>
 140:	00aa3023          	sd	a0,0(s4)
          if (files[*i] == 0) 
 144:	000b2783          	lw	a5,0(s6)
 148:	078e                	slli	a5,a5,0x3
 14a:	97e2                	add	a5,a5,s8
 14c:	6388                	ld	a0,0(a5)
 14e:	cd09                	beqz	a0,168 <find+0x130>
          {
            fprintf(2, "find: malloc failed\n");
            break; 
          }
          memmove(files[*i], path, len);             
 150:	865e                	mv	a2,s7
 152:	85d6                	mv	a1,s5
 154:	3e4000ef          	jal	538 <memmove>
          (*i)++;
 158:	000b2783          	lw	a5,0(s6)
 15c:	2785                	addiw	a5,a5,1
 15e:	00fb2023          	sw	a5,0(s6)
 162:	27013903          	ld	s2,624(sp)
 166:	a8c9                	j	238 <find+0x200>
            fprintf(2, "find: malloc failed\n");
 168:	00001597          	auipc	a1,0x1
 16c:	af058593          	addi	a1,a1,-1296 # c58 <malloc+0x13c>
 170:	4509                	li	a0,2
 172:	0c9000ef          	jal	a3a <fprintf>
            break; 
 176:	27013903          	ld	s2,624(sp)
 17a:	a87d                	j	238 <find+0x200>
      }
      break;
    }
    case T_DIR:
    { 
      if(strlen(path) + 1 + DIRSIZ + 1 > sizeof buf){
 17c:	8556                	mv	a0,s5
 17e:	242000ef          	jal	3c0 <strlen>
 182:	2541                	addiw	a0,a0,16
 184:	20000793          	li	a5,512
 188:	00a7f963          	bgeu	a5,a0,19a <find+0x162>
        printf("ls: path too long\n");
 18c:	00001517          	auipc	a0,0x1
 190:	ae450513          	addi	a0,a0,-1308 # c70 <malloc+0x154>
 194:	0d1000ef          	jal	a64 <printf>
        break;
 198:	a045                	j	238 <find+0x200>
 19a:	27213823          	sd	s2,624(sp)
      }
      strcpy(buf, path);
 19e:	85d6                	mv	a1,s5
 1a0:	da040513          	addi	a0,s0,-608
 1a4:	1cc000ef          	jal	370 <strcpy>
      p = buf + strlen(buf);
 1a8:	da040513          	addi	a0,s0,-608
 1ac:	214000ef          	jal	3c0 <strlen>
 1b0:	1502                	slli	a0,a0,0x20
 1b2:	9101                	srli	a0,a0,0x20
 1b4:	da040793          	addi	a5,s0,-608
 1b8:	00a78733          	add	a4,a5,a0
 1bc:	893a                	mv	s2,a4
      *p++ = '/';
 1be:	00170793          	addi	a5,a4,1
 1c2:	8abe                	mv	s5,a5
 1c4:	02f00793          	li	a5,47
 1c8:	00f70023          	sb	a5,0(a4)
      while(read(fd, &de, sizeof(de)) == sizeof(de))
 1cc:	4641                	li	a2,16
 1ce:	d9040593          	addi	a1,s0,-624
 1d2:	8526                	mv	a0,s1
 1d4:	45a000ef          	jal	62e <read>
 1d8:	47c1                	li	a5,16
 1da:	04f51a63          	bne	a0,a5,22e <find+0x1f6>
      {
        if(de.inum == 0)
 1de:	d9045783          	lhu	a5,-624(s0)
 1e2:	d7ed                	beqz	a5,1cc <find+0x194>
          continue;
        
        memmove(p, de.name, DIRSIZ);
 1e4:	4639                	li	a2,14
 1e6:	d9240593          	addi	a1,s0,-622
 1ea:	8556                	mv	a0,s5
 1ec:	34c000ef          	jal	538 <memmove>
        p[DIRSIZ] = 0;
 1f0:	000907a3          	sb	zero,15(s2)
        
        if(!strcmp(de.name, ".") || !strcmp(de.name, ".."))
 1f4:	00001597          	auipc	a1,0x1
 1f8:	a9458593          	addi	a1,a1,-1388 # c88 <malloc+0x16c>
 1fc:	d9240513          	addi	a0,s0,-622
 200:	190000ef          	jal	390 <strcmp>
 204:	d561                	beqz	a0,1cc <find+0x194>
 206:	00001597          	auipc	a1,0x1
 20a:	a8a58593          	addi	a1,a1,-1398 # c90 <malloc+0x174>
 20e:	d9240513          	addi	a0,s0,-622
 212:	17e000ef          	jal	390 <strcmp>
 216:	d95d                	beqz	a0,1cc <find+0x194>
            continue;
        
        find(buf, filename, files, i, use_exec, exec_args, exec_argc);
 218:	8866                	mv	a6,s9
 21a:	87de                	mv	a5,s7
 21c:	8752                	mv	a4,s4
 21e:	86da                	mv	a3,s6
 220:	8662                	mv	a2,s8
 222:	85ce                	mv	a1,s3
 224:	da040513          	addi	a0,s0,-608
 228:	e11ff0ef          	jal	38 <find>
 22c:	b745                	j	1cc <find+0x194>
 22e:	27013903          	ld	s2,624(sp)
 232:	a019                	j	238 <find+0x200>
 234:	27013903          	ld	s2,624(sp)
      }
      break;

    }
  }
  close(fd);
 238:	8526                	mv	a0,s1
 23a:	404000ef          	jal	63e <close>
 23e:	27813483          	ld	s1,632(sp)
}
 242:	28813083          	ld	ra,648(sp)
 246:	28013403          	ld	s0,640(sp)
 24a:	26813983          	ld	s3,616(sp)
 24e:	26013a03          	ld	s4,608(sp)
 252:	25813a83          	ld	s5,600(sp)
 256:	25013b03          	ld	s6,592(sp)
 25a:	24813b83          	ld	s7,584(sp)
 25e:	24013c03          	ld	s8,576(sp)
 262:	23813c83          	ld	s9,568(sp)
 266:	29010113          	addi	sp,sp,656
 26a:	8082                	ret

000000000000026c <main>:




int main(int argc, char *argv[])
{
 26c:	ba010113          	addi	sp,sp,-1120
 270:	44113c23          	sd	ra,1112(sp)
 274:	44813823          	sd	s0,1104(sp)
 278:	46010413          	addi	s0,sp,1120
  if(argc < 3)
 27c:	4789                	li	a5,2
 27e:	06a7d963          	bge	a5,a0,2f0 <main+0x84>
 282:	44913423          	sd	s1,1096(sp)
 286:	45213023          	sd	s2,1088(sp)
 28a:	43313c23          	sd	s3,1080(sp)
 28e:	43413823          	sd	s4,1072(sp)
 292:	84ae                	mv	s1,a1
  char *exec_args[MAXARG];
  int exec_argc = 0;
  int use_exec = 0;
  char **p;
  
  if (argc >= 5 && !strcmp(argv[3], "-exec"))
 294:	4791                	li	a5,4
  int use_exec = 0;
 296:	4701                	li	a4,0
  int exec_argc = 0;
 298:	4801                	li	a6,0
  if (argc >= 5 && !strcmp(argv[3], "-exec"))
 29a:	06a7cd63          	blt	a5,a0,314 <main+0xa8>
    exec_args[exec_argc] = 0;
  }
 
  
  char *found_files[100];
  int file_index = 0;
 29e:	ba042623          	sw	zero,-1108(s0)
      
  find(argv[1], argv[2], found_files, &file_index, use_exec, exec_args, exec_argc);
 2a2:	ed040793          	addi	a5,s0,-304
 2a6:	bac40693          	addi	a3,s0,-1108
 2aa:	bb040613          	addi	a2,s0,-1104
 2ae:	688c                	ld	a1,16(s1)
 2b0:	6488                	ld	a0,8(s1)
 2b2:	d87ff0ef          	jal	38 <find>
  
  for (int j = 0; j < file_index; j++) 
 2b6:	bac42783          	lw	a5,-1108(s0)
 2ba:	02f05863          	blez	a5,2ea <main+0x7e>
 2be:	bb040493          	addi	s1,s0,-1104
 2c2:	4901                	li	s2,0
  {
      fprintf(1, "%s\n", found_files[j]);
 2c4:	00001a17          	auipc	s4,0x1
 2c8:	95ca0a13          	addi	s4,s4,-1700 # c20 <malloc+0x104>
 2cc:	4985                	li	s3,1
 2ce:	6090                	ld	a2,0(s1)
 2d0:	85d2                	mv	a1,s4
 2d2:	854e                	mv	a0,s3
 2d4:	766000ef          	jal	a3a <fprintf>
      free(found_files[j]); 
 2d8:	6088                	ld	a0,0(s1)
 2da:	7bc000ef          	jal	a96 <free>
  for (int j = 0; j < file_index; j++) 
 2de:	2905                	addiw	s2,s2,1
 2e0:	04a1                	addi	s1,s1,8
 2e2:	bac42783          	lw	a5,-1108(s0)
 2e6:	fef944e3          	blt	s2,a5,2ce <main+0x62>
  }
  
  exit(0);
 2ea:	4501                	li	a0,0
 2ec:	32a000ef          	jal	616 <exit>
 2f0:	44913423          	sd	s1,1096(sp)
 2f4:	45213023          	sd	s2,1088(sp)
 2f8:	43313c23          	sd	s3,1080(sp)
 2fc:	43413823          	sd	s4,1072(sp)
    fprintf(2, "Usage: find <path> <filename>\n");
 300:	00001597          	auipc	a1,0x1
 304:	99858593          	addi	a1,a1,-1640 # c98 <malloc+0x17c>
 308:	853e                	mv	a0,a5
 30a:	730000ef          	jal	a3a <fprintf>
    exit(1);
 30e:	4505                	li	a0,1
 310:	306000ef          	jal	616 <exit>
  if (argc >= 5 && !strcmp(argv[3], "-exec"))
 314:	00001597          	auipc	a1,0x1
 318:	9a458593          	addi	a1,a1,-1628 # cb8 <malloc+0x19c>
 31c:	6c88                	ld	a0,24(s1)
 31e:	072000ef          	jal	390 <strcmp>
 322:	882a                	mv	a6,a0
 324:	e91d                	bnez	a0,35a <main+0xee>
    while(*p && exec_argc < MAXARG - 1)
 326:	7098                	ld	a4,32(s1)
 328:	c305                	beqz	a4,348 <main+0xdc>
    p = argv + 4; // move after -exec
 32a:	02048613          	addi	a2,s1,32
 32e:	ed040693          	addi	a3,s0,-304
      exec_args[exec_argc++] = *p;
 332:	0018079b          	addiw	a5,a6,1
 336:	883e                	mv	a6,a5
 338:	e298                	sd	a4,0(a3)
      p++;
 33a:	0621                	addi	a2,a2,8
    while(*p && exec_argc < MAXARG - 1)
 33c:	6218                	ld	a4,0(a2)
 33e:	06a1                	addi	a3,a3,8
 340:	01f7a793          	slti	a5,a5,31
 344:	c391                	beqz	a5,348 <main+0xdc>
 346:	f775                	bnez	a4,332 <main+0xc6>
    exec_args[exec_argc] = 0;
 348:	00381793          	slli	a5,a6,0x3
 34c:	fd078793          	addi	a5,a5,-48
 350:	97a2                	add	a5,a5,s0
 352:	f007b023          	sd	zero,-256(a5)
    use_exec = 1;
 356:	4705                	li	a4,1
 358:	b799                	j	29e <main+0x32>
  int use_exec = 0;
 35a:	4701                	li	a4,0
  int exec_argc = 0;
 35c:	4801                	li	a6,0
 35e:	b781                	j	29e <main+0x32>

0000000000000360 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
 360:	1141                	addi	sp,sp,-16
 362:	e406                	sd	ra,8(sp)
 364:	e022                	sd	s0,0(sp)
 366:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
 368:	f05ff0ef          	jal	26c <main>
  exit(r);
 36c:	2aa000ef          	jal	616 <exit>

0000000000000370 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 370:	1141                	addi	sp,sp,-16
 372:	e406                	sd	ra,8(sp)
 374:	e022                	sd	s0,0(sp)
 376:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 378:	87aa                	mv	a5,a0
 37a:	0585                	addi	a1,a1,1
 37c:	0785                	addi	a5,a5,1
 37e:	fff5c703          	lbu	a4,-1(a1)
 382:	fee78fa3          	sb	a4,-1(a5)
 386:	fb75                	bnez	a4,37a <strcpy+0xa>
    ;
  return os;
}
 388:	60a2                	ld	ra,8(sp)
 38a:	6402                	ld	s0,0(sp)
 38c:	0141                	addi	sp,sp,16
 38e:	8082                	ret

0000000000000390 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 390:	1141                	addi	sp,sp,-16
 392:	e406                	sd	ra,8(sp)
 394:	e022                	sd	s0,0(sp)
 396:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 398:	00054783          	lbu	a5,0(a0)
 39c:	cb91                	beqz	a5,3b0 <strcmp+0x20>
 39e:	0005c703          	lbu	a4,0(a1)
 3a2:	00f71763          	bne	a4,a5,3b0 <strcmp+0x20>
    p++, q++;
 3a6:	0505                	addi	a0,a0,1
 3a8:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 3aa:	00054783          	lbu	a5,0(a0)
 3ae:	fbe5                	bnez	a5,39e <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 3b0:	0005c503          	lbu	a0,0(a1)
}
 3b4:	40a7853b          	subw	a0,a5,a0
 3b8:	60a2                	ld	ra,8(sp)
 3ba:	6402                	ld	s0,0(sp)
 3bc:	0141                	addi	sp,sp,16
 3be:	8082                	ret

00000000000003c0 <strlen>:

uint
strlen(const char *s)
{
 3c0:	1141                	addi	sp,sp,-16
 3c2:	e406                	sd	ra,8(sp)
 3c4:	e022                	sd	s0,0(sp)
 3c6:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 3c8:	00054783          	lbu	a5,0(a0)
 3cc:	cf91                	beqz	a5,3e8 <strlen+0x28>
 3ce:	00150793          	addi	a5,a0,1
 3d2:	86be                	mv	a3,a5
 3d4:	0785                	addi	a5,a5,1
 3d6:	fff7c703          	lbu	a4,-1(a5)
 3da:	ff65                	bnez	a4,3d2 <strlen+0x12>
 3dc:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 3e0:	60a2                	ld	ra,8(sp)
 3e2:	6402                	ld	s0,0(sp)
 3e4:	0141                	addi	sp,sp,16
 3e6:	8082                	ret
  for(n = 0; s[n]; n++)
 3e8:	4501                	li	a0,0
 3ea:	bfdd                	j	3e0 <strlen+0x20>

00000000000003ec <memset>:

void*
memset(void *dst, int c, uint n)
{
 3ec:	1141                	addi	sp,sp,-16
 3ee:	e406                	sd	ra,8(sp)
 3f0:	e022                	sd	s0,0(sp)
 3f2:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 3f4:	ca19                	beqz	a2,40a <memset+0x1e>
 3f6:	87aa                	mv	a5,a0
 3f8:	1602                	slli	a2,a2,0x20
 3fa:	9201                	srli	a2,a2,0x20
 3fc:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 400:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 404:	0785                	addi	a5,a5,1
 406:	fee79de3          	bne	a5,a4,400 <memset+0x14>
  }
  return dst;
}
 40a:	60a2                	ld	ra,8(sp)
 40c:	6402                	ld	s0,0(sp)
 40e:	0141                	addi	sp,sp,16
 410:	8082                	ret

0000000000000412 <strchr>:

char*
strchr(const char *s, char c)
{
 412:	1141                	addi	sp,sp,-16
 414:	e406                	sd	ra,8(sp)
 416:	e022                	sd	s0,0(sp)
 418:	0800                	addi	s0,sp,16
  for(; *s; s++)
 41a:	00054783          	lbu	a5,0(a0)
 41e:	cf81                	beqz	a5,436 <strchr+0x24>
    if(*s == c)
 420:	00f58763          	beq	a1,a5,42e <strchr+0x1c>
  for(; *s; s++)
 424:	0505                	addi	a0,a0,1
 426:	00054783          	lbu	a5,0(a0)
 42a:	fbfd                	bnez	a5,420 <strchr+0xe>
      return (char*)s;
  return 0;
 42c:	4501                	li	a0,0
}
 42e:	60a2                	ld	ra,8(sp)
 430:	6402                	ld	s0,0(sp)
 432:	0141                	addi	sp,sp,16
 434:	8082                	ret
  return 0;
 436:	4501                	li	a0,0
 438:	bfdd                	j	42e <strchr+0x1c>

000000000000043a <gets>:

char*
gets(char *buf, int max)
{
 43a:	711d                	addi	sp,sp,-96
 43c:	ec86                	sd	ra,88(sp)
 43e:	e8a2                	sd	s0,80(sp)
 440:	e4a6                	sd	s1,72(sp)
 442:	e0ca                	sd	s2,64(sp)
 444:	fc4e                	sd	s3,56(sp)
 446:	f852                	sd	s4,48(sp)
 448:	f456                	sd	s5,40(sp)
 44a:	f05a                	sd	s6,32(sp)
 44c:	ec5e                	sd	s7,24(sp)
 44e:	e862                	sd	s8,16(sp)
 450:	1080                	addi	s0,sp,96
 452:	8baa                	mv	s7,a0
 454:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 456:	892a                	mv	s2,a0
 458:	4481                	li	s1,0
    cc = read(0, &c, 1);
 45a:	faf40b13          	addi	s6,s0,-81
 45e:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 460:	8c26                	mv	s8,s1
 462:	0014899b          	addiw	s3,s1,1
 466:	84ce                	mv	s1,s3
 468:	0349d463          	bge	s3,s4,490 <gets+0x56>
    cc = read(0, &c, 1);
 46c:	8656                	mv	a2,s5
 46e:	85da                	mv	a1,s6
 470:	4501                	li	a0,0
 472:	1bc000ef          	jal	62e <read>
    if(cc < 1)
 476:	00a05d63          	blez	a0,490 <gets+0x56>
      break;
    buf[i++] = c;
 47a:	faf44783          	lbu	a5,-81(s0)
 47e:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 482:	0905                	addi	s2,s2,1
 484:	ff678713          	addi	a4,a5,-10
 488:	c319                	beqz	a4,48e <gets+0x54>
 48a:	17cd                	addi	a5,a5,-13
 48c:	fbf1                	bnez	a5,460 <gets+0x26>
    buf[i++] = c;
 48e:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 490:	9c5e                	add	s8,s8,s7
 492:	000c0023          	sb	zero,0(s8)
  return buf;
}
 496:	855e                	mv	a0,s7
 498:	60e6                	ld	ra,88(sp)
 49a:	6446                	ld	s0,80(sp)
 49c:	64a6                	ld	s1,72(sp)
 49e:	6906                	ld	s2,64(sp)
 4a0:	79e2                	ld	s3,56(sp)
 4a2:	7a42                	ld	s4,48(sp)
 4a4:	7aa2                	ld	s5,40(sp)
 4a6:	7b02                	ld	s6,32(sp)
 4a8:	6be2                	ld	s7,24(sp)
 4aa:	6c42                	ld	s8,16(sp)
 4ac:	6125                	addi	sp,sp,96
 4ae:	8082                	ret

00000000000004b0 <stat>:

int
stat(const char *n, struct stat *st)
{
 4b0:	1101                	addi	sp,sp,-32
 4b2:	ec06                	sd	ra,24(sp)
 4b4:	e822                	sd	s0,16(sp)
 4b6:	e04a                	sd	s2,0(sp)
 4b8:	1000                	addi	s0,sp,32
 4ba:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 4bc:	4581                	li	a1,0
 4be:	198000ef          	jal	656 <open>
  if(fd < 0)
 4c2:	02054263          	bltz	a0,4e6 <stat+0x36>
 4c6:	e426                	sd	s1,8(sp)
 4c8:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 4ca:	85ca                	mv	a1,s2
 4cc:	1a2000ef          	jal	66e <fstat>
 4d0:	892a                	mv	s2,a0
  close(fd);
 4d2:	8526                	mv	a0,s1
 4d4:	16a000ef          	jal	63e <close>
  return r;
 4d8:	64a2                	ld	s1,8(sp)
}
 4da:	854a                	mv	a0,s2
 4dc:	60e2                	ld	ra,24(sp)
 4de:	6442                	ld	s0,16(sp)
 4e0:	6902                	ld	s2,0(sp)
 4e2:	6105                	addi	sp,sp,32
 4e4:	8082                	ret
    return -1;
 4e6:	57fd                	li	a5,-1
 4e8:	893e                	mv	s2,a5
 4ea:	bfc5                	j	4da <stat+0x2a>

00000000000004ec <atoi>:

int
atoi(const char *s)
{
 4ec:	1141                	addi	sp,sp,-16
 4ee:	e406                	sd	ra,8(sp)
 4f0:	e022                	sd	s0,0(sp)
 4f2:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 4f4:	00054683          	lbu	a3,0(a0)
 4f8:	fd06879b          	addiw	a5,a3,-48
 4fc:	0ff7f793          	zext.b	a5,a5
 500:	4625                	li	a2,9
 502:	02f66963          	bltu	a2,a5,534 <atoi+0x48>
 506:	872a                	mv	a4,a0
  n = 0;
 508:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 50a:	0705                	addi	a4,a4,1
 50c:	0025179b          	slliw	a5,a0,0x2
 510:	9fa9                	addw	a5,a5,a0
 512:	0017979b          	slliw	a5,a5,0x1
 516:	9fb5                	addw	a5,a5,a3
 518:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 51c:	00074683          	lbu	a3,0(a4)
 520:	fd06879b          	addiw	a5,a3,-48
 524:	0ff7f793          	zext.b	a5,a5
 528:	fef671e3          	bgeu	a2,a5,50a <atoi+0x1e>
  return n;
}
 52c:	60a2                	ld	ra,8(sp)
 52e:	6402                	ld	s0,0(sp)
 530:	0141                	addi	sp,sp,16
 532:	8082                	ret
  n = 0;
 534:	4501                	li	a0,0
 536:	bfdd                	j	52c <atoi+0x40>

0000000000000538 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 538:	1141                	addi	sp,sp,-16
 53a:	e406                	sd	ra,8(sp)
 53c:	e022                	sd	s0,0(sp)
 53e:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 540:	02b57563          	bgeu	a0,a1,56a <memmove+0x32>
    while(n-- > 0)
 544:	00c05f63          	blez	a2,562 <memmove+0x2a>
 548:	1602                	slli	a2,a2,0x20
 54a:	9201                	srli	a2,a2,0x20
 54c:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 550:	872a                	mv	a4,a0
      *dst++ = *src++;
 552:	0585                	addi	a1,a1,1
 554:	0705                	addi	a4,a4,1
 556:	fff5c683          	lbu	a3,-1(a1)
 55a:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 55e:	fee79ae3          	bne	a5,a4,552 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 562:	60a2                	ld	ra,8(sp)
 564:	6402                	ld	s0,0(sp)
 566:	0141                	addi	sp,sp,16
 568:	8082                	ret
    while(n-- > 0)
 56a:	fec05ce3          	blez	a2,562 <memmove+0x2a>
    dst += n;
 56e:	00c50733          	add	a4,a0,a2
    src += n;
 572:	95b2                	add	a1,a1,a2
 574:	fff6079b          	addiw	a5,a2,-1
 578:	1782                	slli	a5,a5,0x20
 57a:	9381                	srli	a5,a5,0x20
 57c:	fff7c793          	not	a5,a5
 580:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 582:	15fd                	addi	a1,a1,-1
 584:	177d                	addi	a4,a4,-1
 586:	0005c683          	lbu	a3,0(a1)
 58a:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 58e:	fef71ae3          	bne	a4,a5,582 <memmove+0x4a>
 592:	bfc1                	j	562 <memmove+0x2a>

0000000000000594 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 594:	1141                	addi	sp,sp,-16
 596:	e406                	sd	ra,8(sp)
 598:	e022                	sd	s0,0(sp)
 59a:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 59c:	c61d                	beqz	a2,5ca <memcmp+0x36>
 59e:	1602                	slli	a2,a2,0x20
 5a0:	9201                	srli	a2,a2,0x20
 5a2:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 5a6:	00054783          	lbu	a5,0(a0)
 5aa:	0005c703          	lbu	a4,0(a1)
 5ae:	00e79863          	bne	a5,a4,5be <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 5b2:	0505                	addi	a0,a0,1
    p2++;
 5b4:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 5b6:	fed518e3          	bne	a0,a3,5a6 <memcmp+0x12>
  }
  return 0;
 5ba:	4501                	li	a0,0
 5bc:	a019                	j	5c2 <memcmp+0x2e>
      return *p1 - *p2;
 5be:	40e7853b          	subw	a0,a5,a4
}
 5c2:	60a2                	ld	ra,8(sp)
 5c4:	6402                	ld	s0,0(sp)
 5c6:	0141                	addi	sp,sp,16
 5c8:	8082                	ret
  return 0;
 5ca:	4501                	li	a0,0
 5cc:	bfdd                	j	5c2 <memcmp+0x2e>

00000000000005ce <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 5ce:	1141                	addi	sp,sp,-16
 5d0:	e406                	sd	ra,8(sp)
 5d2:	e022                	sd	s0,0(sp)
 5d4:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 5d6:	f63ff0ef          	jal	538 <memmove>
}
 5da:	60a2                	ld	ra,8(sp)
 5dc:	6402                	ld	s0,0(sp)
 5de:	0141                	addi	sp,sp,16
 5e0:	8082                	ret

00000000000005e2 <sbrk>:

char *
sbrk(int n) {
 5e2:	1141                	addi	sp,sp,-16
 5e4:	e406                	sd	ra,8(sp)
 5e6:	e022                	sd	s0,0(sp)
 5e8:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 5ea:	4585                	li	a1,1
 5ec:	0b2000ef          	jal	69e <sys_sbrk>
}
 5f0:	60a2                	ld	ra,8(sp)
 5f2:	6402                	ld	s0,0(sp)
 5f4:	0141                	addi	sp,sp,16
 5f6:	8082                	ret

00000000000005f8 <sbrklazy>:

char *
sbrklazy(int n) {
 5f8:	1141                	addi	sp,sp,-16
 5fa:	e406                	sd	ra,8(sp)
 5fc:	e022                	sd	s0,0(sp)
 5fe:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 600:	4589                	li	a1,2
 602:	09c000ef          	jal	69e <sys_sbrk>
}
 606:	60a2                	ld	ra,8(sp)
 608:	6402                	ld	s0,0(sp)
 60a:	0141                	addi	sp,sp,16
 60c:	8082                	ret

000000000000060e <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 60e:	4885                	li	a7,1
 ecall
 610:	00000073          	ecall
 ret
 614:	8082                	ret

0000000000000616 <exit>:
.global exit
exit:
 li a7, SYS_exit
 616:	4889                	li	a7,2
 ecall
 618:	00000073          	ecall
 ret
 61c:	8082                	ret

000000000000061e <wait>:
.global wait
wait:
 li a7, SYS_wait
 61e:	488d                	li	a7,3
 ecall
 620:	00000073          	ecall
 ret
 624:	8082                	ret

0000000000000626 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 626:	4891                	li	a7,4
 ecall
 628:	00000073          	ecall
 ret
 62c:	8082                	ret

000000000000062e <read>:
.global read
read:
 li a7, SYS_read
 62e:	4895                	li	a7,5
 ecall
 630:	00000073          	ecall
 ret
 634:	8082                	ret

0000000000000636 <write>:
.global write
write:
 li a7, SYS_write
 636:	48c1                	li	a7,16
 ecall
 638:	00000073          	ecall
 ret
 63c:	8082                	ret

000000000000063e <close>:
.global close
close:
 li a7, SYS_close
 63e:	48d5                	li	a7,21
 ecall
 640:	00000073          	ecall
 ret
 644:	8082                	ret

0000000000000646 <kill>:
.global kill
kill:
 li a7, SYS_kill
 646:	4899                	li	a7,6
 ecall
 648:	00000073          	ecall
 ret
 64c:	8082                	ret

000000000000064e <exec>:
.global exec
exec:
 li a7, SYS_exec
 64e:	489d                	li	a7,7
 ecall
 650:	00000073          	ecall
 ret
 654:	8082                	ret

0000000000000656 <open>:
.global open
open:
 li a7, SYS_open
 656:	48bd                	li	a7,15
 ecall
 658:	00000073          	ecall
 ret
 65c:	8082                	ret

000000000000065e <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 65e:	48c5                	li	a7,17
 ecall
 660:	00000073          	ecall
 ret
 664:	8082                	ret

0000000000000666 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 666:	48c9                	li	a7,18
 ecall
 668:	00000073          	ecall
 ret
 66c:	8082                	ret

000000000000066e <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 66e:	48a1                	li	a7,8
 ecall
 670:	00000073          	ecall
 ret
 674:	8082                	ret

0000000000000676 <link>:
.global link
link:
 li a7, SYS_link
 676:	48cd                	li	a7,19
 ecall
 678:	00000073          	ecall
 ret
 67c:	8082                	ret

000000000000067e <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 67e:	48d1                	li	a7,20
 ecall
 680:	00000073          	ecall
 ret
 684:	8082                	ret

0000000000000686 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 686:	48a5                	li	a7,9
 ecall
 688:	00000073          	ecall
 ret
 68c:	8082                	ret

000000000000068e <dup>:
.global dup
dup:
 li a7, SYS_dup
 68e:	48a9                	li	a7,10
 ecall
 690:	00000073          	ecall
 ret
 694:	8082                	ret

0000000000000696 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 696:	48ad                	li	a7,11
 ecall
 698:	00000073          	ecall
 ret
 69c:	8082                	ret

000000000000069e <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 69e:	48b1                	li	a7,12
 ecall
 6a0:	00000073          	ecall
 ret
 6a4:	8082                	ret

00000000000006a6 <pause>:
.global pause
pause:
 li a7, SYS_pause
 6a6:	48b5                	li	a7,13
 ecall
 6a8:	00000073          	ecall
 ret
 6ac:	8082                	ret

00000000000006ae <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 6ae:	48b9                	li	a7,14
 ecall
 6b0:	00000073          	ecall
 ret
 6b4:	8082                	ret

00000000000006b6 <kmemfree>:
.global kmemfree
kmemfree:
 li a7, SYS_kmemfree
 6b6:	48d9                	li	a7,22
 ecall
 6b8:	00000073          	ecall
 ret
 6bc:	8082                	ret

00000000000006be <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 6be:	1101                	addi	sp,sp,-32
 6c0:	ec06                	sd	ra,24(sp)
 6c2:	e822                	sd	s0,16(sp)
 6c4:	1000                	addi	s0,sp,32
 6c6:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 6ca:	4605                	li	a2,1
 6cc:	fef40593          	addi	a1,s0,-17
 6d0:	f67ff0ef          	jal	636 <write>
}
 6d4:	60e2                	ld	ra,24(sp)
 6d6:	6442                	ld	s0,16(sp)
 6d8:	6105                	addi	sp,sp,32
 6da:	8082                	ret

00000000000006dc <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 6dc:	715d                	addi	sp,sp,-80
 6de:	e486                	sd	ra,72(sp)
 6e0:	e0a2                	sd	s0,64(sp)
 6e2:	f84a                	sd	s2,48(sp)
 6e4:	f44e                	sd	s3,40(sp)
 6e6:	0880                	addi	s0,sp,80
 6e8:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 6ea:	c6d1                	beqz	a3,776 <printint+0x9a>
 6ec:	0805d563          	bgez	a1,776 <printint+0x9a>
    neg = 1;
    x = -xx;
 6f0:	40b005b3          	neg	a1,a1
    neg = 1;
 6f4:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 6f6:	fb840993          	addi	s3,s0,-72
  neg = 0;
 6fa:	86ce                	mv	a3,s3
  i = 0;
 6fc:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 6fe:	00000817          	auipc	a6,0x0
 702:	5ca80813          	addi	a6,a6,1482 # cc8 <digits>
 706:	88ba                	mv	a7,a4
 708:	0017051b          	addiw	a0,a4,1
 70c:	872a                	mv	a4,a0
 70e:	02c5f7b3          	remu	a5,a1,a2
 712:	97c2                	add	a5,a5,a6
 714:	0007c783          	lbu	a5,0(a5)
 718:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 71c:	87ae                	mv	a5,a1
 71e:	02c5d5b3          	divu	a1,a1,a2
 722:	0685                	addi	a3,a3,1
 724:	fec7f1e3          	bgeu	a5,a2,706 <printint+0x2a>
  if(neg)
 728:	00030c63          	beqz	t1,740 <printint+0x64>
    buf[i++] = '-';
 72c:	fd050793          	addi	a5,a0,-48
 730:	00878533          	add	a0,a5,s0
 734:	02d00793          	li	a5,45
 738:	fef50423          	sb	a5,-24(a0)
 73c:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 740:	02e05563          	blez	a4,76a <printint+0x8e>
 744:	fc26                	sd	s1,56(sp)
 746:	377d                	addiw	a4,a4,-1
 748:	00e984b3          	add	s1,s3,a4
 74c:	19fd                	addi	s3,s3,-1
 74e:	99ba                	add	s3,s3,a4
 750:	1702                	slli	a4,a4,0x20
 752:	9301                	srli	a4,a4,0x20
 754:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 758:	0004c583          	lbu	a1,0(s1)
 75c:	854a                	mv	a0,s2
 75e:	f61ff0ef          	jal	6be <putc>
  while(--i >= 0)
 762:	14fd                	addi	s1,s1,-1
 764:	ff349ae3          	bne	s1,s3,758 <printint+0x7c>
 768:	74e2                	ld	s1,56(sp)
}
 76a:	60a6                	ld	ra,72(sp)
 76c:	6406                	ld	s0,64(sp)
 76e:	7942                	ld	s2,48(sp)
 770:	79a2                	ld	s3,40(sp)
 772:	6161                	addi	sp,sp,80
 774:	8082                	ret
  neg = 0;
 776:	4301                	li	t1,0
 778:	bfbd                	j	6f6 <printint+0x1a>

000000000000077a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 77a:	711d                	addi	sp,sp,-96
 77c:	ec86                	sd	ra,88(sp)
 77e:	e8a2                	sd	s0,80(sp)
 780:	e4a6                	sd	s1,72(sp)
 782:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 784:	0005c483          	lbu	s1,0(a1)
 788:	22048363          	beqz	s1,9ae <vprintf+0x234>
 78c:	e0ca                	sd	s2,64(sp)
 78e:	fc4e                	sd	s3,56(sp)
 790:	f852                	sd	s4,48(sp)
 792:	f456                	sd	s5,40(sp)
 794:	f05a                	sd	s6,32(sp)
 796:	ec5e                	sd	s7,24(sp)
 798:	e862                	sd	s8,16(sp)
 79a:	8b2a                	mv	s6,a0
 79c:	8a2e                	mv	s4,a1
 79e:	8bb2                	mv	s7,a2
  state = 0;
 7a0:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 7a2:	4901                	li	s2,0
 7a4:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 7a6:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 7aa:	06400c13          	li	s8,100
 7ae:	a00d                	j	7d0 <vprintf+0x56>
        putc(fd, c0);
 7b0:	85a6                	mv	a1,s1
 7b2:	855a                	mv	a0,s6
 7b4:	f0bff0ef          	jal	6be <putc>
 7b8:	a019                	j	7be <vprintf+0x44>
    } else if(state == '%'){
 7ba:	03598363          	beq	s3,s5,7e0 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 7be:	0019079b          	addiw	a5,s2,1
 7c2:	893e                	mv	s2,a5
 7c4:	873e                	mv	a4,a5
 7c6:	97d2                	add	a5,a5,s4
 7c8:	0007c483          	lbu	s1,0(a5)
 7cc:	1c048a63          	beqz	s1,9a0 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 7d0:	0004879b          	sext.w	a5,s1
    if(state == 0){
 7d4:	fe0993e3          	bnez	s3,7ba <vprintf+0x40>
      if(c0 == '%'){
 7d8:	fd579ce3          	bne	a5,s5,7b0 <vprintf+0x36>
        state = '%';
 7dc:	89be                	mv	s3,a5
 7de:	b7c5                	j	7be <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 7e0:	00ea06b3          	add	a3,s4,a4
 7e4:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 7e8:	1c060863          	beqz	a2,9b8 <vprintf+0x23e>
      if(c0 == 'd'){
 7ec:	03878763          	beq	a5,s8,81a <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 7f0:	f9478693          	addi	a3,a5,-108
 7f4:	0016b693          	seqz	a3,a3
 7f8:	f9c60593          	addi	a1,a2,-100
 7fc:	e99d                	bnez	a1,832 <vprintf+0xb8>
 7fe:	ca95                	beqz	a3,832 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 800:	008b8493          	addi	s1,s7,8
 804:	4685                	li	a3,1
 806:	4629                	li	a2,10
 808:	000bb583          	ld	a1,0(s7)
 80c:	855a                	mv	a0,s6
 80e:	ecfff0ef          	jal	6dc <printint>
        i += 1;
 812:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 814:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 816:	4981                	li	s3,0
 818:	b75d                	j	7be <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 81a:	008b8493          	addi	s1,s7,8
 81e:	4685                	li	a3,1
 820:	4629                	li	a2,10
 822:	000ba583          	lw	a1,0(s7)
 826:	855a                	mv	a0,s6
 828:	eb5ff0ef          	jal	6dc <printint>
 82c:	8ba6                	mv	s7,s1
      state = 0;
 82e:	4981                	li	s3,0
 830:	b779                	j	7be <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 832:	9752                	add	a4,a4,s4
 834:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 838:	f9460713          	addi	a4,a2,-108
 83c:	00173713          	seqz	a4,a4
 840:	8f75                	and	a4,a4,a3
 842:	f9c58513          	addi	a0,a1,-100
 846:	18051363          	bnez	a0,9cc <vprintf+0x252>
 84a:	18070163          	beqz	a4,9cc <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 84e:	008b8493          	addi	s1,s7,8
 852:	4685                	li	a3,1
 854:	4629                	li	a2,10
 856:	000bb583          	ld	a1,0(s7)
 85a:	855a                	mv	a0,s6
 85c:	e81ff0ef          	jal	6dc <printint>
        i += 2;
 860:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 862:	8ba6                	mv	s7,s1
      state = 0;
 864:	4981                	li	s3,0
        i += 2;
 866:	bfa1                	j	7be <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 868:	008b8493          	addi	s1,s7,8
 86c:	4681                	li	a3,0
 86e:	4629                	li	a2,10
 870:	000be583          	lwu	a1,0(s7)
 874:	855a                	mv	a0,s6
 876:	e67ff0ef          	jal	6dc <printint>
 87a:	8ba6                	mv	s7,s1
      state = 0;
 87c:	4981                	li	s3,0
 87e:	b781                	j	7be <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 880:	008b8493          	addi	s1,s7,8
 884:	4681                	li	a3,0
 886:	4629                	li	a2,10
 888:	000bb583          	ld	a1,0(s7)
 88c:	855a                	mv	a0,s6
 88e:	e4fff0ef          	jal	6dc <printint>
        i += 1;
 892:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 894:	8ba6                	mv	s7,s1
      state = 0;
 896:	4981                	li	s3,0
 898:	b71d                	j	7be <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 89a:	008b8493          	addi	s1,s7,8
 89e:	4681                	li	a3,0
 8a0:	4629                	li	a2,10
 8a2:	000bb583          	ld	a1,0(s7)
 8a6:	855a                	mv	a0,s6
 8a8:	e35ff0ef          	jal	6dc <printint>
        i += 2;
 8ac:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 8ae:	8ba6                	mv	s7,s1
      state = 0;
 8b0:	4981                	li	s3,0
        i += 2;
 8b2:	b731                	j	7be <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 8b4:	008b8493          	addi	s1,s7,8
 8b8:	4681                	li	a3,0
 8ba:	4641                	li	a2,16
 8bc:	000be583          	lwu	a1,0(s7)
 8c0:	855a                	mv	a0,s6
 8c2:	e1bff0ef          	jal	6dc <printint>
 8c6:	8ba6                	mv	s7,s1
      state = 0;
 8c8:	4981                	li	s3,0
 8ca:	bdd5                	j	7be <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 8cc:	008b8493          	addi	s1,s7,8
 8d0:	4681                	li	a3,0
 8d2:	4641                	li	a2,16
 8d4:	000bb583          	ld	a1,0(s7)
 8d8:	855a                	mv	a0,s6
 8da:	e03ff0ef          	jal	6dc <printint>
        i += 1;
 8de:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 8e0:	8ba6                	mv	s7,s1
      state = 0;
 8e2:	4981                	li	s3,0
 8e4:	bde9                	j	7be <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 8e6:	008b8493          	addi	s1,s7,8
 8ea:	4681                	li	a3,0
 8ec:	4641                	li	a2,16
 8ee:	000bb583          	ld	a1,0(s7)
 8f2:	855a                	mv	a0,s6
 8f4:	de9ff0ef          	jal	6dc <printint>
        i += 2;
 8f8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 8fa:	8ba6                	mv	s7,s1
      state = 0;
 8fc:	4981                	li	s3,0
        i += 2;
 8fe:	b5c1                	j	7be <vprintf+0x44>
 900:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 902:	008b8793          	addi	a5,s7,8
 906:	8cbe                	mv	s9,a5
 908:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 90c:	03000593          	li	a1,48
 910:	855a                	mv	a0,s6
 912:	dadff0ef          	jal	6be <putc>
  putc(fd, 'x');
 916:	07800593          	li	a1,120
 91a:	855a                	mv	a0,s6
 91c:	da3ff0ef          	jal	6be <putc>
 920:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 922:	00000b97          	auipc	s7,0x0
 926:	3a6b8b93          	addi	s7,s7,934 # cc8 <digits>
 92a:	03c9d793          	srli	a5,s3,0x3c
 92e:	97de                	add	a5,a5,s7
 930:	0007c583          	lbu	a1,0(a5)
 934:	855a                	mv	a0,s6
 936:	d89ff0ef          	jal	6be <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 93a:	0992                	slli	s3,s3,0x4
 93c:	34fd                	addiw	s1,s1,-1
 93e:	f4f5                	bnez	s1,92a <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 940:	8be6                	mv	s7,s9
      state = 0;
 942:	4981                	li	s3,0
 944:	6ca2                	ld	s9,8(sp)
 946:	bda5                	j	7be <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 948:	008b8493          	addi	s1,s7,8
 94c:	000bc583          	lbu	a1,0(s7)
 950:	855a                	mv	a0,s6
 952:	d6dff0ef          	jal	6be <putc>
 956:	8ba6                	mv	s7,s1
      state = 0;
 958:	4981                	li	s3,0
 95a:	b595                	j	7be <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 95c:	008b8993          	addi	s3,s7,8
 960:	000bb483          	ld	s1,0(s7)
 964:	cc91                	beqz	s1,980 <vprintf+0x206>
        for(; *s; s++)
 966:	0004c583          	lbu	a1,0(s1)
 96a:	c985                	beqz	a1,99a <vprintf+0x220>
          putc(fd, *s);
 96c:	855a                	mv	a0,s6
 96e:	d51ff0ef          	jal	6be <putc>
        for(; *s; s++)
 972:	0485                	addi	s1,s1,1
 974:	0004c583          	lbu	a1,0(s1)
 978:	f9f5                	bnez	a1,96c <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 97a:	8bce                	mv	s7,s3
      state = 0;
 97c:	4981                	li	s3,0
 97e:	b581                	j	7be <vprintf+0x44>
          s = "(null)";
 980:	00000497          	auipc	s1,0x0
 984:	34048493          	addi	s1,s1,832 # cc0 <malloc+0x1a4>
        for(; *s; s++)
 988:	02800593          	li	a1,40
 98c:	b7c5                	j	96c <vprintf+0x1f2>
        putc(fd, '%');
 98e:	85be                	mv	a1,a5
 990:	855a                	mv	a0,s6
 992:	d2dff0ef          	jal	6be <putc>
      state = 0;
 996:	4981                	li	s3,0
 998:	b51d                	j	7be <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 99a:	8bce                	mv	s7,s3
      state = 0;
 99c:	4981                	li	s3,0
 99e:	b505                	j	7be <vprintf+0x44>
 9a0:	6906                	ld	s2,64(sp)
 9a2:	79e2                	ld	s3,56(sp)
 9a4:	7a42                	ld	s4,48(sp)
 9a6:	7aa2                	ld	s5,40(sp)
 9a8:	7b02                	ld	s6,32(sp)
 9aa:	6be2                	ld	s7,24(sp)
 9ac:	6c42                	ld	s8,16(sp)
    }
  }
}
 9ae:	60e6                	ld	ra,88(sp)
 9b0:	6446                	ld	s0,80(sp)
 9b2:	64a6                	ld	s1,72(sp)
 9b4:	6125                	addi	sp,sp,96
 9b6:	8082                	ret
      if(c0 == 'd'){
 9b8:	06400713          	li	a4,100
 9bc:	e4e78fe3          	beq	a5,a4,81a <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 9c0:	f9478693          	addi	a3,a5,-108
 9c4:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 9c8:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 9ca:	4701                	li	a4,0
      } else if(c0 == 'u'){
 9cc:	07500513          	li	a0,117
 9d0:	e8a78ce3          	beq	a5,a0,868 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 9d4:	f8b60513          	addi	a0,a2,-117
 9d8:	e119                	bnez	a0,9de <vprintf+0x264>
 9da:	ea0693e3          	bnez	a3,880 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 9de:	f8b58513          	addi	a0,a1,-117
 9e2:	e119                	bnez	a0,9e8 <vprintf+0x26e>
 9e4:	ea071be3          	bnez	a4,89a <vprintf+0x120>
      } else if(c0 == 'x'){
 9e8:	07800513          	li	a0,120
 9ec:	eca784e3          	beq	a5,a0,8b4 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 9f0:	f8860613          	addi	a2,a2,-120
 9f4:	e219                	bnez	a2,9fa <vprintf+0x280>
 9f6:	ec069be3          	bnez	a3,8cc <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 9fa:	f8858593          	addi	a1,a1,-120
 9fe:	e199                	bnez	a1,a04 <vprintf+0x28a>
 a00:	ee0713e3          	bnez	a4,8e6 <vprintf+0x16c>
      } else if(c0 == 'p'){
 a04:	07000713          	li	a4,112
 a08:	eee78ce3          	beq	a5,a4,900 <vprintf+0x186>
      } else if(c0 == 'c'){
 a0c:	06300713          	li	a4,99
 a10:	f2e78ce3          	beq	a5,a4,948 <vprintf+0x1ce>
      } else if(c0 == 's'){
 a14:	07300713          	li	a4,115
 a18:	f4e782e3          	beq	a5,a4,95c <vprintf+0x1e2>
      } else if(c0 == '%'){
 a1c:	02500713          	li	a4,37
 a20:	f6e787e3          	beq	a5,a4,98e <vprintf+0x214>
        putc(fd, '%');
 a24:	02500593          	li	a1,37
 a28:	855a                	mv	a0,s6
 a2a:	c95ff0ef          	jal	6be <putc>
        putc(fd, c0);
 a2e:	85a6                	mv	a1,s1
 a30:	855a                	mv	a0,s6
 a32:	c8dff0ef          	jal	6be <putc>
      state = 0;
 a36:	4981                	li	s3,0
 a38:	b359                	j	7be <vprintf+0x44>

0000000000000a3a <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 a3a:	715d                	addi	sp,sp,-80
 a3c:	ec06                	sd	ra,24(sp)
 a3e:	e822                	sd	s0,16(sp)
 a40:	1000                	addi	s0,sp,32
 a42:	e010                	sd	a2,0(s0)
 a44:	e414                	sd	a3,8(s0)
 a46:	e818                	sd	a4,16(s0)
 a48:	ec1c                	sd	a5,24(s0)
 a4a:	03043023          	sd	a6,32(s0)
 a4e:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 a52:	8622                	mv	a2,s0
 a54:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 a58:	d23ff0ef          	jal	77a <vprintf>
}
 a5c:	60e2                	ld	ra,24(sp)
 a5e:	6442                	ld	s0,16(sp)
 a60:	6161                	addi	sp,sp,80
 a62:	8082                	ret

0000000000000a64 <printf>:

void
printf(const char *fmt, ...)
{
 a64:	711d                	addi	sp,sp,-96
 a66:	ec06                	sd	ra,24(sp)
 a68:	e822                	sd	s0,16(sp)
 a6a:	1000                	addi	s0,sp,32
 a6c:	e40c                	sd	a1,8(s0)
 a6e:	e810                	sd	a2,16(s0)
 a70:	ec14                	sd	a3,24(s0)
 a72:	f018                	sd	a4,32(s0)
 a74:	f41c                	sd	a5,40(s0)
 a76:	03043823          	sd	a6,48(s0)
 a7a:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 a7e:	00840613          	addi	a2,s0,8
 a82:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 a86:	85aa                	mv	a1,a0
 a88:	4505                	li	a0,1
 a8a:	cf1ff0ef          	jal	77a <vprintf>
}
 a8e:	60e2                	ld	ra,24(sp)
 a90:	6442                	ld	s0,16(sp)
 a92:	6125                	addi	sp,sp,96
 a94:	8082                	ret

0000000000000a96 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 a96:	1141                	addi	sp,sp,-16
 a98:	e406                	sd	ra,8(sp)
 a9a:	e022                	sd	s0,0(sp)
 a9c:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 a9e:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 aa2:	00000797          	auipc	a5,0x0
 aa6:	55e7b783          	ld	a5,1374(a5) # 1000 <freep>
 aaa:	a039                	j	ab8 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 aac:	6398                	ld	a4,0(a5)
 aae:	00e7e463          	bltu	a5,a4,ab6 <free+0x20>
 ab2:	00e6ea63          	bltu	a3,a4,ac6 <free+0x30>
{
 ab6:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 ab8:	fed7fae3          	bgeu	a5,a3,aac <free+0x16>
 abc:	6398                	ld	a4,0(a5)
 abe:	00e6e463          	bltu	a3,a4,ac6 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 ac2:	fee7eae3          	bltu	a5,a4,ab6 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 ac6:	ff852583          	lw	a1,-8(a0)
 aca:	6390                	ld	a2,0(a5)
 acc:	02059813          	slli	a6,a1,0x20
 ad0:	01c85713          	srli	a4,a6,0x1c
 ad4:	9736                	add	a4,a4,a3
 ad6:	02e60563          	beq	a2,a4,b00 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 ada:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 ade:	4790                	lw	a2,8(a5)
 ae0:	02061593          	slli	a1,a2,0x20
 ae4:	01c5d713          	srli	a4,a1,0x1c
 ae8:	973e                	add	a4,a4,a5
 aea:	02e68263          	beq	a3,a4,b0e <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 aee:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 af0:	00000717          	auipc	a4,0x0
 af4:	50f73823          	sd	a5,1296(a4) # 1000 <freep>
}
 af8:	60a2                	ld	ra,8(sp)
 afa:	6402                	ld	s0,0(sp)
 afc:	0141                	addi	sp,sp,16
 afe:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 b00:	4618                	lw	a4,8(a2)
 b02:	9f2d                	addw	a4,a4,a1
 b04:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 b08:	6398                	ld	a4,0(a5)
 b0a:	6310                	ld	a2,0(a4)
 b0c:	b7f9                	j	ada <free+0x44>
    p->s.size += bp->s.size;
 b0e:	ff852703          	lw	a4,-8(a0)
 b12:	9f31                	addw	a4,a4,a2
 b14:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 b16:	ff053683          	ld	a3,-16(a0)
 b1a:	bfd1                	j	aee <free+0x58>

0000000000000b1c <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 b1c:	7139                	addi	sp,sp,-64
 b1e:	fc06                	sd	ra,56(sp)
 b20:	f822                	sd	s0,48(sp)
 b22:	f04a                	sd	s2,32(sp)
 b24:	ec4e                	sd	s3,24(sp)
 b26:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 b28:	02051993          	slli	s3,a0,0x20
 b2c:	0209d993          	srli	s3,s3,0x20
 b30:	09bd                	addi	s3,s3,15
 b32:	0049d993          	srli	s3,s3,0x4
 b36:	2985                	addiw	s3,s3,1
 b38:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 b3a:	00000517          	auipc	a0,0x0
 b3e:	4c653503          	ld	a0,1222(a0) # 1000 <freep>
 b42:	c905                	beqz	a0,b72 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b44:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b46:	4798                	lw	a4,8(a5)
 b48:	09377663          	bgeu	a4,s3,bd4 <malloc+0xb8>
 b4c:	f426                	sd	s1,40(sp)
 b4e:	e852                	sd	s4,16(sp)
 b50:	e456                	sd	s5,8(sp)
 b52:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 b54:	8a4e                	mv	s4,s3
 b56:	6705                	lui	a4,0x1
 b58:	00e9f363          	bgeu	s3,a4,b5e <malloc+0x42>
 b5c:	6a05                	lui	s4,0x1
 b5e:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 b62:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 b66:	00000497          	auipc	s1,0x0
 b6a:	49a48493          	addi	s1,s1,1178 # 1000 <freep>
  if(p == SBRK_ERROR)
 b6e:	5afd                	li	s5,-1
 b70:	a83d                	j	bae <malloc+0x92>
 b72:	f426                	sd	s1,40(sp)
 b74:	e852                	sd	s4,16(sp)
 b76:	e456                	sd	s5,8(sp)
 b78:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 b7a:	00000797          	auipc	a5,0x0
 b7e:	49678793          	addi	a5,a5,1174 # 1010 <base>
 b82:	00000717          	auipc	a4,0x0
 b86:	46f73f23          	sd	a5,1150(a4) # 1000 <freep>
 b8a:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 b8c:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 b90:	b7d1                	j	b54 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 b92:	6398                	ld	a4,0(a5)
 b94:	e118                	sd	a4,0(a0)
 b96:	a899                	j	bec <malloc+0xd0>
  hp->s.size = nu;
 b98:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 b9c:	0541                	addi	a0,a0,16
 b9e:	ef9ff0ef          	jal	a96 <free>
  return freep;
 ba2:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 ba4:	c125                	beqz	a0,c04 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ba6:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 ba8:	4798                	lw	a4,8(a5)
 baa:	03277163          	bgeu	a4,s2,bcc <malloc+0xb0>
    if(p == freep)
 bae:	6098                	ld	a4,0(s1)
 bb0:	853e                	mv	a0,a5
 bb2:	fef71ae3          	bne	a4,a5,ba6 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 bb6:	8552                	mv	a0,s4
 bb8:	a2bff0ef          	jal	5e2 <sbrk>
  if(p == SBRK_ERROR)
 bbc:	fd551ee3          	bne	a0,s5,b98 <malloc+0x7c>
        return 0;
 bc0:	4501                	li	a0,0
 bc2:	74a2                	ld	s1,40(sp)
 bc4:	6a42                	ld	s4,16(sp)
 bc6:	6aa2                	ld	s5,8(sp)
 bc8:	6b02                	ld	s6,0(sp)
 bca:	a03d                	j	bf8 <malloc+0xdc>
 bcc:	74a2                	ld	s1,40(sp)
 bce:	6a42                	ld	s4,16(sp)
 bd0:	6aa2                	ld	s5,8(sp)
 bd2:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 bd4:	fae90fe3          	beq	s2,a4,b92 <malloc+0x76>
        p->s.size -= nunits;
 bd8:	4137073b          	subw	a4,a4,s3
 bdc:	c798                	sw	a4,8(a5)
        p += p->s.size;
 bde:	02071693          	slli	a3,a4,0x20
 be2:	01c6d713          	srli	a4,a3,0x1c
 be6:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 be8:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 bec:	00000717          	auipc	a4,0x0
 bf0:	40a73a23          	sd	a0,1044(a4) # 1000 <freep>
      return (void*)(p + 1);
 bf4:	01078513          	addi	a0,a5,16
  }
}
 bf8:	70e2                	ld	ra,56(sp)
 bfa:	7442                	ld	s0,48(sp)
 bfc:	7902                	ld	s2,32(sp)
 bfe:	69e2                	ld	s3,24(sp)
 c00:	6121                	addi	sp,sp,64
 c02:	8082                	ret
 c04:	74a2                	ld	s1,40(sp)
 c06:	6a42                	ld	s4,16(sp)
 c08:	6aa2                	ld	s5,8(sp)
 c0a:	6b02                	ld	s6,0(sp)
 c0c:	b7f5                	j	bf8 <malloc+0xdc>
