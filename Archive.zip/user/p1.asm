
user/_p1:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main()
{
   0:	1141                	addi	sp,sp,-16
   2:	e406                	sd	ra,8(sp)
   4:	e022                	sd	s0,0(sp)
   6:	0800                	addi	s0,sp,16
  int free = kmemfree();
   8:	372000ef          	jal	37a <kmemfree>
   c:	85aa                	mv	a1,a0

  printf("Total free memory: %d\n", free);
   e:	00001517          	auipc	a0,0x1
  12:	8d250513          	addi	a0,a0,-1838 # 8e0 <malloc+0x100>
  16:	712000ef          	jal	728 <printf>

}
  1a:	4501                	li	a0,0
  1c:	60a2                	ld	ra,8(sp)
  1e:	6402                	ld	s0,0(sp)
  20:	0141                	addi	sp,sp,16
  22:	8082                	ret

0000000000000024 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
  24:	1141                	addi	sp,sp,-16
  26:	e406                	sd	ra,8(sp)
  28:	e022                	sd	s0,0(sp)
  2a:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
  2c:	fd5ff0ef          	jal	0 <main>
  exit(r);
  30:	2aa000ef          	jal	2da <exit>

0000000000000034 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  34:	1141                	addi	sp,sp,-16
  36:	e406                	sd	ra,8(sp)
  38:	e022                	sd	s0,0(sp)
  3a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  3c:	87aa                	mv	a5,a0
  3e:	0585                	addi	a1,a1,1
  40:	0785                	addi	a5,a5,1
  42:	fff5c703          	lbu	a4,-1(a1)
  46:	fee78fa3          	sb	a4,-1(a5)
  4a:	fb75                	bnez	a4,3e <strcpy+0xa>
    ;
  return os;
}
  4c:	60a2                	ld	ra,8(sp)
  4e:	6402                	ld	s0,0(sp)
  50:	0141                	addi	sp,sp,16
  52:	8082                	ret

0000000000000054 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  54:	1141                	addi	sp,sp,-16
  56:	e406                	sd	ra,8(sp)
  58:	e022                	sd	s0,0(sp)
  5a:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  5c:	00054783          	lbu	a5,0(a0)
  60:	cb91                	beqz	a5,74 <strcmp+0x20>
  62:	0005c703          	lbu	a4,0(a1)
  66:	00f71763          	bne	a4,a5,74 <strcmp+0x20>
    p++, q++;
  6a:	0505                	addi	a0,a0,1
  6c:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
  6e:	00054783          	lbu	a5,0(a0)
  72:	fbe5                	bnez	a5,62 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
  74:	0005c503          	lbu	a0,0(a1)
}
  78:	40a7853b          	subw	a0,a5,a0
  7c:	60a2                	ld	ra,8(sp)
  7e:	6402                	ld	s0,0(sp)
  80:	0141                	addi	sp,sp,16
  82:	8082                	ret

0000000000000084 <strlen>:

uint
strlen(const char *s)
{
  84:	1141                	addi	sp,sp,-16
  86:	e406                	sd	ra,8(sp)
  88:	e022                	sd	s0,0(sp)
  8a:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
  8c:	00054783          	lbu	a5,0(a0)
  90:	cf91                	beqz	a5,ac <strlen+0x28>
  92:	00150793          	addi	a5,a0,1
  96:	86be                	mv	a3,a5
  98:	0785                	addi	a5,a5,1
  9a:	fff7c703          	lbu	a4,-1(a5)
  9e:	ff65                	bnez	a4,96 <strlen+0x12>
  a0:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
  a4:	60a2                	ld	ra,8(sp)
  a6:	6402                	ld	s0,0(sp)
  a8:	0141                	addi	sp,sp,16
  aa:	8082                	ret
  for(n = 0; s[n]; n++)
  ac:	4501                	li	a0,0
  ae:	bfdd                	j	a4 <strlen+0x20>

00000000000000b0 <memset>:

void*
memset(void *dst, int c, uint n)
{
  b0:	1141                	addi	sp,sp,-16
  b2:	e406                	sd	ra,8(sp)
  b4:	e022                	sd	s0,0(sp)
  b6:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
  b8:	ca19                	beqz	a2,ce <memset+0x1e>
  ba:	87aa                	mv	a5,a0
  bc:	1602                	slli	a2,a2,0x20
  be:	9201                	srli	a2,a2,0x20
  c0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
  c4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
  c8:	0785                	addi	a5,a5,1
  ca:	fee79de3          	bne	a5,a4,c4 <memset+0x14>
  }
  return dst;
}
  ce:	60a2                	ld	ra,8(sp)
  d0:	6402                	ld	s0,0(sp)
  d2:	0141                	addi	sp,sp,16
  d4:	8082                	ret

00000000000000d6 <strchr>:

char*
strchr(const char *s, char c)
{
  d6:	1141                	addi	sp,sp,-16
  d8:	e406                	sd	ra,8(sp)
  da:	e022                	sd	s0,0(sp)
  dc:	0800                	addi	s0,sp,16
  for(; *s; s++)
  de:	00054783          	lbu	a5,0(a0)
  e2:	cf81                	beqz	a5,fa <strchr+0x24>
    if(*s == c)
  e4:	00f58763          	beq	a1,a5,f2 <strchr+0x1c>
  for(; *s; s++)
  e8:	0505                	addi	a0,a0,1
  ea:	00054783          	lbu	a5,0(a0)
  ee:	fbfd                	bnez	a5,e4 <strchr+0xe>
      return (char*)s;
  return 0;
  f0:	4501                	li	a0,0
}
  f2:	60a2                	ld	ra,8(sp)
  f4:	6402                	ld	s0,0(sp)
  f6:	0141                	addi	sp,sp,16
  f8:	8082                	ret
  return 0;
  fa:	4501                	li	a0,0
  fc:	bfdd                	j	f2 <strchr+0x1c>

00000000000000fe <gets>:

char*
gets(char *buf, int max)
{
  fe:	711d                	addi	sp,sp,-96
 100:	ec86                	sd	ra,88(sp)
 102:	e8a2                	sd	s0,80(sp)
 104:	e4a6                	sd	s1,72(sp)
 106:	e0ca                	sd	s2,64(sp)
 108:	fc4e                	sd	s3,56(sp)
 10a:	f852                	sd	s4,48(sp)
 10c:	f456                	sd	s5,40(sp)
 10e:	f05a                	sd	s6,32(sp)
 110:	ec5e                	sd	s7,24(sp)
 112:	e862                	sd	s8,16(sp)
 114:	1080                	addi	s0,sp,96
 116:	8baa                	mv	s7,a0
 118:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 11a:	892a                	mv	s2,a0
 11c:	4481                	li	s1,0
    cc = read(0, &c, 1);
 11e:	faf40b13          	addi	s6,s0,-81
 122:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 124:	8c26                	mv	s8,s1
 126:	0014899b          	addiw	s3,s1,1
 12a:	84ce                	mv	s1,s3
 12c:	0349d463          	bge	s3,s4,154 <gets+0x56>
    cc = read(0, &c, 1);
 130:	8656                	mv	a2,s5
 132:	85da                	mv	a1,s6
 134:	4501                	li	a0,0
 136:	1bc000ef          	jal	2f2 <read>
    if(cc < 1)
 13a:	00a05d63          	blez	a0,154 <gets+0x56>
      break;
    buf[i++] = c;
 13e:	faf44783          	lbu	a5,-81(s0)
 142:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 146:	0905                	addi	s2,s2,1
 148:	ff678713          	addi	a4,a5,-10
 14c:	c319                	beqz	a4,152 <gets+0x54>
 14e:	17cd                	addi	a5,a5,-13
 150:	fbf1                	bnez	a5,124 <gets+0x26>
    buf[i++] = c;
 152:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 154:	9c5e                	add	s8,s8,s7
 156:	000c0023          	sb	zero,0(s8)
  return buf;
}
 15a:	855e                	mv	a0,s7
 15c:	60e6                	ld	ra,88(sp)
 15e:	6446                	ld	s0,80(sp)
 160:	64a6                	ld	s1,72(sp)
 162:	6906                	ld	s2,64(sp)
 164:	79e2                	ld	s3,56(sp)
 166:	7a42                	ld	s4,48(sp)
 168:	7aa2                	ld	s5,40(sp)
 16a:	7b02                	ld	s6,32(sp)
 16c:	6be2                	ld	s7,24(sp)
 16e:	6c42                	ld	s8,16(sp)
 170:	6125                	addi	sp,sp,96
 172:	8082                	ret

0000000000000174 <stat>:

int
stat(const char *n, struct stat *st)
{
 174:	1101                	addi	sp,sp,-32
 176:	ec06                	sd	ra,24(sp)
 178:	e822                	sd	s0,16(sp)
 17a:	e04a                	sd	s2,0(sp)
 17c:	1000                	addi	s0,sp,32
 17e:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 180:	4581                	li	a1,0
 182:	198000ef          	jal	31a <open>
  if(fd < 0)
 186:	02054263          	bltz	a0,1aa <stat+0x36>
 18a:	e426                	sd	s1,8(sp)
 18c:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 18e:	85ca                	mv	a1,s2
 190:	1a2000ef          	jal	332 <fstat>
 194:	892a                	mv	s2,a0
  close(fd);
 196:	8526                	mv	a0,s1
 198:	16a000ef          	jal	302 <close>
  return r;
 19c:	64a2                	ld	s1,8(sp)
}
 19e:	854a                	mv	a0,s2
 1a0:	60e2                	ld	ra,24(sp)
 1a2:	6442                	ld	s0,16(sp)
 1a4:	6902                	ld	s2,0(sp)
 1a6:	6105                	addi	sp,sp,32
 1a8:	8082                	ret
    return -1;
 1aa:	57fd                	li	a5,-1
 1ac:	893e                	mv	s2,a5
 1ae:	bfc5                	j	19e <stat+0x2a>

00000000000001b0 <atoi>:

int
atoi(const char *s)
{
 1b0:	1141                	addi	sp,sp,-16
 1b2:	e406                	sd	ra,8(sp)
 1b4:	e022                	sd	s0,0(sp)
 1b6:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 1b8:	00054683          	lbu	a3,0(a0)
 1bc:	fd06879b          	addiw	a5,a3,-48
 1c0:	0ff7f793          	zext.b	a5,a5
 1c4:	4625                	li	a2,9
 1c6:	02f66963          	bltu	a2,a5,1f8 <atoi+0x48>
 1ca:	872a                	mv	a4,a0
  n = 0;
 1cc:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 1ce:	0705                	addi	a4,a4,1
 1d0:	0025179b          	slliw	a5,a0,0x2
 1d4:	9fa9                	addw	a5,a5,a0
 1d6:	0017979b          	slliw	a5,a5,0x1
 1da:	9fb5                	addw	a5,a5,a3
 1dc:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 1e0:	00074683          	lbu	a3,0(a4)
 1e4:	fd06879b          	addiw	a5,a3,-48
 1e8:	0ff7f793          	zext.b	a5,a5
 1ec:	fef671e3          	bgeu	a2,a5,1ce <atoi+0x1e>
  return n;
}
 1f0:	60a2                	ld	ra,8(sp)
 1f2:	6402                	ld	s0,0(sp)
 1f4:	0141                	addi	sp,sp,16
 1f6:	8082                	ret
  n = 0;
 1f8:	4501                	li	a0,0
 1fa:	bfdd                	j	1f0 <atoi+0x40>

00000000000001fc <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 1fc:	1141                	addi	sp,sp,-16
 1fe:	e406                	sd	ra,8(sp)
 200:	e022                	sd	s0,0(sp)
 202:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 204:	02b57563          	bgeu	a0,a1,22e <memmove+0x32>
    while(n-- > 0)
 208:	00c05f63          	blez	a2,226 <memmove+0x2a>
 20c:	1602                	slli	a2,a2,0x20
 20e:	9201                	srli	a2,a2,0x20
 210:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 214:	872a                	mv	a4,a0
      *dst++ = *src++;
 216:	0585                	addi	a1,a1,1
 218:	0705                	addi	a4,a4,1
 21a:	fff5c683          	lbu	a3,-1(a1)
 21e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 222:	fee79ae3          	bne	a5,a4,216 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 226:	60a2                	ld	ra,8(sp)
 228:	6402                	ld	s0,0(sp)
 22a:	0141                	addi	sp,sp,16
 22c:	8082                	ret
    while(n-- > 0)
 22e:	fec05ce3          	blez	a2,226 <memmove+0x2a>
    dst += n;
 232:	00c50733          	add	a4,a0,a2
    src += n;
 236:	95b2                	add	a1,a1,a2
 238:	fff6079b          	addiw	a5,a2,-1
 23c:	1782                	slli	a5,a5,0x20
 23e:	9381                	srli	a5,a5,0x20
 240:	fff7c793          	not	a5,a5
 244:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 246:	15fd                	addi	a1,a1,-1
 248:	177d                	addi	a4,a4,-1
 24a:	0005c683          	lbu	a3,0(a1)
 24e:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 252:	fef71ae3          	bne	a4,a5,246 <memmove+0x4a>
 256:	bfc1                	j	226 <memmove+0x2a>

0000000000000258 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 258:	1141                	addi	sp,sp,-16
 25a:	e406                	sd	ra,8(sp)
 25c:	e022                	sd	s0,0(sp)
 25e:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 260:	c61d                	beqz	a2,28e <memcmp+0x36>
 262:	1602                	slli	a2,a2,0x20
 264:	9201                	srli	a2,a2,0x20
 266:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 26a:	00054783          	lbu	a5,0(a0)
 26e:	0005c703          	lbu	a4,0(a1)
 272:	00e79863          	bne	a5,a4,282 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 276:	0505                	addi	a0,a0,1
    p2++;
 278:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 27a:	fed518e3          	bne	a0,a3,26a <memcmp+0x12>
  }
  return 0;
 27e:	4501                	li	a0,0
 280:	a019                	j	286 <memcmp+0x2e>
      return *p1 - *p2;
 282:	40e7853b          	subw	a0,a5,a4
}
 286:	60a2                	ld	ra,8(sp)
 288:	6402                	ld	s0,0(sp)
 28a:	0141                	addi	sp,sp,16
 28c:	8082                	ret
  return 0;
 28e:	4501                	li	a0,0
 290:	bfdd                	j	286 <memcmp+0x2e>

0000000000000292 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 292:	1141                	addi	sp,sp,-16
 294:	e406                	sd	ra,8(sp)
 296:	e022                	sd	s0,0(sp)
 298:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 29a:	f63ff0ef          	jal	1fc <memmove>
}
 29e:	60a2                	ld	ra,8(sp)
 2a0:	6402                	ld	s0,0(sp)
 2a2:	0141                	addi	sp,sp,16
 2a4:	8082                	ret

00000000000002a6 <sbrk>:

char *
sbrk(int n) {
 2a6:	1141                	addi	sp,sp,-16
 2a8:	e406                	sd	ra,8(sp)
 2aa:	e022                	sd	s0,0(sp)
 2ac:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 2ae:	4585                	li	a1,1
 2b0:	0b2000ef          	jal	362 <sys_sbrk>
}
 2b4:	60a2                	ld	ra,8(sp)
 2b6:	6402                	ld	s0,0(sp)
 2b8:	0141                	addi	sp,sp,16
 2ba:	8082                	ret

00000000000002bc <sbrklazy>:

char *
sbrklazy(int n) {
 2bc:	1141                	addi	sp,sp,-16
 2be:	e406                	sd	ra,8(sp)
 2c0:	e022                	sd	s0,0(sp)
 2c2:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 2c4:	4589                	li	a1,2
 2c6:	09c000ef          	jal	362 <sys_sbrk>
}
 2ca:	60a2                	ld	ra,8(sp)
 2cc:	6402                	ld	s0,0(sp)
 2ce:	0141                	addi	sp,sp,16
 2d0:	8082                	ret

00000000000002d2 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 2d2:	4885                	li	a7,1
 ecall
 2d4:	00000073          	ecall
 ret
 2d8:	8082                	ret

00000000000002da <exit>:
.global exit
exit:
 li a7, SYS_exit
 2da:	4889                	li	a7,2
 ecall
 2dc:	00000073          	ecall
 ret
 2e0:	8082                	ret

00000000000002e2 <wait>:
.global wait
wait:
 li a7, SYS_wait
 2e2:	488d                	li	a7,3
 ecall
 2e4:	00000073          	ecall
 ret
 2e8:	8082                	ret

00000000000002ea <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 2ea:	4891                	li	a7,4
 ecall
 2ec:	00000073          	ecall
 ret
 2f0:	8082                	ret

00000000000002f2 <read>:
.global read
read:
 li a7, SYS_read
 2f2:	4895                	li	a7,5
 ecall
 2f4:	00000073          	ecall
 ret
 2f8:	8082                	ret

00000000000002fa <write>:
.global write
write:
 li a7, SYS_write
 2fa:	48c1                	li	a7,16
 ecall
 2fc:	00000073          	ecall
 ret
 300:	8082                	ret

0000000000000302 <close>:
.global close
close:
 li a7, SYS_close
 302:	48d5                	li	a7,21
 ecall
 304:	00000073          	ecall
 ret
 308:	8082                	ret

000000000000030a <kill>:
.global kill
kill:
 li a7, SYS_kill
 30a:	4899                	li	a7,6
 ecall
 30c:	00000073          	ecall
 ret
 310:	8082                	ret

0000000000000312 <exec>:
.global exec
exec:
 li a7, SYS_exec
 312:	489d                	li	a7,7
 ecall
 314:	00000073          	ecall
 ret
 318:	8082                	ret

000000000000031a <open>:
.global open
open:
 li a7, SYS_open
 31a:	48bd                	li	a7,15
 ecall
 31c:	00000073          	ecall
 ret
 320:	8082                	ret

0000000000000322 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 322:	48c5                	li	a7,17
 ecall
 324:	00000073          	ecall
 ret
 328:	8082                	ret

000000000000032a <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 32a:	48c9                	li	a7,18
 ecall
 32c:	00000073          	ecall
 ret
 330:	8082                	ret

0000000000000332 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 332:	48a1                	li	a7,8
 ecall
 334:	00000073          	ecall
 ret
 338:	8082                	ret

000000000000033a <link>:
.global link
link:
 li a7, SYS_link
 33a:	48cd                	li	a7,19
 ecall
 33c:	00000073          	ecall
 ret
 340:	8082                	ret

0000000000000342 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 342:	48d1                	li	a7,20
 ecall
 344:	00000073          	ecall
 ret
 348:	8082                	ret

000000000000034a <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 34a:	48a5                	li	a7,9
 ecall
 34c:	00000073          	ecall
 ret
 350:	8082                	ret

0000000000000352 <dup>:
.global dup
dup:
 li a7, SYS_dup
 352:	48a9                	li	a7,10
 ecall
 354:	00000073          	ecall
 ret
 358:	8082                	ret

000000000000035a <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 35a:	48ad                	li	a7,11
 ecall
 35c:	00000073          	ecall
 ret
 360:	8082                	ret

0000000000000362 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 362:	48b1                	li	a7,12
 ecall
 364:	00000073          	ecall
 ret
 368:	8082                	ret

000000000000036a <pause>:
.global pause
pause:
 li a7, SYS_pause
 36a:	48b5                	li	a7,13
 ecall
 36c:	00000073          	ecall
 ret
 370:	8082                	ret

0000000000000372 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 372:	48b9                	li	a7,14
 ecall
 374:	00000073          	ecall
 ret
 378:	8082                	ret

000000000000037a <kmemfree>:
.global kmemfree
kmemfree:
 li a7, SYS_kmemfree
 37a:	48d9                	li	a7,22
 ecall
 37c:	00000073          	ecall
 ret
 380:	8082                	ret

0000000000000382 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 382:	1101                	addi	sp,sp,-32
 384:	ec06                	sd	ra,24(sp)
 386:	e822                	sd	s0,16(sp)
 388:	1000                	addi	s0,sp,32
 38a:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 38e:	4605                	li	a2,1
 390:	fef40593          	addi	a1,s0,-17
 394:	f67ff0ef          	jal	2fa <write>
}
 398:	60e2                	ld	ra,24(sp)
 39a:	6442                	ld	s0,16(sp)
 39c:	6105                	addi	sp,sp,32
 39e:	8082                	ret

00000000000003a0 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 3a0:	715d                	addi	sp,sp,-80
 3a2:	e486                	sd	ra,72(sp)
 3a4:	e0a2                	sd	s0,64(sp)
 3a6:	f84a                	sd	s2,48(sp)
 3a8:	f44e                	sd	s3,40(sp)
 3aa:	0880                	addi	s0,sp,80
 3ac:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 3ae:	c6d1                	beqz	a3,43a <printint+0x9a>
 3b0:	0805d563          	bgez	a1,43a <printint+0x9a>
    neg = 1;
    x = -xx;
 3b4:	40b005b3          	neg	a1,a1
    neg = 1;
 3b8:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 3ba:	fb840993          	addi	s3,s0,-72
  neg = 0;
 3be:	86ce                	mv	a3,s3
  i = 0;
 3c0:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 3c2:	00000817          	auipc	a6,0x0
 3c6:	53e80813          	addi	a6,a6,1342 # 900 <digits>
 3ca:	88ba                	mv	a7,a4
 3cc:	0017051b          	addiw	a0,a4,1
 3d0:	872a                	mv	a4,a0
 3d2:	02c5f7b3          	remu	a5,a1,a2
 3d6:	97c2                	add	a5,a5,a6
 3d8:	0007c783          	lbu	a5,0(a5)
 3dc:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 3e0:	87ae                	mv	a5,a1
 3e2:	02c5d5b3          	divu	a1,a1,a2
 3e6:	0685                	addi	a3,a3,1
 3e8:	fec7f1e3          	bgeu	a5,a2,3ca <printint+0x2a>
  if(neg)
 3ec:	00030c63          	beqz	t1,404 <printint+0x64>
    buf[i++] = '-';
 3f0:	fd050793          	addi	a5,a0,-48
 3f4:	00878533          	add	a0,a5,s0
 3f8:	02d00793          	li	a5,45
 3fc:	fef50423          	sb	a5,-24(a0)
 400:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 404:	02e05563          	blez	a4,42e <printint+0x8e>
 408:	fc26                	sd	s1,56(sp)
 40a:	377d                	addiw	a4,a4,-1
 40c:	00e984b3          	add	s1,s3,a4
 410:	19fd                	addi	s3,s3,-1
 412:	99ba                	add	s3,s3,a4
 414:	1702                	slli	a4,a4,0x20
 416:	9301                	srli	a4,a4,0x20
 418:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 41c:	0004c583          	lbu	a1,0(s1)
 420:	854a                	mv	a0,s2
 422:	f61ff0ef          	jal	382 <putc>
  while(--i >= 0)
 426:	14fd                	addi	s1,s1,-1
 428:	ff349ae3          	bne	s1,s3,41c <printint+0x7c>
 42c:	74e2                	ld	s1,56(sp)
}
 42e:	60a6                	ld	ra,72(sp)
 430:	6406                	ld	s0,64(sp)
 432:	7942                	ld	s2,48(sp)
 434:	79a2                	ld	s3,40(sp)
 436:	6161                	addi	sp,sp,80
 438:	8082                	ret
  neg = 0;
 43a:	4301                	li	t1,0
 43c:	bfbd                	j	3ba <printint+0x1a>

000000000000043e <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 43e:	711d                	addi	sp,sp,-96
 440:	ec86                	sd	ra,88(sp)
 442:	e8a2                	sd	s0,80(sp)
 444:	e4a6                	sd	s1,72(sp)
 446:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 448:	0005c483          	lbu	s1,0(a1)
 44c:	22048363          	beqz	s1,672 <vprintf+0x234>
 450:	e0ca                	sd	s2,64(sp)
 452:	fc4e                	sd	s3,56(sp)
 454:	f852                	sd	s4,48(sp)
 456:	f456                	sd	s5,40(sp)
 458:	f05a                	sd	s6,32(sp)
 45a:	ec5e                	sd	s7,24(sp)
 45c:	e862                	sd	s8,16(sp)
 45e:	8b2a                	mv	s6,a0
 460:	8a2e                	mv	s4,a1
 462:	8bb2                	mv	s7,a2
  state = 0;
 464:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 466:	4901                	li	s2,0
 468:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 46a:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 46e:	06400c13          	li	s8,100
 472:	a00d                	j	494 <vprintf+0x56>
        putc(fd, c0);
 474:	85a6                	mv	a1,s1
 476:	855a                	mv	a0,s6
 478:	f0bff0ef          	jal	382 <putc>
 47c:	a019                	j	482 <vprintf+0x44>
    } else if(state == '%'){
 47e:	03598363          	beq	s3,s5,4a4 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 482:	0019079b          	addiw	a5,s2,1
 486:	893e                	mv	s2,a5
 488:	873e                	mv	a4,a5
 48a:	97d2                	add	a5,a5,s4
 48c:	0007c483          	lbu	s1,0(a5)
 490:	1c048a63          	beqz	s1,664 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 494:	0004879b          	sext.w	a5,s1
    if(state == 0){
 498:	fe0993e3          	bnez	s3,47e <vprintf+0x40>
      if(c0 == '%'){
 49c:	fd579ce3          	bne	a5,s5,474 <vprintf+0x36>
        state = '%';
 4a0:	89be                	mv	s3,a5
 4a2:	b7c5                	j	482 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 4a4:	00ea06b3          	add	a3,s4,a4
 4a8:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 4ac:	1c060863          	beqz	a2,67c <vprintf+0x23e>
      if(c0 == 'd'){
 4b0:	03878763          	beq	a5,s8,4de <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 4b4:	f9478693          	addi	a3,a5,-108
 4b8:	0016b693          	seqz	a3,a3
 4bc:	f9c60593          	addi	a1,a2,-100
 4c0:	e99d                	bnez	a1,4f6 <vprintf+0xb8>
 4c2:	ca95                	beqz	a3,4f6 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 4c4:	008b8493          	addi	s1,s7,8
 4c8:	4685                	li	a3,1
 4ca:	4629                	li	a2,10
 4cc:	000bb583          	ld	a1,0(s7)
 4d0:	855a                	mv	a0,s6
 4d2:	ecfff0ef          	jal	3a0 <printint>
        i += 1;
 4d6:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 4d8:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 4da:	4981                	li	s3,0
 4dc:	b75d                	j	482 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 4de:	008b8493          	addi	s1,s7,8
 4e2:	4685                	li	a3,1
 4e4:	4629                	li	a2,10
 4e6:	000ba583          	lw	a1,0(s7)
 4ea:	855a                	mv	a0,s6
 4ec:	eb5ff0ef          	jal	3a0 <printint>
 4f0:	8ba6                	mv	s7,s1
      state = 0;
 4f2:	4981                	li	s3,0
 4f4:	b779                	j	482 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 4f6:	9752                	add	a4,a4,s4
 4f8:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 4fc:	f9460713          	addi	a4,a2,-108
 500:	00173713          	seqz	a4,a4
 504:	8f75                	and	a4,a4,a3
 506:	f9c58513          	addi	a0,a1,-100
 50a:	18051363          	bnez	a0,690 <vprintf+0x252>
 50e:	18070163          	beqz	a4,690 <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 512:	008b8493          	addi	s1,s7,8
 516:	4685                	li	a3,1
 518:	4629                	li	a2,10
 51a:	000bb583          	ld	a1,0(s7)
 51e:	855a                	mv	a0,s6
 520:	e81ff0ef          	jal	3a0 <printint>
        i += 2;
 524:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 526:	8ba6                	mv	s7,s1
      state = 0;
 528:	4981                	li	s3,0
        i += 2;
 52a:	bfa1                	j	482 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 52c:	008b8493          	addi	s1,s7,8
 530:	4681                	li	a3,0
 532:	4629                	li	a2,10
 534:	000be583          	lwu	a1,0(s7)
 538:	855a                	mv	a0,s6
 53a:	e67ff0ef          	jal	3a0 <printint>
 53e:	8ba6                	mv	s7,s1
      state = 0;
 540:	4981                	li	s3,0
 542:	b781                	j	482 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 544:	008b8493          	addi	s1,s7,8
 548:	4681                	li	a3,0
 54a:	4629                	li	a2,10
 54c:	000bb583          	ld	a1,0(s7)
 550:	855a                	mv	a0,s6
 552:	e4fff0ef          	jal	3a0 <printint>
        i += 1;
 556:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 558:	8ba6                	mv	s7,s1
      state = 0;
 55a:	4981                	li	s3,0
 55c:	b71d                	j	482 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 55e:	008b8493          	addi	s1,s7,8
 562:	4681                	li	a3,0
 564:	4629                	li	a2,10
 566:	000bb583          	ld	a1,0(s7)
 56a:	855a                	mv	a0,s6
 56c:	e35ff0ef          	jal	3a0 <printint>
        i += 2;
 570:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 572:	8ba6                	mv	s7,s1
      state = 0;
 574:	4981                	li	s3,0
        i += 2;
 576:	b731                	j	482 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 578:	008b8493          	addi	s1,s7,8
 57c:	4681                	li	a3,0
 57e:	4641                	li	a2,16
 580:	000be583          	lwu	a1,0(s7)
 584:	855a                	mv	a0,s6
 586:	e1bff0ef          	jal	3a0 <printint>
 58a:	8ba6                	mv	s7,s1
      state = 0;
 58c:	4981                	li	s3,0
 58e:	bdd5                	j	482 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 590:	008b8493          	addi	s1,s7,8
 594:	4681                	li	a3,0
 596:	4641                	li	a2,16
 598:	000bb583          	ld	a1,0(s7)
 59c:	855a                	mv	a0,s6
 59e:	e03ff0ef          	jal	3a0 <printint>
        i += 1;
 5a2:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 5a4:	8ba6                	mv	s7,s1
      state = 0;
 5a6:	4981                	li	s3,0
 5a8:	bde9                	j	482 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 5aa:	008b8493          	addi	s1,s7,8
 5ae:	4681                	li	a3,0
 5b0:	4641                	li	a2,16
 5b2:	000bb583          	ld	a1,0(s7)
 5b6:	855a                	mv	a0,s6
 5b8:	de9ff0ef          	jal	3a0 <printint>
        i += 2;
 5bc:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 5be:	8ba6                	mv	s7,s1
      state = 0;
 5c0:	4981                	li	s3,0
        i += 2;
 5c2:	b5c1                	j	482 <vprintf+0x44>
 5c4:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 5c6:	008b8793          	addi	a5,s7,8
 5ca:	8cbe                	mv	s9,a5
 5cc:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 5d0:	03000593          	li	a1,48
 5d4:	855a                	mv	a0,s6
 5d6:	dadff0ef          	jal	382 <putc>
  putc(fd, 'x');
 5da:	07800593          	li	a1,120
 5de:	855a                	mv	a0,s6
 5e0:	da3ff0ef          	jal	382 <putc>
 5e4:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 5e6:	00000b97          	auipc	s7,0x0
 5ea:	31ab8b93          	addi	s7,s7,794 # 900 <digits>
 5ee:	03c9d793          	srli	a5,s3,0x3c
 5f2:	97de                	add	a5,a5,s7
 5f4:	0007c583          	lbu	a1,0(a5)
 5f8:	855a                	mv	a0,s6
 5fa:	d89ff0ef          	jal	382 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 5fe:	0992                	slli	s3,s3,0x4
 600:	34fd                	addiw	s1,s1,-1
 602:	f4f5                	bnez	s1,5ee <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 604:	8be6                	mv	s7,s9
      state = 0;
 606:	4981                	li	s3,0
 608:	6ca2                	ld	s9,8(sp)
 60a:	bda5                	j	482 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 60c:	008b8493          	addi	s1,s7,8
 610:	000bc583          	lbu	a1,0(s7)
 614:	855a                	mv	a0,s6
 616:	d6dff0ef          	jal	382 <putc>
 61a:	8ba6                	mv	s7,s1
      state = 0;
 61c:	4981                	li	s3,0
 61e:	b595                	j	482 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 620:	008b8993          	addi	s3,s7,8
 624:	000bb483          	ld	s1,0(s7)
 628:	cc91                	beqz	s1,644 <vprintf+0x206>
        for(; *s; s++)
 62a:	0004c583          	lbu	a1,0(s1)
 62e:	c985                	beqz	a1,65e <vprintf+0x220>
          putc(fd, *s);
 630:	855a                	mv	a0,s6
 632:	d51ff0ef          	jal	382 <putc>
        for(; *s; s++)
 636:	0485                	addi	s1,s1,1
 638:	0004c583          	lbu	a1,0(s1)
 63c:	f9f5                	bnez	a1,630 <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 63e:	8bce                	mv	s7,s3
      state = 0;
 640:	4981                	li	s3,0
 642:	b581                	j	482 <vprintf+0x44>
          s = "(null)";
 644:	00000497          	auipc	s1,0x0
 648:	2b448493          	addi	s1,s1,692 # 8f8 <malloc+0x118>
        for(; *s; s++)
 64c:	02800593          	li	a1,40
 650:	b7c5                	j	630 <vprintf+0x1f2>
        putc(fd, '%');
 652:	85be                	mv	a1,a5
 654:	855a                	mv	a0,s6
 656:	d2dff0ef          	jal	382 <putc>
      state = 0;
 65a:	4981                	li	s3,0
 65c:	b51d                	j	482 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 65e:	8bce                	mv	s7,s3
      state = 0;
 660:	4981                	li	s3,0
 662:	b505                	j	482 <vprintf+0x44>
 664:	6906                	ld	s2,64(sp)
 666:	79e2                	ld	s3,56(sp)
 668:	7a42                	ld	s4,48(sp)
 66a:	7aa2                	ld	s5,40(sp)
 66c:	7b02                	ld	s6,32(sp)
 66e:	6be2                	ld	s7,24(sp)
 670:	6c42                	ld	s8,16(sp)
    }
  }
}
 672:	60e6                	ld	ra,88(sp)
 674:	6446                	ld	s0,80(sp)
 676:	64a6                	ld	s1,72(sp)
 678:	6125                	addi	sp,sp,96
 67a:	8082                	ret
      if(c0 == 'd'){
 67c:	06400713          	li	a4,100
 680:	e4e78fe3          	beq	a5,a4,4de <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 684:	f9478693          	addi	a3,a5,-108
 688:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 68c:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 68e:	4701                	li	a4,0
      } else if(c0 == 'u'){
 690:	07500513          	li	a0,117
 694:	e8a78ce3          	beq	a5,a0,52c <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 698:	f8b60513          	addi	a0,a2,-117
 69c:	e119                	bnez	a0,6a2 <vprintf+0x264>
 69e:	ea0693e3          	bnez	a3,544 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 6a2:	f8b58513          	addi	a0,a1,-117
 6a6:	e119                	bnez	a0,6ac <vprintf+0x26e>
 6a8:	ea071be3          	bnez	a4,55e <vprintf+0x120>
      } else if(c0 == 'x'){
 6ac:	07800513          	li	a0,120
 6b0:	eca784e3          	beq	a5,a0,578 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 6b4:	f8860613          	addi	a2,a2,-120
 6b8:	e219                	bnez	a2,6be <vprintf+0x280>
 6ba:	ec069be3          	bnez	a3,590 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 6be:	f8858593          	addi	a1,a1,-120
 6c2:	e199                	bnez	a1,6c8 <vprintf+0x28a>
 6c4:	ee0713e3          	bnez	a4,5aa <vprintf+0x16c>
      } else if(c0 == 'p'){
 6c8:	07000713          	li	a4,112
 6cc:	eee78ce3          	beq	a5,a4,5c4 <vprintf+0x186>
      } else if(c0 == 'c'){
 6d0:	06300713          	li	a4,99
 6d4:	f2e78ce3          	beq	a5,a4,60c <vprintf+0x1ce>
      } else if(c0 == 's'){
 6d8:	07300713          	li	a4,115
 6dc:	f4e782e3          	beq	a5,a4,620 <vprintf+0x1e2>
      } else if(c0 == '%'){
 6e0:	02500713          	li	a4,37
 6e4:	f6e787e3          	beq	a5,a4,652 <vprintf+0x214>
        putc(fd, '%');
 6e8:	02500593          	li	a1,37
 6ec:	855a                	mv	a0,s6
 6ee:	c95ff0ef          	jal	382 <putc>
        putc(fd, c0);
 6f2:	85a6                	mv	a1,s1
 6f4:	855a                	mv	a0,s6
 6f6:	c8dff0ef          	jal	382 <putc>
      state = 0;
 6fa:	4981                	li	s3,0
 6fc:	b359                	j	482 <vprintf+0x44>

00000000000006fe <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 6fe:	715d                	addi	sp,sp,-80
 700:	ec06                	sd	ra,24(sp)
 702:	e822                	sd	s0,16(sp)
 704:	1000                	addi	s0,sp,32
 706:	e010                	sd	a2,0(s0)
 708:	e414                	sd	a3,8(s0)
 70a:	e818                	sd	a4,16(s0)
 70c:	ec1c                	sd	a5,24(s0)
 70e:	03043023          	sd	a6,32(s0)
 712:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 716:	8622                	mv	a2,s0
 718:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 71c:	d23ff0ef          	jal	43e <vprintf>
}
 720:	60e2                	ld	ra,24(sp)
 722:	6442                	ld	s0,16(sp)
 724:	6161                	addi	sp,sp,80
 726:	8082                	ret

0000000000000728 <printf>:

void
printf(const char *fmt, ...)
{
 728:	711d                	addi	sp,sp,-96
 72a:	ec06                	sd	ra,24(sp)
 72c:	e822                	sd	s0,16(sp)
 72e:	1000                	addi	s0,sp,32
 730:	e40c                	sd	a1,8(s0)
 732:	e810                	sd	a2,16(s0)
 734:	ec14                	sd	a3,24(s0)
 736:	f018                	sd	a4,32(s0)
 738:	f41c                	sd	a5,40(s0)
 73a:	03043823          	sd	a6,48(s0)
 73e:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 742:	00840613          	addi	a2,s0,8
 746:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 74a:	85aa                	mv	a1,a0
 74c:	4505                	li	a0,1
 74e:	cf1ff0ef          	jal	43e <vprintf>
}
 752:	60e2                	ld	ra,24(sp)
 754:	6442                	ld	s0,16(sp)
 756:	6125                	addi	sp,sp,96
 758:	8082                	ret

000000000000075a <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 75a:	1141                	addi	sp,sp,-16
 75c:	e406                	sd	ra,8(sp)
 75e:	e022                	sd	s0,0(sp)
 760:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 762:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 766:	00001797          	auipc	a5,0x1
 76a:	89a7b783          	ld	a5,-1894(a5) # 1000 <freep>
 76e:	a039                	j	77c <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 770:	6398                	ld	a4,0(a5)
 772:	00e7e463          	bltu	a5,a4,77a <free+0x20>
 776:	00e6ea63          	bltu	a3,a4,78a <free+0x30>
{
 77a:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 77c:	fed7fae3          	bgeu	a5,a3,770 <free+0x16>
 780:	6398                	ld	a4,0(a5)
 782:	00e6e463          	bltu	a3,a4,78a <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 786:	fee7eae3          	bltu	a5,a4,77a <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 78a:	ff852583          	lw	a1,-8(a0)
 78e:	6390                	ld	a2,0(a5)
 790:	02059813          	slli	a6,a1,0x20
 794:	01c85713          	srli	a4,a6,0x1c
 798:	9736                	add	a4,a4,a3
 79a:	02e60563          	beq	a2,a4,7c4 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 79e:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 7a2:	4790                	lw	a2,8(a5)
 7a4:	02061593          	slli	a1,a2,0x20
 7a8:	01c5d713          	srli	a4,a1,0x1c
 7ac:	973e                	add	a4,a4,a5
 7ae:	02e68263          	beq	a3,a4,7d2 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 7b2:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 7b4:	00001717          	auipc	a4,0x1
 7b8:	84f73623          	sd	a5,-1972(a4) # 1000 <freep>
}
 7bc:	60a2                	ld	ra,8(sp)
 7be:	6402                	ld	s0,0(sp)
 7c0:	0141                	addi	sp,sp,16
 7c2:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 7c4:	4618                	lw	a4,8(a2)
 7c6:	9f2d                	addw	a4,a4,a1
 7c8:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 7cc:	6398                	ld	a4,0(a5)
 7ce:	6310                	ld	a2,0(a4)
 7d0:	b7f9                	j	79e <free+0x44>
    p->s.size += bp->s.size;
 7d2:	ff852703          	lw	a4,-8(a0)
 7d6:	9f31                	addw	a4,a4,a2
 7d8:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 7da:	ff053683          	ld	a3,-16(a0)
 7de:	bfd1                	j	7b2 <free+0x58>

00000000000007e0 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 7e0:	7139                	addi	sp,sp,-64
 7e2:	fc06                	sd	ra,56(sp)
 7e4:	f822                	sd	s0,48(sp)
 7e6:	f04a                	sd	s2,32(sp)
 7e8:	ec4e                	sd	s3,24(sp)
 7ea:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 7ec:	02051993          	slli	s3,a0,0x20
 7f0:	0209d993          	srli	s3,s3,0x20
 7f4:	09bd                	addi	s3,s3,15
 7f6:	0049d993          	srli	s3,s3,0x4
 7fa:	2985                	addiw	s3,s3,1
 7fc:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 7fe:	00001517          	auipc	a0,0x1
 802:	80253503          	ld	a0,-2046(a0) # 1000 <freep>
 806:	c905                	beqz	a0,836 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 808:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 80a:	4798                	lw	a4,8(a5)
 80c:	09377663          	bgeu	a4,s3,898 <malloc+0xb8>
 810:	f426                	sd	s1,40(sp)
 812:	e852                	sd	s4,16(sp)
 814:	e456                	sd	s5,8(sp)
 816:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 818:	8a4e                	mv	s4,s3
 81a:	6705                	lui	a4,0x1
 81c:	00e9f363          	bgeu	s3,a4,822 <malloc+0x42>
 820:	6a05                	lui	s4,0x1
 822:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 826:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 82a:	00000497          	auipc	s1,0x0
 82e:	7d648493          	addi	s1,s1,2006 # 1000 <freep>
  if(p == SBRK_ERROR)
 832:	5afd                	li	s5,-1
 834:	a83d                	j	872 <malloc+0x92>
 836:	f426                	sd	s1,40(sp)
 838:	e852                	sd	s4,16(sp)
 83a:	e456                	sd	s5,8(sp)
 83c:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 83e:	00000797          	auipc	a5,0x0
 842:	7d278793          	addi	a5,a5,2002 # 1010 <base>
 846:	00000717          	auipc	a4,0x0
 84a:	7af73d23          	sd	a5,1978(a4) # 1000 <freep>
 84e:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 850:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 854:	b7d1                	j	818 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 856:	6398                	ld	a4,0(a5)
 858:	e118                	sd	a4,0(a0)
 85a:	a899                	j	8b0 <malloc+0xd0>
  hp->s.size = nu;
 85c:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 860:	0541                	addi	a0,a0,16
 862:	ef9ff0ef          	jal	75a <free>
  return freep;
 866:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 868:	c125                	beqz	a0,8c8 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 86a:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 86c:	4798                	lw	a4,8(a5)
 86e:	03277163          	bgeu	a4,s2,890 <malloc+0xb0>
    if(p == freep)
 872:	6098                	ld	a4,0(s1)
 874:	853e                	mv	a0,a5
 876:	fef71ae3          	bne	a4,a5,86a <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 87a:	8552                	mv	a0,s4
 87c:	a2bff0ef          	jal	2a6 <sbrk>
  if(p == SBRK_ERROR)
 880:	fd551ee3          	bne	a0,s5,85c <malloc+0x7c>
        return 0;
 884:	4501                	li	a0,0
 886:	74a2                	ld	s1,40(sp)
 888:	6a42                	ld	s4,16(sp)
 88a:	6aa2                	ld	s5,8(sp)
 88c:	6b02                	ld	s6,0(sp)
 88e:	a03d                	j	8bc <malloc+0xdc>
 890:	74a2                	ld	s1,40(sp)
 892:	6a42                	ld	s4,16(sp)
 894:	6aa2                	ld	s5,8(sp)
 896:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 898:	fae90fe3          	beq	s2,a4,856 <malloc+0x76>
        p->s.size -= nunits;
 89c:	4137073b          	subw	a4,a4,s3
 8a0:	c798                	sw	a4,8(a5)
        p += p->s.size;
 8a2:	02071693          	slli	a3,a4,0x20
 8a6:	01c6d713          	srli	a4,a3,0x1c
 8aa:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 8ac:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 8b0:	00000717          	auipc	a4,0x0
 8b4:	74a73823          	sd	a0,1872(a4) # 1000 <freep>
      return (void*)(p + 1);
 8b8:	01078513          	addi	a0,a5,16
  }
}
 8bc:	70e2                	ld	ra,56(sp)
 8be:	7442                	ld	s0,48(sp)
 8c0:	7902                	ld	s2,32(sp)
 8c2:	69e2                	ld	s3,24(sp)
 8c4:	6121                	addi	sp,sp,64
 8c6:	8082                	ret
 8c8:	74a2                	ld	s1,40(sp)
 8ca:	6a42                	ld	s4,16(sp)
 8cc:	6aa2                	ld	s5,8(sp)
 8ce:	6b02                	ld	s6,0(sp)
 8d0:	b7f5                	j	8bc <malloc+0xdc>
