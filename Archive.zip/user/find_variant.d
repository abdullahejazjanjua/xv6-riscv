user/find_variant.o: user/find_variant.c user/../kernel/types.h \
 user/../kernel/stat.h user/../kernel/fs.h user/../kernel/fcntl.h \
 user/../kernel/param.h user/user.h
