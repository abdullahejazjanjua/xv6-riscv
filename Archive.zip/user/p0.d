user/p0.o: user/p0.c kernel/types.h kernel/stat.h user/user.h
