user/first.o: user/first.c \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/stdio.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/_ansi.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/newlib.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/_newlib_version.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/sys/config.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/machine/ieeefp.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/sys/features.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/sys/cdefs.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/machine/_default_types.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/lib/gcc/riscv64-unknown-elf/15.1.0/include/stddef.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/lib/gcc/riscv64-unknown-elf/15.1.0/include/stdarg.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/sys/reent.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/_ansi.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/sys/_types.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/machine/_types.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/sys/lock.h \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/riscv64-unknown-elf/include/sys/stdio.h
