
user/_sixfive:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "../kernel/types.h"
#include "../kernel/fcntl.h"
#include "user.h"

int main(int argc, char *argv[])
{
   0:	7175                	addi	sp,sp,-144
   2:	e506                	sd	ra,136(sp)
   4:	e122                	sd	s0,128(sp)
   6:	fca6                	sd	s1,120(sp)
   8:	f8ca                	sd	s2,112(sp)
   a:	f4ce                	sd	s3,104(sp)
   c:	f0d2                	sd	s4,96(sp)
   e:	ecd6                	sd	s5,88(sp)
  10:	e8da                	sd	s6,80(sp)
  12:	e4de                	sd	s7,72(sp)
  14:	e0e2                	sd	s8,64(sp)
  16:	fc66                	sd	s9,56(sp)
  18:	0900                	addi	s0,sp,144
  1a:	87ae                	mv	a5,a1
  char buf[32];
  char *sep =  " -\r\t\n./,";
  int fd = open(argv[1], O_RDONLY);
  1c:	4581                	li	a1,0
  1e:	6788                	ld	a0,8(a5)
  20:	39e000ef          	jal	3be <open>
  24:	8a2a                	mv	s4,a0
  
  int idx = 0;
  int valid = 1; 
  26:	4985                	li	s3,1
  int idx = 0;
  28:	4481                	li	s1,0
  char c;

  while(read(fd, &c, 1) != 0)
  2a:	f7f40a93          	addi	s5,s0,-129
  2e:	894e                	mv	s2,s3
  {
    if (strchr(sep, c)) 
  30:	00001b17          	auipc	s6,0x1
  34:	950b0b13          	addi	s6,s6,-1712 # 980 <malloc+0xfc>
      }
        
      idx = 0; 
      valid = 1;
    }
    else if (c >= '0' && c <= '9')
  38:	4ba5                	li	s7,9
        printf("%s\n", buf);
  3a:	f8040c93          	addi	s9,s0,-128
  3e:	00001c17          	auipc	s8,0x1
  42:	952c0c13          	addi	s8,s8,-1710 # 990 <malloc+0x10c>
  while(read(fd, &c, 1) != 0)
  46:	a025                	j	6e <main+0x6e>
    else if (c >= '0' && c <= '9')
  48:	f7f44703          	lbu	a4,-129(s0)
  4c:	fd07079b          	addiw	a5,a4,-48
  50:	0ff7f793          	zext.b	a5,a5
  54:	04fbea63          	bltu	s7,a5,a8 <main+0xa8>
    {
      if (valid)
  58:	00098b63          	beqz	s3,6e <main+0x6e>
      {
        buf[idx] = c;
  5c:	fa048793          	addi	a5,s1,-96
  60:	97a2                	add	a5,a5,s0
  62:	fee78023          	sb	a4,-32(a5)
        idx++;
  66:	2485                	addiw	s1,s1,1
  68:	a019                	j	6e <main+0x6e>
      valid = 1;
  6a:	89ca                	mv	s3,s2
      idx = 0; 
  6c:	4481                	li	s1,0
  while(read(fd, &c, 1) != 0)
  6e:	864a                	mv	a2,s2
  70:	85d6                	mv	a1,s5
  72:	8552                	mv	a0,s4
  74:	322000ef          	jal	396 <read>
  78:	c91d                	beqz	a0,ae <main+0xae>
    if (strchr(sep, c)) 
  7a:	f7f44583          	lbu	a1,-129(s0)
  7e:	855a                	mv	a0,s6
  80:	0fa000ef          	jal	17a <strchr>
  84:	d171                	beqz	a0,48 <main+0x48>
      if (idx > 0 && valid)
  86:	fe9052e3          	blez	s1,6a <main+0x6a>
  8a:	fe0980e3          	beqz	s3,6a <main+0x6a>
        buf[idx] = '\0';
  8e:	fa048793          	addi	a5,s1,-96
  92:	008784b3          	add	s1,a5,s0
  96:	fe048023          	sb	zero,-32(s1)
        printf("%s\n", buf);
  9a:	85e6                	mv	a1,s9
  9c:	8562                	mv	a0,s8
  9e:	72e000ef          	jal	7cc <printf>
      valid = 1;
  a2:	89ca                	mv	s3,s2
      idx = 0; 
  a4:	4481                	li	s1,0
  a6:	b7e1                	j	6e <main+0x6e>
      }
    }
    else 
    {
      valid = 0; 
  a8:	4981                	li	s3,0
      idx = 0;   
  aa:	4481                	li	s1,0
  ac:	b7c9                	j	6e <main+0x6e>
    }
  }
}
  ae:	60aa                	ld	ra,136(sp)
  b0:	640a                	ld	s0,128(sp)
  b2:	74e6                	ld	s1,120(sp)
  b4:	7946                	ld	s2,112(sp)
  b6:	79a6                	ld	s3,104(sp)
  b8:	7a06                	ld	s4,96(sp)
  ba:	6ae6                	ld	s5,88(sp)
  bc:	6b46                	ld	s6,80(sp)
  be:	6ba6                	ld	s7,72(sp)
  c0:	6c06                	ld	s8,64(sp)
  c2:	7ce2                	ld	s9,56(sp)
  c4:	6149                	addi	sp,sp,144
  c6:	8082                	ret

00000000000000c8 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start(int argc, char **argv)
{
  c8:	1141                	addi	sp,sp,-16
  ca:	e406                	sd	ra,8(sp)
  cc:	e022                	sd	s0,0(sp)
  ce:	0800                	addi	s0,sp,16
  int r;
  extern int main(int argc, char **argv);
  r = main(argc, argv);
  d0:	f31ff0ef          	jal	0 <main>
  exit(r);
  d4:	2aa000ef          	jal	37e <exit>

00000000000000d8 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  d8:	1141                	addi	sp,sp,-16
  da:	e406                	sd	ra,8(sp)
  dc:	e022                	sd	s0,0(sp)
  de:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  e0:	87aa                	mv	a5,a0
  e2:	0585                	addi	a1,a1,1
  e4:	0785                	addi	a5,a5,1
  e6:	fff5c703          	lbu	a4,-1(a1)
  ea:	fee78fa3          	sb	a4,-1(a5)
  ee:	fb75                	bnez	a4,e2 <strcpy+0xa>
    ;
  return os;
}
  f0:	60a2                	ld	ra,8(sp)
  f2:	6402                	ld	s0,0(sp)
  f4:	0141                	addi	sp,sp,16
  f6:	8082                	ret

00000000000000f8 <strcmp>:

int
strcmp(const char *p, const char *q)
{
  f8:	1141                	addi	sp,sp,-16
  fa:	e406                	sd	ra,8(sp)
  fc:	e022                	sd	s0,0(sp)
  fe:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 100:	00054783          	lbu	a5,0(a0)
 104:	cb91                	beqz	a5,118 <strcmp+0x20>
 106:	0005c703          	lbu	a4,0(a1)
 10a:	00f71763          	bne	a4,a5,118 <strcmp+0x20>
    p++, q++;
 10e:	0505                	addi	a0,a0,1
 110:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 112:	00054783          	lbu	a5,0(a0)
 116:	fbe5                	bnez	a5,106 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 118:	0005c503          	lbu	a0,0(a1)
}
 11c:	40a7853b          	subw	a0,a5,a0
 120:	60a2                	ld	ra,8(sp)
 122:	6402                	ld	s0,0(sp)
 124:	0141                	addi	sp,sp,16
 126:	8082                	ret

0000000000000128 <strlen>:

uint
strlen(const char *s)
{
 128:	1141                	addi	sp,sp,-16
 12a:	e406                	sd	ra,8(sp)
 12c:	e022                	sd	s0,0(sp)
 12e:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 130:	00054783          	lbu	a5,0(a0)
 134:	cf91                	beqz	a5,150 <strlen+0x28>
 136:	00150793          	addi	a5,a0,1
 13a:	86be                	mv	a3,a5
 13c:	0785                	addi	a5,a5,1
 13e:	fff7c703          	lbu	a4,-1(a5)
 142:	ff65                	bnez	a4,13a <strlen+0x12>
 144:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 148:	60a2                	ld	ra,8(sp)
 14a:	6402                	ld	s0,0(sp)
 14c:	0141                	addi	sp,sp,16
 14e:	8082                	ret
  for(n = 0; s[n]; n++)
 150:	4501                	li	a0,0
 152:	bfdd                	j	148 <strlen+0x20>

0000000000000154 <memset>:

void*
memset(void *dst, int c, uint n)
{
 154:	1141                	addi	sp,sp,-16
 156:	e406                	sd	ra,8(sp)
 158:	e022                	sd	s0,0(sp)
 15a:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 15c:	ca19                	beqz	a2,172 <memset+0x1e>
 15e:	87aa                	mv	a5,a0
 160:	1602                	slli	a2,a2,0x20
 162:	9201                	srli	a2,a2,0x20
 164:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 168:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 16c:	0785                	addi	a5,a5,1
 16e:	fee79de3          	bne	a5,a4,168 <memset+0x14>
  }
  return dst;
}
 172:	60a2                	ld	ra,8(sp)
 174:	6402                	ld	s0,0(sp)
 176:	0141                	addi	sp,sp,16
 178:	8082                	ret

000000000000017a <strchr>:

char*
strchr(const char *s, char c)
{
 17a:	1141                	addi	sp,sp,-16
 17c:	e406                	sd	ra,8(sp)
 17e:	e022                	sd	s0,0(sp)
 180:	0800                	addi	s0,sp,16
  for(; *s; s++)
 182:	00054783          	lbu	a5,0(a0)
 186:	cf81                	beqz	a5,19e <strchr+0x24>
    if(*s == c)
 188:	00f58763          	beq	a1,a5,196 <strchr+0x1c>
  for(; *s; s++)
 18c:	0505                	addi	a0,a0,1
 18e:	00054783          	lbu	a5,0(a0)
 192:	fbfd                	bnez	a5,188 <strchr+0xe>
      return (char*)s;
  return 0;
 194:	4501                	li	a0,0
}
 196:	60a2                	ld	ra,8(sp)
 198:	6402                	ld	s0,0(sp)
 19a:	0141                	addi	sp,sp,16
 19c:	8082                	ret
  return 0;
 19e:	4501                	li	a0,0
 1a0:	bfdd                	j	196 <strchr+0x1c>

00000000000001a2 <gets>:

char*
gets(char *buf, int max)
{
 1a2:	711d                	addi	sp,sp,-96
 1a4:	ec86                	sd	ra,88(sp)
 1a6:	e8a2                	sd	s0,80(sp)
 1a8:	e4a6                	sd	s1,72(sp)
 1aa:	e0ca                	sd	s2,64(sp)
 1ac:	fc4e                	sd	s3,56(sp)
 1ae:	f852                	sd	s4,48(sp)
 1b0:	f456                	sd	s5,40(sp)
 1b2:	f05a                	sd	s6,32(sp)
 1b4:	ec5e                	sd	s7,24(sp)
 1b6:	e862                	sd	s8,16(sp)
 1b8:	1080                	addi	s0,sp,96
 1ba:	8baa                	mv	s7,a0
 1bc:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1be:	892a                	mv	s2,a0
 1c0:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1c2:	faf40b13          	addi	s6,s0,-81
 1c6:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1c8:	8c26                	mv	s8,s1
 1ca:	0014899b          	addiw	s3,s1,1
 1ce:	84ce                	mv	s1,s3
 1d0:	0349d463          	bge	s3,s4,1f8 <gets+0x56>
    cc = read(0, &c, 1);
 1d4:	8656                	mv	a2,s5
 1d6:	85da                	mv	a1,s6
 1d8:	4501                	li	a0,0
 1da:	1bc000ef          	jal	396 <read>
    if(cc < 1)
 1de:	00a05d63          	blez	a0,1f8 <gets+0x56>
      break;
    buf[i++] = c;
 1e2:	faf44783          	lbu	a5,-81(s0)
 1e6:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 1ea:	0905                	addi	s2,s2,1
 1ec:	ff678713          	addi	a4,a5,-10
 1f0:	c319                	beqz	a4,1f6 <gets+0x54>
 1f2:	17cd                	addi	a5,a5,-13
 1f4:	fbf1                	bnez	a5,1c8 <gets+0x26>
    buf[i++] = c;
 1f6:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 1f8:	9c5e                	add	s8,s8,s7
 1fa:	000c0023          	sb	zero,0(s8)
  return buf;
}
 1fe:	855e                	mv	a0,s7
 200:	60e6                	ld	ra,88(sp)
 202:	6446                	ld	s0,80(sp)
 204:	64a6                	ld	s1,72(sp)
 206:	6906                	ld	s2,64(sp)
 208:	79e2                	ld	s3,56(sp)
 20a:	7a42                	ld	s4,48(sp)
 20c:	7aa2                	ld	s5,40(sp)
 20e:	7b02                	ld	s6,32(sp)
 210:	6be2                	ld	s7,24(sp)
 212:	6c42                	ld	s8,16(sp)
 214:	6125                	addi	sp,sp,96
 216:	8082                	ret

0000000000000218 <stat>:

int
stat(const char *n, struct stat *st)
{
 218:	1101                	addi	sp,sp,-32
 21a:	ec06                	sd	ra,24(sp)
 21c:	e822                	sd	s0,16(sp)
 21e:	e04a                	sd	s2,0(sp)
 220:	1000                	addi	s0,sp,32
 222:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 224:	4581                	li	a1,0
 226:	198000ef          	jal	3be <open>
  if(fd < 0)
 22a:	02054263          	bltz	a0,24e <stat+0x36>
 22e:	e426                	sd	s1,8(sp)
 230:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 232:	85ca                	mv	a1,s2
 234:	1a2000ef          	jal	3d6 <fstat>
 238:	892a                	mv	s2,a0
  close(fd);
 23a:	8526                	mv	a0,s1
 23c:	16a000ef          	jal	3a6 <close>
  return r;
 240:	64a2                	ld	s1,8(sp)
}
 242:	854a                	mv	a0,s2
 244:	60e2                	ld	ra,24(sp)
 246:	6442                	ld	s0,16(sp)
 248:	6902                	ld	s2,0(sp)
 24a:	6105                	addi	sp,sp,32
 24c:	8082                	ret
    return -1;
 24e:	57fd                	li	a5,-1
 250:	893e                	mv	s2,a5
 252:	bfc5                	j	242 <stat+0x2a>

0000000000000254 <atoi>:

int
atoi(const char *s)
{
 254:	1141                	addi	sp,sp,-16
 256:	e406                	sd	ra,8(sp)
 258:	e022                	sd	s0,0(sp)
 25a:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 25c:	00054683          	lbu	a3,0(a0)
 260:	fd06879b          	addiw	a5,a3,-48
 264:	0ff7f793          	zext.b	a5,a5
 268:	4625                	li	a2,9
 26a:	02f66963          	bltu	a2,a5,29c <atoi+0x48>
 26e:	872a                	mv	a4,a0
  n = 0;
 270:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 272:	0705                	addi	a4,a4,1
 274:	0025179b          	slliw	a5,a0,0x2
 278:	9fa9                	addw	a5,a5,a0
 27a:	0017979b          	slliw	a5,a5,0x1
 27e:	9fb5                	addw	a5,a5,a3
 280:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 284:	00074683          	lbu	a3,0(a4)
 288:	fd06879b          	addiw	a5,a3,-48
 28c:	0ff7f793          	zext.b	a5,a5
 290:	fef671e3          	bgeu	a2,a5,272 <atoi+0x1e>
  return n;
}
 294:	60a2                	ld	ra,8(sp)
 296:	6402                	ld	s0,0(sp)
 298:	0141                	addi	sp,sp,16
 29a:	8082                	ret
  n = 0;
 29c:	4501                	li	a0,0
 29e:	bfdd                	j	294 <atoi+0x40>

00000000000002a0 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2a0:	1141                	addi	sp,sp,-16
 2a2:	e406                	sd	ra,8(sp)
 2a4:	e022                	sd	s0,0(sp)
 2a6:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2a8:	02b57563          	bgeu	a0,a1,2d2 <memmove+0x32>
    while(n-- > 0)
 2ac:	00c05f63          	blez	a2,2ca <memmove+0x2a>
 2b0:	1602                	slli	a2,a2,0x20
 2b2:	9201                	srli	a2,a2,0x20
 2b4:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2b8:	872a                	mv	a4,a0
      *dst++ = *src++;
 2ba:	0585                	addi	a1,a1,1
 2bc:	0705                	addi	a4,a4,1
 2be:	fff5c683          	lbu	a3,-1(a1)
 2c2:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2c6:	fee79ae3          	bne	a5,a4,2ba <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2ca:	60a2                	ld	ra,8(sp)
 2cc:	6402                	ld	s0,0(sp)
 2ce:	0141                	addi	sp,sp,16
 2d0:	8082                	ret
    while(n-- > 0)
 2d2:	fec05ce3          	blez	a2,2ca <memmove+0x2a>
    dst += n;
 2d6:	00c50733          	add	a4,a0,a2
    src += n;
 2da:	95b2                	add	a1,a1,a2
 2dc:	fff6079b          	addiw	a5,a2,-1
 2e0:	1782                	slli	a5,a5,0x20
 2e2:	9381                	srli	a5,a5,0x20
 2e4:	fff7c793          	not	a5,a5
 2e8:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2ea:	15fd                	addi	a1,a1,-1
 2ec:	177d                	addi	a4,a4,-1
 2ee:	0005c683          	lbu	a3,0(a1)
 2f2:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 2f6:	fef71ae3          	bne	a4,a5,2ea <memmove+0x4a>
 2fa:	bfc1                	j	2ca <memmove+0x2a>

00000000000002fc <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 2fc:	1141                	addi	sp,sp,-16
 2fe:	e406                	sd	ra,8(sp)
 300:	e022                	sd	s0,0(sp)
 302:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 304:	c61d                	beqz	a2,332 <memcmp+0x36>
 306:	1602                	slli	a2,a2,0x20
 308:	9201                	srli	a2,a2,0x20
 30a:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 30e:	00054783          	lbu	a5,0(a0)
 312:	0005c703          	lbu	a4,0(a1)
 316:	00e79863          	bne	a5,a4,326 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 31a:	0505                	addi	a0,a0,1
    p2++;
 31c:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 31e:	fed518e3          	bne	a0,a3,30e <memcmp+0x12>
  }
  return 0;
 322:	4501                	li	a0,0
 324:	a019                	j	32a <memcmp+0x2e>
      return *p1 - *p2;
 326:	40e7853b          	subw	a0,a5,a4
}
 32a:	60a2                	ld	ra,8(sp)
 32c:	6402                	ld	s0,0(sp)
 32e:	0141                	addi	sp,sp,16
 330:	8082                	ret
  return 0;
 332:	4501                	li	a0,0
 334:	bfdd                	j	32a <memcmp+0x2e>

0000000000000336 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 336:	1141                	addi	sp,sp,-16
 338:	e406                	sd	ra,8(sp)
 33a:	e022                	sd	s0,0(sp)
 33c:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 33e:	f63ff0ef          	jal	2a0 <memmove>
}
 342:	60a2                	ld	ra,8(sp)
 344:	6402                	ld	s0,0(sp)
 346:	0141                	addi	sp,sp,16
 348:	8082                	ret

000000000000034a <sbrk>:

char *
sbrk(int n) {
 34a:	1141                	addi	sp,sp,-16
 34c:	e406                	sd	ra,8(sp)
 34e:	e022                	sd	s0,0(sp)
 350:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 352:	4585                	li	a1,1
 354:	0b2000ef          	jal	406 <sys_sbrk>
}
 358:	60a2                	ld	ra,8(sp)
 35a:	6402                	ld	s0,0(sp)
 35c:	0141                	addi	sp,sp,16
 35e:	8082                	ret

0000000000000360 <sbrklazy>:

char *
sbrklazy(int n) {
 360:	1141                	addi	sp,sp,-16
 362:	e406                	sd	ra,8(sp)
 364:	e022                	sd	s0,0(sp)
 366:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 368:	4589                	li	a1,2
 36a:	09c000ef          	jal	406 <sys_sbrk>
}
 36e:	60a2                	ld	ra,8(sp)
 370:	6402                	ld	s0,0(sp)
 372:	0141                	addi	sp,sp,16
 374:	8082                	ret

0000000000000376 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 376:	4885                	li	a7,1
 ecall
 378:	00000073          	ecall
 ret
 37c:	8082                	ret

000000000000037e <exit>:
.global exit
exit:
 li a7, SYS_exit
 37e:	4889                	li	a7,2
 ecall
 380:	00000073          	ecall
 ret
 384:	8082                	ret

0000000000000386 <wait>:
.global wait
wait:
 li a7, SYS_wait
 386:	488d                	li	a7,3
 ecall
 388:	00000073          	ecall
 ret
 38c:	8082                	ret

000000000000038e <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 38e:	4891                	li	a7,4
 ecall
 390:	00000073          	ecall
 ret
 394:	8082                	ret

0000000000000396 <read>:
.global read
read:
 li a7, SYS_read
 396:	4895                	li	a7,5
 ecall
 398:	00000073          	ecall
 ret
 39c:	8082                	ret

000000000000039e <write>:
.global write
write:
 li a7, SYS_write
 39e:	48c1                	li	a7,16
 ecall
 3a0:	00000073          	ecall
 ret
 3a4:	8082                	ret

00000000000003a6 <close>:
.global close
close:
 li a7, SYS_close
 3a6:	48d5                	li	a7,21
 ecall
 3a8:	00000073          	ecall
 ret
 3ac:	8082                	ret

00000000000003ae <kill>:
.global kill
kill:
 li a7, SYS_kill
 3ae:	4899                	li	a7,6
 ecall
 3b0:	00000073          	ecall
 ret
 3b4:	8082                	ret

00000000000003b6 <exec>:
.global exec
exec:
 li a7, SYS_exec
 3b6:	489d                	li	a7,7
 ecall
 3b8:	00000073          	ecall
 ret
 3bc:	8082                	ret

00000000000003be <open>:
.global open
open:
 li a7, SYS_open
 3be:	48bd                	li	a7,15
 ecall
 3c0:	00000073          	ecall
 ret
 3c4:	8082                	ret

00000000000003c6 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3c6:	48c5                	li	a7,17
 ecall
 3c8:	00000073          	ecall
 ret
 3cc:	8082                	ret

00000000000003ce <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3ce:	48c9                	li	a7,18
 ecall
 3d0:	00000073          	ecall
 ret
 3d4:	8082                	ret

00000000000003d6 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3d6:	48a1                	li	a7,8
 ecall
 3d8:	00000073          	ecall
 ret
 3dc:	8082                	ret

00000000000003de <link>:
.global link
link:
 li a7, SYS_link
 3de:	48cd                	li	a7,19
 ecall
 3e0:	00000073          	ecall
 ret
 3e4:	8082                	ret

00000000000003e6 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3e6:	48d1                	li	a7,20
 ecall
 3e8:	00000073          	ecall
 ret
 3ec:	8082                	ret

00000000000003ee <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3ee:	48a5                	li	a7,9
 ecall
 3f0:	00000073          	ecall
 ret
 3f4:	8082                	ret

00000000000003f6 <dup>:
.global dup
dup:
 li a7, SYS_dup
 3f6:	48a9                	li	a7,10
 ecall
 3f8:	00000073          	ecall
 ret
 3fc:	8082                	ret

00000000000003fe <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 3fe:	48ad                	li	a7,11
 ecall
 400:	00000073          	ecall
 ret
 404:	8082                	ret

0000000000000406 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 406:	48b1                	li	a7,12
 ecall
 408:	00000073          	ecall
 ret
 40c:	8082                	ret

000000000000040e <pause>:
.global pause
pause:
 li a7, SYS_pause
 40e:	48b5                	li	a7,13
 ecall
 410:	00000073          	ecall
 ret
 414:	8082                	ret

0000000000000416 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 416:	48b9                	li	a7,14
 ecall
 418:	00000073          	ecall
 ret
 41c:	8082                	ret

000000000000041e <kmemfree>:
.global kmemfree
kmemfree:
 li a7, SYS_kmemfree
 41e:	48d9                	li	a7,22
 ecall
 420:	00000073          	ecall
 ret
 424:	8082                	ret

0000000000000426 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 426:	1101                	addi	sp,sp,-32
 428:	ec06                	sd	ra,24(sp)
 42a:	e822                	sd	s0,16(sp)
 42c:	1000                	addi	s0,sp,32
 42e:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 432:	4605                	li	a2,1
 434:	fef40593          	addi	a1,s0,-17
 438:	f67ff0ef          	jal	39e <write>
}
 43c:	60e2                	ld	ra,24(sp)
 43e:	6442                	ld	s0,16(sp)
 440:	6105                	addi	sp,sp,32
 442:	8082                	ret

0000000000000444 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 444:	715d                	addi	sp,sp,-80
 446:	e486                	sd	ra,72(sp)
 448:	e0a2                	sd	s0,64(sp)
 44a:	f84a                	sd	s2,48(sp)
 44c:	f44e                	sd	s3,40(sp)
 44e:	0880                	addi	s0,sp,80
 450:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  unsigned long long x;

  neg = 0;
  if(sgn && xx < 0){
 452:	c6d1                	beqz	a3,4de <printint+0x9a>
 454:	0805d563          	bgez	a1,4de <printint+0x9a>
    neg = 1;
    x = -xx;
 458:	40b005b3          	neg	a1,a1
    neg = 1;
 45c:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 45e:	fb840993          	addi	s3,s0,-72
  neg = 0;
 462:	86ce                	mv	a3,s3
  i = 0;
 464:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 466:	00000817          	auipc	a6,0x0
 46a:	53a80813          	addi	a6,a6,1338 # 9a0 <digits>
 46e:	88ba                	mv	a7,a4
 470:	0017051b          	addiw	a0,a4,1
 474:	872a                	mv	a4,a0
 476:	02c5f7b3          	remu	a5,a1,a2
 47a:	97c2                	add	a5,a5,a6
 47c:	0007c783          	lbu	a5,0(a5)
 480:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 484:	87ae                	mv	a5,a1
 486:	02c5d5b3          	divu	a1,a1,a2
 48a:	0685                	addi	a3,a3,1
 48c:	fec7f1e3          	bgeu	a5,a2,46e <printint+0x2a>
  if(neg)
 490:	00030c63          	beqz	t1,4a8 <printint+0x64>
    buf[i++] = '-';
 494:	fd050793          	addi	a5,a0,-48
 498:	00878533          	add	a0,a5,s0
 49c:	02d00793          	li	a5,45
 4a0:	fef50423          	sb	a5,-24(a0)
 4a4:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 4a8:	02e05563          	blez	a4,4d2 <printint+0x8e>
 4ac:	fc26                	sd	s1,56(sp)
 4ae:	377d                	addiw	a4,a4,-1
 4b0:	00e984b3          	add	s1,s3,a4
 4b4:	19fd                	addi	s3,s3,-1
 4b6:	99ba                	add	s3,s3,a4
 4b8:	1702                	slli	a4,a4,0x20
 4ba:	9301                	srli	a4,a4,0x20
 4bc:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 4c0:	0004c583          	lbu	a1,0(s1)
 4c4:	854a                	mv	a0,s2
 4c6:	f61ff0ef          	jal	426 <putc>
  while(--i >= 0)
 4ca:	14fd                	addi	s1,s1,-1
 4cc:	ff349ae3          	bne	s1,s3,4c0 <printint+0x7c>
 4d0:	74e2                	ld	s1,56(sp)
}
 4d2:	60a6                	ld	ra,72(sp)
 4d4:	6406                	ld	s0,64(sp)
 4d6:	7942                	ld	s2,48(sp)
 4d8:	79a2                	ld	s3,40(sp)
 4da:	6161                	addi	sp,sp,80
 4dc:	8082                	ret
  neg = 0;
 4de:	4301                	li	t1,0
 4e0:	bfbd                	j	45e <printint+0x1a>

00000000000004e2 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 4e2:	711d                	addi	sp,sp,-96
 4e4:	ec86                	sd	ra,88(sp)
 4e6:	e8a2                	sd	s0,80(sp)
 4e8:	e4a6                	sd	s1,72(sp)
 4ea:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 4ec:	0005c483          	lbu	s1,0(a1)
 4f0:	22048363          	beqz	s1,716 <vprintf+0x234>
 4f4:	e0ca                	sd	s2,64(sp)
 4f6:	fc4e                	sd	s3,56(sp)
 4f8:	f852                	sd	s4,48(sp)
 4fa:	f456                	sd	s5,40(sp)
 4fc:	f05a                	sd	s6,32(sp)
 4fe:	ec5e                	sd	s7,24(sp)
 500:	e862                	sd	s8,16(sp)
 502:	8b2a                	mv	s6,a0
 504:	8a2e                	mv	s4,a1
 506:	8bb2                	mv	s7,a2
  state = 0;
 508:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 50a:	4901                	li	s2,0
 50c:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 50e:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 512:	06400c13          	li	s8,100
 516:	a00d                	j	538 <vprintf+0x56>
        putc(fd, c0);
 518:	85a6                	mv	a1,s1
 51a:	855a                	mv	a0,s6
 51c:	f0bff0ef          	jal	426 <putc>
 520:	a019                	j	526 <vprintf+0x44>
    } else if(state == '%'){
 522:	03598363          	beq	s3,s5,548 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 526:	0019079b          	addiw	a5,s2,1
 52a:	893e                	mv	s2,a5
 52c:	873e                	mv	a4,a5
 52e:	97d2                	add	a5,a5,s4
 530:	0007c483          	lbu	s1,0(a5)
 534:	1c048a63          	beqz	s1,708 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 538:	0004879b          	sext.w	a5,s1
    if(state == 0){
 53c:	fe0993e3          	bnez	s3,522 <vprintf+0x40>
      if(c0 == '%'){
 540:	fd579ce3          	bne	a5,s5,518 <vprintf+0x36>
        state = '%';
 544:	89be                	mv	s3,a5
 546:	b7c5                	j	526 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 548:	00ea06b3          	add	a3,s4,a4
 54c:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 550:	1c060863          	beqz	a2,720 <vprintf+0x23e>
      if(c0 == 'd'){
 554:	03878763          	beq	a5,s8,582 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 558:	f9478693          	addi	a3,a5,-108
 55c:	0016b693          	seqz	a3,a3
 560:	f9c60593          	addi	a1,a2,-100
 564:	e99d                	bnez	a1,59a <vprintf+0xb8>
 566:	ca95                	beqz	a3,59a <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 568:	008b8493          	addi	s1,s7,8
 56c:	4685                	li	a3,1
 56e:	4629                	li	a2,10
 570:	000bb583          	ld	a1,0(s7)
 574:	855a                	mv	a0,s6
 576:	ecfff0ef          	jal	444 <printint>
        i += 1;
 57a:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 57c:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 57e:	4981                	li	s3,0
 580:	b75d                	j	526 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 582:	008b8493          	addi	s1,s7,8
 586:	4685                	li	a3,1
 588:	4629                	li	a2,10
 58a:	000ba583          	lw	a1,0(s7)
 58e:	855a                	mv	a0,s6
 590:	eb5ff0ef          	jal	444 <printint>
 594:	8ba6                	mv	s7,s1
      state = 0;
 596:	4981                	li	s3,0
 598:	b779                	j	526 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 59a:	9752                	add	a4,a4,s4
 59c:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 5a0:	f9460713          	addi	a4,a2,-108
 5a4:	00173713          	seqz	a4,a4
 5a8:	8f75                	and	a4,a4,a3
 5aa:	f9c58513          	addi	a0,a1,-100
 5ae:	18051363          	bnez	a0,734 <vprintf+0x252>
 5b2:	18070163          	beqz	a4,734 <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5b6:	008b8493          	addi	s1,s7,8
 5ba:	4685                	li	a3,1
 5bc:	4629                	li	a2,10
 5be:	000bb583          	ld	a1,0(s7)
 5c2:	855a                	mv	a0,s6
 5c4:	e81ff0ef          	jal	444 <printint>
        i += 2;
 5c8:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 5ca:	8ba6                	mv	s7,s1
      state = 0;
 5cc:	4981                	li	s3,0
        i += 2;
 5ce:	bfa1                	j	526 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 5d0:	008b8493          	addi	s1,s7,8
 5d4:	4681                	li	a3,0
 5d6:	4629                	li	a2,10
 5d8:	000be583          	lwu	a1,0(s7)
 5dc:	855a                	mv	a0,s6
 5de:	e67ff0ef          	jal	444 <printint>
 5e2:	8ba6                	mv	s7,s1
      state = 0;
 5e4:	4981                	li	s3,0
 5e6:	b781                	j	526 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 5e8:	008b8493          	addi	s1,s7,8
 5ec:	4681                	li	a3,0
 5ee:	4629                	li	a2,10
 5f0:	000bb583          	ld	a1,0(s7)
 5f4:	855a                	mv	a0,s6
 5f6:	e4fff0ef          	jal	444 <printint>
        i += 1;
 5fa:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 5fc:	8ba6                	mv	s7,s1
      state = 0;
 5fe:	4981                	li	s3,0
 600:	b71d                	j	526 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 602:	008b8493          	addi	s1,s7,8
 606:	4681                	li	a3,0
 608:	4629                	li	a2,10
 60a:	000bb583          	ld	a1,0(s7)
 60e:	855a                	mv	a0,s6
 610:	e35ff0ef          	jal	444 <printint>
        i += 2;
 614:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 616:	8ba6                	mv	s7,s1
      state = 0;
 618:	4981                	li	s3,0
        i += 2;
 61a:	b731                	j	526 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 61c:	008b8493          	addi	s1,s7,8
 620:	4681                	li	a3,0
 622:	4641                	li	a2,16
 624:	000be583          	lwu	a1,0(s7)
 628:	855a                	mv	a0,s6
 62a:	e1bff0ef          	jal	444 <printint>
 62e:	8ba6                	mv	s7,s1
      state = 0;
 630:	4981                	li	s3,0
 632:	bdd5                	j	526 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 634:	008b8493          	addi	s1,s7,8
 638:	4681                	li	a3,0
 63a:	4641                	li	a2,16
 63c:	000bb583          	ld	a1,0(s7)
 640:	855a                	mv	a0,s6
 642:	e03ff0ef          	jal	444 <printint>
        i += 1;
 646:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 648:	8ba6                	mv	s7,s1
      state = 0;
 64a:	4981                	li	s3,0
 64c:	bde9                	j	526 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 64e:	008b8493          	addi	s1,s7,8
 652:	4681                	li	a3,0
 654:	4641                	li	a2,16
 656:	000bb583          	ld	a1,0(s7)
 65a:	855a                	mv	a0,s6
 65c:	de9ff0ef          	jal	444 <printint>
        i += 2;
 660:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 662:	8ba6                	mv	s7,s1
      state = 0;
 664:	4981                	li	s3,0
        i += 2;
 666:	b5c1                	j	526 <vprintf+0x44>
 668:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 66a:	008b8793          	addi	a5,s7,8
 66e:	8cbe                	mv	s9,a5
 670:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 674:	03000593          	li	a1,48
 678:	855a                	mv	a0,s6
 67a:	dadff0ef          	jal	426 <putc>
  putc(fd, 'x');
 67e:	07800593          	li	a1,120
 682:	855a                	mv	a0,s6
 684:	da3ff0ef          	jal	426 <putc>
 688:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 68a:	00000b97          	auipc	s7,0x0
 68e:	316b8b93          	addi	s7,s7,790 # 9a0 <digits>
 692:	03c9d793          	srli	a5,s3,0x3c
 696:	97de                	add	a5,a5,s7
 698:	0007c583          	lbu	a1,0(a5)
 69c:	855a                	mv	a0,s6
 69e:	d89ff0ef          	jal	426 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 6a2:	0992                	slli	s3,s3,0x4
 6a4:	34fd                	addiw	s1,s1,-1
 6a6:	f4f5                	bnez	s1,692 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 6a8:	8be6                	mv	s7,s9
      state = 0;
 6aa:	4981                	li	s3,0
 6ac:	6ca2                	ld	s9,8(sp)
 6ae:	bda5                	j	526 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 6b0:	008b8493          	addi	s1,s7,8
 6b4:	000bc583          	lbu	a1,0(s7)
 6b8:	855a                	mv	a0,s6
 6ba:	d6dff0ef          	jal	426 <putc>
 6be:	8ba6                	mv	s7,s1
      state = 0;
 6c0:	4981                	li	s3,0
 6c2:	b595                	j	526 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 6c4:	008b8993          	addi	s3,s7,8
 6c8:	000bb483          	ld	s1,0(s7)
 6cc:	cc91                	beqz	s1,6e8 <vprintf+0x206>
        for(; *s; s++)
 6ce:	0004c583          	lbu	a1,0(s1)
 6d2:	c985                	beqz	a1,702 <vprintf+0x220>
          putc(fd, *s);
 6d4:	855a                	mv	a0,s6
 6d6:	d51ff0ef          	jal	426 <putc>
        for(; *s; s++)
 6da:	0485                	addi	s1,s1,1
 6dc:	0004c583          	lbu	a1,0(s1)
 6e0:	f9f5                	bnez	a1,6d4 <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 6e2:	8bce                	mv	s7,s3
      state = 0;
 6e4:	4981                	li	s3,0
 6e6:	b581                	j	526 <vprintf+0x44>
          s = "(null)";
 6e8:	00000497          	auipc	s1,0x0
 6ec:	2b048493          	addi	s1,s1,688 # 998 <malloc+0x114>
        for(; *s; s++)
 6f0:	02800593          	li	a1,40
 6f4:	b7c5                	j	6d4 <vprintf+0x1f2>
        putc(fd, '%');
 6f6:	85be                	mv	a1,a5
 6f8:	855a                	mv	a0,s6
 6fa:	d2dff0ef          	jal	426 <putc>
      state = 0;
 6fe:	4981                	li	s3,0
 700:	b51d                	j	526 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 702:	8bce                	mv	s7,s3
      state = 0;
 704:	4981                	li	s3,0
 706:	b505                	j	526 <vprintf+0x44>
 708:	6906                	ld	s2,64(sp)
 70a:	79e2                	ld	s3,56(sp)
 70c:	7a42                	ld	s4,48(sp)
 70e:	7aa2                	ld	s5,40(sp)
 710:	7b02                	ld	s6,32(sp)
 712:	6be2                	ld	s7,24(sp)
 714:	6c42                	ld	s8,16(sp)
    }
  }
}
 716:	60e6                	ld	ra,88(sp)
 718:	6446                	ld	s0,80(sp)
 71a:	64a6                	ld	s1,72(sp)
 71c:	6125                	addi	sp,sp,96
 71e:	8082                	ret
      if(c0 == 'd'){
 720:	06400713          	li	a4,100
 724:	e4e78fe3          	beq	a5,a4,582 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 728:	f9478693          	addi	a3,a5,-108
 72c:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 730:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 732:	4701                	li	a4,0
      } else if(c0 == 'u'){
 734:	07500513          	li	a0,117
 738:	e8a78ce3          	beq	a5,a0,5d0 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 73c:	f8b60513          	addi	a0,a2,-117
 740:	e119                	bnez	a0,746 <vprintf+0x264>
 742:	ea0693e3          	bnez	a3,5e8 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 746:	f8b58513          	addi	a0,a1,-117
 74a:	e119                	bnez	a0,750 <vprintf+0x26e>
 74c:	ea071be3          	bnez	a4,602 <vprintf+0x120>
      } else if(c0 == 'x'){
 750:	07800513          	li	a0,120
 754:	eca784e3          	beq	a5,a0,61c <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 758:	f8860613          	addi	a2,a2,-120
 75c:	e219                	bnez	a2,762 <vprintf+0x280>
 75e:	ec069be3          	bnez	a3,634 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 762:	f8858593          	addi	a1,a1,-120
 766:	e199                	bnez	a1,76c <vprintf+0x28a>
 768:	ee0713e3          	bnez	a4,64e <vprintf+0x16c>
      } else if(c0 == 'p'){
 76c:	07000713          	li	a4,112
 770:	eee78ce3          	beq	a5,a4,668 <vprintf+0x186>
      } else if(c0 == 'c'){
 774:	06300713          	li	a4,99
 778:	f2e78ce3          	beq	a5,a4,6b0 <vprintf+0x1ce>
      } else if(c0 == 's'){
 77c:	07300713          	li	a4,115
 780:	f4e782e3          	beq	a5,a4,6c4 <vprintf+0x1e2>
      } else if(c0 == '%'){
 784:	02500713          	li	a4,37
 788:	f6e787e3          	beq	a5,a4,6f6 <vprintf+0x214>
        putc(fd, '%');
 78c:	02500593          	li	a1,37
 790:	855a                	mv	a0,s6
 792:	c95ff0ef          	jal	426 <putc>
        putc(fd, c0);
 796:	85a6                	mv	a1,s1
 798:	855a                	mv	a0,s6
 79a:	c8dff0ef          	jal	426 <putc>
      state = 0;
 79e:	4981                	li	s3,0
 7a0:	b359                	j	526 <vprintf+0x44>

00000000000007a2 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 7a2:	715d                	addi	sp,sp,-80
 7a4:	ec06                	sd	ra,24(sp)
 7a6:	e822                	sd	s0,16(sp)
 7a8:	1000                	addi	s0,sp,32
 7aa:	e010                	sd	a2,0(s0)
 7ac:	e414                	sd	a3,8(s0)
 7ae:	e818                	sd	a4,16(s0)
 7b0:	ec1c                	sd	a5,24(s0)
 7b2:	03043023          	sd	a6,32(s0)
 7b6:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7ba:	8622                	mv	a2,s0
 7bc:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7c0:	d23ff0ef          	jal	4e2 <vprintf>
}
 7c4:	60e2                	ld	ra,24(sp)
 7c6:	6442                	ld	s0,16(sp)
 7c8:	6161                	addi	sp,sp,80
 7ca:	8082                	ret

00000000000007cc <printf>:

void
printf(const char *fmt, ...)
{
 7cc:	711d                	addi	sp,sp,-96
 7ce:	ec06                	sd	ra,24(sp)
 7d0:	e822                	sd	s0,16(sp)
 7d2:	1000                	addi	s0,sp,32
 7d4:	e40c                	sd	a1,8(s0)
 7d6:	e810                	sd	a2,16(s0)
 7d8:	ec14                	sd	a3,24(s0)
 7da:	f018                	sd	a4,32(s0)
 7dc:	f41c                	sd	a5,40(s0)
 7de:	03043823          	sd	a6,48(s0)
 7e2:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 7e6:	00840613          	addi	a2,s0,8
 7ea:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 7ee:	85aa                	mv	a1,a0
 7f0:	4505                	li	a0,1
 7f2:	cf1ff0ef          	jal	4e2 <vprintf>
}
 7f6:	60e2                	ld	ra,24(sp)
 7f8:	6442                	ld	s0,16(sp)
 7fa:	6125                	addi	sp,sp,96
 7fc:	8082                	ret

00000000000007fe <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 7fe:	1141                	addi	sp,sp,-16
 800:	e406                	sd	ra,8(sp)
 802:	e022                	sd	s0,0(sp)
 804:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 806:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 80a:	00000797          	auipc	a5,0x0
 80e:	7f67b783          	ld	a5,2038(a5) # 1000 <freep>
 812:	a039                	j	820 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 814:	6398                	ld	a4,0(a5)
 816:	00e7e463          	bltu	a5,a4,81e <free+0x20>
 81a:	00e6ea63          	bltu	a3,a4,82e <free+0x30>
{
 81e:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 820:	fed7fae3          	bgeu	a5,a3,814 <free+0x16>
 824:	6398                	ld	a4,0(a5)
 826:	00e6e463          	bltu	a3,a4,82e <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 82a:	fee7eae3          	bltu	a5,a4,81e <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 82e:	ff852583          	lw	a1,-8(a0)
 832:	6390                	ld	a2,0(a5)
 834:	02059813          	slli	a6,a1,0x20
 838:	01c85713          	srli	a4,a6,0x1c
 83c:	9736                	add	a4,a4,a3
 83e:	02e60563          	beq	a2,a4,868 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 842:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 846:	4790                	lw	a2,8(a5)
 848:	02061593          	slli	a1,a2,0x20
 84c:	01c5d713          	srli	a4,a1,0x1c
 850:	973e                	add	a4,a4,a5
 852:	02e68263          	beq	a3,a4,876 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 856:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 858:	00000717          	auipc	a4,0x0
 85c:	7af73423          	sd	a5,1960(a4) # 1000 <freep>
}
 860:	60a2                	ld	ra,8(sp)
 862:	6402                	ld	s0,0(sp)
 864:	0141                	addi	sp,sp,16
 866:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 868:	4618                	lw	a4,8(a2)
 86a:	9f2d                	addw	a4,a4,a1
 86c:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 870:	6398                	ld	a4,0(a5)
 872:	6310                	ld	a2,0(a4)
 874:	b7f9                	j	842 <free+0x44>
    p->s.size += bp->s.size;
 876:	ff852703          	lw	a4,-8(a0)
 87a:	9f31                	addw	a4,a4,a2
 87c:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 87e:	ff053683          	ld	a3,-16(a0)
 882:	bfd1                	j	856 <free+0x58>

0000000000000884 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 884:	7139                	addi	sp,sp,-64
 886:	fc06                	sd	ra,56(sp)
 888:	f822                	sd	s0,48(sp)
 88a:	f04a                	sd	s2,32(sp)
 88c:	ec4e                	sd	s3,24(sp)
 88e:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 890:	02051993          	slli	s3,a0,0x20
 894:	0209d993          	srli	s3,s3,0x20
 898:	09bd                	addi	s3,s3,15
 89a:	0049d993          	srli	s3,s3,0x4
 89e:	2985                	addiw	s3,s3,1
 8a0:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 8a2:	00000517          	auipc	a0,0x0
 8a6:	75e53503          	ld	a0,1886(a0) # 1000 <freep>
 8aa:	c905                	beqz	a0,8da <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8ac:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8ae:	4798                	lw	a4,8(a5)
 8b0:	09377663          	bgeu	a4,s3,93c <malloc+0xb8>
 8b4:	f426                	sd	s1,40(sp)
 8b6:	e852                	sd	s4,16(sp)
 8b8:	e456                	sd	s5,8(sp)
 8ba:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 8bc:	8a4e                	mv	s4,s3
 8be:	6705                	lui	a4,0x1
 8c0:	00e9f363          	bgeu	s3,a4,8c6 <malloc+0x42>
 8c4:	6a05                	lui	s4,0x1
 8c6:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8ca:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 8ce:	00000497          	auipc	s1,0x0
 8d2:	73248493          	addi	s1,s1,1842 # 1000 <freep>
  if(p == SBRK_ERROR)
 8d6:	5afd                	li	s5,-1
 8d8:	a83d                	j	916 <malloc+0x92>
 8da:	f426                	sd	s1,40(sp)
 8dc:	e852                	sd	s4,16(sp)
 8de:	e456                	sd	s5,8(sp)
 8e0:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 8e2:	00000797          	auipc	a5,0x0
 8e6:	72e78793          	addi	a5,a5,1838 # 1010 <base>
 8ea:	00000717          	auipc	a4,0x0
 8ee:	70f73b23          	sd	a5,1814(a4) # 1000 <freep>
 8f2:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 8f4:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 8f8:	b7d1                	j	8bc <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 8fa:	6398                	ld	a4,0(a5)
 8fc:	e118                	sd	a4,0(a0)
 8fe:	a899                	j	954 <malloc+0xd0>
  hp->s.size = nu;
 900:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 904:	0541                	addi	a0,a0,16
 906:	ef9ff0ef          	jal	7fe <free>
  return freep;
 90a:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 90c:	c125                	beqz	a0,96c <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 90e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 910:	4798                	lw	a4,8(a5)
 912:	03277163          	bgeu	a4,s2,934 <malloc+0xb0>
    if(p == freep)
 916:	6098                	ld	a4,0(s1)
 918:	853e                	mv	a0,a5
 91a:	fef71ae3          	bne	a4,a5,90e <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 91e:	8552                	mv	a0,s4
 920:	a2bff0ef          	jal	34a <sbrk>
  if(p == SBRK_ERROR)
 924:	fd551ee3          	bne	a0,s5,900 <malloc+0x7c>
        return 0;
 928:	4501                	li	a0,0
 92a:	74a2                	ld	s1,40(sp)
 92c:	6a42                	ld	s4,16(sp)
 92e:	6aa2                	ld	s5,8(sp)
 930:	6b02                	ld	s6,0(sp)
 932:	a03d                	j	960 <malloc+0xdc>
 934:	74a2                	ld	s1,40(sp)
 936:	6a42                	ld	s4,16(sp)
 938:	6aa2                	ld	s5,8(sp)
 93a:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 93c:	fae90fe3          	beq	s2,a4,8fa <malloc+0x76>
        p->s.size -= nunits;
 940:	4137073b          	subw	a4,a4,s3
 944:	c798                	sw	a4,8(a5)
        p += p->s.size;
 946:	02071693          	slli	a3,a4,0x20
 94a:	01c6d713          	srli	a4,a3,0x1c
 94e:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 950:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 954:	00000717          	auipc	a4,0x0
 958:	6aa73623          	sd	a0,1708(a4) # 1000 <freep>
      return (void*)(p + 1);
 95c:	01078513          	addi	a0,a5,16
  }
}
 960:	70e2                	ld	ra,56(sp)
 962:	7442                	ld	s0,48(sp)
 964:	7902                	ld	s2,32(sp)
 966:	69e2                	ld	s3,24(sp)
 968:	6121                	addi	sp,sp,64
 96a:	8082                	ret
 96c:	74a2                	ld	s1,40(sp)
 96e:	6a42                	ld	s4,16(sp)
 970:	6aa2                	ld	s5,8(sp)
 972:	6b02                	ld	s6,0(sp)
 974:	b7f5                	j	960 <malloc+0xdc>
