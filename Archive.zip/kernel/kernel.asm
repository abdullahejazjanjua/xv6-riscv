
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
    80000000:	00008117          	auipc	sp,0x8
    80000004:	87010113          	addi	sp,sp,-1936 # 80007870 <stack0>
    80000008:	6505                	lui	a0,0x1
    8000000a:	f14025f3          	csrr	a1,mhartid
    8000000e:	0585                	addi	a1,a1,1
    80000010:	02b50533          	mul	a0,a0,a1
    80000014:	912a                	add	sp,sp,a0
    80000016:	04e000ef          	jal	80000064 <start>

000000008000001a <spin>:
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000024:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000028:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002c:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80000030:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000034:	577d                	li	a4,-1
    80000036:	177e                	slli	a4,a4,0x3f
    80000038:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    8000003a:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003e:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000042:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000046:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    8000004a:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004e:	000f4737          	lui	a4,0xf4
    80000052:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000056:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000058:	14d79073          	csrw	stimecmp,a5
}
    8000005c:	60a2                	ld	ra,8(sp)
    8000005e:	6402                	ld	s0,0(sp)
    80000060:	0141                	addi	sp,sp,16
    80000062:	8082                	ret

0000000080000064 <start>:
{
    80000064:	1141                	addi	sp,sp,-16
    80000066:	e406                	sd	ra,8(sp)
    80000068:	e022                	sd	s0,0(sp)
    8000006a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000070:	7779                	lui	a4,0xffffe
    80000072:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7ffddc87>
    80000076:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000078:	6705                	lui	a4,0x1
    8000007a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000080:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000084:	00001797          	auipc	a5,0x1
    80000088:	e5278793          	addi	a5,a5,-430 # 80000ed6 <main>
    8000008c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80000090:	4781                	li	a5,0
    80000092:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000096:	67c1                	lui	a5,0x10
    80000098:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000009a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000a2:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a6:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000aa:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000ae:	57fd                	li	a5,-1
    800000b0:	83a9                	srli	a5,a5,0xa
    800000b2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b6:	47bd                	li	a5,15
    800000b8:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000bc:	f61ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000c0:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c4:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c6:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c8:	30200073          	mret
}
    800000cc:	60a2                	ld	ra,8(sp)
    800000ce:	6402                	ld	s0,0(sp)
    800000d0:	0141                	addi	sp,sp,16
    800000d2:	8082                	ret

00000000800000d4 <consolewrite>:
// user write() system calls to the console go here.
// uses sleep() and UART interrupts.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d4:	7119                	addi	sp,sp,-128
    800000d6:	fc86                	sd	ra,120(sp)
    800000d8:	f8a2                	sd	s0,112(sp)
    800000da:	f4a6                	sd	s1,104(sp)
    800000dc:	0100                	addi	s0,sp,128
  char buf[32]; // move batches from user space to uart.
  int i = 0;

  while(i < n){
    800000de:	06c05b63          	blez	a2,80000154 <consolewrite+0x80>
    800000e2:	f0ca                	sd	s2,96(sp)
    800000e4:	ecce                	sd	s3,88(sp)
    800000e6:	e8d2                	sd	s4,80(sp)
    800000e8:	e4d6                	sd	s5,72(sp)
    800000ea:	e0da                	sd	s6,64(sp)
    800000ec:	fc5e                	sd	s7,56(sp)
    800000ee:	f862                	sd	s8,48(sp)
    800000f0:	f466                	sd	s9,40(sp)
    800000f2:	f06a                	sd	s10,32(sp)
    800000f4:	8b2a                	mv	s6,a0
    800000f6:	8bae                	mv	s7,a1
    800000f8:	8a32                	mv	s4,a2
  int i = 0;
    800000fa:	4481                	li	s1,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000fc:	02000c93          	li	s9,32
    80000100:	02000d13          	li	s10,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000104:	f8040a93          	addi	s5,s0,-128
    80000108:	5c7d                	li	s8,-1
    8000010a:	a025                	j	80000132 <consolewrite+0x5e>
    if(nn > n - i)
    8000010c:	0009099b          	sext.w	s3,s2
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000110:	86ce                	mv	a3,s3
    80000112:	01748633          	add	a2,s1,s7
    80000116:	85da                	mv	a1,s6
    80000118:	8556                	mv	a0,s5
    8000011a:	1f0020ef          	jal	8000230a <either_copyin>
    8000011e:	03850d63          	beq	a0,s8,80000158 <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000122:	85ce                	mv	a1,s3
    80000124:	8556                	mv	a0,s5
    80000126:	7b4000ef          	jal	800008da <uartwrite>
    i += nn;
    8000012a:	009904bb          	addw	s1,s2,s1
  while(i < n){
    8000012e:	0144d963          	bge	s1,s4,80000140 <consolewrite+0x6c>
    if(nn > n - i)
    80000132:	409a07bb          	subw	a5,s4,s1
    80000136:	893e                	mv	s2,a5
    80000138:	fcfcdae3          	bge	s9,a5,8000010c <consolewrite+0x38>
    8000013c:	896a                	mv	s2,s10
    8000013e:	b7f9                	j	8000010c <consolewrite+0x38>
    80000140:	7906                	ld	s2,96(sp)
    80000142:	69e6                	ld	s3,88(sp)
    80000144:	6a46                	ld	s4,80(sp)
    80000146:	6aa6                	ld	s5,72(sp)
    80000148:	6b06                	ld	s6,64(sp)
    8000014a:	7be2                	ld	s7,56(sp)
    8000014c:	7c42                	ld	s8,48(sp)
    8000014e:	7ca2                	ld	s9,40(sp)
    80000150:	7d02                	ld	s10,32(sp)
    80000152:	a821                	j	8000016a <consolewrite+0x96>
  int i = 0;
    80000154:	4481                	li	s1,0
    80000156:	a811                	j	8000016a <consolewrite+0x96>
    80000158:	7906                	ld	s2,96(sp)
    8000015a:	69e6                	ld	s3,88(sp)
    8000015c:	6a46                	ld	s4,80(sp)
    8000015e:	6aa6                	ld	s5,72(sp)
    80000160:	6b06                	ld	s6,64(sp)
    80000162:	7be2                	ld	s7,56(sp)
    80000164:	7c42                	ld	s8,48(sp)
    80000166:	7ca2                	ld	s9,40(sp)
    80000168:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016a:	8526                	mv	a0,s1
    8000016c:	70e6                	ld	ra,120(sp)
    8000016e:	7446                	ld	s0,112(sp)
    80000170:	74a6                	ld	s1,104(sp)
    80000172:	6109                	addi	sp,sp,128
    80000174:	8082                	ret

0000000080000176 <consoleread>:
// user_dst indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000176:	711d                	addi	sp,sp,-96
    80000178:	ec86                	sd	ra,88(sp)
    8000017a:	e8a2                	sd	s0,80(sp)
    8000017c:	e4a6                	sd	s1,72(sp)
    8000017e:	e0ca                	sd	s2,64(sp)
    80000180:	fc4e                	sd	s3,56(sp)
    80000182:	f852                	sd	s4,48(sp)
    80000184:	f05a                	sd	s6,32(sp)
    80000186:	ec5e                	sd	s7,24(sp)
    80000188:	1080                	addi	s0,sp,96
    8000018a:	8b2a                	mv	s6,a0
    8000018c:	8a2e                	mv	s4,a1
    8000018e:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000190:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000192:	0000f517          	auipc	a0,0xf
    80000196:	6de50513          	addi	a0,a0,1758 # 8000f870 <cons>
    8000019a:	2b7000ef          	jal	80000c50 <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000019e:	0000f497          	auipc	s1,0xf
    800001a2:	6d248493          	addi	s1,s1,1746 # 8000f870 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a6:	0000f917          	auipc	s2,0xf
    800001aa:	76290913          	addi	s2,s2,1890 # 8000f908 <cons+0x98>
  while(n > 0){
    800001ae:	0b305b63          	blez	s3,80000264 <consoleread+0xee>
    while(cons.r == cons.w){
    800001b2:	0984a783          	lw	a5,152(s1)
    800001b6:	09c4a703          	lw	a4,156(s1)
    800001ba:	0af71063          	bne	a4,a5,8000025a <consoleread+0xe4>
      if(killed(myproc())){
    800001be:	798010ef          	jal	80001956 <myproc>
    800001c2:	7e1010ef          	jal	800021a2 <killed>
    800001c6:	e12d                	bnez	a0,80000228 <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    800001c8:	85a6                	mv	a1,s1
    800001ca:	854a                	mv	a0,s2
    800001cc:	59b010ef          	jal	80001f66 <sleep>
    while(cons.r == cons.w){
    800001d0:	0984a783          	lw	a5,152(s1)
    800001d4:	09c4a703          	lw	a4,156(s1)
    800001d8:	fef703e3          	beq	a4,a5,800001be <consoleread+0x48>
    800001dc:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001de:	0000f717          	auipc	a4,0xf
    800001e2:	69270713          	addi	a4,a4,1682 # 8000f870 <cons>
    800001e6:	0017869b          	addiw	a3,a5,1
    800001ea:	08d72c23          	sw	a3,152(a4)
    800001ee:	07f7f693          	andi	a3,a5,127
    800001f2:	9736                	add	a4,a4,a3
    800001f4:	01874703          	lbu	a4,24(a4)
    800001f8:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800001fc:	4691                	li	a3,4
    800001fe:	04da8663          	beq	s5,a3,8000024a <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000202:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000206:	4685                	li	a3,1
    80000208:	faf40613          	addi	a2,s0,-81
    8000020c:	85d2                	mv	a1,s4
    8000020e:	855a                	mv	a0,s6
    80000210:	0b0020ef          	jal	800022c0 <either_copyout>
    80000214:	57fd                	li	a5,-1
    80000216:	04f50663          	beq	a0,a5,80000262 <consoleread+0xec>
      break;

    dst++;
    8000021a:	0a05                	addi	s4,s4,1
    --n;
    8000021c:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    8000021e:	47a9                	li	a5,10
    80000220:	04fa8b63          	beq	s5,a5,80000276 <consoleread+0x100>
    80000224:	7aa2                	ld	s5,40(sp)
    80000226:	b761                	j	800001ae <consoleread+0x38>
        release(&cons.lock);
    80000228:	0000f517          	auipc	a0,0xf
    8000022c:	64850513          	addi	a0,a0,1608 # 8000f870 <cons>
    80000230:	2b5000ef          	jal	80000ce4 <release>
        return -1;
    80000234:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000236:	60e6                	ld	ra,88(sp)
    80000238:	6446                	ld	s0,80(sp)
    8000023a:	64a6                	ld	s1,72(sp)
    8000023c:	6906                	ld	s2,64(sp)
    8000023e:	79e2                	ld	s3,56(sp)
    80000240:	7a42                	ld	s4,48(sp)
    80000242:	7b02                	ld	s6,32(sp)
    80000244:	6be2                	ld	s7,24(sp)
    80000246:	6125                	addi	sp,sp,96
    80000248:	8082                	ret
      if(n < target){
    8000024a:	0179fa63          	bgeu	s3,s7,8000025e <consoleread+0xe8>
        cons.r--;
    8000024e:	0000f717          	auipc	a4,0xf
    80000252:	6af72d23          	sw	a5,1722(a4) # 8000f908 <cons+0x98>
    80000256:	7aa2                	ld	s5,40(sp)
    80000258:	a031                	j	80000264 <consoleread+0xee>
    8000025a:	f456                	sd	s5,40(sp)
    8000025c:	b749                	j	800001de <consoleread+0x68>
    8000025e:	7aa2                	ld	s5,40(sp)
    80000260:	a011                	j	80000264 <consoleread+0xee>
    80000262:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000264:	0000f517          	auipc	a0,0xf
    80000268:	60c50513          	addi	a0,a0,1548 # 8000f870 <cons>
    8000026c:	279000ef          	jal	80000ce4 <release>
  return target - n;
    80000270:	413b853b          	subw	a0,s7,s3
    80000274:	b7c9                	j	80000236 <consoleread+0xc0>
    80000276:	7aa2                	ld	s5,40(sp)
    80000278:	b7f5                	j	80000264 <consoleread+0xee>

000000008000027a <consputc>:
{
    8000027a:	1141                	addi	sp,sp,-16
    8000027c:	e406                	sd	ra,8(sp)
    8000027e:	e022                	sd	s0,0(sp)
    80000280:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000282:	10000793          	li	a5,256
    80000286:	00f50863          	beq	a0,a5,80000296 <consputc+0x1c>
    uartputc_sync(c);
    8000028a:	6e4000ef          	jal	8000096e <uartputc_sync>
}
    8000028e:	60a2                	ld	ra,8(sp)
    80000290:	6402                	ld	s0,0(sp)
    80000292:	0141                	addi	sp,sp,16
    80000294:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000296:	4521                	li	a0,8
    80000298:	6d6000ef          	jal	8000096e <uartputc_sync>
    8000029c:	02000513          	li	a0,32
    800002a0:	6ce000ef          	jal	8000096e <uartputc_sync>
    800002a4:	4521                	li	a0,8
    800002a6:	6c8000ef          	jal	8000096e <uartputc_sync>
    800002aa:	b7d5                	j	8000028e <consputc+0x14>

00000000800002ac <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002ac:	1101                	addi	sp,sp,-32
    800002ae:	ec06                	sd	ra,24(sp)
    800002b0:	e822                	sd	s0,16(sp)
    800002b2:	e426                	sd	s1,8(sp)
    800002b4:	1000                	addi	s0,sp,32
    800002b6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b8:	0000f517          	auipc	a0,0xf
    800002bc:	5b850513          	addi	a0,a0,1464 # 8000f870 <cons>
    800002c0:	191000ef          	jal	80000c50 <acquire>

  switch(c){
    800002c4:	47d5                	li	a5,21
    800002c6:	08f48d63          	beq	s1,a5,80000360 <consoleintr+0xb4>
    800002ca:	0297c563          	blt	a5,s1,800002f4 <consoleintr+0x48>
    800002ce:	47a1                	li	a5,8
    800002d0:	0ef48263          	beq	s1,a5,800003b4 <consoleintr+0x108>
    800002d4:	47c1                	li	a5,16
    800002d6:	10f49363          	bne	s1,a5,800003dc <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    800002da:	07a020ef          	jal	80002354 <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002de:	0000f517          	auipc	a0,0xf
    800002e2:	59250513          	addi	a0,a0,1426 # 8000f870 <cons>
    800002e6:	1ff000ef          	jal	80000ce4 <release>
}
    800002ea:	60e2                	ld	ra,24(sp)
    800002ec:	6442                	ld	s0,16(sp)
    800002ee:	64a2                	ld	s1,8(sp)
    800002f0:	6105                	addi	sp,sp,32
    800002f2:	8082                	ret
  switch(c){
    800002f4:	07f00793          	li	a5,127
    800002f8:	0af48e63          	beq	s1,a5,800003b4 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002fc:	0000f717          	auipc	a4,0xf
    80000300:	57470713          	addi	a4,a4,1396 # 8000f870 <cons>
    80000304:	0a072783          	lw	a5,160(a4)
    80000308:	09872703          	lw	a4,152(a4)
    8000030c:	9f99                	subw	a5,a5,a4
    8000030e:	07f00713          	li	a4,127
    80000312:	fcf766e3          	bltu	a4,a5,800002de <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000316:	47b5                	li	a5,13
    80000318:	0cf48563          	beq	s1,a5,800003e2 <consoleintr+0x136>
      consputc(c);
    8000031c:	8526                	mv	a0,s1
    8000031e:	f5dff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000322:	0000f717          	auipc	a4,0xf
    80000326:	54e70713          	addi	a4,a4,1358 # 8000f870 <cons>
    8000032a:	0a072683          	lw	a3,160(a4)
    8000032e:	0016879b          	addiw	a5,a3,1
    80000332:	863e                	mv	a2,a5
    80000334:	0af72023          	sw	a5,160(a4)
    80000338:	07f6f693          	andi	a3,a3,127
    8000033c:	9736                	add	a4,a4,a3
    8000033e:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000342:	ff648713          	addi	a4,s1,-10
    80000346:	c371                	beqz	a4,8000040a <consoleintr+0x15e>
    80000348:	14f1                	addi	s1,s1,-4
    8000034a:	c0e1                	beqz	s1,8000040a <consoleintr+0x15e>
    8000034c:	0000f717          	auipc	a4,0xf
    80000350:	5bc72703          	lw	a4,1468(a4) # 8000f908 <cons+0x98>
    80000354:	9f99                	subw	a5,a5,a4
    80000356:	08000713          	li	a4,128
    8000035a:	f8e792e3          	bne	a5,a4,800002de <consoleintr+0x32>
    8000035e:	a075                	j	8000040a <consoleintr+0x15e>
    80000360:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80000362:	0000f717          	auipc	a4,0xf
    80000366:	50e70713          	addi	a4,a4,1294 # 8000f870 <cons>
    8000036a:	0a072783          	lw	a5,160(a4)
    8000036e:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000372:	0000f497          	auipc	s1,0xf
    80000376:	4fe48493          	addi	s1,s1,1278 # 8000f870 <cons>
    while(cons.e != cons.w &&
    8000037a:	4929                	li	s2,10
    8000037c:	02f70863          	beq	a4,a5,800003ac <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000380:	37fd                	addiw	a5,a5,-1
    80000382:	07f7f713          	andi	a4,a5,127
    80000386:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000388:	01874703          	lbu	a4,24(a4)
    8000038c:	03270263          	beq	a4,s2,800003b0 <consoleintr+0x104>
      cons.e--;
    80000390:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000394:	10000513          	li	a0,256
    80000398:	ee3ff0ef          	jal	8000027a <consputc>
    while(cons.e != cons.w &&
    8000039c:	0a04a783          	lw	a5,160(s1)
    800003a0:	09c4a703          	lw	a4,156(s1)
    800003a4:	fcf71ee3          	bne	a4,a5,80000380 <consoleintr+0xd4>
    800003a8:	6902                	ld	s2,0(sp)
    800003aa:	bf15                	j	800002de <consoleintr+0x32>
    800003ac:	6902                	ld	s2,0(sp)
    800003ae:	bf05                	j	800002de <consoleintr+0x32>
    800003b0:	6902                	ld	s2,0(sp)
    800003b2:	b735                	j	800002de <consoleintr+0x32>
    if(cons.e != cons.w){
    800003b4:	0000f717          	auipc	a4,0xf
    800003b8:	4bc70713          	addi	a4,a4,1212 # 8000f870 <cons>
    800003bc:	0a072783          	lw	a5,160(a4)
    800003c0:	09c72703          	lw	a4,156(a4)
    800003c4:	f0f70de3          	beq	a4,a5,800002de <consoleintr+0x32>
      cons.e--;
    800003c8:	37fd                	addiw	a5,a5,-1
    800003ca:	0000f717          	auipc	a4,0xf
    800003ce:	54f72323          	sw	a5,1350(a4) # 8000f910 <cons+0xa0>
      consputc(BACKSPACE);
    800003d2:	10000513          	li	a0,256
    800003d6:	ea5ff0ef          	jal	8000027a <consputc>
    800003da:	b711                	j	800002de <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003dc:	f00481e3          	beqz	s1,800002de <consoleintr+0x32>
    800003e0:	bf31                	j	800002fc <consoleintr+0x50>
      consputc(c);
    800003e2:	4529                	li	a0,10
    800003e4:	e97ff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003e8:	0000f797          	auipc	a5,0xf
    800003ec:	48878793          	addi	a5,a5,1160 # 8000f870 <cons>
    800003f0:	0a07a703          	lw	a4,160(a5)
    800003f4:	0017069b          	addiw	a3,a4,1
    800003f8:	8636                	mv	a2,a3
    800003fa:	0ad7a023          	sw	a3,160(a5)
    800003fe:	07f77713          	andi	a4,a4,127
    80000402:	97ba                	add	a5,a5,a4
    80000404:	4729                	li	a4,10
    80000406:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040a:	0000f797          	auipc	a5,0xf
    8000040e:	50c7a123          	sw	a2,1282(a5) # 8000f90c <cons+0x9c>
        wakeup(&cons.r);
    80000412:	0000f517          	auipc	a0,0xf
    80000416:	4f650513          	addi	a0,a0,1270 # 8000f908 <cons+0x98>
    8000041a:	399010ef          	jal	80001fb2 <wakeup>
    8000041e:	b5c1                	j	800002de <consoleintr+0x32>

0000000080000420 <consoleinit>:

void
consoleinit(void)
{
    80000420:	1141                	addi	sp,sp,-16
    80000422:	e406                	sd	ra,8(sp)
    80000424:	e022                	sd	s0,0(sp)
    80000426:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000428:	00007597          	auipc	a1,0x7
    8000042c:	bd858593          	addi	a1,a1,-1064 # 80007000 <etext>
    80000430:	0000f517          	auipc	a0,0xf
    80000434:	44050513          	addi	a0,a0,1088 # 8000f870 <cons>
    80000438:	78e000ef          	jal	80000bc6 <initlock>

  uartinit();
    8000043c:	448000ef          	jal	80000884 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000440:	0001f797          	auipc	a5,0x1f
    80000444:	5a078793          	addi	a5,a5,1440 # 8001f9e0 <devsw>
    80000448:	00000717          	auipc	a4,0x0
    8000044c:	d2e70713          	addi	a4,a4,-722 # 80000176 <consoleread>
    80000450:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000452:	00000717          	auipc	a4,0x0
    80000456:	c8270713          	addi	a4,a4,-894 # 800000d4 <consolewrite>
    8000045a:	ef98                	sd	a4,24(a5)
}
    8000045c:	60a2                	ld	ra,8(sp)
    8000045e:	6402                	ld	s0,0(sp)
    80000460:	0141                	addi	sp,sp,16
    80000462:	8082                	ret

0000000080000464 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000464:	7139                	addi	sp,sp,-64
    80000466:	fc06                	sd	ra,56(sp)
    80000468:	f822                	sd	s0,48(sp)
    8000046a:	f04a                	sd	s2,32(sp)
    8000046c:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    8000046e:	c219                	beqz	a2,80000474 <printint+0x10>
    80000470:	08054163          	bltz	a0,800004f2 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80000474:	4301                	li	t1,0

  i = 0;
    80000476:	fc840913          	addi	s2,s0,-56
    x = xx;
    8000047a:	86ca                	mv	a3,s2
  i = 0;
    8000047c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    8000047e:	00007817          	auipc	a6,0x7
    80000482:	29280813          	addi	a6,a6,658 # 80007710 <digits>
    80000486:	88ba                	mv	a7,a4
    80000488:	0017061b          	addiw	a2,a4,1
    8000048c:	8732                	mv	a4,a2
    8000048e:	02b577b3          	remu	a5,a0,a1
    80000492:	97c2                	add	a5,a5,a6
    80000494:	0007c783          	lbu	a5,0(a5)
    80000498:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    8000049c:	87aa                	mv	a5,a0
    8000049e:	02b55533          	divu	a0,a0,a1
    800004a2:	0685                	addi	a3,a3,1
    800004a4:	feb7f1e3          	bgeu	a5,a1,80000486 <printint+0x22>

  if(sign)
    800004a8:	00030c63          	beqz	t1,800004c0 <printint+0x5c>
    buf[i++] = '-';
    800004ac:	fe060793          	addi	a5,a2,-32
    800004b0:	00878633          	add	a2,a5,s0
    800004b4:	02d00793          	li	a5,45
    800004b8:	fef60423          	sb	a5,-24(a2)
    800004bc:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    800004c0:	02e05463          	blez	a4,800004e8 <printint+0x84>
    800004c4:	f426                	sd	s1,40(sp)
    800004c6:	377d                	addiw	a4,a4,-1
    800004c8:	00e904b3          	add	s1,s2,a4
    800004cc:	197d                	addi	s2,s2,-1
    800004ce:	993a                	add	s2,s2,a4
    800004d0:	1702                	slli	a4,a4,0x20
    800004d2:	9301                	srli	a4,a4,0x20
    800004d4:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004d8:	0004c503          	lbu	a0,0(s1)
    800004dc:	d9fff0ef          	jal	8000027a <consputc>
  while(--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x74>
    800004e6:	74a2                	ld	s1,40(sp)
}
    800004e8:	70e2                	ld	ra,56(sp)
    800004ea:	7442                	ld	s0,48(sp)
    800004ec:	7902                	ld	s2,32(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004f6:	4305                	li	t1,1
    x = -xx;
    800004f8:	bfbd                	j	80000476 <printint+0x12>

00000000800004fa <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	f0ca                	sd	s2,96(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	892a                	mv	s2,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0)
    80000518:	00007797          	auipc	a5,0x7
    8000051c:	32c7a783          	lw	a5,812(a5) # 80007844 <panicking>
    80000520:	cf9d                	beqz	a5,8000055e <printf+0x64>
    acquire(&pr.lock);

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000052a:	00094503          	lbu	a0,0(s2)
    8000052e:	22050663          	beqz	a0,8000075a <printf+0x260>
    80000532:	f4a6                	sd	s1,104(sp)
    80000534:	ecce                	sd	s3,88(sp)
    80000536:	e8d2                	sd	s4,80(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	fc5e                	sd	s7,56(sp)
    8000053e:	f862                	sd	s8,48(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4a01                	li	s4,0
    if(cx != '%'){
    80000546:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    8000054a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    8000054e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    80000552:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    80000556:	4b29                	li	s6,10
    if(c0 == 'd'){
    80000558:	06400b93          	li	s7,100
    8000055c:	a015                	j	80000580 <printf+0x86>
    acquire(&pr.lock);
    8000055e:	0000f517          	auipc	a0,0xf
    80000562:	3ba50513          	addi	a0,a0,954 # 8000f918 <pr>
    80000566:	6ea000ef          	jal	80000c50 <acquire>
    8000056a:	bf65                	j	80000522 <printf+0x28>
      consputc(cx);
    8000056c:	d0fff0ef          	jal	8000027a <consputc>
      continue;
    80000570:	84d2                	mv	s1,s4
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000572:	2485                	addiw	s1,s1,1
    80000574:	8a26                	mv	s4,s1
    80000576:	94ca                	add	s1,s1,s2
    80000578:	0004c503          	lbu	a0,0(s1)
    8000057c:	1c050663          	beqz	a0,80000748 <printf+0x24e>
    if(cx != '%'){
    80000580:	ff3516e3          	bne	a0,s3,8000056c <printf+0x72>
    i++;
    80000584:	001a079b          	addiw	a5,s4,1
    80000588:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000058a:	00f90733          	add	a4,s2,a5
    8000058e:	00074a83          	lbu	s5,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000592:	200a8963          	beqz	s5,800007a4 <printf+0x2aa>
    80000596:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000059a:	1e068c63          	beqz	a3,80000792 <printf+0x298>
    if(c0 == 'd'){
    8000059e:	037a8863          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    800005a2:	f94a8713          	addi	a4,s5,-108
    800005a6:	00173713          	seqz	a4,a4
    800005aa:	f9c68613          	addi	a2,a3,-100
    800005ae:	ee05                	bnez	a2,800005e6 <printf+0xec>
    800005b0:	cb1d                	beqz	a4,800005e6 <printf+0xec>
      printint(va_arg(ap, uint64), 10, 1);
    800005b2:	f8843783          	ld	a5,-120(s0)
    800005b6:	00878713          	addi	a4,a5,8
    800005ba:	f8e43423          	sd	a4,-120(s0)
    800005be:	4605                	li	a2,1
    800005c0:	85da                	mv	a1,s6
    800005c2:	6388                	ld	a0,0(a5)
    800005c4:	ea1ff0ef          	jal	80000464 <printint>
      i += 1;
    800005c8:	002a049b          	addiw	s1,s4,2
    800005cc:	b75d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, int), 10, 1);
    800005ce:	f8843783          	ld	a5,-120(s0)
    800005d2:	00878713          	addi	a4,a5,8
    800005d6:	f8e43423          	sd	a4,-120(s0)
    800005da:	4605                	li	a2,1
    800005dc:	85da                	mv	a1,s6
    800005de:	4388                	lw	a0,0(a5)
    800005e0:	e85ff0ef          	jal	80000464 <printint>
    800005e4:	b779                	j	80000572 <printf+0x78>
    if(c1) c2 = fmt[i+2] & 0xff;
    800005e6:	97ca                	add	a5,a5,s2
    800005e8:	8636                	mv	a2,a3
    800005ea:	0027c683          	lbu	a3,2(a5)
    800005ee:	a2c9                	j	800007b0 <printf+0x2b6>
      printint(va_arg(ap, uint64), 10, 1);
    800005f0:	f8843783          	ld	a5,-120(s0)
    800005f4:	00878713          	addi	a4,a5,8
    800005f8:	f8e43423          	sd	a4,-120(s0)
    800005fc:	4605                	li	a2,1
    800005fe:	45a9                	li	a1,10
    80000600:	6388                	ld	a0,0(a5)
    80000602:	e63ff0ef          	jal	80000464 <printint>
      i += 2;
    80000606:	003a049b          	addiw	s1,s4,3
    8000060a:	b7a5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 10, 0);
    8000060c:	f8843783          	ld	a5,-120(s0)
    80000610:	00878713          	addi	a4,a5,8
    80000614:	f8e43423          	sd	a4,-120(s0)
    80000618:	4601                	li	a2,0
    8000061a:	85da                	mv	a1,s6
    8000061c:	0007e503          	lwu	a0,0(a5)
    80000620:	e45ff0ef          	jal	80000464 <printint>
    80000624:	b7b9                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000626:	f8843783          	ld	a5,-120(s0)
    8000062a:	00878713          	addi	a4,a5,8
    8000062e:	f8e43423          	sd	a4,-120(s0)
    80000632:	4601                	li	a2,0
    80000634:	85da                	mv	a1,s6
    80000636:	6388                	ld	a0,0(a5)
    80000638:	e2dff0ef          	jal	80000464 <printint>
      i += 1;
    8000063c:	002a049b          	addiw	s1,s4,2
    80000640:	bf0d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000642:	f8843783          	ld	a5,-120(s0)
    80000646:	00878713          	addi	a4,a5,8
    8000064a:	f8e43423          	sd	a4,-120(s0)
    8000064e:	4601                	li	a2,0
    80000650:	45a9                	li	a1,10
    80000652:	6388                	ld	a0,0(a5)
    80000654:	e11ff0ef          	jal	80000464 <printint>
      i += 2;
    80000658:	003a049b          	addiw	s1,s4,3
    8000065c:	bf19                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 16, 0);
    8000065e:	f8843783          	ld	a5,-120(s0)
    80000662:	00878713          	addi	a4,a5,8
    80000666:	f8e43423          	sd	a4,-120(s0)
    8000066a:	4601                	li	a2,0
    8000066c:	45c1                	li	a1,16
    8000066e:	0007e503          	lwu	a0,0(a5)
    80000672:	df3ff0ef          	jal	80000464 <printint>
    80000676:	bdf5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000678:	f8843783          	ld	a5,-120(s0)
    8000067c:	00878713          	addi	a4,a5,8
    80000680:	f8e43423          	sd	a4,-120(s0)
    80000684:	45c1                	li	a1,16
    80000686:	6388                	ld	a0,0(a5)
    80000688:	dddff0ef          	jal	80000464 <printint>
      i += 1;
    8000068c:	002a049b          	addiw	s1,s4,2
    80000690:	b5cd                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000692:	f8843783          	ld	a5,-120(s0)
    80000696:	00878713          	addi	a4,a5,8
    8000069a:	f8e43423          	sd	a4,-120(s0)
    8000069e:	4601                	li	a2,0
    800006a0:	45c1                	li	a1,16
    800006a2:	6388                	ld	a0,0(a5)
    800006a4:	dc1ff0ef          	jal	80000464 <printint>
      i += 2;
    800006a8:	003a049b          	addiw	s1,s4,3
    800006ac:	b5d9                	j	80000572 <printf+0x78>
    800006ae:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006b0:	f8843783          	ld	a5,-120(s0)
    800006b4:	00878713          	addi	a4,a5,8
    800006b8:	f8e43423          	sd	a4,-120(s0)
    800006bc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006c0:	03000513          	li	a0,48
    800006c4:	bb7ff0ef          	jal	8000027a <consputc>
  consputc('x');
    800006c8:	07800513          	li	a0,120
    800006cc:	bafff0ef          	jal	8000027a <consputc>
    800006d0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006d2:	00007c97          	auipc	s9,0x7
    800006d6:	03ec8c93          	addi	s9,s9,62 # 80007710 <digits>
    800006da:	03cad793          	srli	a5,s5,0x3c
    800006de:	97e6                	add	a5,a5,s9
    800006e0:	0007c503          	lbu	a0,0(a5)
    800006e4:	b97ff0ef          	jal	8000027a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006e8:	0a92                	slli	s5,s5,0x4
    800006ea:	3a7d                	addiw	s4,s4,-1
    800006ec:	fe0a17e3          	bnez	s4,800006da <printf+0x1e0>
    800006f0:	7ca2                	ld	s9,40(sp)
    800006f2:	b541                	j	80000572 <printf+0x78>
    } else if(c0 == 'c'){
      consputc(va_arg(ap, uint));
    800006f4:	f8843783          	ld	a5,-120(s0)
    800006f8:	00878713          	addi	a4,a5,8
    800006fc:	f8e43423          	sd	a4,-120(s0)
    80000700:	4388                	lw	a0,0(a5)
    80000702:	b79ff0ef          	jal	8000027a <consputc>
    80000706:	b5b5                	j	80000572 <printf+0x78>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    80000708:	f8843783          	ld	a5,-120(s0)
    8000070c:	00878713          	addi	a4,a5,8
    80000710:	f8e43423          	sd	a4,-120(s0)
    80000714:	0007ba03          	ld	s4,0(a5)
    80000718:	000a0d63          	beqz	s4,80000732 <printf+0x238>
        s = "(null)";
      for(; *s; s++)
    8000071c:	000a4503          	lbu	a0,0(s4)
    80000720:	e40509e3          	beqz	a0,80000572 <printf+0x78>
        consputc(*s);
    80000724:	b57ff0ef          	jal	8000027a <consputc>
      for(; *s; s++)
    80000728:	0a05                	addi	s4,s4,1
    8000072a:	000a4503          	lbu	a0,0(s4)
    8000072e:	f97d                	bnez	a0,80000724 <printf+0x22a>
    80000730:	b589                	j	80000572 <printf+0x78>
        s = "(null)";
    80000732:	00007a17          	auipc	s4,0x7
    80000736:	8d6a0a13          	addi	s4,s4,-1834 # 80007008 <etext+0x8>
      for(; *s; s++)
    8000073a:	02800513          	li	a0,40
    8000073e:	b7dd                	j	80000724 <printf+0x22a>
    } else if(c0 == '%'){
      consputc('%');
    80000740:	8556                	mv	a0,s5
    80000742:	b39ff0ef          	jal	8000027a <consputc>
    80000746:	b535                	j	80000572 <printf+0x78>
    80000748:	74a6                	ld	s1,104(sp)
    8000074a:	69e6                	ld	s3,88(sp)
    8000074c:	6a46                	ld	s4,80(sp)
    8000074e:	6aa6                	ld	s5,72(sp)
    80000750:	6b06                	ld	s6,64(sp)
    80000752:	7be2                	ld	s7,56(sp)
    80000754:	7c42                	ld	s8,48(sp)
    80000756:	7d02                	ld	s10,32(sp)
    80000758:	6de2                	ld	s11,24(sp)
    }

  }
  va_end(ap);

  if(panicking == 0)
    8000075a:	00007797          	auipc	a5,0x7
    8000075e:	0ea7a783          	lw	a5,234(a5) # 80007844 <panicking>
    80000762:	c38d                	beqz	a5,80000784 <printf+0x28a>
    release(&pr.lock);

  return 0;
}
    80000764:	4501                	li	a0,0
    80000766:	70e6                	ld	ra,120(sp)
    80000768:	7446                	ld	s0,112(sp)
    8000076a:	7906                	ld	s2,96(sp)
    8000076c:	6129                	addi	sp,sp,192
    8000076e:	8082                	ret
    80000770:	74a6                	ld	s1,104(sp)
    80000772:	69e6                	ld	s3,88(sp)
    80000774:	6a46                	ld	s4,80(sp)
    80000776:	6aa6                	ld	s5,72(sp)
    80000778:	6b06                	ld	s6,64(sp)
    8000077a:	7be2                	ld	s7,56(sp)
    8000077c:	7c42                	ld	s8,48(sp)
    8000077e:	7d02                	ld	s10,32(sp)
    80000780:	6de2                	ld	s11,24(sp)
    80000782:	bfe1                	j	8000075a <printf+0x260>
    release(&pr.lock);
    80000784:	0000f517          	auipc	a0,0xf
    80000788:	19450513          	addi	a0,a0,404 # 8000f918 <pr>
    8000078c:	558000ef          	jal	80000ce4 <release>
  return 0;
    80000790:	bfd1                	j	80000764 <printf+0x26a>
    if(c0 == 'd'){
    80000792:	e37a8ee3          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    80000796:	f94a8713          	addi	a4,s5,-108
    8000079a:	00173713          	seqz	a4,a4
    8000079e:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007a0:	4781                	li	a5,0
    800007a2:	a00d                	j	800007c4 <printf+0x2ca>
    } else if(c0 == 'l' && c1 == 'd'){
    800007a4:	f94a8713          	addi	a4,s5,-108
    800007a8:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    800007ac:	8656                	mv	a2,s5
    800007ae:	86d6                	mv	a3,s5
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007b0:	f9460793          	addi	a5,a2,-108
    800007b4:	0017b793          	seqz	a5,a5
    800007b8:	8ff9                	and	a5,a5,a4
    800007ba:	f9c68593          	addi	a1,a3,-100
    800007be:	e199                	bnez	a1,800007c4 <printf+0x2ca>
    800007c0:	e20798e3          	bnez	a5,800005f0 <printf+0xf6>
    } else if(c0 == 'u'){
    800007c4:	e58a84e3          	beq	s5,s8,8000060c <printf+0x112>
    } else if(c0 == 'l' && c1 == 'u'){
    800007c8:	f8b60593          	addi	a1,a2,-117
    800007cc:	e199                	bnez	a1,800007d2 <printf+0x2d8>
    800007ce:	e4071ce3          	bnez	a4,80000626 <printf+0x12c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800007d2:	f8b68593          	addi	a1,a3,-117
    800007d6:	e199                	bnez	a1,800007dc <printf+0x2e2>
    800007d8:	e60795e3          	bnez	a5,80000642 <printf+0x148>
    } else if(c0 == 'x'){
    800007dc:	e9aa81e3          	beq	s5,s10,8000065e <printf+0x164>
    } else if(c0 == 'l' && c1 == 'x'){
    800007e0:	f8860613          	addi	a2,a2,-120
    800007e4:	e219                	bnez	a2,800007ea <printf+0x2f0>
    800007e6:	e80719e3          	bnez	a4,80000678 <printf+0x17e>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800007ea:	f8868693          	addi	a3,a3,-120
    800007ee:	e299                	bnez	a3,800007f4 <printf+0x2fa>
    800007f0:	ea0791e3          	bnez	a5,80000692 <printf+0x198>
    } else if(c0 == 'p'){
    800007f4:	ebba8de3          	beq	s5,s11,800006ae <printf+0x1b4>
    } else if(c0 == 'c'){
    800007f8:	06300793          	li	a5,99
    800007fc:	eefa8ce3          	beq	s5,a5,800006f4 <printf+0x1fa>
    } else if(c0 == 's'){
    80000800:	07300793          	li	a5,115
    80000804:	f0fa82e3          	beq	s5,a5,80000708 <printf+0x20e>
    } else if(c0 == '%'){
    80000808:	02500793          	li	a5,37
    8000080c:	f2fa8ae3          	beq	s5,a5,80000740 <printf+0x246>
    } else if(c0 == 0){
    80000810:	f60a80e3          	beqz	s5,80000770 <printf+0x276>
      consputc('%');
    80000814:	02500513          	li	a0,37
    80000818:	a63ff0ef          	jal	8000027a <consputc>
      consputc(c0);
    8000081c:	8556                	mv	a0,s5
    8000081e:	a5dff0ef          	jal	8000027a <consputc>
    80000822:	bb81                	j	80000572 <printf+0x78>

0000000080000824 <panic>:

void
panic(char *s)
{
    80000824:	1101                	addi	sp,sp,-32
    80000826:	ec06                	sd	ra,24(sp)
    80000828:	e822                	sd	s0,16(sp)
    8000082a:	e426                	sd	s1,8(sp)
    8000082c:	e04a                	sd	s2,0(sp)
    8000082e:	1000                	addi	s0,sp,32
    80000830:	892a                	mv	s2,a0
  panicking = 1;
    80000832:	4485                	li	s1,1
    80000834:	00007797          	auipc	a5,0x7
    80000838:	0097a823          	sw	s1,16(a5) # 80007844 <panicking>
  printf("panic: ");
    8000083c:	00006517          	auipc	a0,0x6
    80000840:	7dc50513          	addi	a0,a0,2012 # 80007018 <etext+0x18>
    80000844:	cb7ff0ef          	jal	800004fa <printf>
  printf("%s\n", s);
    80000848:	85ca                	mv	a1,s2
    8000084a:	00006517          	auipc	a0,0x6
    8000084e:	7d650513          	addi	a0,a0,2006 # 80007020 <etext+0x20>
    80000852:	ca9ff0ef          	jal	800004fa <printf>
  panicked = 1; // freeze uart output from other CPUs
    80000856:	00007797          	auipc	a5,0x7
    8000085a:	fe97a523          	sw	s1,-22(a5) # 80007840 <panicked>
  for(;;)
    8000085e:	a001                	j	8000085e <panic+0x3a>

0000000080000860 <printfinit>:
    ;
}

void
printfinit(void)
{
    80000860:	1141                	addi	sp,sp,-16
    80000862:	e406                	sd	ra,8(sp)
    80000864:	e022                	sd	s0,0(sp)
    80000866:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000868:	00006597          	auipc	a1,0x6
    8000086c:	7c058593          	addi	a1,a1,1984 # 80007028 <etext+0x28>
    80000870:	0000f517          	auipc	a0,0xf
    80000874:	0a850513          	addi	a0,a0,168 # 8000f918 <pr>
    80000878:	34e000ef          	jal	80000bc6 <initlock>
}
    8000087c:	60a2                	ld	ra,8(sp)
    8000087e:	6402                	ld	s0,0(sp)
    80000880:	0141                	addi	sp,sp,16
    80000882:	8082                	ret

0000000080000884 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    80000884:	1141                	addi	sp,sp,-16
    80000886:	e406                	sd	ra,8(sp)
    80000888:	e022                	sd	s0,0(sp)
    8000088a:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000088c:	100007b7          	lui	a5,0x10000
    80000890:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000894:	10000737          	lui	a4,0x10000
    80000898:	f8000693          	li	a3,-128
    8000089c:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008a0:	468d                	li	a3,3
    800008a2:	10000637          	lui	a2,0x10000
    800008a6:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008aa:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008ae:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008b2:	8732                	mv	a4,a2
    800008b4:	461d                	li	a2,7
    800008b6:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008ba:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    800008be:	00006597          	auipc	a1,0x6
    800008c2:	77258593          	addi	a1,a1,1906 # 80007030 <etext+0x30>
    800008c6:	0000f517          	auipc	a0,0xf
    800008ca:	06a50513          	addi	a0,a0,106 # 8000f930 <tx_lock>
    800008ce:	2f8000ef          	jal	80000bc6 <initlock>
}
    800008d2:	60a2                	ld	ra,8(sp)
    800008d4:	6402                	ld	s0,0(sp)
    800008d6:	0141                	addi	sp,sp,16
    800008d8:	8082                	ret

00000000800008da <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008da:	715d                	addi	sp,sp,-80
    800008dc:	e486                	sd	ra,72(sp)
    800008de:	e0a2                	sd	s0,64(sp)
    800008e0:	fc26                	sd	s1,56(sp)
    800008e2:	ec56                	sd	s5,24(sp)
    800008e4:	0880                	addi	s0,sp,80
    800008e6:	8aaa                	mv	s5,a0
    800008e8:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008ea:	0000f517          	auipc	a0,0xf
    800008ee:	04650513          	addi	a0,a0,70 # 8000f930 <tx_lock>
    800008f2:	35e000ef          	jal	80000c50 <acquire>

  int i = 0;
  while(i < n){ 
    800008f6:	06905063          	blez	s1,80000956 <uartwrite+0x7c>
    800008fa:	f84a                	sd	s2,48(sp)
    800008fc:	f44e                	sd	s3,40(sp)
    800008fe:	f052                	sd	s4,32(sp)
    80000900:	e85a                	sd	s6,16(sp)
    80000902:	e45e                	sd	s7,8(sp)
    80000904:	8a56                	mv	s4,s5
    80000906:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    80000908:	00007497          	auipc	s1,0x7
    8000090c:	f4448493          	addi	s1,s1,-188 # 8000784c <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    80000910:	0000f997          	auipc	s3,0xf
    80000914:	02098993          	addi	s3,s3,32 # 8000f930 <tx_lock>
    80000918:	00007917          	auipc	s2,0x7
    8000091c:	f3090913          	addi	s2,s2,-208 # 80007848 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    80000920:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    80000924:	4b05                	li	s6,1
    80000926:	a005                	j	80000946 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock);
    80000928:	85ce                	mv	a1,s3
    8000092a:	854a                	mv	a0,s2
    8000092c:	63a010ef          	jal	80001f66 <sleep>
    while(tx_busy != 0){
    80000930:	409c                	lw	a5,0(s1)
    80000932:	fbfd                	bnez	a5,80000928 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    80000934:	000a4783          	lbu	a5,0(s4)
    80000938:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    8000093c:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    80000940:	0a05                	addi	s4,s4,1
    80000942:	015a0563          	beq	s4,s5,8000094c <uartwrite+0x72>
    while(tx_busy != 0){
    80000946:	409c                	lw	a5,0(s1)
    80000948:	f3e5                	bnez	a5,80000928 <uartwrite+0x4e>
    8000094a:	b7ed                	j	80000934 <uartwrite+0x5a>
    8000094c:	7942                	ld	s2,48(sp)
    8000094e:	79a2                	ld	s3,40(sp)
    80000950:	7a02                	ld	s4,32(sp)
    80000952:	6b42                	ld	s6,16(sp)
    80000954:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000956:	0000f517          	auipc	a0,0xf
    8000095a:	fda50513          	addi	a0,a0,-38 # 8000f930 <tx_lock>
    8000095e:	386000ef          	jal	80000ce4 <release>
}
    80000962:	60a6                	ld	ra,72(sp)
    80000964:	6406                	ld	s0,64(sp)
    80000966:	74e2                	ld	s1,56(sp)
    80000968:	6ae2                	ld	s5,24(sp)
    8000096a:	6161                	addi	sp,sp,80
    8000096c:	8082                	ret

000000008000096e <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000096e:	1101                	addi	sp,sp,-32
    80000970:	ec06                	sd	ra,24(sp)
    80000972:	e822                	sd	s0,16(sp)
    80000974:	e426                	sd	s1,8(sp)
    80000976:	1000                	addi	s0,sp,32
    80000978:	84aa                	mv	s1,a0
  if(panicking == 0)
    8000097a:	00007797          	auipc	a5,0x7
    8000097e:	eca7a783          	lw	a5,-310(a5) # 80007844 <panicking>
    80000982:	cf95                	beqz	a5,800009be <uartputc_sync+0x50>
    push_off();

  if(panicked){
    80000984:	00007797          	auipc	a5,0x7
    80000988:	ebc7a783          	lw	a5,-324(a5) # 80007840 <panicked>
    8000098c:	ef85                	bnez	a5,800009c4 <uartputc_sync+0x56>
    for(;;)
      ;
  }

  // wait for UART to set Transmit Holding Empty in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000098e:	10000737          	lui	a4,0x10000
    80000992:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000994:	00074783          	lbu	a5,0(a4)
    80000998:	0207f793          	andi	a5,a5,32
    8000099c:	dfe5                	beqz	a5,80000994 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000099e:	0ff4f513          	zext.b	a0,s1
    800009a2:	100007b7          	lui	a5,0x10000
    800009a6:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    800009aa:	00007797          	auipc	a5,0x7
    800009ae:	e9a7a783          	lw	a5,-358(a5) # 80007844 <panicking>
    800009b2:	cb91                	beqz	a5,800009c6 <uartputc_sync+0x58>
    pop_off();
}
    800009b4:	60e2                	ld	ra,24(sp)
    800009b6:	6442                	ld	s0,16(sp)
    800009b8:	64a2                	ld	s1,8(sp)
    800009ba:	6105                	addi	sp,sp,32
    800009bc:	8082                	ret
    push_off();
    800009be:	24e000ef          	jal	80000c0c <push_off>
    800009c2:	b7c9                	j	80000984 <uartputc_sync+0x16>
    for(;;)
    800009c4:	a001                	j	800009c4 <uartputc_sync+0x56>
    pop_off();
    800009c6:	2ce000ef          	jal	80000c94 <pop_off>
}
    800009ca:	b7ed                	j	800009b4 <uartputc_sync+0x46>

00000000800009cc <uartgetc>:

// try to read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800009cc:	1141                	addi	sp,sp,-16
    800009ce:	e406                	sd	ra,8(sp)
    800009d0:	e022                	sd	s0,0(sp)
    800009d2:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    800009d4:	100007b7          	lui	a5,0x10000
    800009d8:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009dc:	8b85                	andi	a5,a5,1
    800009de:	cb89                	beqz	a5,800009f0 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    800009e0:	100007b7          	lui	a5,0x10000
    800009e4:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009e8:	60a2                	ld	ra,8(sp)
    800009ea:	6402                	ld	s0,0(sp)
    800009ec:	0141                	addi	sp,sp,16
    800009ee:	8082                	ret
    return -1;
    800009f0:	557d                	li	a0,-1
    800009f2:	bfdd                	j	800009e8 <uartgetc+0x1c>

00000000800009f4 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009f4:	1101                	addi	sp,sp,-32
    800009f6:	ec06                	sd	ra,24(sp)
    800009f8:	e822                	sd	s0,16(sp)
    800009fa:	e426                	sd	s1,8(sp)
    800009fc:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009fe:	100007b7          	lui	a5,0x10000
    80000a02:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  acquire(&tx_lock);
    80000a06:	0000f517          	auipc	a0,0xf
    80000a0a:	f2a50513          	addi	a0,a0,-214 # 8000f930 <tx_lock>
    80000a0e:	242000ef          	jal	80000c50 <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    80000a12:	100007b7          	lui	a5,0x10000
    80000a16:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a1a:	0207f793          	andi	a5,a5,32
    80000a1e:	ef99                	bnez	a5,80000a3c <uartintr+0x48>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    80000a20:	0000f517          	auipc	a0,0xf
    80000a24:	f1050513          	addi	a0,a0,-240 # 8000f930 <tx_lock>
    80000a28:	2bc000ef          	jal	80000ce4 <release>

  // read and process incoming characters, if any.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a2c:	54fd                	li	s1,-1
    int c = uartgetc();
    80000a2e:	f9fff0ef          	jal	800009cc <uartgetc>
    if(c == -1)
    80000a32:	02950063          	beq	a0,s1,80000a52 <uartintr+0x5e>
      break;
    consoleintr(c);
    80000a36:	877ff0ef          	jal	800002ac <consoleintr>
  while(1){
    80000a3a:	bfd5                	j	80000a2e <uartintr+0x3a>
    tx_busy = 0;
    80000a3c:	00007797          	auipc	a5,0x7
    80000a40:	e007a823          	sw	zero,-496(a5) # 8000784c <tx_busy>
    wakeup(&tx_chan);
    80000a44:	00007517          	auipc	a0,0x7
    80000a48:	e0450513          	addi	a0,a0,-508 # 80007848 <tx_chan>
    80000a4c:	566010ef          	jal	80001fb2 <wakeup>
    80000a50:	bfc1                	j	80000a20 <uartintr+0x2c>
  }
}
    80000a52:	60e2                	ld	ra,24(sp)
    80000a54:	6442                	ld	s0,16(sp)
    80000a56:	64a2                	ld	s1,8(sp)
    80000a58:	6105                	addi	sp,sp,32
    80000a5a:	8082                	ret

0000000080000a5c <kfree>:
// Free the page of physical memory pointed at by pa,
// which normally should have been returned by a
// call to kalloc().  (The exception is when
// initializing the allocator; see kinit above.)
void kfree(void *pa)
{
    80000a5c:	1101                	addi	sp,sp,-32
    80000a5e:	ec06                	sd	ra,24(sp)
    80000a60:	e822                	sd	s0,16(sp)
    80000a62:	e426                	sd	s1,8(sp)
    80000a64:	e04a                	sd	s2,0(sp)
    80000a66:	1000                	addi	s0,sp,32
  // pa: physical address
  struct run *r;

  // Checks if pa is alligned on a page boundary (whether start address is multiple of PGSIZE)
  // or if it is not below the starting address or if it is not after the ending address
  if(((uint64)pa % PGSIZE) != 0 || (char*)pa < end || (uint64)pa >= PHYSTOP)
    80000a68:	00020797          	auipc	a5,0x20
    80000a6c:	11078793          	addi	a5,a5,272 # 80020b78 <end>
    80000a70:	00f53733          	sltu	a4,a0,a5
    80000a74:	47c5                	li	a5,17
    80000a76:	07ee                	slli	a5,a5,0x1b
    80000a78:	17fd                	addi	a5,a5,-1
    80000a7a:	00a7b7b3          	sltu	a5,a5,a0
    80000a7e:	8fd9                	or	a5,a5,a4
    80000a80:	ef95                	bnez	a5,80000abc <kfree+0x60>
    80000a82:	84aa                	mv	s1,a0
    80000a84:	03451793          	slli	a5,a0,0x34
    80000a88:	eb95                	bnez	a5,80000abc <kfree+0x60>
    panic("kfree");

  // Fill with junk to catch dangling refs.
  memset(pa, 1, PGSIZE);
    80000a8a:	6605                	lui	a2,0x1
    80000a8c:	4585                	li	a1,1
    80000a8e:	292000ef          	jal	80000d20 <memset>

  r = (struct run*)pa;

  acquire(&kmem.lock);
    80000a92:	0000f917          	auipc	s2,0xf
    80000a96:	eb690913          	addi	s2,s2,-330 # 8000f948 <kmem>
    80000a9a:	854a                	mv	a0,s2
    80000a9c:	1b4000ef          	jal	80000c50 <acquire>
  r->next = kmem.freelist;
    80000aa0:	01893783          	ld	a5,24(s2)
    80000aa4:	e09c                	sd	a5,0(s1)
  kmem.freelist = r;
    80000aa6:	00993c23          	sd	s1,24(s2)
  release(&kmem.lock);
    80000aaa:	854a                	mv	a0,s2
    80000aac:	238000ef          	jal	80000ce4 <release>
}
    80000ab0:	60e2                	ld	ra,24(sp)
    80000ab2:	6442                	ld	s0,16(sp)
    80000ab4:	64a2                	ld	s1,8(sp)
    80000ab6:	6902                	ld	s2,0(sp)
    80000ab8:	6105                	addi	sp,sp,32
    80000aba:	8082                	ret
    panic("kfree");
    80000abc:	00006517          	auipc	a0,0x6
    80000ac0:	57c50513          	addi	a0,a0,1404 # 80007038 <etext+0x38>
    80000ac4:	d61ff0ef          	jal	80000824 <panic>

0000000080000ac8 <freerange>:
{
    80000ac8:	7179                	addi	sp,sp,-48
    80000aca:	f406                	sd	ra,40(sp)
    80000acc:	f022                	sd	s0,32(sp)
    80000ace:	ec26                	sd	s1,24(sp)
    80000ad0:	1800                	addi	s0,sp,48
  p = (char*)PGROUNDUP((uint64)pa_start); // PGROUNDUP would allign the PA to nearest page boundary (4097 -> 8192)
    80000ad2:	6785                	lui	a5,0x1
    80000ad4:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000ad8:	00e504b3          	add	s1,a0,a4
    80000adc:	777d                	lui	a4,0xfffff
    80000ade:	8cf9                	and	s1,s1,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000ae0:	94be                	add	s1,s1,a5
    80000ae2:	0295e263          	bltu	a1,s1,80000b06 <freerange+0x3e>
    80000ae6:	e84a                	sd	s2,16(sp)
    80000ae8:	e44e                	sd	s3,8(sp)
    80000aea:	e052                	sd	s4,0(sp)
    80000aec:	892e                	mv	s2,a1
    kfree(p);
    80000aee:	8a3a                	mv	s4,a4
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000af0:	89be                	mv	s3,a5
    kfree(p);
    80000af2:	01448533          	add	a0,s1,s4
    80000af6:	f67ff0ef          	jal	80000a5c <kfree>
  for(; p + PGSIZE <= (char*)pa_end; p += PGSIZE)
    80000afa:	94ce                	add	s1,s1,s3
    80000afc:	fe997be3          	bgeu	s2,s1,80000af2 <freerange+0x2a>
    80000b00:	6942                	ld	s2,16(sp)
    80000b02:	69a2                	ld	s3,8(sp)
    80000b04:	6a02                	ld	s4,0(sp)
}
    80000b06:	70a2                	ld	ra,40(sp)
    80000b08:	7402                	ld	s0,32(sp)
    80000b0a:	64e2                	ld	s1,24(sp)
    80000b0c:	6145                	addi	sp,sp,48
    80000b0e:	8082                	ret

0000000080000b10 <kinit>:
{
    80000b10:	1141                	addi	sp,sp,-16
    80000b12:	e406                	sd	ra,8(sp)
    80000b14:	e022                	sd	s0,0(sp)
    80000b16:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000b18:	00006597          	auipc	a1,0x6
    80000b1c:	52858593          	addi	a1,a1,1320 # 80007040 <etext+0x40>
    80000b20:	0000f517          	auipc	a0,0xf
    80000b24:	e2850513          	addi	a0,a0,-472 # 8000f948 <kmem>
    80000b28:	09e000ef          	jal	80000bc6 <initlock>
  freerange(end, (void*)PHYSTOP);
    80000b2c:	45c5                	li	a1,17
    80000b2e:	05ee                	slli	a1,a1,0x1b
    80000b30:	00020517          	auipc	a0,0x20
    80000b34:	04850513          	addi	a0,a0,72 # 80020b78 <end>
    80000b38:	f91ff0ef          	jal	80000ac8 <freerange>
}
    80000b3c:	60a2                	ld	ra,8(sp)
    80000b3e:	6402                	ld	s0,0(sp)
    80000b40:	0141                	addi	sp,sp,16
    80000b42:	8082                	ret

0000000080000b44 <kalloc>:

// Allocate one 4096-byte page of physical memory.
// Returns a pointer that the kernel can use.
// Returns 0 if the memory cannot be allocated.
void* kalloc(void)
{
    80000b44:	1101                	addi	sp,sp,-32
    80000b46:	ec06                	sd	ra,24(sp)
    80000b48:	e822                	sd	s0,16(sp)
    80000b4a:	e426                	sd	s1,8(sp)
    80000b4c:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000b4e:	0000f517          	auipc	a0,0xf
    80000b52:	dfa50513          	addi	a0,a0,-518 # 8000f948 <kmem>
    80000b56:	0fa000ef          	jal	80000c50 <acquire>
  r = kmem.freelist;  // Store memory address
    80000b5a:	0000f497          	auipc	s1,0xf
    80000b5e:	e064b483          	ld	s1,-506(s1) # 8000f960 <kmem+0x18>
  if(r) // if r is not NULL, then move the freelist head forward
    80000b62:	c49d                	beqz	s1,80000b90 <kalloc+0x4c>
    kmem.freelist = r->next;
    80000b64:	609c                	ld	a5,0(s1)
    80000b66:	0000f717          	auipc	a4,0xf
    80000b6a:	def73d23          	sd	a5,-518(a4) # 8000f960 <kmem+0x18>
  release(&kmem.lock);
    80000b6e:	0000f517          	auipc	a0,0xf
    80000b72:	dda50513          	addi	a0,a0,-550 # 8000f948 <kmem>
    80000b76:	16e000ef          	jal	80000ce4 <release>

  if(r) // if our removed node from freelist is not empty, fill it with garbage values till pgsize
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000b7a:	6605                	lui	a2,0x1
    80000b7c:	4595                	li	a1,5
    80000b7e:	8526                	mv	a0,s1
    80000b80:	1a0000ef          	jal	80000d20 <memset>


  return (void*)r; // return the start address
}
    80000b84:	8526                	mv	a0,s1
    80000b86:	60e2                	ld	ra,24(sp)
    80000b88:	6442                	ld	s0,16(sp)
    80000b8a:	64a2                	ld	s1,8(sp)
    80000b8c:	6105                	addi	sp,sp,32
    80000b8e:	8082                	ret
  release(&kmem.lock);
    80000b90:	0000f517          	auipc	a0,0xf
    80000b94:	db850513          	addi	a0,a0,-584 # 8000f948 <kmem>
    80000b98:	14c000ef          	jal	80000ce4 <release>
  if(r) // if our removed node from freelist is not empty, fill it with garbage values till pgsize
    80000b9c:	b7e5                	j	80000b84 <kalloc+0x40>

0000000080000b9e <kmemfree>:

uint64 kmemfree(void)
{
    80000b9e:	1141                	addi	sp,sp,-16
    80000ba0:	e406                	sd	ra,8(sp)
    80000ba2:	e022                	sd	s0,0(sp)
    80000ba4:	0800                	addi	s0,sp,16
  struct run *r;
  uint64 free = 0;

  for(r = kmem.freelist; r; r = r->next)
    80000ba6:	0000f797          	auipc	a5,0xf
    80000baa:	dba7b783          	ld	a5,-582(a5) # 8000f960 <kmem+0x18>
    80000bae:	cb91                	beqz	a5,80000bc2 <kmemfree+0x24>
  uint64 free = 0;
    80000bb0:	4501                	li	a0,0
  {
    free += PGSIZE;
    80000bb2:	6705                	lui	a4,0x1
    80000bb4:	953a                	add	a0,a0,a4
  for(r = kmem.freelist; r; r = r->next)
    80000bb6:	639c                	ld	a5,0(a5)
    80000bb8:	fff5                	bnez	a5,80000bb4 <kmemfree+0x16>
  }

  return free;

}
    80000bba:	60a2                	ld	ra,8(sp)
    80000bbc:	6402                	ld	s0,0(sp)
    80000bbe:	0141                	addi	sp,sp,16
    80000bc0:	8082                	ret
  uint64 free = 0;
    80000bc2:	4501                	li	a0,0
  return free;
    80000bc4:	bfdd                	j	80000bba <kmemfree+0x1c>

0000000080000bc6 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000bc6:	1141                	addi	sp,sp,-16
    80000bc8:	e406                	sd	ra,8(sp)
    80000bca:	e022                	sd	s0,0(sp)
    80000bcc:	0800                	addi	s0,sp,16
  lk->name = name;
    80000bce:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000bd0:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000bd4:	00053823          	sd	zero,16(a0)
}
    80000bd8:	60a2                	ld	ra,8(sp)
    80000bda:	6402                	ld	s0,0(sp)
    80000bdc:	0141                	addi	sp,sp,16
    80000bde:	8082                	ret

0000000080000be0 <holding>:
// Check whether this cpu is holding the lock.
// Interrupts must be off.
int holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000be0:	411c                	lw	a5,0(a0)
    80000be2:	e399                	bnez	a5,80000be8 <holding+0x8>
    80000be4:	4501                	li	a0,0
  return r;
}
    80000be6:	8082                	ret
{
    80000be8:	1101                	addi	sp,sp,-32
    80000bea:	ec06                	sd	ra,24(sp)
    80000bec:	e822                	sd	s0,16(sp)
    80000bee:	e426                	sd	s1,8(sp)
    80000bf0:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000bf2:	691c                	ld	a5,16(a0)
    80000bf4:	84be                	mv	s1,a5
    80000bf6:	541000ef          	jal	80001936 <mycpu>
    80000bfa:	40a48533          	sub	a0,s1,a0
    80000bfe:	00153513          	seqz	a0,a0
}
    80000c02:	60e2                	ld	ra,24(sp)
    80000c04:	6442                	ld	s0,16(sp)
    80000c06:	64a2                	ld	s1,8(sp)
    80000c08:	6105                	addi	sp,sp,32
    80000c0a:	8082                	ret

0000000080000c0c <push_off>:
// push_off/pop_off are like intr_off()/intr_on() except that they are matched:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void push_off(void)
{
    80000c0c:	1101                	addi	sp,sp,-32
    80000c0e:	ec06                	sd	ra,24(sp)
    80000c10:	e822                	sd	s0,16(sp)
    80000c12:	e426                	sd	s1,8(sp)
    80000c14:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000c16:	100027f3          	csrr	a5,sstatus
    80000c1a:	84be                	mv	s1,a5
    80000c1c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000c20:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000c22:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000c26:	511000ef          	jal	80001936 <mycpu>
    80000c2a:	5d3c                	lw	a5,120(a0)
    80000c2c:	cb99                	beqz	a5,80000c42 <push_off+0x36>
    mycpu()->intena = old; // stores the previous state of interrupt (on/off)
  mycpu()->noff += 1;
    80000c2e:	509000ef          	jal	80001936 <mycpu>
    80000c32:	5d3c                	lw	a5,120(a0)
    80000c34:	2785                	addiw	a5,a5,1
    80000c36:	dd3c                	sw	a5,120(a0)
}
    80000c38:	60e2                	ld	ra,24(sp)
    80000c3a:	6442                	ld	s0,16(sp)
    80000c3c:	64a2                	ld	s1,8(sp)
    80000c3e:	6105                	addi	sp,sp,32
    80000c40:	8082                	ret
    mycpu()->intena = old; // stores the previous state of interrupt (on/off)
    80000c42:	4f5000ef          	jal	80001936 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000c46:	0014d793          	srli	a5,s1,0x1
    80000c4a:	8b85                	andi	a5,a5,1
    80000c4c:	dd7c                	sw	a5,124(a0)
    80000c4e:	b7c5                	j	80000c2e <push_off+0x22>

0000000080000c50 <acquire>:
{
    80000c50:	1101                	addi	sp,sp,-32
    80000c52:	ec06                	sd	ra,24(sp)
    80000c54:	e822                	sd	s0,16(sp)
    80000c56:	e426                	sd	s1,8(sp)
    80000c58:	1000                	addi	s0,sp,32
    80000c5a:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000c5c:	fb1ff0ef          	jal	80000c0c <push_off>
  if(holding(lk))
    80000c60:	8526                	mv	a0,s1
    80000c62:	f7fff0ef          	jal	80000be0 <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c66:	4705                	li	a4,1
  if(holding(lk))
    80000c68:	e105                	bnez	a0,80000c88 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000c6a:	87ba                	mv	a5,a4
    80000c6c:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000c70:	2781                	sext.w	a5,a5
    80000c72:	ffe5                	bnez	a5,80000c6a <acquire+0x1a>
  __sync_synchronize();
    80000c74:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000c78:	4bf000ef          	jal	80001936 <mycpu>
    80000c7c:	e888                	sd	a0,16(s1)
}
    80000c7e:	60e2                	ld	ra,24(sp)
    80000c80:	6442                	ld	s0,16(sp)
    80000c82:	64a2                	ld	s1,8(sp)
    80000c84:	6105                	addi	sp,sp,32
    80000c86:	8082                	ret
    panic("acquire");
    80000c88:	00006517          	auipc	a0,0x6
    80000c8c:	3c050513          	addi	a0,a0,960 # 80007048 <etext+0x48>
    80000c90:	b95ff0ef          	jal	80000824 <panic>

0000000080000c94 <pop_off>:

void pop_off(void)
{
    80000c94:	1141                	addi	sp,sp,-16
    80000c96:	e406                	sd	ra,8(sp)
    80000c98:	e022                	sd	s0,0(sp)
    80000c9a:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000c9c:	49b000ef          	jal	80001936 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000ca0:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000ca4:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000ca6:	e39d                	bnez	a5,80000ccc <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000ca8:	5d3c                	lw	a5,120(a0)
    80000caa:	02f05763          	blez	a5,80000cd8 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80000cae:	37fd                	addiw	a5,a5,-1
    80000cb0:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena) // if counter is 0 and the interrupt was on previously
    80000cb2:	eb89                	bnez	a5,80000cc4 <pop_off+0x30>
    80000cb4:	5d7c                	lw	a5,124(a0)
    80000cb6:	c799                	beqz	a5,80000cc4 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000cb8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000cbc:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000cc0:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000cc4:	60a2                	ld	ra,8(sp)
    80000cc6:	6402                	ld	s0,0(sp)
    80000cc8:	0141                	addi	sp,sp,16
    80000cca:	8082                	ret
    panic("pop_off - interruptible");
    80000ccc:	00006517          	auipc	a0,0x6
    80000cd0:	38450513          	addi	a0,a0,900 # 80007050 <etext+0x50>
    80000cd4:	b51ff0ef          	jal	80000824 <panic>
    panic("pop_off");
    80000cd8:	00006517          	auipc	a0,0x6
    80000cdc:	39050513          	addi	a0,a0,912 # 80007068 <etext+0x68>
    80000ce0:	b45ff0ef          	jal	80000824 <panic>

0000000080000ce4 <release>:
{
    80000ce4:	1101                	addi	sp,sp,-32
    80000ce6:	ec06                	sd	ra,24(sp)
    80000ce8:	e822                	sd	s0,16(sp)
    80000cea:	e426                	sd	s1,8(sp)
    80000cec:	1000                	addi	s0,sp,32
    80000cee:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000cf0:	ef1ff0ef          	jal	80000be0 <holding>
    80000cf4:	c105                	beqz	a0,80000d14 <release+0x30>
  lk->cpu = 0;
    80000cf6:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000cfa:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000cfe:	0310000f          	fence	rw,w
    80000d02:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000d06:	f8fff0ef          	jal	80000c94 <pop_off>
}
    80000d0a:	60e2                	ld	ra,24(sp)
    80000d0c:	6442                	ld	s0,16(sp)
    80000d0e:	64a2                	ld	s1,8(sp)
    80000d10:	6105                	addi	sp,sp,32
    80000d12:	8082                	ret
    panic("release");
    80000d14:	00006517          	auipc	a0,0x6
    80000d18:	35c50513          	addi	a0,a0,860 # 80007070 <etext+0x70>
    80000d1c:	b09ff0ef          	jal	80000824 <panic>

0000000080000d20 <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000d20:	1141                	addi	sp,sp,-16
    80000d22:	e406                	sd	ra,8(sp)
    80000d24:	e022                	sd	s0,0(sp)
    80000d26:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000d28:	ca19                	beqz	a2,80000d3e <memset+0x1e>
    80000d2a:	87aa                	mv	a5,a0
    80000d2c:	1602                	slli	a2,a2,0x20
    80000d2e:	9201                	srli	a2,a2,0x20
    80000d30:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000d34:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000d38:	0785                	addi	a5,a5,1
    80000d3a:	fee79de3          	bne	a5,a4,80000d34 <memset+0x14>
  }
  return dst;
}
    80000d3e:	60a2                	ld	ra,8(sp)
    80000d40:	6402                	ld	s0,0(sp)
    80000d42:	0141                	addi	sp,sp,16
    80000d44:	8082                	ret

0000000080000d46 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000d46:	1141                	addi	sp,sp,-16
    80000d48:	e406                	sd	ra,8(sp)
    80000d4a:	e022                	sd	s0,0(sp)
    80000d4c:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000d4e:	c61d                	beqz	a2,80000d7c <memcmp+0x36>
    80000d50:	1602                	slli	a2,a2,0x20
    80000d52:	9201                	srli	a2,a2,0x20
    80000d54:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000d58:	00054783          	lbu	a5,0(a0)
    80000d5c:	0005c703          	lbu	a4,0(a1)
    80000d60:	00e79863          	bne	a5,a4,80000d70 <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000d64:	0505                	addi	a0,a0,1
    80000d66:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000d68:	fed518e3          	bne	a0,a3,80000d58 <memcmp+0x12>
  }

  return 0;
    80000d6c:	4501                	li	a0,0
    80000d6e:	a019                	j	80000d74 <memcmp+0x2e>
      return *s1 - *s2;
    80000d70:	40e7853b          	subw	a0,a5,a4
}
    80000d74:	60a2                	ld	ra,8(sp)
    80000d76:	6402                	ld	s0,0(sp)
    80000d78:	0141                	addi	sp,sp,16
    80000d7a:	8082                	ret
  return 0;
    80000d7c:	4501                	li	a0,0
    80000d7e:	bfdd                	j	80000d74 <memcmp+0x2e>

0000000080000d80 <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000d80:	1141                	addi	sp,sp,-16
    80000d82:	e406                	sd	ra,8(sp)
    80000d84:	e022                	sd	s0,0(sp)
    80000d86:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000d88:	c205                	beqz	a2,80000da8 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000d8a:	02a5e363          	bltu	a1,a0,80000db0 <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000d8e:	1602                	slli	a2,a2,0x20
    80000d90:	9201                	srli	a2,a2,0x20
    80000d92:	00c587b3          	add	a5,a1,a2
{
    80000d96:	872a                	mv	a4,a0
      *d++ = *s++;
    80000d98:	0585                	addi	a1,a1,1
    80000d9a:	0705                	addi	a4,a4,1 # 1001 <_entry-0x7fffefff>
    80000d9c:	fff5c683          	lbu	a3,-1(a1)
    80000da0:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000da4:	feb79ae3          	bne	a5,a1,80000d98 <memmove+0x18>

  return dst;
}
    80000da8:	60a2                	ld	ra,8(sp)
    80000daa:	6402                	ld	s0,0(sp)
    80000dac:	0141                	addi	sp,sp,16
    80000dae:	8082                	ret
  if(s < d && s + n > d){
    80000db0:	02061693          	slli	a3,a2,0x20
    80000db4:	9281                	srli	a3,a3,0x20
    80000db6:	00d58733          	add	a4,a1,a3
    80000dba:	fce57ae3          	bgeu	a0,a4,80000d8e <memmove+0xe>
    d += n;
    80000dbe:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000dc0:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000dc4:	1782                	slli	a5,a5,0x20
    80000dc6:	9381                	srli	a5,a5,0x20
    80000dc8:	fff7c793          	not	a5,a5
    80000dcc:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000dce:	177d                	addi	a4,a4,-1
    80000dd0:	16fd                	addi	a3,a3,-1
    80000dd2:	00074603          	lbu	a2,0(a4)
    80000dd6:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000dda:	fee79ae3          	bne	a5,a4,80000dce <memmove+0x4e>
    80000dde:	b7e9                	j	80000da8 <memmove+0x28>

0000000080000de0 <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000de0:	1141                	addi	sp,sp,-16
    80000de2:	e406                	sd	ra,8(sp)
    80000de4:	e022                	sd	s0,0(sp)
    80000de6:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000de8:	f99ff0ef          	jal	80000d80 <memmove>
}
    80000dec:	60a2                	ld	ra,8(sp)
    80000dee:	6402                	ld	s0,0(sp)
    80000df0:	0141                	addi	sp,sp,16
    80000df2:	8082                	ret

0000000080000df4 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000df4:	1141                	addi	sp,sp,-16
    80000df6:	e406                	sd	ra,8(sp)
    80000df8:	e022                	sd	s0,0(sp)
    80000dfa:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000dfc:	ce11                	beqz	a2,80000e18 <strncmp+0x24>
    80000dfe:	00054783          	lbu	a5,0(a0)
    80000e02:	cf89                	beqz	a5,80000e1c <strncmp+0x28>
    80000e04:	0005c703          	lbu	a4,0(a1)
    80000e08:	00f71a63          	bne	a4,a5,80000e1c <strncmp+0x28>
    n--, p++, q++;
    80000e0c:	367d                	addiw	a2,a2,-1
    80000e0e:	0505                	addi	a0,a0,1
    80000e10:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000e12:	f675                	bnez	a2,80000dfe <strncmp+0xa>
  if(n == 0)
    return 0;
    80000e14:	4501                	li	a0,0
    80000e16:	a801                	j	80000e26 <strncmp+0x32>
    80000e18:	4501                	li	a0,0
    80000e1a:	a031                	j	80000e26 <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    80000e1c:	00054503          	lbu	a0,0(a0)
    80000e20:	0005c783          	lbu	a5,0(a1)
    80000e24:	9d1d                	subw	a0,a0,a5
}
    80000e26:	60a2                	ld	ra,8(sp)
    80000e28:	6402                	ld	s0,0(sp)
    80000e2a:	0141                	addi	sp,sp,16
    80000e2c:	8082                	ret

0000000080000e2e <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000e2e:	1141                	addi	sp,sp,-16
    80000e30:	e406                	sd	ra,8(sp)
    80000e32:	e022                	sd	s0,0(sp)
    80000e34:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80000e36:	87aa                	mv	a5,a0
    80000e38:	a011                	j	80000e3c <strncpy+0xe>
    80000e3a:	8636                	mv	a2,a3
    80000e3c:	02c05863          	blez	a2,80000e6c <strncpy+0x3e>
    80000e40:	fff6069b          	addiw	a3,a2,-1
    80000e44:	8836                	mv	a6,a3
    80000e46:	0785                	addi	a5,a5,1
    80000e48:	0005c703          	lbu	a4,0(a1)
    80000e4c:	fee78fa3          	sb	a4,-1(a5)
    80000e50:	0585                	addi	a1,a1,1
    80000e52:	f765                	bnez	a4,80000e3a <strncpy+0xc>
    ;
  while(n-- > 0)
    80000e54:	873e                	mv	a4,a5
    80000e56:	01005b63          	blez	a6,80000e6c <strncpy+0x3e>
    80000e5a:	9fb1                	addw	a5,a5,a2
    80000e5c:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    80000e5e:	0705                	addi	a4,a4,1
    80000e60:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80000e64:	40e786bb          	subw	a3,a5,a4
    80000e68:	fed04be3          	bgtz	a3,80000e5e <strncpy+0x30>
  return os;
}
    80000e6c:	60a2                	ld	ra,8(sp)
    80000e6e:	6402                	ld	s0,0(sp)
    80000e70:	0141                	addi	sp,sp,16
    80000e72:	8082                	ret

0000000080000e74 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80000e74:	1141                	addi	sp,sp,-16
    80000e76:	e406                	sd	ra,8(sp)
    80000e78:	e022                	sd	s0,0(sp)
    80000e7a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80000e7c:	02c05363          	blez	a2,80000ea2 <safestrcpy+0x2e>
    80000e80:	fff6069b          	addiw	a3,a2,-1
    80000e84:	1682                	slli	a3,a3,0x20
    80000e86:	9281                	srli	a3,a3,0x20
    80000e88:	96ae                	add	a3,a3,a1
    80000e8a:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80000e8c:	00d58963          	beq	a1,a3,80000e9e <safestrcpy+0x2a>
    80000e90:	0585                	addi	a1,a1,1
    80000e92:	0785                	addi	a5,a5,1
    80000e94:	fff5c703          	lbu	a4,-1(a1)
    80000e98:	fee78fa3          	sb	a4,-1(a5)
    80000e9c:	fb65                	bnez	a4,80000e8c <safestrcpy+0x18>
    ;
  *s = 0;
    80000e9e:	00078023          	sb	zero,0(a5)
  return os;
}
    80000ea2:	60a2                	ld	ra,8(sp)
    80000ea4:	6402                	ld	s0,0(sp)
    80000ea6:	0141                	addi	sp,sp,16
    80000ea8:	8082                	ret

0000000080000eaa <strlen>:

int
strlen(const char *s)
{
    80000eaa:	1141                	addi	sp,sp,-16
    80000eac:	e406                	sd	ra,8(sp)
    80000eae:	e022                	sd	s0,0(sp)
    80000eb0:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    80000eb2:	00054783          	lbu	a5,0(a0)
    80000eb6:	cf91                	beqz	a5,80000ed2 <strlen+0x28>
    80000eb8:	00150793          	addi	a5,a0,1
    80000ebc:	86be                	mv	a3,a5
    80000ebe:	0785                	addi	a5,a5,1
    80000ec0:	fff7c703          	lbu	a4,-1(a5)
    80000ec4:	ff65                	bnez	a4,80000ebc <strlen+0x12>
    80000ec6:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80000eca:	60a2                	ld	ra,8(sp)
    80000ecc:	6402                	ld	s0,0(sp)
    80000ece:	0141                	addi	sp,sp,16
    80000ed0:	8082                	ret
  for(n = 0; s[n]; n++)
    80000ed2:	4501                	li	a0,0
    80000ed4:	bfdd                	j	80000eca <strlen+0x20>

0000000080000ed6 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    80000ed6:	1141                	addi	sp,sp,-16
    80000ed8:	e406                	sd	ra,8(sp)
    80000eda:	e022                	sd	s0,0(sp)
    80000edc:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80000ede:	245000ef          	jal	80001922 <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    80000ee2:	00007717          	auipc	a4,0x7
    80000ee6:	96e70713          	addi	a4,a4,-1682 # 80007850 <started>
  if(cpuid() == 0){
    80000eea:	c51d                	beqz	a0,80000f18 <main+0x42>
    while(started == 0)
    80000eec:	431c                	lw	a5,0(a4)
    80000eee:	2781                	sext.w	a5,a5
    80000ef0:	dff5                	beqz	a5,80000eec <main+0x16>
      ;
    __sync_synchronize();
    80000ef2:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    80000ef6:	22d000ef          	jal	80001922 <cpuid>
    80000efa:	85aa                	mv	a1,a0
    80000efc:	00006517          	auipc	a0,0x6
    80000f00:	19c50513          	addi	a0,a0,412 # 80007098 <etext+0x98>
    80000f04:	df6ff0ef          	jal	800004fa <printf>
    kvminithart();    // turn on paging
    80000f08:	080000ef          	jal	80000f88 <kvminithart>
    trapinithart();   // install kernel trap vector
    80000f0c:	57a010ef          	jal	80002486 <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    80000f10:	5a8040ef          	jal	800054b8 <plicinithart>
  }

  scheduler();
    80000f14:	6b9000ef          	jal	80001dcc <scheduler>
    consoleinit();
    80000f18:	d08ff0ef          	jal	80000420 <consoleinit>
    printfinit();
    80000f1c:	945ff0ef          	jal	80000860 <printfinit>
    printf("\n");
    80000f20:	00006517          	auipc	a0,0x6
    80000f24:	15850513          	addi	a0,a0,344 # 80007078 <etext+0x78>
    80000f28:	dd2ff0ef          	jal	800004fa <printf>
    printf("xv6 kernel is booting\n");
    80000f2c:	00006517          	auipc	a0,0x6
    80000f30:	15450513          	addi	a0,a0,340 # 80007080 <etext+0x80>
    80000f34:	dc6ff0ef          	jal	800004fa <printf>
    printf("\n");
    80000f38:	00006517          	auipc	a0,0x6
    80000f3c:	14050513          	addi	a0,a0,320 # 80007078 <etext+0x78>
    80000f40:	dbaff0ef          	jal	800004fa <printf>
    kinit();         // physical page allocator
    80000f44:	bcdff0ef          	jal	80000b10 <kinit>
    kvminit();       // create kernel page table
    80000f48:	2cc000ef          	jal	80001214 <kvminit>
    kvminithart();   // turn on paging
    80000f4c:	03c000ef          	jal	80000f88 <kvminithart>
    procinit();      // process table
    80000f50:	11d000ef          	jal	8000186c <procinit>
    trapinit();      // trap vectors
    80000f54:	50e010ef          	jal	80002462 <trapinit>
    trapinithart();  // install kernel trap vector
    80000f58:	52e010ef          	jal	80002486 <trapinithart>
    plicinit();      // set up interrupt controller
    80000f5c:	542040ef          	jal	8000549e <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    80000f60:	558040ef          	jal	800054b8 <plicinithart>
    binit();         // buffer cache
    80000f64:	3cf010ef          	jal	80002b32 <binit>
    iinit();         // inode table
    80000f68:	120020ef          	jal	80003088 <iinit>
    fileinit();      // file table
    80000f6c:	04c030ef          	jal	80003fb8 <fileinit>
    virtio_disk_init(); // emulated hard disk
    80000f70:	638040ef          	jal	800055a8 <virtio_disk_init>
    userinit();      // first user process
    80000f74:	4ad000ef          	jal	80001c20 <userinit>
    __sync_synchronize();
    80000f78:	0330000f          	fence	rw,rw
    started = 1;
    80000f7c:	4785                	li	a5,1
    80000f7e:	00007717          	auipc	a4,0x7
    80000f82:	8cf72923          	sw	a5,-1838(a4) # 80007850 <started>
    80000f86:	b779                	j	80000f14 <main+0x3e>

0000000080000f88 <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    80000f88:	1141                	addi	sp,sp,-16
    80000f8a:	e406                	sd	ra,8(sp)
    80000f8c:	e022                	sd	s0,0(sp)
    80000f8e:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80000f90:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80000f94:	00007797          	auipc	a5,0x7
    80000f98:	8c47b783          	ld	a5,-1852(a5) # 80007858 <kernel_pagetable>
    80000f9c:	83b1                	srli	a5,a5,0xc
    80000f9e:	577d                	li	a4,-1
    80000fa0:	177e                	slli	a4,a4,0x3f
    80000fa2:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80000fa4:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    80000fa8:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80000fac:	60a2                	ld	ra,8(sp)
    80000fae:	6402                	ld	s0,0(sp)
    80000fb0:	0141                	addi	sp,sp,16
    80000fb2:	8082                	ret

0000000080000fb4 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80000fb4:	7139                	addi	sp,sp,-64
    80000fb6:	fc06                	sd	ra,56(sp)
    80000fb8:	f822                	sd	s0,48(sp)
    80000fba:	f426                	sd	s1,40(sp)
    80000fbc:	f04a                	sd	s2,32(sp)
    80000fbe:	ec4e                	sd	s3,24(sp)
    80000fc0:	e852                	sd	s4,16(sp)
    80000fc2:	e456                	sd	s5,8(sp)
    80000fc4:	e05a                	sd	s6,0(sp)
    80000fc6:	0080                	addi	s0,sp,64
    80000fc8:	84aa                	mv	s1,a0
    80000fca:	89ae                	mv	s3,a1
    80000fcc:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    80000fce:	57fd                	li	a5,-1
    80000fd0:	83e9                	srli	a5,a5,0x1a
    80000fd2:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    80000fd4:	4ab1                	li	s5,12
  if(va >= MAXVA)
    80000fd6:	04b7e263          	bltu	a5,a1,8000101a <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    80000fda:	0149d933          	srl	s2,s3,s4
    80000fde:	1ff97913          	andi	s2,s2,511
    80000fe2:	090e                	slli	s2,s2,0x3
    80000fe4:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    80000fe6:	00093483          	ld	s1,0(s2)
    80000fea:	0014f793          	andi	a5,s1,1
    80000fee:	cf85                	beqz	a5,80001026 <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    80000ff0:	80a9                	srli	s1,s1,0xa
    80000ff2:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    80000ff4:	3a5d                	addiw	s4,s4,-9
    80000ff6:	ff5a12e3          	bne	s4,s5,80000fda <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    80000ffa:	00c9d513          	srli	a0,s3,0xc
    80000ffe:	1ff57513          	andi	a0,a0,511
    80001002:	050e                	slli	a0,a0,0x3
    80001004:	9526                	add	a0,a0,s1
}
    80001006:	70e2                	ld	ra,56(sp)
    80001008:	7442                	ld	s0,48(sp)
    8000100a:	74a2                	ld	s1,40(sp)
    8000100c:	7902                	ld	s2,32(sp)
    8000100e:	69e2                	ld	s3,24(sp)
    80001010:	6a42                	ld	s4,16(sp)
    80001012:	6aa2                	ld	s5,8(sp)
    80001014:	6b02                	ld	s6,0(sp)
    80001016:	6121                	addi	sp,sp,64
    80001018:	8082                	ret
    panic("walk");
    8000101a:	00006517          	auipc	a0,0x6
    8000101e:	09650513          	addi	a0,a0,150 # 800070b0 <etext+0xb0>
    80001022:	803ff0ef          	jal	80000824 <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    80001026:	020b0263          	beqz	s6,8000104a <walk+0x96>
    8000102a:	b1bff0ef          	jal	80000b44 <kalloc>
    8000102e:	84aa                	mv	s1,a0
    80001030:	d979                	beqz	a0,80001006 <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    80001032:	6605                	lui	a2,0x1
    80001034:	4581                	li	a1,0
    80001036:	cebff0ef          	jal	80000d20 <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    8000103a:	00c4d793          	srli	a5,s1,0xc
    8000103e:	07aa                	slli	a5,a5,0xa
    80001040:	0017e793          	ori	a5,a5,1
    80001044:	00f93023          	sd	a5,0(s2)
    80001048:	b775                	j	80000ff4 <walk+0x40>
        return 0;
    8000104a:	4501                	li	a0,0
    8000104c:	bf6d                	j	80001006 <walk+0x52>

000000008000104e <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    8000104e:	57fd                	li	a5,-1
    80001050:	83e9                	srli	a5,a5,0x1a
    80001052:	00b7f463          	bgeu	a5,a1,8000105a <walkaddr+0xc>
    return 0;
    80001056:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    80001058:	8082                	ret
{
    8000105a:	1141                	addi	sp,sp,-16
    8000105c:	e406                	sd	ra,8(sp)
    8000105e:	e022                	sd	s0,0(sp)
    80001060:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001062:	4601                	li	a2,0
    80001064:	f51ff0ef          	jal	80000fb4 <walk>
  if(pte == 0)
    80001068:	c901                	beqz	a0,80001078 <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    8000106a:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    8000106c:	0117f693          	andi	a3,a5,17
    80001070:	4745                	li	a4,17
    return 0;
    80001072:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80001074:	00e68663          	beq	a3,a4,80001080 <walkaddr+0x32>
}
    80001078:	60a2                	ld	ra,8(sp)
    8000107a:	6402                	ld	s0,0(sp)
    8000107c:	0141                	addi	sp,sp,16
    8000107e:	8082                	ret
  pa = PTE2PA(*pte);
    80001080:	83a9                	srli	a5,a5,0xa
    80001082:	00c79513          	slli	a0,a5,0xc
  return pa;
    80001086:	bfcd                	j	80001078 <walkaddr+0x2a>

0000000080001088 <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    80001088:	715d                	addi	sp,sp,-80
    8000108a:	e486                	sd	ra,72(sp)
    8000108c:	e0a2                	sd	s0,64(sp)
    8000108e:	fc26                	sd	s1,56(sp)
    80001090:	f84a                	sd	s2,48(sp)
    80001092:	f44e                	sd	s3,40(sp)
    80001094:	f052                	sd	s4,32(sp)
    80001096:	ec56                	sd	s5,24(sp)
    80001098:	e85a                	sd	s6,16(sp)
    8000109a:	e45e                	sd	s7,8(sp)
    8000109c:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    8000109e:	03459793          	slli	a5,a1,0x34
    800010a2:	eba1                	bnez	a5,800010f2 <mappages+0x6a>
    800010a4:	8a2a                	mv	s4,a0
    800010a6:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    800010a8:	03461793          	slli	a5,a2,0x34
    800010ac:	eba9                	bnez	a5,800010fe <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    800010ae:	ce31                	beqz	a2,8000110a <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    800010b0:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    800010b4:	80060613          	addi	a2,a2,-2048
    800010b8:	00b60933          	add	s2,a2,a1
  a = va;
    800010bc:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    800010be:	4b05                	li	s6,1
    800010c0:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    800010c4:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    800010c6:	865a                	mv	a2,s6
    800010c8:	85a6                	mv	a1,s1
    800010ca:	8552                	mv	a0,s4
    800010cc:	ee9ff0ef          	jal	80000fb4 <walk>
    800010d0:	c929                	beqz	a0,80001122 <mappages+0x9a>
    if(*pte & PTE_V)
    800010d2:	611c                	ld	a5,0(a0)
    800010d4:	8b85                	andi	a5,a5,1
    800010d6:	e3a1                	bnez	a5,80001116 <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800010d8:	013487b3          	add	a5,s1,s3
    800010dc:	83b1                	srli	a5,a5,0xc
    800010de:	07aa                	slli	a5,a5,0xa
    800010e0:	0157e7b3          	or	a5,a5,s5
    800010e4:	0017e793          	ori	a5,a5,1
    800010e8:	e11c                	sd	a5,0(a0)
    if(a == last)
    800010ea:	05248863          	beq	s1,s2,8000113a <mappages+0xb2>
    a += PGSIZE;
    800010ee:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800010f0:	bfd9                	j	800010c6 <mappages+0x3e>
    panic("mappages: va not aligned");
    800010f2:	00006517          	auipc	a0,0x6
    800010f6:	fc650513          	addi	a0,a0,-58 # 800070b8 <etext+0xb8>
    800010fa:	f2aff0ef          	jal	80000824 <panic>
    panic("mappages: size not aligned");
    800010fe:	00006517          	auipc	a0,0x6
    80001102:	fda50513          	addi	a0,a0,-38 # 800070d8 <etext+0xd8>
    80001106:	f1eff0ef          	jal	80000824 <panic>
    panic("mappages: size");
    8000110a:	00006517          	auipc	a0,0x6
    8000110e:	fee50513          	addi	a0,a0,-18 # 800070f8 <etext+0xf8>
    80001112:	f12ff0ef          	jal	80000824 <panic>
      panic("mappages: remap");
    80001116:	00006517          	auipc	a0,0x6
    8000111a:	ff250513          	addi	a0,a0,-14 # 80007108 <etext+0x108>
    8000111e:	f06ff0ef          	jal	80000824 <panic>
      return -1;
    80001122:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    80001124:	60a6                	ld	ra,72(sp)
    80001126:	6406                	ld	s0,64(sp)
    80001128:	74e2                	ld	s1,56(sp)
    8000112a:	7942                	ld	s2,48(sp)
    8000112c:	79a2                	ld	s3,40(sp)
    8000112e:	7a02                	ld	s4,32(sp)
    80001130:	6ae2                	ld	s5,24(sp)
    80001132:	6b42                	ld	s6,16(sp)
    80001134:	6ba2                	ld	s7,8(sp)
    80001136:	6161                	addi	sp,sp,80
    80001138:	8082                	ret
  return 0;
    8000113a:	4501                	li	a0,0
    8000113c:	b7e5                	j	80001124 <mappages+0x9c>

000000008000113e <kvmmap>:
{
    8000113e:	1141                	addi	sp,sp,-16
    80001140:	e406                	sd	ra,8(sp)
    80001142:	e022                	sd	s0,0(sp)
    80001144:	0800                	addi	s0,sp,16
    80001146:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    80001148:	86b2                	mv	a3,a2
    8000114a:	863e                	mv	a2,a5
    8000114c:	f3dff0ef          	jal	80001088 <mappages>
    80001150:	e509                	bnez	a0,8000115a <kvmmap+0x1c>
}
    80001152:	60a2                	ld	ra,8(sp)
    80001154:	6402                	ld	s0,0(sp)
    80001156:	0141                	addi	sp,sp,16
    80001158:	8082                	ret
    panic("kvmmap");
    8000115a:	00006517          	auipc	a0,0x6
    8000115e:	fbe50513          	addi	a0,a0,-66 # 80007118 <etext+0x118>
    80001162:	ec2ff0ef          	jal	80000824 <panic>

0000000080001166 <kvmmake>:
{
    80001166:	1101                	addi	sp,sp,-32
    80001168:	ec06                	sd	ra,24(sp)
    8000116a:	e822                	sd	s0,16(sp)
    8000116c:	e426                	sd	s1,8(sp)
    8000116e:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001170:	9d5ff0ef          	jal	80000b44 <kalloc>
    80001174:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    80001176:	6605                	lui	a2,0x1
    80001178:	4581                	li	a1,0
    8000117a:	ba7ff0ef          	jal	80000d20 <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    8000117e:	4719                	li	a4,6
    80001180:	6685                	lui	a3,0x1
    80001182:	10000637          	lui	a2,0x10000
    80001186:	85b2                	mv	a1,a2
    80001188:	8526                	mv	a0,s1
    8000118a:	fb5ff0ef          	jal	8000113e <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    8000118e:	4719                	li	a4,6
    80001190:	6685                	lui	a3,0x1
    80001192:	10001637          	lui	a2,0x10001
    80001196:	85b2                	mv	a1,a2
    80001198:	8526                	mv	a0,s1
    8000119a:	fa5ff0ef          	jal	8000113e <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    8000119e:	4719                	li	a4,6
    800011a0:	040006b7          	lui	a3,0x4000
    800011a4:	0c000637          	lui	a2,0xc000
    800011a8:	85b2                	mv	a1,a2
    800011aa:	8526                	mv	a0,s1
    800011ac:	f93ff0ef          	jal	8000113e <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    800011b0:	4729                	li	a4,10
    800011b2:	80006697          	auipc	a3,0x80006
    800011b6:	e4e68693          	addi	a3,a3,-434 # 7000 <_entry-0x7fff9000>
    800011ba:	4605                	li	a2,1
    800011bc:	067e                	slli	a2,a2,0x1f
    800011be:	85b2                	mv	a1,a2
    800011c0:	8526                	mv	a0,s1
    800011c2:	f7dff0ef          	jal	8000113e <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    800011c6:	4719                	li	a4,6
    800011c8:	00006697          	auipc	a3,0x6
    800011cc:	e3868693          	addi	a3,a3,-456 # 80007000 <etext>
    800011d0:	47c5                	li	a5,17
    800011d2:	07ee                	slli	a5,a5,0x1b
    800011d4:	40d786b3          	sub	a3,a5,a3
    800011d8:	00006617          	auipc	a2,0x6
    800011dc:	e2860613          	addi	a2,a2,-472 # 80007000 <etext>
    800011e0:	85b2                	mv	a1,a2
    800011e2:	8526                	mv	a0,s1
    800011e4:	f5bff0ef          	jal	8000113e <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800011e8:	4729                	li	a4,10
    800011ea:	6685                	lui	a3,0x1
    800011ec:	00005617          	auipc	a2,0x5
    800011f0:	e1460613          	addi	a2,a2,-492 # 80006000 <_trampoline>
    800011f4:	040005b7          	lui	a1,0x4000
    800011f8:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800011fa:	05b2                	slli	a1,a1,0xc
    800011fc:	8526                	mv	a0,s1
    800011fe:	f41ff0ef          	jal	8000113e <kvmmap>
  proc_mapstacks(kpgtbl);
    80001202:	8526                	mv	a0,s1
    80001204:	5c4000ef          	jal	800017c8 <proc_mapstacks>
}
    80001208:	8526                	mv	a0,s1
    8000120a:	60e2                	ld	ra,24(sp)
    8000120c:	6442                	ld	s0,16(sp)
    8000120e:	64a2                	ld	s1,8(sp)
    80001210:	6105                	addi	sp,sp,32
    80001212:	8082                	ret

0000000080001214 <kvminit>:
{
    80001214:	1141                	addi	sp,sp,-16
    80001216:	e406                	sd	ra,8(sp)
    80001218:	e022                	sd	s0,0(sp)
    8000121a:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    8000121c:	f4bff0ef          	jal	80001166 <kvmmake>
    80001220:	00006797          	auipc	a5,0x6
    80001224:	62a7bc23          	sd	a0,1592(a5) # 80007858 <kernel_pagetable>
}
    80001228:	60a2                	ld	ra,8(sp)
    8000122a:	6402                	ld	s0,0(sp)
    8000122c:	0141                	addi	sp,sp,16
    8000122e:	8082                	ret

0000000080001230 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001230:	1101                	addi	sp,sp,-32
    80001232:	ec06                	sd	ra,24(sp)
    80001234:	e822                	sd	s0,16(sp)
    80001236:	e426                	sd	s1,8(sp)
    80001238:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    8000123a:	90bff0ef          	jal	80000b44 <kalloc>
    8000123e:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001240:	c509                	beqz	a0,8000124a <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80001242:	6605                	lui	a2,0x1
    80001244:	4581                	li	a1,0
    80001246:	adbff0ef          	jal	80000d20 <memset>
  return pagetable;
}
    8000124a:	8526                	mv	a0,s1
    8000124c:	60e2                	ld	ra,24(sp)
    8000124e:	6442                	ld	s0,16(sp)
    80001250:	64a2                	ld	s1,8(sp)
    80001252:	6105                	addi	sp,sp,32
    80001254:	8082                	ret

0000000080001256 <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    80001256:	7139                	addi	sp,sp,-64
    80001258:	fc06                	sd	ra,56(sp)
    8000125a:	f822                	sd	s0,48(sp)
    8000125c:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    8000125e:	03459793          	slli	a5,a1,0x34
    80001262:	e38d                	bnez	a5,80001284 <uvmunmap+0x2e>
    80001264:	f04a                	sd	s2,32(sp)
    80001266:	ec4e                	sd	s3,24(sp)
    80001268:	e852                	sd	s4,16(sp)
    8000126a:	e456                	sd	s5,8(sp)
    8000126c:	e05a                	sd	s6,0(sp)
    8000126e:	8a2a                	mv	s4,a0
    80001270:	892e                	mv	s2,a1
    80001272:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001274:	0632                	slli	a2,a2,0xc
    80001276:	00b609b3          	add	s3,a2,a1
    8000127a:	6b05                	lui	s6,0x1
    8000127c:	0535f963          	bgeu	a1,s3,800012ce <uvmunmap+0x78>
    80001280:	f426                	sd	s1,40(sp)
    80001282:	a015                	j	800012a6 <uvmunmap+0x50>
    80001284:	f426                	sd	s1,40(sp)
    80001286:	f04a                	sd	s2,32(sp)
    80001288:	ec4e                	sd	s3,24(sp)
    8000128a:	e852                	sd	s4,16(sp)
    8000128c:	e456                	sd	s5,8(sp)
    8000128e:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    80001290:	00006517          	auipc	a0,0x6
    80001294:	e9050513          	addi	a0,a0,-368 # 80007120 <etext+0x120>
    80001298:	d8cff0ef          	jal	80000824 <panic>
      continue;
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    8000129c:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    800012a0:	995a                	add	s2,s2,s6
    800012a2:	03397563          	bgeu	s2,s3,800012cc <uvmunmap+0x76>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    800012a6:	4601                	li	a2,0
    800012a8:	85ca                	mv	a1,s2
    800012aa:	8552                	mv	a0,s4
    800012ac:	d09ff0ef          	jal	80000fb4 <walk>
    800012b0:	84aa                	mv	s1,a0
    800012b2:	d57d                	beqz	a0,800012a0 <uvmunmap+0x4a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    800012b4:	611c                	ld	a5,0(a0)
    800012b6:	0017f713          	andi	a4,a5,1
    800012ba:	d37d                	beqz	a4,800012a0 <uvmunmap+0x4a>
    if(do_free){
    800012bc:	fe0a80e3          	beqz	s5,8000129c <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    800012c0:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    800012c2:	00c79513          	slli	a0,a5,0xc
    800012c6:	f96ff0ef          	jal	80000a5c <kfree>
    800012ca:	bfc9                	j	8000129c <uvmunmap+0x46>
    800012cc:	74a2                	ld	s1,40(sp)
    800012ce:	7902                	ld	s2,32(sp)
    800012d0:	69e2                	ld	s3,24(sp)
    800012d2:	6a42                	ld	s4,16(sp)
    800012d4:	6aa2                	ld	s5,8(sp)
    800012d6:	6b02                	ld	s6,0(sp)
  }
}
    800012d8:	70e2                	ld	ra,56(sp)
    800012da:	7442                	ld	s0,48(sp)
    800012dc:	6121                	addi	sp,sp,64
    800012de:	8082                	ret

00000000800012e0 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800012e0:	1101                	addi	sp,sp,-32
    800012e2:	ec06                	sd	ra,24(sp)
    800012e4:	e822                	sd	s0,16(sp)
    800012e6:	e426                	sd	s1,8(sp)
    800012e8:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800012ea:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800012ec:	00b67d63          	bgeu	a2,a1,80001306 <uvmdealloc+0x26>
    800012f0:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800012f2:	6785                	lui	a5,0x1
    800012f4:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800012f6:	00f60733          	add	a4,a2,a5
    800012fa:	76fd                	lui	a3,0xfffff
    800012fc:	8f75                	and	a4,a4,a3
    800012fe:	97ae                	add	a5,a5,a1
    80001300:	8ff5                	and	a5,a5,a3
    80001302:	00f76863          	bltu	a4,a5,80001312 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    80001306:	8526                	mv	a0,s1
    80001308:	60e2                	ld	ra,24(sp)
    8000130a:	6442                	ld	s0,16(sp)
    8000130c:	64a2                	ld	s1,8(sp)
    8000130e:	6105                	addi	sp,sp,32
    80001310:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    80001312:	8f99                	sub	a5,a5,a4
    80001314:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    80001316:	4685                	li	a3,1
    80001318:	0007861b          	sext.w	a2,a5
    8000131c:	85ba                	mv	a1,a4
    8000131e:	f39ff0ef          	jal	80001256 <uvmunmap>
    80001322:	b7d5                	j	80001306 <uvmdealloc+0x26>

0000000080001324 <uvmalloc>:
  if(newsz < oldsz)
    80001324:	0ab66163          	bltu	a2,a1,800013c6 <uvmalloc+0xa2>
{
    80001328:	715d                	addi	sp,sp,-80
    8000132a:	e486                	sd	ra,72(sp)
    8000132c:	e0a2                	sd	s0,64(sp)
    8000132e:	f84a                	sd	s2,48(sp)
    80001330:	f052                	sd	s4,32(sp)
    80001332:	ec56                	sd	s5,24(sp)
    80001334:	e45e                	sd	s7,8(sp)
    80001336:	0880                	addi	s0,sp,80
    80001338:	8aaa                	mv	s5,a0
    8000133a:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    8000133c:	6785                	lui	a5,0x1
    8000133e:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001340:	95be                	add	a1,a1,a5
    80001342:	77fd                	lui	a5,0xfffff
    80001344:	00f5f933          	and	s2,a1,a5
    80001348:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000134a:	08c97063          	bgeu	s2,a2,800013ca <uvmalloc+0xa6>
    8000134e:	fc26                	sd	s1,56(sp)
    80001350:	f44e                	sd	s3,40(sp)
    80001352:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    80001354:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    80001356:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    8000135a:	feaff0ef          	jal	80000b44 <kalloc>
    8000135e:	84aa                	mv	s1,a0
    if(mem == 0){
    80001360:	c50d                	beqz	a0,8000138a <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    80001362:	864e                	mv	a2,s3
    80001364:	4581                	li	a1,0
    80001366:	9bbff0ef          	jal	80000d20 <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000136a:	875a                	mv	a4,s6
    8000136c:	86a6                	mv	a3,s1
    8000136e:	864e                	mv	a2,s3
    80001370:	85ca                	mv	a1,s2
    80001372:	8556                	mv	a0,s5
    80001374:	d15ff0ef          	jal	80001088 <mappages>
    80001378:	e915                	bnez	a0,800013ac <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000137a:	994e                	add	s2,s2,s3
    8000137c:	fd496fe3          	bltu	s2,s4,8000135a <uvmalloc+0x36>
  return newsz;
    80001380:	8552                	mv	a0,s4
    80001382:	74e2                	ld	s1,56(sp)
    80001384:	79a2                	ld	s3,40(sp)
    80001386:	6b42                	ld	s6,16(sp)
    80001388:	a811                	j	8000139c <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    8000138a:	865e                	mv	a2,s7
    8000138c:	85ca                	mv	a1,s2
    8000138e:	8556                	mv	a0,s5
    80001390:	f51ff0ef          	jal	800012e0 <uvmdealloc>
      return 0;
    80001394:	4501                	li	a0,0
    80001396:	74e2                	ld	s1,56(sp)
    80001398:	79a2                	ld	s3,40(sp)
    8000139a:	6b42                	ld	s6,16(sp)
}
    8000139c:	60a6                	ld	ra,72(sp)
    8000139e:	6406                	ld	s0,64(sp)
    800013a0:	7942                	ld	s2,48(sp)
    800013a2:	7a02                	ld	s4,32(sp)
    800013a4:	6ae2                	ld	s5,24(sp)
    800013a6:	6ba2                	ld	s7,8(sp)
    800013a8:	6161                	addi	sp,sp,80
    800013aa:	8082                	ret
      kfree(mem);
    800013ac:	8526                	mv	a0,s1
    800013ae:	eaeff0ef          	jal	80000a5c <kfree>
      uvmdealloc(pagetable, a, oldsz);
    800013b2:	865e                	mv	a2,s7
    800013b4:	85ca                	mv	a1,s2
    800013b6:	8556                	mv	a0,s5
    800013b8:	f29ff0ef          	jal	800012e0 <uvmdealloc>
      return 0;
    800013bc:	4501                	li	a0,0
    800013be:	74e2                	ld	s1,56(sp)
    800013c0:	79a2                	ld	s3,40(sp)
    800013c2:	6b42                	ld	s6,16(sp)
    800013c4:	bfe1                	j	8000139c <uvmalloc+0x78>
    return oldsz;
    800013c6:	852e                	mv	a0,a1
}
    800013c8:	8082                	ret
  return newsz;
    800013ca:	8532                	mv	a0,a2
    800013cc:	bfc1                	j	8000139c <uvmalloc+0x78>

00000000800013ce <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800013ce:	7179                	addi	sp,sp,-48
    800013d0:	f406                	sd	ra,40(sp)
    800013d2:	f022                	sd	s0,32(sp)
    800013d4:	ec26                	sd	s1,24(sp)
    800013d6:	e84a                	sd	s2,16(sp)
    800013d8:	e44e                	sd	s3,8(sp)
    800013da:	1800                	addi	s0,sp,48
    800013dc:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800013de:	84aa                	mv	s1,a0
    800013e0:	6905                	lui	s2,0x1
    800013e2:	992a                	add	s2,s2,a0
    800013e4:	a811                	j	800013f8 <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    800013e6:	00006517          	auipc	a0,0x6
    800013ea:	d5250513          	addi	a0,a0,-686 # 80007138 <etext+0x138>
    800013ee:	c36ff0ef          	jal	80000824 <panic>
  for(int i = 0; i < 512; i++){
    800013f2:	04a1                	addi	s1,s1,8
    800013f4:	03248163          	beq	s1,s2,80001416 <freewalk+0x48>
    pte_t pte = pagetable[i];
    800013f8:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800013fa:	0017f713          	andi	a4,a5,1
    800013fe:	db75                	beqz	a4,800013f2 <freewalk+0x24>
    80001400:	00e7f713          	andi	a4,a5,14
    80001404:	f36d                	bnez	a4,800013e6 <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    80001406:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    80001408:	00c79513          	slli	a0,a5,0xc
    8000140c:	fc3ff0ef          	jal	800013ce <freewalk>
      pagetable[i] = 0;
    80001410:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    80001414:	bff9                	j	800013f2 <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    80001416:	854e                	mv	a0,s3
    80001418:	e44ff0ef          	jal	80000a5c <kfree>
}
    8000141c:	70a2                	ld	ra,40(sp)
    8000141e:	7402                	ld	s0,32(sp)
    80001420:	64e2                	ld	s1,24(sp)
    80001422:	6942                	ld	s2,16(sp)
    80001424:	69a2                	ld	s3,8(sp)
    80001426:	6145                	addi	sp,sp,48
    80001428:	8082                	ret

000000008000142a <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    8000142a:	1101                	addi	sp,sp,-32
    8000142c:	ec06                	sd	ra,24(sp)
    8000142e:	e822                	sd	s0,16(sp)
    80001430:	e426                	sd	s1,8(sp)
    80001432:	1000                	addi	s0,sp,32
    80001434:	84aa                	mv	s1,a0
  if(sz > 0)
    80001436:	e989                	bnez	a1,80001448 <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    80001438:	8526                	mv	a0,s1
    8000143a:	f95ff0ef          	jal	800013ce <freewalk>
}
    8000143e:	60e2                	ld	ra,24(sp)
    80001440:	6442                	ld	s0,16(sp)
    80001442:	64a2                	ld	s1,8(sp)
    80001444:	6105                	addi	sp,sp,32
    80001446:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    80001448:	6785                	lui	a5,0x1
    8000144a:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    8000144c:	95be                	add	a1,a1,a5
    8000144e:	4685                	li	a3,1
    80001450:	00c5d613          	srli	a2,a1,0xc
    80001454:	4581                	li	a1,0
    80001456:	e01ff0ef          	jal	80001256 <uvmunmap>
    8000145a:	bff9                	j	80001438 <uvmfree+0xe>

000000008000145c <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    8000145c:	ca59                	beqz	a2,800014f2 <uvmcopy+0x96>
{
    8000145e:	715d                	addi	sp,sp,-80
    80001460:	e486                	sd	ra,72(sp)
    80001462:	e0a2                	sd	s0,64(sp)
    80001464:	fc26                	sd	s1,56(sp)
    80001466:	f84a                	sd	s2,48(sp)
    80001468:	f44e                	sd	s3,40(sp)
    8000146a:	f052                	sd	s4,32(sp)
    8000146c:	ec56                	sd	s5,24(sp)
    8000146e:	e85a                	sd	s6,16(sp)
    80001470:	e45e                	sd	s7,8(sp)
    80001472:	0880                	addi	s0,sp,80
    80001474:	8b2a                	mv	s6,a0
    80001476:	8bae                	mv	s7,a1
    80001478:	8ab2                	mv	s5,a2
  for(i = 0; i < sz; i += PGSIZE){
    8000147a:	4481                	li	s1,0
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    if((mem = kalloc()) == 0)
      goto err;
    memmove(mem, (char*)pa, PGSIZE);
    8000147c:	6a05                	lui	s4,0x1
    8000147e:	a021                	j	80001486 <uvmcopy+0x2a>
  for(i = 0; i < sz; i += PGSIZE){
    80001480:	94d2                	add	s1,s1,s4
    80001482:	0554fc63          	bgeu	s1,s5,800014da <uvmcopy+0x7e>
    if((pte = walk(old, i, 0)) == 0)
    80001486:	4601                	li	a2,0
    80001488:	85a6                	mv	a1,s1
    8000148a:	855a                	mv	a0,s6
    8000148c:	b29ff0ef          	jal	80000fb4 <walk>
    80001490:	d965                	beqz	a0,80001480 <uvmcopy+0x24>
    if((*pte & PTE_V) == 0)
    80001492:	00053983          	ld	s3,0(a0)
    80001496:	0019f793          	andi	a5,s3,1
    8000149a:	d3fd                	beqz	a5,80001480 <uvmcopy+0x24>
    if((mem = kalloc()) == 0)
    8000149c:	ea8ff0ef          	jal	80000b44 <kalloc>
    800014a0:	892a                	mv	s2,a0
    800014a2:	c11d                	beqz	a0,800014c8 <uvmcopy+0x6c>
    pa = PTE2PA(*pte);
    800014a4:	00a9d593          	srli	a1,s3,0xa
    memmove(mem, (char*)pa, PGSIZE);
    800014a8:	8652                	mv	a2,s4
    800014aa:	05b2                	slli	a1,a1,0xc
    800014ac:	8d5ff0ef          	jal	80000d80 <memmove>
    if(mappages(new, i, PGSIZE, (uint64)mem, flags) != 0){
    800014b0:	3ff9f713          	andi	a4,s3,1023
    800014b4:	86ca                	mv	a3,s2
    800014b6:	8652                	mv	a2,s4
    800014b8:	85a6                	mv	a1,s1
    800014ba:	855e                	mv	a0,s7
    800014bc:	bcdff0ef          	jal	80001088 <mappages>
    800014c0:	d161                	beqz	a0,80001480 <uvmcopy+0x24>
      kfree(mem);
    800014c2:	854a                	mv	a0,s2
    800014c4:	d98ff0ef          	jal	80000a5c <kfree>
    }
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    800014c8:	4685                	li	a3,1
    800014ca:	00c4d613          	srli	a2,s1,0xc
    800014ce:	4581                	li	a1,0
    800014d0:	855e                	mv	a0,s7
    800014d2:	d85ff0ef          	jal	80001256 <uvmunmap>
  return -1;
    800014d6:	557d                	li	a0,-1
    800014d8:	a011                	j	800014dc <uvmcopy+0x80>
  return 0;
    800014da:	4501                	li	a0,0
}
    800014dc:	60a6                	ld	ra,72(sp)
    800014de:	6406                	ld	s0,64(sp)
    800014e0:	74e2                	ld	s1,56(sp)
    800014e2:	7942                	ld	s2,48(sp)
    800014e4:	79a2                	ld	s3,40(sp)
    800014e6:	7a02                	ld	s4,32(sp)
    800014e8:	6ae2                	ld	s5,24(sp)
    800014ea:	6b42                	ld	s6,16(sp)
    800014ec:	6ba2                	ld	s7,8(sp)
    800014ee:	6161                	addi	sp,sp,80
    800014f0:	8082                	ret
  return 0;
    800014f2:	4501                	li	a0,0
}
    800014f4:	8082                	ret

00000000800014f6 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800014f6:	1141                	addi	sp,sp,-16
    800014f8:	e406                	sd	ra,8(sp)
    800014fa:	e022                	sd	s0,0(sp)
    800014fc:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800014fe:	4601                	li	a2,0
    80001500:	ab5ff0ef          	jal	80000fb4 <walk>
  if(pte == 0)
    80001504:	c901                	beqz	a0,80001514 <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    80001506:	611c                	ld	a5,0(a0)
    80001508:	9bbd                	andi	a5,a5,-17
    8000150a:	e11c                	sd	a5,0(a0)
}
    8000150c:	60a2                	ld	ra,8(sp)
    8000150e:	6402                	ld	s0,0(sp)
    80001510:	0141                	addi	sp,sp,16
    80001512:	8082                	ret
    panic("uvmclear");
    80001514:	00006517          	auipc	a0,0x6
    80001518:	c3450513          	addi	a0,a0,-972 # 80007148 <etext+0x148>
    8000151c:	b08ff0ef          	jal	80000824 <panic>

0000000080001520 <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    80001520:	cac5                	beqz	a3,800015d0 <copyinstr+0xb0>
{
    80001522:	715d                	addi	sp,sp,-80
    80001524:	e486                	sd	ra,72(sp)
    80001526:	e0a2                	sd	s0,64(sp)
    80001528:	fc26                	sd	s1,56(sp)
    8000152a:	f84a                	sd	s2,48(sp)
    8000152c:	f44e                	sd	s3,40(sp)
    8000152e:	f052                	sd	s4,32(sp)
    80001530:	ec56                	sd	s5,24(sp)
    80001532:	e85a                	sd	s6,16(sp)
    80001534:	e45e                	sd	s7,8(sp)
    80001536:	0880                	addi	s0,sp,80
    80001538:	8aaa                	mv	s5,a0
    8000153a:	84ae                	mv	s1,a1
    8000153c:	8bb2                	mv	s7,a2
    8000153e:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    80001540:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    80001542:	6a05                	lui	s4,0x1
    80001544:	a82d                	j	8000157e <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80001546:	00078023          	sb	zero,0(a5)
        got_null = 1;
    8000154a:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    8000154c:	0017c793          	xori	a5,a5,1
    80001550:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    80001554:	60a6                	ld	ra,72(sp)
    80001556:	6406                	ld	s0,64(sp)
    80001558:	74e2                	ld	s1,56(sp)
    8000155a:	7942                	ld	s2,48(sp)
    8000155c:	79a2                	ld	s3,40(sp)
    8000155e:	7a02                	ld	s4,32(sp)
    80001560:	6ae2                	ld	s5,24(sp)
    80001562:	6b42                	ld	s6,16(sp)
    80001564:	6ba2                	ld	s7,8(sp)
    80001566:	6161                	addi	sp,sp,80
    80001568:	8082                	ret
    8000156a:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    8000156e:	9726                	add	a4,a4,s1
      --max;
    80001570:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    80001574:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80001578:	04e58463          	beq	a1,a4,800015c0 <copyinstr+0xa0>
{
    8000157c:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    8000157e:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    80001582:	85ca                	mv	a1,s2
    80001584:	8556                	mv	a0,s5
    80001586:	ac9ff0ef          	jal	8000104e <walkaddr>
    if(pa0 == 0)
    8000158a:	cd0d                	beqz	a0,800015c4 <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    8000158c:	417906b3          	sub	a3,s2,s7
    80001590:	96d2                	add	a3,a3,s4
    if(n > max)
    80001592:	00d9f363          	bgeu	s3,a3,80001598 <copyinstr+0x78>
    80001596:	86ce                	mv	a3,s3
    while(n > 0){
    80001598:	ca85                	beqz	a3,800015c8 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    8000159a:	01750633          	add	a2,a0,s7
    8000159e:	41260633          	sub	a2,a2,s2
    800015a2:	87a6                	mv	a5,s1
      if(*p == '\0'){
    800015a4:	8e05                	sub	a2,a2,s1
    while(n > 0){
    800015a6:	96a6                	add	a3,a3,s1
    800015a8:	85be                	mv	a1,a5
      if(*p == '\0'){
    800015aa:	00f60733          	add	a4,a2,a5
    800015ae:	00074703          	lbu	a4,0(a4)
    800015b2:	db51                	beqz	a4,80001546 <copyinstr+0x26>
        *dst = *p;
    800015b4:	00e78023          	sb	a4,0(a5)
      dst++;
    800015b8:	0785                	addi	a5,a5,1
    while(n > 0){
    800015ba:	fed797e3          	bne	a5,a3,800015a8 <copyinstr+0x88>
    800015be:	b775                	j	8000156a <copyinstr+0x4a>
    800015c0:	4781                	li	a5,0
    800015c2:	b769                	j	8000154c <copyinstr+0x2c>
      return -1;
    800015c4:	557d                	li	a0,-1
    800015c6:	b779                	j	80001554 <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    800015c8:	6b85                	lui	s7,0x1
    800015ca:	9bca                	add	s7,s7,s2
    800015cc:	87a6                	mv	a5,s1
    800015ce:	b77d                	j	8000157c <copyinstr+0x5c>
  int got_null = 0;
    800015d0:	4781                	li	a5,0
  if(got_null){
    800015d2:	0017c793          	xori	a5,a5,1
    800015d6:	40f0053b          	negw	a0,a5
}
    800015da:	8082                	ret

00000000800015dc <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    800015dc:	1141                	addi	sp,sp,-16
    800015de:	e406                	sd	ra,8(sp)
    800015e0:	e022                	sd	s0,0(sp)
    800015e2:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800015e4:	4601                	li	a2,0
    800015e6:	9cfff0ef          	jal	80000fb4 <walk>
  if (pte == 0) {
    800015ea:	c119                	beqz	a0,800015f0 <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V){
    800015ec:	6108                	ld	a0,0(a0)
    800015ee:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800015f0:	60a2                	ld	ra,8(sp)
    800015f2:	6402                	ld	s0,0(sp)
    800015f4:	0141                	addi	sp,sp,16
    800015f6:	8082                	ret

00000000800015f8 <vmfault>:
{
    800015f8:	7179                	addi	sp,sp,-48
    800015fa:	f406                	sd	ra,40(sp)
    800015fc:	f022                	sd	s0,32(sp)
    800015fe:	e84a                	sd	s2,16(sp)
    80001600:	e44e                	sd	s3,8(sp)
    80001602:	1800                	addi	s0,sp,48
    80001604:	89aa                	mv	s3,a0
    80001606:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001608:	34e000ef          	jal	80001956 <myproc>
  if (va >= p->sz)
    8000160c:	653c                	ld	a5,72(a0)
    8000160e:	00f96a63          	bltu	s2,a5,80001622 <vmfault+0x2a>
    return 0;
    80001612:	4981                	li	s3,0
}
    80001614:	854e                	mv	a0,s3
    80001616:	70a2                	ld	ra,40(sp)
    80001618:	7402                	ld	s0,32(sp)
    8000161a:	6942                	ld	s2,16(sp)
    8000161c:	69a2                	ld	s3,8(sp)
    8000161e:	6145                	addi	sp,sp,48
    80001620:	8082                	ret
    80001622:	ec26                	sd	s1,24(sp)
    80001624:	e052                	sd	s4,0(sp)
    80001626:	84aa                	mv	s1,a0
  va = PGROUNDDOWN(va);
    80001628:	77fd                	lui	a5,0xfffff
    8000162a:	00f97a33          	and	s4,s2,a5
  if(ismapped(pagetable, va)) {
    8000162e:	85d2                	mv	a1,s4
    80001630:	854e                	mv	a0,s3
    80001632:	fabff0ef          	jal	800015dc <ismapped>
    return 0;
    80001636:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    80001638:	c501                	beqz	a0,80001640 <vmfault+0x48>
    8000163a:	64e2                	ld	s1,24(sp)
    8000163c:	6a02                	ld	s4,0(sp)
    8000163e:	bfd9                	j	80001614 <vmfault+0x1c>
  mem = (uint64) kalloc();
    80001640:	d04ff0ef          	jal	80000b44 <kalloc>
    80001644:	892a                	mv	s2,a0
  if(mem == 0)
    80001646:	c905                	beqz	a0,80001676 <vmfault+0x7e>
  mem = (uint64) kalloc();
    80001648:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    8000164a:	6605                	lui	a2,0x1
    8000164c:	4581                	li	a1,0
    8000164e:	ed2ff0ef          	jal	80000d20 <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    80001652:	4759                	li	a4,22
    80001654:	86ca                	mv	a3,s2
    80001656:	6605                	lui	a2,0x1
    80001658:	85d2                	mv	a1,s4
    8000165a:	68a8                	ld	a0,80(s1)
    8000165c:	a2dff0ef          	jal	80001088 <mappages>
    80001660:	e501                	bnez	a0,80001668 <vmfault+0x70>
    80001662:	64e2                	ld	s1,24(sp)
    80001664:	6a02                	ld	s4,0(sp)
    80001666:	b77d                	j	80001614 <vmfault+0x1c>
    kfree((void *)mem);
    80001668:	854a                	mv	a0,s2
    8000166a:	bf2ff0ef          	jal	80000a5c <kfree>
    return 0;
    8000166e:	4981                	li	s3,0
    80001670:	64e2                	ld	s1,24(sp)
    80001672:	6a02                	ld	s4,0(sp)
    80001674:	b745                	j	80001614 <vmfault+0x1c>
    80001676:	64e2                	ld	s1,24(sp)
    80001678:	6a02                	ld	s4,0(sp)
    8000167a:	bf69                	j	80001614 <vmfault+0x1c>

000000008000167c <copyout>:
  while(len > 0){
    8000167c:	cad1                	beqz	a3,80001710 <copyout+0x94>
{
    8000167e:	711d                	addi	sp,sp,-96
    80001680:	ec86                	sd	ra,88(sp)
    80001682:	e8a2                	sd	s0,80(sp)
    80001684:	e4a6                	sd	s1,72(sp)
    80001686:	e0ca                	sd	s2,64(sp)
    80001688:	fc4e                	sd	s3,56(sp)
    8000168a:	f852                	sd	s4,48(sp)
    8000168c:	f456                	sd	s5,40(sp)
    8000168e:	f05a                	sd	s6,32(sp)
    80001690:	ec5e                	sd	s7,24(sp)
    80001692:	e862                	sd	s8,16(sp)
    80001694:	e466                	sd	s9,8(sp)
    80001696:	e06a                	sd	s10,0(sp)
    80001698:	1080                	addi	s0,sp,96
    8000169a:	8baa                	mv	s7,a0
    8000169c:	8a2e                	mv	s4,a1
    8000169e:	8b32                	mv	s6,a2
    800016a0:	8ab6                	mv	s5,a3
    va0 = PGROUNDDOWN(dstva);
    800016a2:	7d7d                	lui	s10,0xfffff
    if(va0 >= MAXVA)
    800016a4:	5cfd                	li	s9,-1
    800016a6:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    800016aa:	6c05                	lui	s8,0x1
    800016ac:	a005                	j	800016cc <copyout+0x50>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    800016ae:	409a0533          	sub	a0,s4,s1
    800016b2:	0009061b          	sext.w	a2,s2
    800016b6:	85da                	mv	a1,s6
    800016b8:	954e                	add	a0,a0,s3
    800016ba:	ec6ff0ef          	jal	80000d80 <memmove>
    len -= n;
    800016be:	412a8ab3          	sub	s5,s5,s2
    src += n;
    800016c2:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    800016c4:	01848a33          	add	s4,s1,s8
  while(len > 0){
    800016c8:	040a8263          	beqz	s5,8000170c <copyout+0x90>
    va0 = PGROUNDDOWN(dstva);
    800016cc:	01aa74b3          	and	s1,s4,s10
    if(va0 >= MAXVA)
    800016d0:	049ce263          	bltu	s9,s1,80001714 <copyout+0x98>
    pa0 = walkaddr(pagetable, va0);
    800016d4:	85a6                	mv	a1,s1
    800016d6:	855e                	mv	a0,s7
    800016d8:	977ff0ef          	jal	8000104e <walkaddr>
    800016dc:	89aa                	mv	s3,a0
    if(pa0 == 0) {
    800016de:	e901                	bnez	a0,800016ee <copyout+0x72>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    800016e0:	4601                	li	a2,0
    800016e2:	85a6                	mv	a1,s1
    800016e4:	855e                	mv	a0,s7
    800016e6:	f13ff0ef          	jal	800015f8 <vmfault>
    800016ea:	89aa                	mv	s3,a0
    800016ec:	c139                	beqz	a0,80001732 <copyout+0xb6>
    pte = walk(pagetable, va0, 0);
    800016ee:	4601                	li	a2,0
    800016f0:	85a6                	mv	a1,s1
    800016f2:	855e                	mv	a0,s7
    800016f4:	8c1ff0ef          	jal	80000fb4 <walk>
    if((*pte & PTE_W) == 0)
    800016f8:	611c                	ld	a5,0(a0)
    800016fa:	8b91                	andi	a5,a5,4
    800016fc:	cf8d                	beqz	a5,80001736 <copyout+0xba>
    n = PGSIZE - (dstva - va0);
    800016fe:	41448933          	sub	s2,s1,s4
    80001702:	9962                	add	s2,s2,s8
    if(n > len)
    80001704:	fb2af5e3          	bgeu	s5,s2,800016ae <copyout+0x32>
    80001708:	8956                	mv	s2,s5
    8000170a:	b755                	j	800016ae <copyout+0x32>
  return 0;
    8000170c:	4501                	li	a0,0
    8000170e:	a021                	j	80001716 <copyout+0x9a>
    80001710:	4501                	li	a0,0
}
    80001712:	8082                	ret
      return -1;
    80001714:	557d                	li	a0,-1
}
    80001716:	60e6                	ld	ra,88(sp)
    80001718:	6446                	ld	s0,80(sp)
    8000171a:	64a6                	ld	s1,72(sp)
    8000171c:	6906                	ld	s2,64(sp)
    8000171e:	79e2                	ld	s3,56(sp)
    80001720:	7a42                	ld	s4,48(sp)
    80001722:	7aa2                	ld	s5,40(sp)
    80001724:	7b02                	ld	s6,32(sp)
    80001726:	6be2                	ld	s7,24(sp)
    80001728:	6c42                	ld	s8,16(sp)
    8000172a:	6ca2                	ld	s9,8(sp)
    8000172c:	6d02                	ld	s10,0(sp)
    8000172e:	6125                	addi	sp,sp,96
    80001730:	8082                	ret
        return -1;
    80001732:	557d                	li	a0,-1
    80001734:	b7cd                	j	80001716 <copyout+0x9a>
      return -1;
    80001736:	557d                	li	a0,-1
    80001738:	bff9                	j	80001716 <copyout+0x9a>

000000008000173a <copyin>:
  while(len > 0){
    8000173a:	c6c9                	beqz	a3,800017c4 <copyin+0x8a>
{
    8000173c:	715d                	addi	sp,sp,-80
    8000173e:	e486                	sd	ra,72(sp)
    80001740:	e0a2                	sd	s0,64(sp)
    80001742:	fc26                	sd	s1,56(sp)
    80001744:	f84a                	sd	s2,48(sp)
    80001746:	f44e                	sd	s3,40(sp)
    80001748:	f052                	sd	s4,32(sp)
    8000174a:	ec56                	sd	s5,24(sp)
    8000174c:	e85a                	sd	s6,16(sp)
    8000174e:	e45e                	sd	s7,8(sp)
    80001750:	e062                	sd	s8,0(sp)
    80001752:	0880                	addi	s0,sp,80
    80001754:	8baa                	mv	s7,a0
    80001756:	8aae                	mv	s5,a1
    80001758:	8932                	mv	s2,a2
    8000175a:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    8000175c:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    8000175e:	6b05                	lui	s6,0x1
    80001760:	a035                	j	8000178c <copyin+0x52>
    80001762:	412984b3          	sub	s1,s3,s2
    80001766:	94da                	add	s1,s1,s6
    if(n > len)
    80001768:	009a7363          	bgeu	s4,s1,8000176e <copyin+0x34>
    8000176c:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    8000176e:	413905b3          	sub	a1,s2,s3
    80001772:	0004861b          	sext.w	a2,s1
    80001776:	95aa                	add	a1,a1,a0
    80001778:	8556                	mv	a0,s5
    8000177a:	e06ff0ef          	jal	80000d80 <memmove>
    len -= n;
    8000177e:	409a0a33          	sub	s4,s4,s1
    dst += n;
    80001782:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    80001784:	01698933          	add	s2,s3,s6
  while(len > 0){
    80001788:	020a0163          	beqz	s4,800017aa <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    8000178c:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    80001790:	85ce                	mv	a1,s3
    80001792:	855e                	mv	a0,s7
    80001794:	8bbff0ef          	jal	8000104e <walkaddr>
    if(pa0 == 0) {
    80001798:	f569                	bnez	a0,80001762 <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    8000179a:	4601                	li	a2,0
    8000179c:	85ce                	mv	a1,s3
    8000179e:	855e                	mv	a0,s7
    800017a0:	e59ff0ef          	jal	800015f8 <vmfault>
    800017a4:	fd5d                	bnez	a0,80001762 <copyin+0x28>
        return -1;
    800017a6:	557d                	li	a0,-1
    800017a8:	a011                	j	800017ac <copyin+0x72>
  return 0;
    800017aa:	4501                	li	a0,0
}
    800017ac:	60a6                	ld	ra,72(sp)
    800017ae:	6406                	ld	s0,64(sp)
    800017b0:	74e2                	ld	s1,56(sp)
    800017b2:	7942                	ld	s2,48(sp)
    800017b4:	79a2                	ld	s3,40(sp)
    800017b6:	7a02                	ld	s4,32(sp)
    800017b8:	6ae2                	ld	s5,24(sp)
    800017ba:	6b42                	ld	s6,16(sp)
    800017bc:	6ba2                	ld	s7,8(sp)
    800017be:	6c02                	ld	s8,0(sp)
    800017c0:	6161                	addi	sp,sp,80
    800017c2:	8082                	ret
  return 0;
    800017c4:	4501                	li	a0,0
}
    800017c6:	8082                	ret

00000000800017c8 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800017c8:	715d                	addi	sp,sp,-80
    800017ca:	e486                	sd	ra,72(sp)
    800017cc:	e0a2                	sd	s0,64(sp)
    800017ce:	fc26                	sd	s1,56(sp)
    800017d0:	f84a                	sd	s2,48(sp)
    800017d2:	f44e                	sd	s3,40(sp)
    800017d4:	f052                	sd	s4,32(sp)
    800017d6:	ec56                	sd	s5,24(sp)
    800017d8:	e85a                	sd	s6,16(sp)
    800017da:	e45e                	sd	s7,8(sp)
    800017dc:	e062                	sd	s8,0(sp)
    800017de:	0880                	addi	s0,sp,80
    800017e0:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    800017e2:	0000e497          	auipc	s1,0xe
    800017e6:	5b648493          	addi	s1,s1,1462 # 8000fd98 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800017ea:	8c26                	mv	s8,s1
    800017ec:	000a57b7          	lui	a5,0xa5
    800017f0:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800017f4:	07b2                	slli	a5,a5,0xc
    800017f6:	fa578793          	addi	a5,a5,-91
    800017fa:	4fa50937          	lui	s2,0x4fa50
    800017fe:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80001802:	1902                	slli	s2,s2,0x20
    80001804:	993e                	add	s2,s2,a5
    80001806:	040009b7          	lui	s3,0x4000
    8000180a:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    8000180c:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    8000180e:	4b99                	li	s7,6
    80001810:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    80001812:	00014a97          	auipc	s5,0x14
    80001816:	f86a8a93          	addi	s5,s5,-122 # 80015798 <tickslock>
    char *pa = kalloc();
    8000181a:	b2aff0ef          	jal	80000b44 <kalloc>
    8000181e:	862a                	mv	a2,a0
    if(pa == 0)
    80001820:	c121                	beqz	a0,80001860 <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    80001822:	418485b3          	sub	a1,s1,s8
    80001826:	858d                	srai	a1,a1,0x3
    80001828:	032585b3          	mul	a1,a1,s2
    8000182c:	05b6                	slli	a1,a1,0xd
    8000182e:	6789                	lui	a5,0x2
    80001830:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001832:	875e                	mv	a4,s7
    80001834:	86da                	mv	a3,s6
    80001836:	40b985b3          	sub	a1,s3,a1
    8000183a:	8552                	mv	a0,s4
    8000183c:	903ff0ef          	jal	8000113e <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001840:	16848493          	addi	s1,s1,360
    80001844:	fd549be3          	bne	s1,s5,8000181a <proc_mapstacks+0x52>
  }
}
    80001848:	60a6                	ld	ra,72(sp)
    8000184a:	6406                	ld	s0,64(sp)
    8000184c:	74e2                	ld	s1,56(sp)
    8000184e:	7942                	ld	s2,48(sp)
    80001850:	79a2                	ld	s3,40(sp)
    80001852:	7a02                	ld	s4,32(sp)
    80001854:	6ae2                	ld	s5,24(sp)
    80001856:	6b42                	ld	s6,16(sp)
    80001858:	6ba2                	ld	s7,8(sp)
    8000185a:	6c02                	ld	s8,0(sp)
    8000185c:	6161                	addi	sp,sp,80
    8000185e:	8082                	ret
      panic("kalloc");
    80001860:	00006517          	auipc	a0,0x6
    80001864:	8f850513          	addi	a0,a0,-1800 # 80007158 <etext+0x158>
    80001868:	fbdfe0ef          	jal	80000824 <panic>

000000008000186c <procinit>:

// initialize the proc table.
void
procinit(void)
{
    8000186c:	7139                	addi	sp,sp,-64
    8000186e:	fc06                	sd	ra,56(sp)
    80001870:	f822                	sd	s0,48(sp)
    80001872:	f426                	sd	s1,40(sp)
    80001874:	f04a                	sd	s2,32(sp)
    80001876:	ec4e                	sd	s3,24(sp)
    80001878:	e852                	sd	s4,16(sp)
    8000187a:	e456                	sd	s5,8(sp)
    8000187c:	e05a                	sd	s6,0(sp)
    8000187e:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001880:	00006597          	auipc	a1,0x6
    80001884:	8e058593          	addi	a1,a1,-1824 # 80007160 <etext+0x160>
    80001888:	0000e517          	auipc	a0,0xe
    8000188c:	0e050513          	addi	a0,a0,224 # 8000f968 <pid_lock>
    80001890:	b36ff0ef          	jal	80000bc6 <initlock>
  initlock(&wait_lock, "wait_lock");
    80001894:	00006597          	auipc	a1,0x6
    80001898:	8d458593          	addi	a1,a1,-1836 # 80007168 <etext+0x168>
    8000189c:	0000e517          	auipc	a0,0xe
    800018a0:	0e450513          	addi	a0,a0,228 # 8000f980 <wait_lock>
    800018a4:	b22ff0ef          	jal	80000bc6 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    800018a8:	0000e497          	auipc	s1,0xe
    800018ac:	4f048493          	addi	s1,s1,1264 # 8000fd98 <proc>
      initlock(&p->lock, "proc");
    800018b0:	00006b17          	auipc	s6,0x6
    800018b4:	8c8b0b13          	addi	s6,s6,-1848 # 80007178 <etext+0x178>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    800018b8:	8aa6                	mv	s5,s1
    800018ba:	000a57b7          	lui	a5,0xa5
    800018be:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800018c2:	07b2                	slli	a5,a5,0xc
    800018c4:	fa578793          	addi	a5,a5,-91
    800018c8:	4fa50937          	lui	s2,0x4fa50
    800018cc:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800018d0:	1902                	slli	s2,s2,0x20
    800018d2:	993e                	add	s2,s2,a5
    800018d4:	040009b7          	lui	s3,0x4000
    800018d8:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800018da:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    800018dc:	00014a17          	auipc	s4,0x14
    800018e0:	ebca0a13          	addi	s4,s4,-324 # 80015798 <tickslock>
      initlock(&p->lock, "proc");
    800018e4:	85da                	mv	a1,s6
    800018e6:	8526                	mv	a0,s1
    800018e8:	adeff0ef          	jal	80000bc6 <initlock>
      p->state = UNUSED;
    800018ec:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    800018f0:	415487b3          	sub	a5,s1,s5
    800018f4:	878d                	srai	a5,a5,0x3
    800018f6:	032787b3          	mul	a5,a5,s2
    800018fa:	07b6                	slli	a5,a5,0xd
    800018fc:	6709                	lui	a4,0x2
    800018fe:	9fb9                	addw	a5,a5,a4
    80001900:	40f987b3          	sub	a5,s3,a5
    80001904:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001906:	16848493          	addi	s1,s1,360
    8000190a:	fd449de3          	bne	s1,s4,800018e4 <procinit+0x78>
  }
}
    8000190e:	70e2                	ld	ra,56(sp)
    80001910:	7442                	ld	s0,48(sp)
    80001912:	74a2                	ld	s1,40(sp)
    80001914:	7902                	ld	s2,32(sp)
    80001916:	69e2                	ld	s3,24(sp)
    80001918:	6a42                	ld	s4,16(sp)
    8000191a:	6aa2                	ld	s5,8(sp)
    8000191c:	6b02                	ld	s6,0(sp)
    8000191e:	6121                	addi	sp,sp,64
    80001920:	8082                	ret

0000000080001922 <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001922:	1141                	addi	sp,sp,-16
    80001924:	e406                	sd	ra,8(sp)
    80001926:	e022                	sd	s0,0(sp)
    80001928:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    8000192a:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    8000192c:	2501                	sext.w	a0,a0
    8000192e:	60a2                	ld	ra,8(sp)
    80001930:	6402                	ld	s0,0(sp)
    80001932:	0141                	addi	sp,sp,16
    80001934:	8082                	ret

0000000080001936 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001936:	1141                	addi	sp,sp,-16
    80001938:	e406                	sd	ra,8(sp)
    8000193a:	e022                	sd	s0,0(sp)
    8000193c:	0800                	addi	s0,sp,16
    8000193e:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001940:	2781                	sext.w	a5,a5
    80001942:	079e                	slli	a5,a5,0x7
  return c;
}
    80001944:	0000e517          	auipc	a0,0xe
    80001948:	05450513          	addi	a0,a0,84 # 8000f998 <cpus>
    8000194c:	953e                	add	a0,a0,a5
    8000194e:	60a2                	ld	ra,8(sp)
    80001950:	6402                	ld	s0,0(sp)
    80001952:	0141                	addi	sp,sp,16
    80001954:	8082                	ret

0000000080001956 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001956:	1101                	addi	sp,sp,-32
    80001958:	ec06                	sd	ra,24(sp)
    8000195a:	e822                	sd	s0,16(sp)
    8000195c:	e426                	sd	s1,8(sp)
    8000195e:	1000                	addi	s0,sp,32
  push_off();
    80001960:	aacff0ef          	jal	80000c0c <push_off>
    80001964:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001966:	2781                	sext.w	a5,a5
    80001968:	079e                	slli	a5,a5,0x7
    8000196a:	0000e717          	auipc	a4,0xe
    8000196e:	ffe70713          	addi	a4,a4,-2 # 8000f968 <pid_lock>
    80001972:	97ba                	add	a5,a5,a4
    80001974:	7b9c                	ld	a5,48(a5)
    80001976:	84be                	mv	s1,a5
  pop_off();
    80001978:	b1cff0ef          	jal	80000c94 <pop_off>
  return p;
}
    8000197c:	8526                	mv	a0,s1
    8000197e:	60e2                	ld	ra,24(sp)
    80001980:	6442                	ld	s0,16(sp)
    80001982:	64a2                	ld	s1,8(sp)
    80001984:	6105                	addi	sp,sp,32
    80001986:	8082                	ret

0000000080001988 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001988:	7179                	addi	sp,sp,-48
    8000198a:	f406                	sd	ra,40(sp)
    8000198c:	f022                	sd	s0,32(sp)
    8000198e:	ec26                	sd	s1,24(sp)
    80001990:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001992:	fc5ff0ef          	jal	80001956 <myproc>
    80001996:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001998:	b4cff0ef          	jal	80000ce4 <release>

  if (first) {
    8000199c:	00006797          	auipc	a5,0x6
    800019a0:	e947a783          	lw	a5,-364(a5) # 80007830 <first.1>
    800019a4:	cf95                	beqz	a5,800019e0 <forkret+0x58>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    800019a6:	4505                	li	a0,1
    800019a8:	39d010ef          	jal	80003544 <fsinit>

    first = 0;
    800019ac:	00006797          	auipc	a5,0x6
    800019b0:	e807a223          	sw	zero,-380(a5) # 80007830 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    800019b4:	0330000f          	fence	rw,rw

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    800019b8:	00005797          	auipc	a5,0x5
    800019bc:	7c878793          	addi	a5,a5,1992 # 80007180 <etext+0x180>
    800019c0:	fcf43823          	sd	a5,-48(s0)
    800019c4:	fc043c23          	sd	zero,-40(s0)
    800019c8:	fd040593          	addi	a1,s0,-48
    800019cc:	853e                	mv	a0,a5
    800019ce:	4ff020ef          	jal	800046cc <kexec>
    800019d2:	6cbc                	ld	a5,88(s1)
    800019d4:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    800019d6:	6cbc                	ld	a5,88(s1)
    800019d8:	7bb8                	ld	a4,112(a5)
    800019da:	57fd                	li	a5,-1
    800019dc:	02f70d63          	beq	a4,a5,80001a16 <forkret+0x8e>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    800019e0:	2c3000ef          	jal	800024a2 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800019e4:	68a8                	ld	a0,80(s1)
    800019e6:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    800019e8:	04000737          	lui	a4,0x4000
    800019ec:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800019ee:	0732                	slli	a4,a4,0xc
    800019f0:	00004797          	auipc	a5,0x4
    800019f4:	6ac78793          	addi	a5,a5,1708 # 8000609c <userret>
    800019f8:	00004697          	auipc	a3,0x4
    800019fc:	60868693          	addi	a3,a3,1544 # 80006000 <_trampoline>
    80001a00:	8f95                	sub	a5,a5,a3
    80001a02:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001a04:	577d                	li	a4,-1
    80001a06:	177e                	slli	a4,a4,0x3f
    80001a08:	8d59                	or	a0,a0,a4
    80001a0a:	9782                	jalr	a5
}
    80001a0c:	70a2                	ld	ra,40(sp)
    80001a0e:	7402                	ld	s0,32(sp)
    80001a10:	64e2                	ld	s1,24(sp)
    80001a12:	6145                	addi	sp,sp,48
    80001a14:	8082                	ret
      panic("exec");
    80001a16:	00005517          	auipc	a0,0x5
    80001a1a:	77250513          	addi	a0,a0,1906 # 80007188 <etext+0x188>
    80001a1e:	e07fe0ef          	jal	80000824 <panic>

0000000080001a22 <allocpid>:
{
    80001a22:	1101                	addi	sp,sp,-32
    80001a24:	ec06                	sd	ra,24(sp)
    80001a26:	e822                	sd	s0,16(sp)
    80001a28:	e426                	sd	s1,8(sp)
    80001a2a:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001a2c:	0000e517          	auipc	a0,0xe
    80001a30:	f3c50513          	addi	a0,a0,-196 # 8000f968 <pid_lock>
    80001a34:	a1cff0ef          	jal	80000c50 <acquire>
  pid = nextpid;
    80001a38:	00006797          	auipc	a5,0x6
    80001a3c:	dfc78793          	addi	a5,a5,-516 # 80007834 <nextpid>
    80001a40:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001a42:	0014871b          	addiw	a4,s1,1
    80001a46:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001a48:	0000e517          	auipc	a0,0xe
    80001a4c:	f2050513          	addi	a0,a0,-224 # 8000f968 <pid_lock>
    80001a50:	a94ff0ef          	jal	80000ce4 <release>
}
    80001a54:	8526                	mv	a0,s1
    80001a56:	60e2                	ld	ra,24(sp)
    80001a58:	6442                	ld	s0,16(sp)
    80001a5a:	64a2                	ld	s1,8(sp)
    80001a5c:	6105                	addi	sp,sp,32
    80001a5e:	8082                	ret

0000000080001a60 <proc_pagetable>:
{
    80001a60:	1101                	addi	sp,sp,-32
    80001a62:	ec06                	sd	ra,24(sp)
    80001a64:	e822                	sd	s0,16(sp)
    80001a66:	e426                	sd	s1,8(sp)
    80001a68:	e04a                	sd	s2,0(sp)
    80001a6a:	1000                	addi	s0,sp,32
    80001a6c:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001a6e:	fc2ff0ef          	jal	80001230 <uvmcreate>
    80001a72:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001a74:	cd05                	beqz	a0,80001aac <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001a76:	4729                	li	a4,10
    80001a78:	00004697          	auipc	a3,0x4
    80001a7c:	58868693          	addi	a3,a3,1416 # 80006000 <_trampoline>
    80001a80:	6605                	lui	a2,0x1
    80001a82:	040005b7          	lui	a1,0x4000
    80001a86:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001a88:	05b2                	slli	a1,a1,0xc
    80001a8a:	dfeff0ef          	jal	80001088 <mappages>
    80001a8e:	02054663          	bltz	a0,80001aba <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001a92:	4719                	li	a4,6
    80001a94:	05893683          	ld	a3,88(s2)
    80001a98:	6605                	lui	a2,0x1
    80001a9a:	020005b7          	lui	a1,0x2000
    80001a9e:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001aa0:	05b6                	slli	a1,a1,0xd
    80001aa2:	8526                	mv	a0,s1
    80001aa4:	de4ff0ef          	jal	80001088 <mappages>
    80001aa8:	00054f63          	bltz	a0,80001ac6 <proc_pagetable+0x66>
}
    80001aac:	8526                	mv	a0,s1
    80001aae:	60e2                	ld	ra,24(sp)
    80001ab0:	6442                	ld	s0,16(sp)
    80001ab2:	64a2                	ld	s1,8(sp)
    80001ab4:	6902                	ld	s2,0(sp)
    80001ab6:	6105                	addi	sp,sp,32
    80001ab8:	8082                	ret
    uvmfree(pagetable, 0);
    80001aba:	4581                	li	a1,0
    80001abc:	8526                	mv	a0,s1
    80001abe:	96dff0ef          	jal	8000142a <uvmfree>
    return 0;
    80001ac2:	4481                	li	s1,0
    80001ac4:	b7e5                	j	80001aac <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001ac6:	4681                	li	a3,0
    80001ac8:	4605                	li	a2,1
    80001aca:	040005b7          	lui	a1,0x4000
    80001ace:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001ad0:	05b2                	slli	a1,a1,0xc
    80001ad2:	8526                	mv	a0,s1
    80001ad4:	f82ff0ef          	jal	80001256 <uvmunmap>
    uvmfree(pagetable, 0);
    80001ad8:	4581                	li	a1,0
    80001ada:	8526                	mv	a0,s1
    80001adc:	94fff0ef          	jal	8000142a <uvmfree>
    return 0;
    80001ae0:	4481                	li	s1,0
    80001ae2:	b7e9                	j	80001aac <proc_pagetable+0x4c>

0000000080001ae4 <proc_freepagetable>:
{
    80001ae4:	1101                	addi	sp,sp,-32
    80001ae6:	ec06                	sd	ra,24(sp)
    80001ae8:	e822                	sd	s0,16(sp)
    80001aea:	e426                	sd	s1,8(sp)
    80001aec:	e04a                	sd	s2,0(sp)
    80001aee:	1000                	addi	s0,sp,32
    80001af0:	84aa                	mv	s1,a0
    80001af2:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001af4:	4681                	li	a3,0
    80001af6:	4605                	li	a2,1
    80001af8:	040005b7          	lui	a1,0x4000
    80001afc:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001afe:	05b2                	slli	a1,a1,0xc
    80001b00:	f56ff0ef          	jal	80001256 <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001b04:	4681                	li	a3,0
    80001b06:	4605                	li	a2,1
    80001b08:	020005b7          	lui	a1,0x2000
    80001b0c:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001b0e:	05b6                	slli	a1,a1,0xd
    80001b10:	8526                	mv	a0,s1
    80001b12:	f44ff0ef          	jal	80001256 <uvmunmap>
  uvmfree(pagetable, sz);
    80001b16:	85ca                	mv	a1,s2
    80001b18:	8526                	mv	a0,s1
    80001b1a:	911ff0ef          	jal	8000142a <uvmfree>
}
    80001b1e:	60e2                	ld	ra,24(sp)
    80001b20:	6442                	ld	s0,16(sp)
    80001b22:	64a2                	ld	s1,8(sp)
    80001b24:	6902                	ld	s2,0(sp)
    80001b26:	6105                	addi	sp,sp,32
    80001b28:	8082                	ret

0000000080001b2a <freeproc>:
{
    80001b2a:	1101                	addi	sp,sp,-32
    80001b2c:	ec06                	sd	ra,24(sp)
    80001b2e:	e822                	sd	s0,16(sp)
    80001b30:	e426                	sd	s1,8(sp)
    80001b32:	1000                	addi	s0,sp,32
    80001b34:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001b36:	6d28                	ld	a0,88(a0)
    80001b38:	c119                	beqz	a0,80001b3e <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001b3a:	f23fe0ef          	jal	80000a5c <kfree>
  p->trapframe = 0;
    80001b3e:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001b42:	68a8                	ld	a0,80(s1)
    80001b44:	c501                	beqz	a0,80001b4c <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001b46:	64ac                	ld	a1,72(s1)
    80001b48:	f9dff0ef          	jal	80001ae4 <proc_freepagetable>
  p->pagetable = 0;
    80001b4c:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001b50:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001b54:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001b58:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001b5c:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001b60:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001b64:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001b68:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001b6c:	0004ac23          	sw	zero,24(s1)
}
    80001b70:	60e2                	ld	ra,24(sp)
    80001b72:	6442                	ld	s0,16(sp)
    80001b74:	64a2                	ld	s1,8(sp)
    80001b76:	6105                	addi	sp,sp,32
    80001b78:	8082                	ret

0000000080001b7a <allocproc>:
{
    80001b7a:	1101                	addi	sp,sp,-32
    80001b7c:	ec06                	sd	ra,24(sp)
    80001b7e:	e822                	sd	s0,16(sp)
    80001b80:	e426                	sd	s1,8(sp)
    80001b82:	e04a                	sd	s2,0(sp)
    80001b84:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001b86:	0000e497          	auipc	s1,0xe
    80001b8a:	21248493          	addi	s1,s1,530 # 8000fd98 <proc>
    80001b8e:	00014917          	auipc	s2,0x14
    80001b92:	c0a90913          	addi	s2,s2,-1014 # 80015798 <tickslock>
    acquire(&p->lock);
    80001b96:	8526                	mv	a0,s1
    80001b98:	8b8ff0ef          	jal	80000c50 <acquire>
    if(p->state == UNUSED) {
    80001b9c:	4c9c                	lw	a5,24(s1)
    80001b9e:	cb91                	beqz	a5,80001bb2 <allocproc+0x38>
      release(&p->lock);
    80001ba0:	8526                	mv	a0,s1
    80001ba2:	942ff0ef          	jal	80000ce4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001ba6:	16848493          	addi	s1,s1,360
    80001baa:	ff2496e3          	bne	s1,s2,80001b96 <allocproc+0x1c>
  return 0;
    80001bae:	4481                	li	s1,0
    80001bb0:	a089                	j	80001bf2 <allocproc+0x78>
  p->pid = allocpid();
    80001bb2:	e71ff0ef          	jal	80001a22 <allocpid>
    80001bb6:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001bb8:	4785                	li	a5,1
    80001bba:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001bbc:	f89fe0ef          	jal	80000b44 <kalloc>
    80001bc0:	892a                	mv	s2,a0
    80001bc2:	eca8                	sd	a0,88(s1)
    80001bc4:	cd15                	beqz	a0,80001c00 <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001bc6:	8526                	mv	a0,s1
    80001bc8:	e99ff0ef          	jal	80001a60 <proc_pagetable>
    80001bcc:	892a                	mv	s2,a0
    80001bce:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001bd0:	c121                	beqz	a0,80001c10 <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001bd2:	07000613          	li	a2,112
    80001bd6:	4581                	li	a1,0
    80001bd8:	06048513          	addi	a0,s1,96
    80001bdc:	944ff0ef          	jal	80000d20 <memset>
  p->context.ra = (uint64)forkret;
    80001be0:	00000797          	auipc	a5,0x0
    80001be4:	da878793          	addi	a5,a5,-600 # 80001988 <forkret>
    80001be8:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001bea:	60bc                	ld	a5,64(s1)
    80001bec:	6705                	lui	a4,0x1
    80001bee:	97ba                	add	a5,a5,a4
    80001bf0:	f4bc                	sd	a5,104(s1)
}
    80001bf2:	8526                	mv	a0,s1
    80001bf4:	60e2                	ld	ra,24(sp)
    80001bf6:	6442                	ld	s0,16(sp)
    80001bf8:	64a2                	ld	s1,8(sp)
    80001bfa:	6902                	ld	s2,0(sp)
    80001bfc:	6105                	addi	sp,sp,32
    80001bfe:	8082                	ret
    freeproc(p);
    80001c00:	8526                	mv	a0,s1
    80001c02:	f29ff0ef          	jal	80001b2a <freeproc>
    release(&p->lock);
    80001c06:	8526                	mv	a0,s1
    80001c08:	8dcff0ef          	jal	80000ce4 <release>
    return 0;
    80001c0c:	84ca                	mv	s1,s2
    80001c0e:	b7d5                	j	80001bf2 <allocproc+0x78>
    freeproc(p);
    80001c10:	8526                	mv	a0,s1
    80001c12:	f19ff0ef          	jal	80001b2a <freeproc>
    release(&p->lock);
    80001c16:	8526                	mv	a0,s1
    80001c18:	8ccff0ef          	jal	80000ce4 <release>
    return 0;
    80001c1c:	84ca                	mv	s1,s2
    80001c1e:	bfd1                	j	80001bf2 <allocproc+0x78>

0000000080001c20 <userinit>:
{
    80001c20:	1101                	addi	sp,sp,-32
    80001c22:	ec06                	sd	ra,24(sp)
    80001c24:	e822                	sd	s0,16(sp)
    80001c26:	e426                	sd	s1,8(sp)
    80001c28:	1000                	addi	s0,sp,32
  p = allocproc();
    80001c2a:	f51ff0ef          	jal	80001b7a <allocproc>
    80001c2e:	84aa                	mv	s1,a0
  initproc = p;
    80001c30:	00006797          	auipc	a5,0x6
    80001c34:	c2a7b823          	sd	a0,-976(a5) # 80007860 <initproc>
  p->cwd = namei("/");
    80001c38:	00005517          	auipc	a0,0x5
    80001c3c:	55850513          	addi	a0,a0,1368 # 80007190 <etext+0x190>
    80001c40:	63f010ef          	jal	80003a7e <namei>
    80001c44:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001c48:	478d                	li	a5,3
    80001c4a:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001c4c:	8526                	mv	a0,s1
    80001c4e:	896ff0ef          	jal	80000ce4 <release>
}
    80001c52:	60e2                	ld	ra,24(sp)
    80001c54:	6442                	ld	s0,16(sp)
    80001c56:	64a2                	ld	s1,8(sp)
    80001c58:	6105                	addi	sp,sp,32
    80001c5a:	8082                	ret

0000000080001c5c <growproc>:
{
    80001c5c:	1101                	addi	sp,sp,-32
    80001c5e:	ec06                	sd	ra,24(sp)
    80001c60:	e822                	sd	s0,16(sp)
    80001c62:	e426                	sd	s1,8(sp)
    80001c64:	e04a                	sd	s2,0(sp)
    80001c66:	1000                	addi	s0,sp,32
    80001c68:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80001c6a:	cedff0ef          	jal	80001956 <myproc>
    80001c6e:	892a                	mv	s2,a0
  sz = p->sz;
    80001c70:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001c72:	02905963          	blez	s1,80001ca4 <growproc+0x48>
    if(sz + n > TRAPFRAME) {
    80001c76:	00b48633          	add	a2,s1,a1
    80001c7a:	020007b7          	lui	a5,0x2000
    80001c7e:	17fd                	addi	a5,a5,-1 # 1ffffff <_entry-0x7e000001>
    80001c80:	07b6                	slli	a5,a5,0xd
    80001c82:	02c7ea63          	bltu	a5,a2,80001cb6 <growproc+0x5a>
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001c86:	4691                	li	a3,4
    80001c88:	6928                	ld	a0,80(a0)
    80001c8a:	e9aff0ef          	jal	80001324 <uvmalloc>
    80001c8e:	85aa                	mv	a1,a0
    80001c90:	c50d                	beqz	a0,80001cba <growproc+0x5e>
  p->sz = sz;
    80001c92:	04b93423          	sd	a1,72(s2)
  return 0;
    80001c96:	4501                	li	a0,0
}
    80001c98:	60e2                	ld	ra,24(sp)
    80001c9a:	6442                	ld	s0,16(sp)
    80001c9c:	64a2                	ld	s1,8(sp)
    80001c9e:	6902                	ld	s2,0(sp)
    80001ca0:	6105                	addi	sp,sp,32
    80001ca2:	8082                	ret
  } else if(n < 0){
    80001ca4:	fe04d7e3          	bgez	s1,80001c92 <growproc+0x36>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001ca8:	00b48633          	add	a2,s1,a1
    80001cac:	6928                	ld	a0,80(a0)
    80001cae:	e32ff0ef          	jal	800012e0 <uvmdealloc>
    80001cb2:	85aa                	mv	a1,a0
    80001cb4:	bff9                	j	80001c92 <growproc+0x36>
      return -1;
    80001cb6:	557d                	li	a0,-1
    80001cb8:	b7c5                	j	80001c98 <growproc+0x3c>
      return -1;
    80001cba:	557d                	li	a0,-1
    80001cbc:	bff1                	j	80001c98 <growproc+0x3c>

0000000080001cbe <kfork>:
{
    80001cbe:	7139                	addi	sp,sp,-64
    80001cc0:	fc06                	sd	ra,56(sp)
    80001cc2:	f822                	sd	s0,48(sp)
    80001cc4:	f426                	sd	s1,40(sp)
    80001cc6:	e456                	sd	s5,8(sp)
    80001cc8:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001cca:	c8dff0ef          	jal	80001956 <myproc>
    80001cce:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001cd0:	eabff0ef          	jal	80001b7a <allocproc>
    80001cd4:	0e050a63          	beqz	a0,80001dc8 <kfork+0x10a>
    80001cd8:	e852                	sd	s4,16(sp)
    80001cda:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001cdc:	048ab603          	ld	a2,72(s5)
    80001ce0:	692c                	ld	a1,80(a0)
    80001ce2:	050ab503          	ld	a0,80(s5)
    80001ce6:	f76ff0ef          	jal	8000145c <uvmcopy>
    80001cea:	04054863          	bltz	a0,80001d3a <kfork+0x7c>
    80001cee:	f04a                	sd	s2,32(sp)
    80001cf0:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001cf2:	048ab783          	ld	a5,72(s5)
    80001cf6:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001cfa:	058ab683          	ld	a3,88(s5)
    80001cfe:	87b6                	mv	a5,a3
    80001d00:	058a3703          	ld	a4,88(s4)
    80001d04:	12068693          	addi	a3,a3,288
    80001d08:	6388                	ld	a0,0(a5)
    80001d0a:	678c                	ld	a1,8(a5)
    80001d0c:	6b90                	ld	a2,16(a5)
    80001d0e:	e308                	sd	a0,0(a4)
    80001d10:	e70c                	sd	a1,8(a4)
    80001d12:	eb10                	sd	a2,16(a4)
    80001d14:	6f90                	ld	a2,24(a5)
    80001d16:	ef10                	sd	a2,24(a4)
    80001d18:	02078793          	addi	a5,a5,32
    80001d1c:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001d20:	fed794e3          	bne	a5,a3,80001d08 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001d24:	058a3783          	ld	a5,88(s4)
    80001d28:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001d2c:	0d0a8493          	addi	s1,s5,208
    80001d30:	0d0a0913          	addi	s2,s4,208
    80001d34:	150a8993          	addi	s3,s5,336
    80001d38:	a831                	j	80001d54 <kfork+0x96>
    freeproc(np);
    80001d3a:	8552                	mv	a0,s4
    80001d3c:	defff0ef          	jal	80001b2a <freeproc>
    release(&np->lock);
    80001d40:	8552                	mv	a0,s4
    80001d42:	fa3fe0ef          	jal	80000ce4 <release>
    return -1;
    80001d46:	54fd                	li	s1,-1
    80001d48:	6a42                	ld	s4,16(sp)
    80001d4a:	a885                	j	80001dba <kfork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001d4c:	04a1                	addi	s1,s1,8
    80001d4e:	0921                	addi	s2,s2,8
    80001d50:	01348963          	beq	s1,s3,80001d62 <kfork+0xa4>
    if(p->ofile[i])
    80001d54:	6088                	ld	a0,0(s1)
    80001d56:	d97d                	beqz	a0,80001d4c <kfork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001d58:	2e2020ef          	jal	8000403a <filedup>
    80001d5c:	00a93023          	sd	a0,0(s2)
    80001d60:	b7f5                	j	80001d4c <kfork+0x8e>
  np->cwd = idup(p->cwd);
    80001d62:	150ab503          	ld	a0,336(s5)
    80001d66:	4b4010ef          	jal	8000321a <idup>
    80001d6a:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001d6e:	4641                	li	a2,16
    80001d70:	158a8593          	addi	a1,s5,344
    80001d74:	158a0513          	addi	a0,s4,344
    80001d78:	8fcff0ef          	jal	80000e74 <safestrcpy>
  pid = np->pid;
    80001d7c:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001d80:	8552                	mv	a0,s4
    80001d82:	f63fe0ef          	jal	80000ce4 <release>
  acquire(&wait_lock);
    80001d86:	0000e517          	auipc	a0,0xe
    80001d8a:	bfa50513          	addi	a0,a0,-1030 # 8000f980 <wait_lock>
    80001d8e:	ec3fe0ef          	jal	80000c50 <acquire>
  np->parent = p;
    80001d92:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001d96:	0000e517          	auipc	a0,0xe
    80001d9a:	bea50513          	addi	a0,a0,-1046 # 8000f980 <wait_lock>
    80001d9e:	f47fe0ef          	jal	80000ce4 <release>
  acquire(&np->lock);
    80001da2:	8552                	mv	a0,s4
    80001da4:	eadfe0ef          	jal	80000c50 <acquire>
  np->state = RUNNABLE;
    80001da8:	478d                	li	a5,3
    80001daa:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001dae:	8552                	mv	a0,s4
    80001db0:	f35fe0ef          	jal	80000ce4 <release>
  return pid;
    80001db4:	7902                	ld	s2,32(sp)
    80001db6:	69e2                	ld	s3,24(sp)
    80001db8:	6a42                	ld	s4,16(sp)
}
    80001dba:	8526                	mv	a0,s1
    80001dbc:	70e2                	ld	ra,56(sp)
    80001dbe:	7442                	ld	s0,48(sp)
    80001dc0:	74a2                	ld	s1,40(sp)
    80001dc2:	6aa2                	ld	s5,8(sp)
    80001dc4:	6121                	addi	sp,sp,64
    80001dc6:	8082                	ret
    return -1;
    80001dc8:	54fd                	li	s1,-1
    80001dca:	bfc5                	j	80001dba <kfork+0xfc>

0000000080001dcc <scheduler>:
{
    80001dcc:	715d                	addi	sp,sp,-80
    80001dce:	e486                	sd	ra,72(sp)
    80001dd0:	e0a2                	sd	s0,64(sp)
    80001dd2:	fc26                	sd	s1,56(sp)
    80001dd4:	f84a                	sd	s2,48(sp)
    80001dd6:	f44e                	sd	s3,40(sp)
    80001dd8:	f052                	sd	s4,32(sp)
    80001dda:	ec56                	sd	s5,24(sp)
    80001ddc:	e85a                	sd	s6,16(sp)
    80001dde:	e45e                	sd	s7,8(sp)
    80001de0:	e062                	sd	s8,0(sp)
    80001de2:	0880                	addi	s0,sp,80
    80001de4:	8792                	mv	a5,tp
  int id = r_tp();
    80001de6:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001de8:	00779b13          	slli	s6,a5,0x7
    80001dec:	0000e717          	auipc	a4,0xe
    80001df0:	b7c70713          	addi	a4,a4,-1156 # 8000f968 <pid_lock>
    80001df4:	975a                	add	a4,a4,s6
    80001df6:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001dfa:	0000e717          	auipc	a4,0xe
    80001dfe:	ba670713          	addi	a4,a4,-1114 # 8000f9a0 <cpus+0x8>
    80001e02:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001e04:	4c11                	li	s8,4
        c->proc = p;
    80001e06:	079e                	slli	a5,a5,0x7
    80001e08:	0000ea17          	auipc	s4,0xe
    80001e0c:	b60a0a13          	addi	s4,s4,-1184 # 8000f968 <pid_lock>
    80001e10:	9a3e                	add	s4,s4,a5
        found = 1;
    80001e12:	4b85                	li	s7,1
    80001e14:	a83d                	j	80001e52 <scheduler+0x86>
      release(&p->lock);
    80001e16:	8526                	mv	a0,s1
    80001e18:	ecdfe0ef          	jal	80000ce4 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001e1c:	16848493          	addi	s1,s1,360
    80001e20:	03248563          	beq	s1,s2,80001e4a <scheduler+0x7e>
      acquire(&p->lock);
    80001e24:	8526                	mv	a0,s1
    80001e26:	e2bfe0ef          	jal	80000c50 <acquire>
      if(p->state == RUNNABLE) {
    80001e2a:	4c9c                	lw	a5,24(s1)
    80001e2c:	ff3795e3          	bne	a5,s3,80001e16 <scheduler+0x4a>
        p->state = RUNNING;
    80001e30:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001e34:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80001e38:	06048593          	addi	a1,s1,96
    80001e3c:	855a                	mv	a0,s6
    80001e3e:	5ba000ef          	jal	800023f8 <swtch>
        c->proc = 0;
    80001e42:	020a3823          	sd	zero,48(s4)
        found = 1;
    80001e46:	8ade                	mv	s5,s7
    80001e48:	b7f9                	j	80001e16 <scheduler+0x4a>
    if(found == 0) {
    80001e4a:	000a9463          	bnez	s5,80001e52 <scheduler+0x86>
      asm volatile("wfi");
    80001e4e:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e52:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80001e56:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e5a:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001e5e:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80001e62:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80001e64:	10079073          	csrw	sstatus,a5
    int found = 0;
    80001e68:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80001e6a:	0000e497          	auipc	s1,0xe
    80001e6e:	f2e48493          	addi	s1,s1,-210 # 8000fd98 <proc>
      if(p->state == RUNNABLE) {
    80001e72:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    80001e74:	00014917          	auipc	s2,0x14
    80001e78:	92490913          	addi	s2,s2,-1756 # 80015798 <tickslock>
    80001e7c:	b765                	j	80001e24 <scheduler+0x58>

0000000080001e7e <sched>:
{
    80001e7e:	7179                	addi	sp,sp,-48
    80001e80:	f406                	sd	ra,40(sp)
    80001e82:	f022                	sd	s0,32(sp)
    80001e84:	ec26                	sd	s1,24(sp)
    80001e86:	e84a                	sd	s2,16(sp)
    80001e88:	e44e                	sd	s3,8(sp)
    80001e8a:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80001e8c:	acbff0ef          	jal	80001956 <myproc>
    80001e90:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    80001e92:	d4ffe0ef          	jal	80000be0 <holding>
    80001e96:	c935                	beqz	a0,80001f0a <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001e98:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80001e9a:	2781                	sext.w	a5,a5
    80001e9c:	079e                	slli	a5,a5,0x7
    80001e9e:	0000e717          	auipc	a4,0xe
    80001ea2:	aca70713          	addi	a4,a4,-1334 # 8000f968 <pid_lock>
    80001ea6:	97ba                	add	a5,a5,a4
    80001ea8:	0a87a703          	lw	a4,168(a5)
    80001eac:	4785                	li	a5,1
    80001eae:	06f71463          	bne	a4,a5,80001f16 <sched+0x98>
  if(p->state == RUNNING)
    80001eb2:	4c98                	lw	a4,24(s1)
    80001eb4:	4791                	li	a5,4
    80001eb6:	06f70663          	beq	a4,a5,80001f22 <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80001eba:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80001ebe:	8b89                	andi	a5,a5,2
  if(intr_get())
    80001ec0:	e7bd                	bnez	a5,80001f2e <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    80001ec2:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    80001ec4:	0000e917          	auipc	s2,0xe
    80001ec8:	aa490913          	addi	s2,s2,-1372 # 8000f968 <pid_lock>
    80001ecc:	2781                	sext.w	a5,a5
    80001ece:	079e                	slli	a5,a5,0x7
    80001ed0:	97ca                	add	a5,a5,s2
    80001ed2:	0ac7a983          	lw	s3,172(a5)
    80001ed6:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    80001ed8:	2781                	sext.w	a5,a5
    80001eda:	079e                	slli	a5,a5,0x7
    80001edc:	07a1                	addi	a5,a5,8
    80001ede:	0000e597          	auipc	a1,0xe
    80001ee2:	aba58593          	addi	a1,a1,-1350 # 8000f998 <cpus>
    80001ee6:	95be                	add	a1,a1,a5
    80001ee8:	06048513          	addi	a0,s1,96
    80001eec:	50c000ef          	jal	800023f8 <swtch>
    80001ef0:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    80001ef2:	2781                	sext.w	a5,a5
    80001ef4:	079e                	slli	a5,a5,0x7
    80001ef6:	993e                	add	s2,s2,a5
    80001ef8:	0b392623          	sw	s3,172(s2)
}
    80001efc:	70a2                	ld	ra,40(sp)
    80001efe:	7402                	ld	s0,32(sp)
    80001f00:	64e2                	ld	s1,24(sp)
    80001f02:	6942                	ld	s2,16(sp)
    80001f04:	69a2                	ld	s3,8(sp)
    80001f06:	6145                	addi	sp,sp,48
    80001f08:	8082                	ret
    panic("sched p->lock");
    80001f0a:	00005517          	auipc	a0,0x5
    80001f0e:	28e50513          	addi	a0,a0,654 # 80007198 <etext+0x198>
    80001f12:	913fe0ef          	jal	80000824 <panic>
    panic("sched locks");
    80001f16:	00005517          	auipc	a0,0x5
    80001f1a:	29250513          	addi	a0,a0,658 # 800071a8 <etext+0x1a8>
    80001f1e:	907fe0ef          	jal	80000824 <panic>
    panic("sched RUNNING");
    80001f22:	00005517          	auipc	a0,0x5
    80001f26:	29650513          	addi	a0,a0,662 # 800071b8 <etext+0x1b8>
    80001f2a:	8fbfe0ef          	jal	80000824 <panic>
    panic("sched interruptible");
    80001f2e:	00005517          	auipc	a0,0x5
    80001f32:	29a50513          	addi	a0,a0,666 # 800071c8 <etext+0x1c8>
    80001f36:	8effe0ef          	jal	80000824 <panic>

0000000080001f3a <yield>:
{
    80001f3a:	1101                	addi	sp,sp,-32
    80001f3c:	ec06                	sd	ra,24(sp)
    80001f3e:	e822                	sd	s0,16(sp)
    80001f40:	e426                	sd	s1,8(sp)
    80001f42:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    80001f44:	a13ff0ef          	jal	80001956 <myproc>
    80001f48:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80001f4a:	d07fe0ef          	jal	80000c50 <acquire>
  p->state = RUNNABLE;
    80001f4e:	478d                	li	a5,3
    80001f50:	cc9c                	sw	a5,24(s1)
  sched();
    80001f52:	f2dff0ef          	jal	80001e7e <sched>
  release(&p->lock);
    80001f56:	8526                	mv	a0,s1
    80001f58:	d8dfe0ef          	jal	80000ce4 <release>
}
    80001f5c:	60e2                	ld	ra,24(sp)
    80001f5e:	6442                	ld	s0,16(sp)
    80001f60:	64a2                	ld	s1,8(sp)
    80001f62:	6105                	addi	sp,sp,32
    80001f64:	8082                	ret

0000000080001f66 <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    80001f66:	7179                	addi	sp,sp,-48
    80001f68:	f406                	sd	ra,40(sp)
    80001f6a:	f022                	sd	s0,32(sp)
    80001f6c:	ec26                	sd	s1,24(sp)
    80001f6e:	e84a                	sd	s2,16(sp)
    80001f70:	e44e                	sd	s3,8(sp)
    80001f72:	1800                	addi	s0,sp,48
    80001f74:	89aa                	mv	s3,a0
    80001f76:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80001f78:	9dfff0ef          	jal	80001956 <myproc>
    80001f7c:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80001f7e:	cd3fe0ef          	jal	80000c50 <acquire>
  release(lk);
    80001f82:	854a                	mv	a0,s2
    80001f84:	d61fe0ef          	jal	80000ce4 <release>

  // Go to sleep.
  p->chan = chan;
    80001f88:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80001f8c:	4789                	li	a5,2
    80001f8e:	cc9c                	sw	a5,24(s1)

  sched();
    80001f90:	eefff0ef          	jal	80001e7e <sched>

  // Tidy up.
  p->chan = 0;
    80001f94:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80001f98:	8526                	mv	a0,s1
    80001f9a:	d4bfe0ef          	jal	80000ce4 <release>
  acquire(lk);
    80001f9e:	854a                	mv	a0,s2
    80001fa0:	cb1fe0ef          	jal	80000c50 <acquire>
}
    80001fa4:	70a2                	ld	ra,40(sp)
    80001fa6:	7402                	ld	s0,32(sp)
    80001fa8:	64e2                	ld	s1,24(sp)
    80001faa:	6942                	ld	s2,16(sp)
    80001fac:	69a2                	ld	s3,8(sp)
    80001fae:	6145                	addi	sp,sp,48
    80001fb0:	8082                	ret

0000000080001fb2 <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    80001fb2:	7139                	addi	sp,sp,-64
    80001fb4:	fc06                	sd	ra,56(sp)
    80001fb6:	f822                	sd	s0,48(sp)
    80001fb8:	f426                	sd	s1,40(sp)
    80001fba:	f04a                	sd	s2,32(sp)
    80001fbc:	ec4e                	sd	s3,24(sp)
    80001fbe:	e852                	sd	s4,16(sp)
    80001fc0:	e456                	sd	s5,8(sp)
    80001fc2:	0080                	addi	s0,sp,64
    80001fc4:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    80001fc6:	0000e497          	auipc	s1,0xe
    80001fca:	dd248493          	addi	s1,s1,-558 # 8000fd98 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80001fce:	4989                	li	s3,2
        p->state = RUNNABLE;
    80001fd0:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    80001fd2:	00013917          	auipc	s2,0x13
    80001fd6:	7c690913          	addi	s2,s2,1990 # 80015798 <tickslock>
    80001fda:	a801                	j	80001fea <wakeup+0x38>
      }
      release(&p->lock);
    80001fdc:	8526                	mv	a0,s1
    80001fde:	d07fe0ef          	jal	80000ce4 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001fe2:	16848493          	addi	s1,s1,360
    80001fe6:	03248263          	beq	s1,s2,8000200a <wakeup+0x58>
    if(p != myproc()){
    80001fea:	96dff0ef          	jal	80001956 <myproc>
    80001fee:	fe950ae3          	beq	a0,s1,80001fe2 <wakeup+0x30>
      acquire(&p->lock);
    80001ff2:	8526                	mv	a0,s1
    80001ff4:	c5dfe0ef          	jal	80000c50 <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    80001ff8:	4c9c                	lw	a5,24(s1)
    80001ffa:	ff3791e3          	bne	a5,s3,80001fdc <wakeup+0x2a>
    80001ffe:	709c                	ld	a5,32(s1)
    80002000:	fd479ee3          	bne	a5,s4,80001fdc <wakeup+0x2a>
        p->state = RUNNABLE;
    80002004:	0154ac23          	sw	s5,24(s1)
    80002008:	bfd1                	j	80001fdc <wakeup+0x2a>
    }
  }
}
    8000200a:	70e2                	ld	ra,56(sp)
    8000200c:	7442                	ld	s0,48(sp)
    8000200e:	74a2                	ld	s1,40(sp)
    80002010:	7902                	ld	s2,32(sp)
    80002012:	69e2                	ld	s3,24(sp)
    80002014:	6a42                	ld	s4,16(sp)
    80002016:	6aa2                	ld	s5,8(sp)
    80002018:	6121                	addi	sp,sp,64
    8000201a:	8082                	ret

000000008000201c <reparent>:
{
    8000201c:	7179                	addi	sp,sp,-48
    8000201e:	f406                	sd	ra,40(sp)
    80002020:	f022                	sd	s0,32(sp)
    80002022:	ec26                	sd	s1,24(sp)
    80002024:	e84a                	sd	s2,16(sp)
    80002026:	e44e                	sd	s3,8(sp)
    80002028:	e052                	sd	s4,0(sp)
    8000202a:	1800                	addi	s0,sp,48
    8000202c:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000202e:	0000e497          	auipc	s1,0xe
    80002032:	d6a48493          	addi	s1,s1,-662 # 8000fd98 <proc>
      pp->parent = initproc;
    80002036:	00006a17          	auipc	s4,0x6
    8000203a:	82aa0a13          	addi	s4,s4,-2006 # 80007860 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    8000203e:	00013997          	auipc	s3,0x13
    80002042:	75a98993          	addi	s3,s3,1882 # 80015798 <tickslock>
    80002046:	a029                	j	80002050 <reparent+0x34>
    80002048:	16848493          	addi	s1,s1,360
    8000204c:	01348b63          	beq	s1,s3,80002062 <reparent+0x46>
    if(pp->parent == p){
    80002050:	7c9c                	ld	a5,56(s1)
    80002052:	ff279be3          	bne	a5,s2,80002048 <reparent+0x2c>
      pp->parent = initproc;
    80002056:	000a3503          	ld	a0,0(s4)
    8000205a:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    8000205c:	f57ff0ef          	jal	80001fb2 <wakeup>
    80002060:	b7e5                	j	80002048 <reparent+0x2c>
}
    80002062:	70a2                	ld	ra,40(sp)
    80002064:	7402                	ld	s0,32(sp)
    80002066:	64e2                	ld	s1,24(sp)
    80002068:	6942                	ld	s2,16(sp)
    8000206a:	69a2                	ld	s3,8(sp)
    8000206c:	6a02                	ld	s4,0(sp)
    8000206e:	6145                	addi	sp,sp,48
    80002070:	8082                	ret

0000000080002072 <kexit>:
{
    80002072:	7179                	addi	sp,sp,-48
    80002074:	f406                	sd	ra,40(sp)
    80002076:	f022                	sd	s0,32(sp)
    80002078:	ec26                	sd	s1,24(sp)
    8000207a:	e84a                	sd	s2,16(sp)
    8000207c:	e44e                	sd	s3,8(sp)
    8000207e:	e052                	sd	s4,0(sp)
    80002080:	1800                	addi	s0,sp,48
    80002082:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    80002084:	8d3ff0ef          	jal	80001956 <myproc>
    80002088:	89aa                	mv	s3,a0
  if(p == initproc)
    8000208a:	00005797          	auipc	a5,0x5
    8000208e:	7d67b783          	ld	a5,2006(a5) # 80007860 <initproc>
    80002092:	0d050493          	addi	s1,a0,208
    80002096:	15050913          	addi	s2,a0,336
    8000209a:	00a79b63          	bne	a5,a0,800020b0 <kexit+0x3e>
    panic("init exiting");
    8000209e:	00005517          	auipc	a0,0x5
    800020a2:	14250513          	addi	a0,a0,322 # 800071e0 <etext+0x1e0>
    800020a6:	f7efe0ef          	jal	80000824 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    800020aa:	04a1                	addi	s1,s1,8
    800020ac:	01248963          	beq	s1,s2,800020be <kexit+0x4c>
    if(p->ofile[fd]){
    800020b0:	6088                	ld	a0,0(s1)
    800020b2:	dd65                	beqz	a0,800020aa <kexit+0x38>
      fileclose(f);
    800020b4:	7cd010ef          	jal	80004080 <fileclose>
      p->ofile[fd] = 0;
    800020b8:	0004b023          	sd	zero,0(s1)
    800020bc:	b7fd                	j	800020aa <kexit+0x38>
  begin_op();
    800020be:	39f010ef          	jal	80003c5c <begin_op>
  iput(p->cwd);
    800020c2:	1509b503          	ld	a0,336(s3)
    800020c6:	30c010ef          	jal	800033d2 <iput>
  end_op();
    800020ca:	403010ef          	jal	80003ccc <end_op>
  p->cwd = 0;
    800020ce:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    800020d2:	0000e517          	auipc	a0,0xe
    800020d6:	8ae50513          	addi	a0,a0,-1874 # 8000f980 <wait_lock>
    800020da:	b77fe0ef          	jal	80000c50 <acquire>
  reparent(p);
    800020de:	854e                	mv	a0,s3
    800020e0:	f3dff0ef          	jal	8000201c <reparent>
  wakeup(p->parent);
    800020e4:	0389b503          	ld	a0,56(s3)
    800020e8:	ecbff0ef          	jal	80001fb2 <wakeup>
  acquire(&p->lock);
    800020ec:	854e                	mv	a0,s3
    800020ee:	b63fe0ef          	jal	80000c50 <acquire>
  p->xstate = status;
    800020f2:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800020f6:	4795                	li	a5,5
    800020f8:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800020fc:	0000e517          	auipc	a0,0xe
    80002100:	88450513          	addi	a0,a0,-1916 # 8000f980 <wait_lock>
    80002104:	be1fe0ef          	jal	80000ce4 <release>
  sched();
    80002108:	d77ff0ef          	jal	80001e7e <sched>
  panic("zombie exit");
    8000210c:	00005517          	auipc	a0,0x5
    80002110:	0e450513          	addi	a0,a0,228 # 800071f0 <etext+0x1f0>
    80002114:	f10fe0ef          	jal	80000824 <panic>

0000000080002118 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    80002118:	7179                	addi	sp,sp,-48
    8000211a:	f406                	sd	ra,40(sp)
    8000211c:	f022                	sd	s0,32(sp)
    8000211e:	ec26                	sd	s1,24(sp)
    80002120:	e84a                	sd	s2,16(sp)
    80002122:	e44e                	sd	s3,8(sp)
    80002124:	1800                	addi	s0,sp,48
    80002126:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    80002128:	0000e497          	auipc	s1,0xe
    8000212c:	c7048493          	addi	s1,s1,-912 # 8000fd98 <proc>
    80002130:	00013997          	auipc	s3,0x13
    80002134:	66898993          	addi	s3,s3,1640 # 80015798 <tickslock>
    acquire(&p->lock);
    80002138:	8526                	mv	a0,s1
    8000213a:	b17fe0ef          	jal	80000c50 <acquire>
    if(p->pid == pid){
    8000213e:	589c                	lw	a5,48(s1)
    80002140:	01278b63          	beq	a5,s2,80002156 <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    80002144:	8526                	mv	a0,s1
    80002146:	b9ffe0ef          	jal	80000ce4 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    8000214a:	16848493          	addi	s1,s1,360
    8000214e:	ff3495e3          	bne	s1,s3,80002138 <kkill+0x20>
  }
  return -1;
    80002152:	557d                	li	a0,-1
    80002154:	a819                	j	8000216a <kkill+0x52>
      p->killed = 1;
    80002156:	4785                	li	a5,1
    80002158:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    8000215a:	4c98                	lw	a4,24(s1)
    8000215c:	4789                	li	a5,2
    8000215e:	00f70d63          	beq	a4,a5,80002178 <kkill+0x60>
      release(&p->lock);
    80002162:	8526                	mv	a0,s1
    80002164:	b81fe0ef          	jal	80000ce4 <release>
      return 0;
    80002168:	4501                	li	a0,0
}
    8000216a:	70a2                	ld	ra,40(sp)
    8000216c:	7402                	ld	s0,32(sp)
    8000216e:	64e2                	ld	s1,24(sp)
    80002170:	6942                	ld	s2,16(sp)
    80002172:	69a2                	ld	s3,8(sp)
    80002174:	6145                	addi	sp,sp,48
    80002176:	8082                	ret
        p->state = RUNNABLE;
    80002178:	478d                	li	a5,3
    8000217a:	cc9c                	sw	a5,24(s1)
    8000217c:	b7dd                	j	80002162 <kkill+0x4a>

000000008000217e <setkilled>:

void
setkilled(struct proc *p)
{
    8000217e:	1101                	addi	sp,sp,-32
    80002180:	ec06                	sd	ra,24(sp)
    80002182:	e822                	sd	s0,16(sp)
    80002184:	e426                	sd	s1,8(sp)
    80002186:	1000                	addi	s0,sp,32
    80002188:	84aa                	mv	s1,a0
  acquire(&p->lock);
    8000218a:	ac7fe0ef          	jal	80000c50 <acquire>
  p->killed = 1;
    8000218e:	4785                	li	a5,1
    80002190:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    80002192:	8526                	mv	a0,s1
    80002194:	b51fe0ef          	jal	80000ce4 <release>
}
    80002198:	60e2                	ld	ra,24(sp)
    8000219a:	6442                	ld	s0,16(sp)
    8000219c:	64a2                	ld	s1,8(sp)
    8000219e:	6105                	addi	sp,sp,32
    800021a0:	8082                	ret

00000000800021a2 <killed>:

int
killed(struct proc *p)
{
    800021a2:	1101                	addi	sp,sp,-32
    800021a4:	ec06                	sd	ra,24(sp)
    800021a6:	e822                	sd	s0,16(sp)
    800021a8:	e426                	sd	s1,8(sp)
    800021aa:	e04a                	sd	s2,0(sp)
    800021ac:	1000                	addi	s0,sp,32
    800021ae:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    800021b0:	aa1fe0ef          	jal	80000c50 <acquire>
  k = p->killed;
    800021b4:	549c                	lw	a5,40(s1)
    800021b6:	893e                	mv	s2,a5
  release(&p->lock);
    800021b8:	8526                	mv	a0,s1
    800021ba:	b2bfe0ef          	jal	80000ce4 <release>
  return k;
}
    800021be:	854a                	mv	a0,s2
    800021c0:	60e2                	ld	ra,24(sp)
    800021c2:	6442                	ld	s0,16(sp)
    800021c4:	64a2                	ld	s1,8(sp)
    800021c6:	6902                	ld	s2,0(sp)
    800021c8:	6105                	addi	sp,sp,32
    800021ca:	8082                	ret

00000000800021cc <kwait>:
{
    800021cc:	715d                	addi	sp,sp,-80
    800021ce:	e486                	sd	ra,72(sp)
    800021d0:	e0a2                	sd	s0,64(sp)
    800021d2:	fc26                	sd	s1,56(sp)
    800021d4:	f84a                	sd	s2,48(sp)
    800021d6:	f44e                	sd	s3,40(sp)
    800021d8:	f052                	sd	s4,32(sp)
    800021da:	ec56                	sd	s5,24(sp)
    800021dc:	e85a                	sd	s6,16(sp)
    800021de:	e45e                	sd	s7,8(sp)
    800021e0:	0880                	addi	s0,sp,80
    800021e2:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    800021e4:	f72ff0ef          	jal	80001956 <myproc>
    800021e8:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800021ea:	0000d517          	auipc	a0,0xd
    800021ee:	79650513          	addi	a0,a0,1942 # 8000f980 <wait_lock>
    800021f2:	a5ffe0ef          	jal	80000c50 <acquire>
        if(pp->state == ZOMBIE){
    800021f6:	4a15                	li	s4,5
        havekids = 1;
    800021f8:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800021fa:	00013997          	auipc	s3,0x13
    800021fe:	59e98993          	addi	s3,s3,1438 # 80015798 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002202:	0000db17          	auipc	s6,0xd
    80002206:	77eb0b13          	addi	s6,s6,1918 # 8000f980 <wait_lock>
    8000220a:	a869                	j	800022a4 <kwait+0xd8>
          pid = pp->pid;
    8000220c:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    80002210:	000b8c63          	beqz	s7,80002228 <kwait+0x5c>
    80002214:	4691                	li	a3,4
    80002216:	02c48613          	addi	a2,s1,44
    8000221a:	85de                	mv	a1,s7
    8000221c:	05093503          	ld	a0,80(s2)
    80002220:	c5cff0ef          	jal	8000167c <copyout>
    80002224:	02054a63          	bltz	a0,80002258 <kwait+0x8c>
          freeproc(pp);
    80002228:	8526                	mv	a0,s1
    8000222a:	901ff0ef          	jal	80001b2a <freeproc>
          release(&pp->lock);
    8000222e:	8526                	mv	a0,s1
    80002230:	ab5fe0ef          	jal	80000ce4 <release>
          release(&wait_lock);
    80002234:	0000d517          	auipc	a0,0xd
    80002238:	74c50513          	addi	a0,a0,1868 # 8000f980 <wait_lock>
    8000223c:	aa9fe0ef          	jal	80000ce4 <release>
}
    80002240:	854e                	mv	a0,s3
    80002242:	60a6                	ld	ra,72(sp)
    80002244:	6406                	ld	s0,64(sp)
    80002246:	74e2                	ld	s1,56(sp)
    80002248:	7942                	ld	s2,48(sp)
    8000224a:	79a2                	ld	s3,40(sp)
    8000224c:	7a02                	ld	s4,32(sp)
    8000224e:	6ae2                	ld	s5,24(sp)
    80002250:	6b42                	ld	s6,16(sp)
    80002252:	6ba2                	ld	s7,8(sp)
    80002254:	6161                	addi	sp,sp,80
    80002256:	8082                	ret
            release(&pp->lock);
    80002258:	8526                	mv	a0,s1
    8000225a:	a8bfe0ef          	jal	80000ce4 <release>
            release(&wait_lock);
    8000225e:	0000d517          	auipc	a0,0xd
    80002262:	72250513          	addi	a0,a0,1826 # 8000f980 <wait_lock>
    80002266:	a7ffe0ef          	jal	80000ce4 <release>
            return -1;
    8000226a:	59fd                	li	s3,-1
    8000226c:	bfd1                	j	80002240 <kwait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000226e:	16848493          	addi	s1,s1,360
    80002272:	03348063          	beq	s1,s3,80002292 <kwait+0xc6>
      if(pp->parent == p){
    80002276:	7c9c                	ld	a5,56(s1)
    80002278:	ff279be3          	bne	a5,s2,8000226e <kwait+0xa2>
        acquire(&pp->lock);
    8000227c:	8526                	mv	a0,s1
    8000227e:	9d3fe0ef          	jal	80000c50 <acquire>
        if(pp->state == ZOMBIE){
    80002282:	4c9c                	lw	a5,24(s1)
    80002284:	f94784e3          	beq	a5,s4,8000220c <kwait+0x40>
        release(&pp->lock);
    80002288:	8526                	mv	a0,s1
    8000228a:	a5bfe0ef          	jal	80000ce4 <release>
        havekids = 1;
    8000228e:	8756                	mv	a4,s5
    80002290:	bff9                	j	8000226e <kwait+0xa2>
    if(!havekids || killed(p)){
    80002292:	cf19                	beqz	a4,800022b0 <kwait+0xe4>
    80002294:	854a                	mv	a0,s2
    80002296:	f0dff0ef          	jal	800021a2 <killed>
    8000229a:	e919                	bnez	a0,800022b0 <kwait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    8000229c:	85da                	mv	a1,s6
    8000229e:	854a                	mv	a0,s2
    800022a0:	cc7ff0ef          	jal	80001f66 <sleep>
    havekids = 0;
    800022a4:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800022a6:	0000e497          	auipc	s1,0xe
    800022aa:	af248493          	addi	s1,s1,-1294 # 8000fd98 <proc>
    800022ae:	b7e1                	j	80002276 <kwait+0xaa>
      release(&wait_lock);
    800022b0:	0000d517          	auipc	a0,0xd
    800022b4:	6d050513          	addi	a0,a0,1744 # 8000f980 <wait_lock>
    800022b8:	a2dfe0ef          	jal	80000ce4 <release>
      return -1;
    800022bc:	59fd                	li	s3,-1
    800022be:	b749                	j	80002240 <kwait+0x74>

00000000800022c0 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    800022c0:	7179                	addi	sp,sp,-48
    800022c2:	f406                	sd	ra,40(sp)
    800022c4:	f022                	sd	s0,32(sp)
    800022c6:	ec26                	sd	s1,24(sp)
    800022c8:	e84a                	sd	s2,16(sp)
    800022ca:	e44e                	sd	s3,8(sp)
    800022cc:	e052                	sd	s4,0(sp)
    800022ce:	1800                	addi	s0,sp,48
    800022d0:	84aa                	mv	s1,a0
    800022d2:	8a2e                	mv	s4,a1
    800022d4:	89b2                	mv	s3,a2
    800022d6:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800022d8:	e7eff0ef          	jal	80001956 <myproc>
  if(user_dst){
    800022dc:	cc99                	beqz	s1,800022fa <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800022de:	86ca                	mv	a3,s2
    800022e0:	864e                	mv	a2,s3
    800022e2:	85d2                	mv	a1,s4
    800022e4:	6928                	ld	a0,80(a0)
    800022e6:	b96ff0ef          	jal	8000167c <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800022ea:	70a2                	ld	ra,40(sp)
    800022ec:	7402                	ld	s0,32(sp)
    800022ee:	64e2                	ld	s1,24(sp)
    800022f0:	6942                	ld	s2,16(sp)
    800022f2:	69a2                	ld	s3,8(sp)
    800022f4:	6a02                	ld	s4,0(sp)
    800022f6:	6145                	addi	sp,sp,48
    800022f8:	8082                	ret
    memmove((char *)dst, src, len);
    800022fa:	0009061b          	sext.w	a2,s2
    800022fe:	85ce                	mv	a1,s3
    80002300:	8552                	mv	a0,s4
    80002302:	a7ffe0ef          	jal	80000d80 <memmove>
    return 0;
    80002306:	8526                	mv	a0,s1
    80002308:	b7cd                	j	800022ea <either_copyout+0x2a>

000000008000230a <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    8000230a:	7179                	addi	sp,sp,-48
    8000230c:	f406                	sd	ra,40(sp)
    8000230e:	f022                	sd	s0,32(sp)
    80002310:	ec26                	sd	s1,24(sp)
    80002312:	e84a                	sd	s2,16(sp)
    80002314:	e44e                	sd	s3,8(sp)
    80002316:	e052                	sd	s4,0(sp)
    80002318:	1800                	addi	s0,sp,48
    8000231a:	8a2a                	mv	s4,a0
    8000231c:	84ae                	mv	s1,a1
    8000231e:	89b2                	mv	s3,a2
    80002320:	8936                	mv	s2,a3
  struct proc *p = myproc();
    80002322:	e34ff0ef          	jal	80001956 <myproc>
  if(user_src){
    80002326:	cc99                	beqz	s1,80002344 <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    80002328:	86ca                	mv	a3,s2
    8000232a:	864e                	mv	a2,s3
    8000232c:	85d2                	mv	a1,s4
    8000232e:	6928                	ld	a0,80(a0)
    80002330:	c0aff0ef          	jal	8000173a <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    80002334:	70a2                	ld	ra,40(sp)
    80002336:	7402                	ld	s0,32(sp)
    80002338:	64e2                	ld	s1,24(sp)
    8000233a:	6942                	ld	s2,16(sp)
    8000233c:	69a2                	ld	s3,8(sp)
    8000233e:	6a02                	ld	s4,0(sp)
    80002340:	6145                	addi	sp,sp,48
    80002342:	8082                	ret
    memmove(dst, (char*)src, len);
    80002344:	0009061b          	sext.w	a2,s2
    80002348:	85ce                	mv	a1,s3
    8000234a:	8552                	mv	a0,s4
    8000234c:	a35fe0ef          	jal	80000d80 <memmove>
    return 0;
    80002350:	8526                	mv	a0,s1
    80002352:	b7cd                	j	80002334 <either_copyin+0x2a>

0000000080002354 <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    80002354:	715d                	addi	sp,sp,-80
    80002356:	e486                	sd	ra,72(sp)
    80002358:	e0a2                	sd	s0,64(sp)
    8000235a:	fc26                	sd	s1,56(sp)
    8000235c:	f84a                	sd	s2,48(sp)
    8000235e:	f44e                	sd	s3,40(sp)
    80002360:	f052                	sd	s4,32(sp)
    80002362:	ec56                	sd	s5,24(sp)
    80002364:	e85a                	sd	s6,16(sp)
    80002366:	e45e                	sd	s7,8(sp)
    80002368:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    8000236a:	00005517          	auipc	a0,0x5
    8000236e:	d0e50513          	addi	a0,a0,-754 # 80007078 <etext+0x78>
    80002372:	988fe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002376:	0000e497          	auipc	s1,0xe
    8000237a:	b7a48493          	addi	s1,s1,-1158 # 8000fef0 <proc+0x158>
    8000237e:	00013917          	auipc	s2,0x13
    80002382:	57290913          	addi	s2,s2,1394 # 800158f0 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002386:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002388:	00005997          	auipc	s3,0x5
    8000238c:	e7898993          	addi	s3,s3,-392 # 80007200 <etext+0x200>
    printf("%d %s %s", p->pid, state, p->name);
    80002390:	00005a97          	auipc	s5,0x5
    80002394:	e78a8a93          	addi	s5,s5,-392 # 80007208 <etext+0x208>
    printf("\n");
    80002398:	00005a17          	auipc	s4,0x5
    8000239c:	ce0a0a13          	addi	s4,s4,-800 # 80007078 <etext+0x78>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023a0:	00005b97          	auipc	s7,0x5
    800023a4:	388b8b93          	addi	s7,s7,904 # 80007728 <states.0>
    800023a8:	a829                	j	800023c2 <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    800023aa:	ed86a583          	lw	a1,-296(a3)
    800023ae:	8556                	mv	a0,s5
    800023b0:	94afe0ef          	jal	800004fa <printf>
    printf("\n");
    800023b4:	8552                	mv	a0,s4
    800023b6:	944fe0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    800023ba:	16848493          	addi	s1,s1,360
    800023be:	03248263          	beq	s1,s2,800023e2 <procdump+0x8e>
    if(p->state == UNUSED)
    800023c2:	86a6                	mv	a3,s1
    800023c4:	ec04a783          	lw	a5,-320(s1)
    800023c8:	dbed                	beqz	a5,800023ba <procdump+0x66>
      state = "???";
    800023ca:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    800023cc:	fcfb6fe3          	bltu	s6,a5,800023aa <procdump+0x56>
    800023d0:	02079713          	slli	a4,a5,0x20
    800023d4:	01d75793          	srli	a5,a4,0x1d
    800023d8:	97de                	add	a5,a5,s7
    800023da:	6390                	ld	a2,0(a5)
    800023dc:	f679                	bnez	a2,800023aa <procdump+0x56>
      state = "???";
    800023de:	864e                	mv	a2,s3
    800023e0:	b7e9                	j	800023aa <procdump+0x56>
  }
}
    800023e2:	60a6                	ld	ra,72(sp)
    800023e4:	6406                	ld	s0,64(sp)
    800023e6:	74e2                	ld	s1,56(sp)
    800023e8:	7942                	ld	s2,48(sp)
    800023ea:	79a2                	ld	s3,40(sp)
    800023ec:	7a02                	ld	s4,32(sp)
    800023ee:	6ae2                	ld	s5,24(sp)
    800023f0:	6b42                	ld	s6,16(sp)
    800023f2:	6ba2                	ld	s7,8(sp)
    800023f4:	6161                	addi	sp,sp,80
    800023f6:	8082                	ret

00000000800023f8 <swtch>:
# Save current registers in old. Load from new.


.globl swtch
swtch:
        sd ra, 0(a0)
    800023f8:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    800023fc:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    80002400:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    80002402:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    80002404:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    80002408:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    8000240c:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    80002410:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    80002414:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    80002418:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    8000241c:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    80002420:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    80002424:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    80002428:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    8000242c:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    80002430:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    80002434:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    80002436:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002438:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    8000243c:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002440:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    80002444:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002448:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    8000244c:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002450:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    80002454:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002458:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    8000245c:	0685bd83          	ld	s11,104(a1)

        ret
    80002460:	8082                	ret

0000000080002462 <trapinit>:

extern int devintr();

void
trapinit(void)
{
    80002462:	1141                	addi	sp,sp,-16
    80002464:	e406                	sd	ra,8(sp)
    80002466:	e022                	sd	s0,0(sp)
    80002468:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    8000246a:	00005597          	auipc	a1,0x5
    8000246e:	dde58593          	addi	a1,a1,-546 # 80007248 <etext+0x248>
    80002472:	00013517          	auipc	a0,0x13
    80002476:	32650513          	addi	a0,a0,806 # 80015798 <tickslock>
    8000247a:	f4cfe0ef          	jal	80000bc6 <initlock>
}
    8000247e:	60a2                	ld	ra,8(sp)
    80002480:	6402                	ld	s0,0(sp)
    80002482:	0141                	addi	sp,sp,16
    80002484:	8082                	ret

0000000080002486 <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    80002486:	1141                	addi	sp,sp,-16
    80002488:	e406                	sd	ra,8(sp)
    8000248a:	e022                	sd	s0,0(sp)
    8000248c:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000248e:	00003797          	auipc	a5,0x3
    80002492:	fb278793          	addi	a5,a5,-78 # 80005440 <kernelvec>
    80002496:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    8000249a:	60a2                	ld	ra,8(sp)
    8000249c:	6402                	ld	s0,0(sp)
    8000249e:	0141                	addi	sp,sp,16
    800024a0:	8082                	ret

00000000800024a2 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    800024a2:	1141                	addi	sp,sp,-16
    800024a4:	e406                	sd	ra,8(sp)
    800024a6:	e022                	sd	s0,0(sp)
    800024a8:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    800024aa:	cacff0ef          	jal	80001956 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800024ae:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    800024b2:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800024b4:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    800024b8:	04000737          	lui	a4,0x4000
    800024bc:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    800024be:	0732                	slli	a4,a4,0xc
    800024c0:	00004797          	auipc	a5,0x4
    800024c4:	b4078793          	addi	a5,a5,-1216 # 80006000 <_trampoline>
    800024c8:	00004697          	auipc	a3,0x4
    800024cc:	b3868693          	addi	a3,a3,-1224 # 80006000 <_trampoline>
    800024d0:	8f95                	sub	a5,a5,a3
    800024d2:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    800024d4:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    800024d8:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    800024da:	18002773          	csrr	a4,satp
    800024de:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    800024e0:	6d38                	ld	a4,88(a0)
    800024e2:	613c                	ld	a5,64(a0)
    800024e4:	6685                	lui	a3,0x1
    800024e6:	97b6                	add	a5,a5,a3
    800024e8:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    800024ea:	6d3c                	ld	a5,88(a0)
    800024ec:	00000717          	auipc	a4,0x0
    800024f0:	0fc70713          	addi	a4,a4,252 # 800025e8 <usertrap>
    800024f4:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    800024f6:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    800024f8:	8712                	mv	a4,tp
    800024fa:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800024fc:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    80002500:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002504:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002508:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    8000250c:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000250e:	6f9c                	ld	a5,24(a5)
    80002510:	14179073          	csrw	sepc,a5
}
    80002514:	60a2                	ld	ra,8(sp)
    80002516:	6402                	ld	s0,0(sp)
    80002518:	0141                	addi	sp,sp,16
    8000251a:	8082                	ret

000000008000251c <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    8000251c:	1141                	addi	sp,sp,-16
    8000251e:	e406                	sd	ra,8(sp)
    80002520:	e022                	sd	s0,0(sp)
    80002522:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    80002524:	bfeff0ef          	jal	80001922 <cpuid>
    80002528:	cd11                	beqz	a0,80002544 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    8000252a:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    8000252e:	000f4737          	lui	a4,0xf4
    80002532:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80002536:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80002538:	14d79073          	csrw	stimecmp,a5
}
    8000253c:	60a2                	ld	ra,8(sp)
    8000253e:	6402                	ld	s0,0(sp)
    80002540:	0141                	addi	sp,sp,16
    80002542:	8082                	ret
    acquire(&tickslock);
    80002544:	00013517          	auipc	a0,0x13
    80002548:	25450513          	addi	a0,a0,596 # 80015798 <tickslock>
    8000254c:	f04fe0ef          	jal	80000c50 <acquire>
    ticks++;
    80002550:	00005717          	auipc	a4,0x5
    80002554:	31870713          	addi	a4,a4,792 # 80007868 <ticks>
    80002558:	431c                	lw	a5,0(a4)
    8000255a:	2785                	addiw	a5,a5,1
    8000255c:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    8000255e:	853a                	mv	a0,a4
    80002560:	a53ff0ef          	jal	80001fb2 <wakeup>
    release(&tickslock);
    80002564:	00013517          	auipc	a0,0x13
    80002568:	23450513          	addi	a0,a0,564 # 80015798 <tickslock>
    8000256c:	f78fe0ef          	jal	80000ce4 <release>
    80002570:	bf6d                	j	8000252a <clockintr+0xe>

0000000080002572 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    80002572:	1101                	addi	sp,sp,-32
    80002574:	ec06                	sd	ra,24(sp)
    80002576:	e822                	sd	s0,16(sp)
    80002578:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000257a:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    8000257e:	57fd                	li	a5,-1
    80002580:	17fe                	slli	a5,a5,0x3f
    80002582:	07a5                	addi	a5,a5,9
    80002584:	00f70c63          	beq	a4,a5,8000259c <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002588:	57fd                	li	a5,-1
    8000258a:	17fe                	slli	a5,a5,0x3f
    8000258c:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    8000258e:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    80002590:	04f70863          	beq	a4,a5,800025e0 <devintr+0x6e>
  }
}
    80002594:	60e2                	ld	ra,24(sp)
    80002596:	6442                	ld	s0,16(sp)
    80002598:	6105                	addi	sp,sp,32
    8000259a:	8082                	ret
    8000259c:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    8000259e:	74f020ef          	jal	800054ec <plic_claim>
    800025a2:	872a                	mv	a4,a0
    800025a4:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    800025a6:	47a9                	li	a5,10
    800025a8:	00f50963          	beq	a0,a5,800025ba <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    800025ac:	4785                	li	a5,1
    800025ae:	00f50963          	beq	a0,a5,800025c0 <devintr+0x4e>
    return 1;
    800025b2:	4505                	li	a0,1
    } else if(irq){
    800025b4:	eb09                	bnez	a4,800025c6 <devintr+0x54>
    800025b6:	64a2                	ld	s1,8(sp)
    800025b8:	bff1                	j	80002594 <devintr+0x22>
      uartintr();
    800025ba:	c3afe0ef          	jal	800009f4 <uartintr>
    if(irq)
    800025be:	a819                	j	800025d4 <devintr+0x62>
      virtio_disk_intr();
    800025c0:	3c2030ef          	jal	80005982 <virtio_disk_intr>
    if(irq)
    800025c4:	a801                	j	800025d4 <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    800025c6:	85ba                	mv	a1,a4
    800025c8:	00005517          	auipc	a0,0x5
    800025cc:	c8850513          	addi	a0,a0,-888 # 80007250 <etext+0x250>
    800025d0:	f2bfd0ef          	jal	800004fa <printf>
      plic_complete(irq);
    800025d4:	8526                	mv	a0,s1
    800025d6:	737020ef          	jal	8000550c <plic_complete>
    return 1;
    800025da:	4505                	li	a0,1
    800025dc:	64a2                	ld	s1,8(sp)
    800025de:	bf5d                	j	80002594 <devintr+0x22>
    clockintr();
    800025e0:	f3dff0ef          	jal	8000251c <clockintr>
    return 2;
    800025e4:	4509                	li	a0,2
    800025e6:	b77d                	j	80002594 <devintr+0x22>

00000000800025e8 <usertrap>:
{
    800025e8:	1101                	addi	sp,sp,-32
    800025ea:	ec06                	sd	ra,24(sp)
    800025ec:	e822                	sd	s0,16(sp)
    800025ee:	e426                	sd	s1,8(sp)
    800025f0:	e04a                	sd	s2,0(sp)
    800025f2:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800025f4:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    800025f8:	1007f793          	andi	a5,a5,256
    800025fc:	eba5                	bnez	a5,8000266c <usertrap+0x84>
  asm volatile("csrw stvec, %0" : : "r" (x));
    800025fe:	00003797          	auipc	a5,0x3
    80002602:	e4278793          	addi	a5,a5,-446 # 80005440 <kernelvec>
    80002606:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    8000260a:	b4cff0ef          	jal	80001956 <myproc>
    8000260e:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    80002610:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002612:	14102773          	csrr	a4,sepc
    80002616:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002618:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    8000261c:	47a1                	li	a5,8
    8000261e:	04f70d63          	beq	a4,a5,80002678 <usertrap+0x90>
  } else if((which_dev = devintr()) != 0){
    80002622:	f51ff0ef          	jal	80002572 <devintr>
    80002626:	892a                	mv	s2,a0
    80002628:	e945                	bnez	a0,800026d8 <usertrap+0xf0>
    8000262a:	14202773          	csrr	a4,scause
  } else if((r_scause() == 15 || r_scause() == 13) &&
    8000262e:	47bd                	li	a5,15
    80002630:	08f70863          	beq	a4,a5,800026c0 <usertrap+0xd8>
    80002634:	14202773          	csrr	a4,scause
    80002638:	47b5                	li	a5,13
    8000263a:	08f70363          	beq	a4,a5,800026c0 <usertrap+0xd8>
    8000263e:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002642:	5890                	lw	a2,48(s1)
    80002644:	00005517          	auipc	a0,0x5
    80002648:	c4c50513          	addi	a0,a0,-948 # 80007290 <etext+0x290>
    8000264c:	eaffd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002650:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002654:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    80002658:	00005517          	auipc	a0,0x5
    8000265c:	c6850513          	addi	a0,a0,-920 # 800072c0 <etext+0x2c0>
    80002660:	e9bfd0ef          	jal	800004fa <printf>
    setkilled(p);
    80002664:	8526                	mv	a0,s1
    80002666:	b19ff0ef          	jal	8000217e <setkilled>
    8000266a:	a035                	j	80002696 <usertrap+0xae>
    panic("usertrap: not from user mode");
    8000266c:	00005517          	auipc	a0,0x5
    80002670:	c0450513          	addi	a0,a0,-1020 # 80007270 <etext+0x270>
    80002674:	9b0fe0ef          	jal	80000824 <panic>
    if(killed(p))
    80002678:	b2bff0ef          	jal	800021a2 <killed>
    8000267c:	ed15                	bnez	a0,800026b8 <usertrap+0xd0>
    p->trapframe->epc += 4;
    8000267e:	6cb8                	ld	a4,88(s1)
    80002680:	6f1c                	ld	a5,24(a4)
    80002682:	0791                	addi	a5,a5,4
    80002684:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002686:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000268a:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000268e:	10079073          	csrw	sstatus,a5
    syscall();
    80002692:	240000ef          	jal	800028d2 <syscall>
  if(killed(p))
    80002696:	8526                	mv	a0,s1
    80002698:	b0bff0ef          	jal	800021a2 <killed>
    8000269c:	e139                	bnez	a0,800026e2 <usertrap+0xfa>
  prepare_return();
    8000269e:	e05ff0ef          	jal	800024a2 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    800026a2:	68a8                	ld	a0,80(s1)
    800026a4:	8131                	srli	a0,a0,0xc
    800026a6:	57fd                	li	a5,-1
    800026a8:	17fe                	slli	a5,a5,0x3f
    800026aa:	8d5d                	or	a0,a0,a5
}
    800026ac:	60e2                	ld	ra,24(sp)
    800026ae:	6442                	ld	s0,16(sp)
    800026b0:	64a2                	ld	s1,8(sp)
    800026b2:	6902                	ld	s2,0(sp)
    800026b4:	6105                	addi	sp,sp,32
    800026b6:	8082                	ret
      kexit(-1);
    800026b8:	557d                	li	a0,-1
    800026ba:	9b9ff0ef          	jal	80002072 <kexit>
    800026be:	b7c1                	j	8000267e <usertrap+0x96>
  asm volatile("csrr %0, stval" : "=r" (x) );
    800026c0:	143025f3          	csrr	a1,stval
  asm volatile("csrr %0, scause" : "=r" (x) );
    800026c4:	14202673          	csrr	a2,scause
            vmfault(p->pagetable, r_stval(), (r_scause() == 13)? 1 : 0) != 0) {
    800026c8:	164d                	addi	a2,a2,-13 # ff3 <_entry-0x7ffff00d>
    800026ca:	00163613          	seqz	a2,a2
    800026ce:	68a8                	ld	a0,80(s1)
    800026d0:	f29fe0ef          	jal	800015f8 <vmfault>
  } else if((r_scause() == 15 || r_scause() == 13) &&
    800026d4:	f169                	bnez	a0,80002696 <usertrap+0xae>
    800026d6:	b7a5                	j	8000263e <usertrap+0x56>
  if(killed(p))
    800026d8:	8526                	mv	a0,s1
    800026da:	ac9ff0ef          	jal	800021a2 <killed>
    800026de:	c511                	beqz	a0,800026ea <usertrap+0x102>
    800026e0:	a011                	j	800026e4 <usertrap+0xfc>
    800026e2:	4901                	li	s2,0
    kexit(-1);
    800026e4:	557d                	li	a0,-1
    800026e6:	98dff0ef          	jal	80002072 <kexit>
  if(which_dev == 2)
    800026ea:	4789                	li	a5,2
    800026ec:	faf919e3          	bne	s2,a5,8000269e <usertrap+0xb6>
    yield();
    800026f0:	84bff0ef          	jal	80001f3a <yield>
    800026f4:	b76d                	j	8000269e <usertrap+0xb6>

00000000800026f6 <kerneltrap>:
{
    800026f6:	7179                	addi	sp,sp,-48
    800026f8:	f406                	sd	ra,40(sp)
    800026fa:	f022                	sd	s0,32(sp)
    800026fc:	ec26                	sd	s1,24(sp)
    800026fe:	e84a                	sd	s2,16(sp)
    80002700:	e44e                	sd	s3,8(sp)
    80002702:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002704:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002708:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    8000270c:	142027f3          	csrr	a5,scause
    80002710:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    80002712:	1004f793          	andi	a5,s1,256
    80002716:	c795                	beqz	a5,80002742 <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002718:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    8000271c:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    8000271e:	eb85                	bnez	a5,8000274e <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    80002720:	e53ff0ef          	jal	80002572 <devintr>
    80002724:	c91d                	beqz	a0,8000275a <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    80002726:	4789                	li	a5,2
    80002728:	04f50a63          	beq	a0,a5,8000277c <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000272c:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002730:	10049073          	csrw	sstatus,s1
}
    80002734:	70a2                	ld	ra,40(sp)
    80002736:	7402                	ld	s0,32(sp)
    80002738:	64e2                	ld	s1,24(sp)
    8000273a:	6942                	ld	s2,16(sp)
    8000273c:	69a2                	ld	s3,8(sp)
    8000273e:	6145                	addi	sp,sp,48
    80002740:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    80002742:	00005517          	auipc	a0,0x5
    80002746:	ba650513          	addi	a0,a0,-1114 # 800072e8 <etext+0x2e8>
    8000274a:	8dafe0ef          	jal	80000824 <panic>
    panic("kerneltrap: interrupts enabled");
    8000274e:	00005517          	auipc	a0,0x5
    80002752:	bc250513          	addi	a0,a0,-1086 # 80007310 <etext+0x310>
    80002756:	8cefe0ef          	jal	80000824 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    8000275a:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    8000275e:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80002762:	85ce                	mv	a1,s3
    80002764:	00005517          	auipc	a0,0x5
    80002768:	bcc50513          	addi	a0,a0,-1076 # 80007330 <etext+0x330>
    8000276c:	d8ffd0ef          	jal	800004fa <printf>
    panic("kerneltrap");
    80002770:	00005517          	auipc	a0,0x5
    80002774:	be850513          	addi	a0,a0,-1048 # 80007358 <etext+0x358>
    80002778:	8acfe0ef          	jal	80000824 <panic>
  if(which_dev == 2 && myproc() != 0)
    8000277c:	9daff0ef          	jal	80001956 <myproc>
    80002780:	d555                	beqz	a0,8000272c <kerneltrap+0x36>
    yield();
    80002782:	fb8ff0ef          	jal	80001f3a <yield>
    80002786:	b75d                	j	8000272c <kerneltrap+0x36>

0000000080002788 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002788:	1101                	addi	sp,sp,-32
    8000278a:	ec06                	sd	ra,24(sp)
    8000278c:	e822                	sd	s0,16(sp)
    8000278e:	e426                	sd	s1,8(sp)
    80002790:	1000                	addi	s0,sp,32
    80002792:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002794:	9c2ff0ef          	jal	80001956 <myproc>
  switch (n) {
    80002798:	4795                	li	a5,5
    8000279a:	0497e163          	bltu	a5,s1,800027dc <argraw+0x54>
    8000279e:	048a                	slli	s1,s1,0x2
    800027a0:	00005717          	auipc	a4,0x5
    800027a4:	fb870713          	addi	a4,a4,-72 # 80007758 <states.0+0x30>
    800027a8:	94ba                	add	s1,s1,a4
    800027aa:	409c                	lw	a5,0(s1)
    800027ac:	97ba                	add	a5,a5,a4
    800027ae:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    800027b0:	6d3c                	ld	a5,88(a0)
    800027b2:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    800027b4:	60e2                	ld	ra,24(sp)
    800027b6:	6442                	ld	s0,16(sp)
    800027b8:	64a2                	ld	s1,8(sp)
    800027ba:	6105                	addi	sp,sp,32
    800027bc:	8082                	ret
    return p->trapframe->a1;
    800027be:	6d3c                	ld	a5,88(a0)
    800027c0:	7fa8                	ld	a0,120(a5)
    800027c2:	bfcd                	j	800027b4 <argraw+0x2c>
    return p->trapframe->a2;
    800027c4:	6d3c                	ld	a5,88(a0)
    800027c6:	63c8                	ld	a0,128(a5)
    800027c8:	b7f5                	j	800027b4 <argraw+0x2c>
    return p->trapframe->a3;
    800027ca:	6d3c                	ld	a5,88(a0)
    800027cc:	67c8                	ld	a0,136(a5)
    800027ce:	b7dd                	j	800027b4 <argraw+0x2c>
    return p->trapframe->a4;
    800027d0:	6d3c                	ld	a5,88(a0)
    800027d2:	6bc8                	ld	a0,144(a5)
    800027d4:	b7c5                	j	800027b4 <argraw+0x2c>
    return p->trapframe->a5;
    800027d6:	6d3c                	ld	a5,88(a0)
    800027d8:	6fc8                	ld	a0,152(a5)
    800027da:	bfe9                	j	800027b4 <argraw+0x2c>
  panic("argraw");
    800027dc:	00005517          	auipc	a0,0x5
    800027e0:	b8c50513          	addi	a0,a0,-1140 # 80007368 <etext+0x368>
    800027e4:	840fe0ef          	jal	80000824 <panic>

00000000800027e8 <fetchaddr>:
{
    800027e8:	1101                	addi	sp,sp,-32
    800027ea:	ec06                	sd	ra,24(sp)
    800027ec:	e822                	sd	s0,16(sp)
    800027ee:	e426                	sd	s1,8(sp)
    800027f0:	e04a                	sd	s2,0(sp)
    800027f2:	1000                	addi	s0,sp,32
    800027f4:	84aa                	mv	s1,a0
    800027f6:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800027f8:	95eff0ef          	jal	80001956 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    800027fc:	653c                	ld	a5,72(a0)
    800027fe:	02f4f663          	bgeu	s1,a5,8000282a <fetchaddr+0x42>
    80002802:	00848713          	addi	a4,s1,8
    80002806:	02e7e463          	bltu	a5,a4,8000282e <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    8000280a:	46a1                	li	a3,8
    8000280c:	8626                	mv	a2,s1
    8000280e:	85ca                	mv	a1,s2
    80002810:	6928                	ld	a0,80(a0)
    80002812:	f29fe0ef          	jal	8000173a <copyin>
    80002816:	00a03533          	snez	a0,a0
    8000281a:	40a0053b          	negw	a0,a0
}
    8000281e:	60e2                	ld	ra,24(sp)
    80002820:	6442                	ld	s0,16(sp)
    80002822:	64a2                	ld	s1,8(sp)
    80002824:	6902                	ld	s2,0(sp)
    80002826:	6105                	addi	sp,sp,32
    80002828:	8082                	ret
    return -1;
    8000282a:	557d                	li	a0,-1
    8000282c:	bfcd                	j	8000281e <fetchaddr+0x36>
    8000282e:	557d                	li	a0,-1
    80002830:	b7fd                	j	8000281e <fetchaddr+0x36>

0000000080002832 <fetchstr>:
{
    80002832:	7179                	addi	sp,sp,-48
    80002834:	f406                	sd	ra,40(sp)
    80002836:	f022                	sd	s0,32(sp)
    80002838:	ec26                	sd	s1,24(sp)
    8000283a:	e84a                	sd	s2,16(sp)
    8000283c:	e44e                	sd	s3,8(sp)
    8000283e:	1800                	addi	s0,sp,48
    80002840:	89aa                	mv	s3,a0
    80002842:	84ae                	mv	s1,a1
    80002844:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002846:	910ff0ef          	jal	80001956 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    8000284a:	86ca                	mv	a3,s2
    8000284c:	864e                	mv	a2,s3
    8000284e:	85a6                	mv	a1,s1
    80002850:	6928                	ld	a0,80(a0)
    80002852:	ccffe0ef          	jal	80001520 <copyinstr>
    80002856:	00054c63          	bltz	a0,8000286e <fetchstr+0x3c>
  return strlen(buf);
    8000285a:	8526                	mv	a0,s1
    8000285c:	e4efe0ef          	jal	80000eaa <strlen>
}
    80002860:	70a2                	ld	ra,40(sp)
    80002862:	7402                	ld	s0,32(sp)
    80002864:	64e2                	ld	s1,24(sp)
    80002866:	6942                	ld	s2,16(sp)
    80002868:	69a2                	ld	s3,8(sp)
    8000286a:	6145                	addi	sp,sp,48
    8000286c:	8082                	ret
    return -1;
    8000286e:	557d                	li	a0,-1
    80002870:	bfc5                	j	80002860 <fetchstr+0x2e>

0000000080002872 <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002872:	1101                	addi	sp,sp,-32
    80002874:	ec06                	sd	ra,24(sp)
    80002876:	e822                	sd	s0,16(sp)
    80002878:	e426                	sd	s1,8(sp)
    8000287a:	1000                	addi	s0,sp,32
    8000287c:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000287e:	f0bff0ef          	jal	80002788 <argraw>
    80002882:	c088                	sw	a0,0(s1)
}
    80002884:	60e2                	ld	ra,24(sp)
    80002886:	6442                	ld	s0,16(sp)
    80002888:	64a2                	ld	s1,8(sp)
    8000288a:	6105                	addi	sp,sp,32
    8000288c:	8082                	ret

000000008000288e <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    8000288e:	1101                	addi	sp,sp,-32
    80002890:	ec06                	sd	ra,24(sp)
    80002892:	e822                	sd	s0,16(sp)
    80002894:	e426                	sd	s1,8(sp)
    80002896:	1000                	addi	s0,sp,32
    80002898:	84ae                	mv	s1,a1
  *ip = argraw(n);
    8000289a:	eefff0ef          	jal	80002788 <argraw>
    8000289e:	e088                	sd	a0,0(s1)
}
    800028a0:	60e2                	ld	ra,24(sp)
    800028a2:	6442                	ld	s0,16(sp)
    800028a4:	64a2                	ld	s1,8(sp)
    800028a6:	6105                	addi	sp,sp,32
    800028a8:	8082                	ret

00000000800028aa <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    800028aa:	1101                	addi	sp,sp,-32
    800028ac:	ec06                	sd	ra,24(sp)
    800028ae:	e822                	sd	s0,16(sp)
    800028b0:	e426                	sd	s1,8(sp)
    800028b2:	e04a                	sd	s2,0(sp)
    800028b4:	1000                	addi	s0,sp,32
    800028b6:	892e                	mv	s2,a1
    800028b8:	84b2                	mv	s1,a2
  *ip = argraw(n);
    800028ba:	ecfff0ef          	jal	80002788 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    800028be:	8626                	mv	a2,s1
    800028c0:	85ca                	mv	a1,s2
    800028c2:	f71ff0ef          	jal	80002832 <fetchstr>
}
    800028c6:	60e2                	ld	ra,24(sp)
    800028c8:	6442                	ld	s0,16(sp)
    800028ca:	64a2                	ld	s1,8(sp)
    800028cc:	6902                	ld	s2,0(sp)
    800028ce:	6105                	addi	sp,sp,32
    800028d0:	8082                	ret

00000000800028d2 <syscall>:
[SYS_kmemfree] sys_kmemfree,
};

void
syscall(void)
{
    800028d2:	1101                	addi	sp,sp,-32
    800028d4:	ec06                	sd	ra,24(sp)
    800028d6:	e822                	sd	s0,16(sp)
    800028d8:	e426                	sd	s1,8(sp)
    800028da:	e04a                	sd	s2,0(sp)
    800028dc:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    800028de:	878ff0ef          	jal	80001956 <myproc>
    800028e2:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    800028e4:	05853903          	ld	s2,88(a0)
    800028e8:	0a893783          	ld	a5,168(s2)
    800028ec:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    800028f0:	37fd                	addiw	a5,a5,-1
    800028f2:	4755                	li	a4,21
    800028f4:	00f76f63          	bltu	a4,a5,80002912 <syscall+0x40>
    800028f8:	00369713          	slli	a4,a3,0x3
    800028fc:	00005797          	auipc	a5,0x5
    80002900:	e7478793          	addi	a5,a5,-396 # 80007770 <syscalls>
    80002904:	97ba                	add	a5,a5,a4
    80002906:	639c                	ld	a5,0(a5)
    80002908:	c789                	beqz	a5,80002912 <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    8000290a:	9782                	jalr	a5
    8000290c:	06a93823          	sd	a0,112(s2)
    80002910:	a829                	j	8000292a <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002912:	15848613          	addi	a2,s1,344
    80002916:	588c                	lw	a1,48(s1)
    80002918:	00005517          	auipc	a0,0x5
    8000291c:	a5850513          	addi	a0,a0,-1448 # 80007370 <etext+0x370>
    80002920:	bdbfd0ef          	jal	800004fa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002924:	6cbc                	ld	a5,88(s1)
    80002926:	577d                	li	a4,-1
    80002928:	fbb8                	sd	a4,112(a5)
  }
}
    8000292a:	60e2                	ld	ra,24(sp)
    8000292c:	6442                	ld	s0,16(sp)
    8000292e:	64a2                	ld	s1,8(sp)
    80002930:	6902                	ld	s2,0(sp)
    80002932:	6105                	addi	sp,sp,32
    80002934:	8082                	ret

0000000080002936 <sys_exit>:
#include "proc.h"
#include "vm.h"

uint64
sys_exit(void)
{
    80002936:	1101                	addi	sp,sp,-32
    80002938:	ec06                	sd	ra,24(sp)
    8000293a:	e822                	sd	s0,16(sp)
    8000293c:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    8000293e:	fec40593          	addi	a1,s0,-20
    80002942:	4501                	li	a0,0
    80002944:	f2fff0ef          	jal	80002872 <argint>
  kexit(n);
    80002948:	fec42503          	lw	a0,-20(s0)
    8000294c:	f26ff0ef          	jal	80002072 <kexit>
  return 0;  // not reached
}
    80002950:	4501                	li	a0,0
    80002952:	60e2                	ld	ra,24(sp)
    80002954:	6442                	ld	s0,16(sp)
    80002956:	6105                	addi	sp,sp,32
    80002958:	8082                	ret

000000008000295a <sys_getpid>:

uint64
sys_getpid(void)
{
    8000295a:	1141                	addi	sp,sp,-16
    8000295c:	e406                	sd	ra,8(sp)
    8000295e:	e022                	sd	s0,0(sp)
    80002960:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002962:	ff5fe0ef          	jal	80001956 <myproc>
}
    80002966:	5908                	lw	a0,48(a0)
    80002968:	60a2                	ld	ra,8(sp)
    8000296a:	6402                	ld	s0,0(sp)
    8000296c:	0141                	addi	sp,sp,16
    8000296e:	8082                	ret

0000000080002970 <sys_fork>:

uint64
sys_fork(void)
{
    80002970:	1141                	addi	sp,sp,-16
    80002972:	e406                	sd	ra,8(sp)
    80002974:	e022                	sd	s0,0(sp)
    80002976:	0800                	addi	s0,sp,16
  return kfork();
    80002978:	b46ff0ef          	jal	80001cbe <kfork>
}
    8000297c:	60a2                	ld	ra,8(sp)
    8000297e:	6402                	ld	s0,0(sp)
    80002980:	0141                	addi	sp,sp,16
    80002982:	8082                	ret

0000000080002984 <sys_wait>:

uint64
sys_wait(void)
{
    80002984:	1101                	addi	sp,sp,-32
    80002986:	ec06                	sd	ra,24(sp)
    80002988:	e822                	sd	s0,16(sp)
    8000298a:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    8000298c:	fe840593          	addi	a1,s0,-24
    80002990:	4501                	li	a0,0
    80002992:	efdff0ef          	jal	8000288e <argaddr>
  return kwait(p);
    80002996:	fe843503          	ld	a0,-24(s0)
    8000299a:	833ff0ef          	jal	800021cc <kwait>
}
    8000299e:	60e2                	ld	ra,24(sp)
    800029a0:	6442                	ld	s0,16(sp)
    800029a2:	6105                	addi	sp,sp,32
    800029a4:	8082                	ret

00000000800029a6 <sys_sbrk>:

uint64
sys_sbrk(void)
{
    800029a6:	7179                	addi	sp,sp,-48
    800029a8:	f406                	sd	ra,40(sp)
    800029aa:	f022                	sd	s0,32(sp)
    800029ac:	ec26                	sd	s1,24(sp)
    800029ae:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    800029b0:	fd840593          	addi	a1,s0,-40
    800029b4:	4501                	li	a0,0
    800029b6:	ebdff0ef          	jal	80002872 <argint>
  argint(1, &t);
    800029ba:	fdc40593          	addi	a1,s0,-36
    800029be:	4505                	li	a0,1
    800029c0:	eb3ff0ef          	jal	80002872 <argint>
  addr = myproc()->sz;
    800029c4:	f93fe0ef          	jal	80001956 <myproc>
    800029c8:	6524                	ld	s1,72(a0)

  if(t == SBRK_EAGER || n < 0) {
    800029ca:	fdc42703          	lw	a4,-36(s0)
    800029ce:	4785                	li	a5,1
    800029d0:	02f70763          	beq	a4,a5,800029fe <sys_sbrk+0x58>
    800029d4:	fd842783          	lw	a5,-40(s0)
    800029d8:	0207c363          	bltz	a5,800029fe <sys_sbrk+0x58>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    800029dc:	97a6                	add	a5,a5,s1
      return -1;
    if(addr + n > TRAPFRAME)
    800029de:	02000737          	lui	a4,0x2000
    800029e2:	177d                	addi	a4,a4,-1 # 1ffffff <_entry-0x7e000001>
    800029e4:	0736                	slli	a4,a4,0xd
    800029e6:	02f76a63          	bltu	a4,a5,80002a1a <sys_sbrk+0x74>
    800029ea:	0297e863          	bltu	a5,s1,80002a1a <sys_sbrk+0x74>
      return -1;
    myproc()->sz += n;
    800029ee:	f69fe0ef          	jal	80001956 <myproc>
    800029f2:	fd842703          	lw	a4,-40(s0)
    800029f6:	653c                	ld	a5,72(a0)
    800029f8:	97ba                	add	a5,a5,a4
    800029fa:	e53c                	sd	a5,72(a0)
    800029fc:	a039                	j	80002a0a <sys_sbrk+0x64>
    if(growproc(n) < 0) {
    800029fe:	fd842503          	lw	a0,-40(s0)
    80002a02:	a5aff0ef          	jal	80001c5c <growproc>
    80002a06:	00054863          	bltz	a0,80002a16 <sys_sbrk+0x70>
  }
  return addr;
}
    80002a0a:	8526                	mv	a0,s1
    80002a0c:	70a2                	ld	ra,40(sp)
    80002a0e:	7402                	ld	s0,32(sp)
    80002a10:	64e2                	ld	s1,24(sp)
    80002a12:	6145                	addi	sp,sp,48
    80002a14:	8082                	ret
      return -1;
    80002a16:	54fd                	li	s1,-1
    80002a18:	bfcd                	j	80002a0a <sys_sbrk+0x64>
      return -1;
    80002a1a:	54fd                	li	s1,-1
    80002a1c:	b7fd                	j	80002a0a <sys_sbrk+0x64>

0000000080002a1e <sys_pause>:

uint64
sys_pause(void)
{
    80002a1e:	7139                	addi	sp,sp,-64
    80002a20:	fc06                	sd	ra,56(sp)
    80002a22:	f822                	sd	s0,48(sp)
    80002a24:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002a26:	fcc40593          	addi	a1,s0,-52
    80002a2a:	4501                	li	a0,0
    80002a2c:	e47ff0ef          	jal	80002872 <argint>
  if(n < 0)
    80002a30:	fcc42783          	lw	a5,-52(s0)
    80002a34:	0607c863          	bltz	a5,80002aa4 <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002a38:	00013517          	auipc	a0,0x13
    80002a3c:	d6050513          	addi	a0,a0,-672 # 80015798 <tickslock>
    80002a40:	a10fe0ef          	jal	80000c50 <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002a44:	fcc42783          	lw	a5,-52(s0)
    80002a48:	c3b9                	beqz	a5,80002a8e <sys_pause+0x70>
    80002a4a:	f426                	sd	s1,40(sp)
    80002a4c:	f04a                	sd	s2,32(sp)
    80002a4e:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002a50:	00005997          	auipc	s3,0x5
    80002a54:	e189a983          	lw	s3,-488(s3) # 80007868 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002a58:	00013917          	auipc	s2,0x13
    80002a5c:	d4090913          	addi	s2,s2,-704 # 80015798 <tickslock>
    80002a60:	00005497          	auipc	s1,0x5
    80002a64:	e0848493          	addi	s1,s1,-504 # 80007868 <ticks>
    if(killed(myproc())){
    80002a68:	eeffe0ef          	jal	80001956 <myproc>
    80002a6c:	f36ff0ef          	jal	800021a2 <killed>
    80002a70:	ed0d                	bnez	a0,80002aaa <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002a72:	85ca                	mv	a1,s2
    80002a74:	8526                	mv	a0,s1
    80002a76:	cf0ff0ef          	jal	80001f66 <sleep>
  while(ticks - ticks0 < n){
    80002a7a:	409c                	lw	a5,0(s1)
    80002a7c:	413787bb          	subw	a5,a5,s3
    80002a80:	fcc42703          	lw	a4,-52(s0)
    80002a84:	fee7e2e3          	bltu	a5,a4,80002a68 <sys_pause+0x4a>
    80002a88:	74a2                	ld	s1,40(sp)
    80002a8a:	7902                	ld	s2,32(sp)
    80002a8c:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002a8e:	00013517          	auipc	a0,0x13
    80002a92:	d0a50513          	addi	a0,a0,-758 # 80015798 <tickslock>
    80002a96:	a4efe0ef          	jal	80000ce4 <release>
  return 0;
    80002a9a:	4501                	li	a0,0
}
    80002a9c:	70e2                	ld	ra,56(sp)
    80002a9e:	7442                	ld	s0,48(sp)
    80002aa0:	6121                	addi	sp,sp,64
    80002aa2:	8082                	ret
    n = 0;
    80002aa4:	fc042623          	sw	zero,-52(s0)
    80002aa8:	bf41                	j	80002a38 <sys_pause+0x1a>
      release(&tickslock);
    80002aaa:	00013517          	auipc	a0,0x13
    80002aae:	cee50513          	addi	a0,a0,-786 # 80015798 <tickslock>
    80002ab2:	a32fe0ef          	jal	80000ce4 <release>
      return -1;
    80002ab6:	557d                	li	a0,-1
    80002ab8:	74a2                	ld	s1,40(sp)
    80002aba:	7902                	ld	s2,32(sp)
    80002abc:	69e2                	ld	s3,24(sp)
    80002abe:	bff9                	j	80002a9c <sys_pause+0x7e>

0000000080002ac0 <sys_kill>:

uint64
sys_kill(void)
{
    80002ac0:	1101                	addi	sp,sp,-32
    80002ac2:	ec06                	sd	ra,24(sp)
    80002ac4:	e822                	sd	s0,16(sp)
    80002ac6:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002ac8:	fec40593          	addi	a1,s0,-20
    80002acc:	4501                	li	a0,0
    80002ace:	da5ff0ef          	jal	80002872 <argint>
  return kkill(pid);
    80002ad2:	fec42503          	lw	a0,-20(s0)
    80002ad6:	e42ff0ef          	jal	80002118 <kkill>
}
    80002ada:	60e2                	ld	ra,24(sp)
    80002adc:	6442                	ld	s0,16(sp)
    80002ade:	6105                	addi	sp,sp,32
    80002ae0:	8082                	ret

0000000080002ae2 <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002ae2:	1101                	addi	sp,sp,-32
    80002ae4:	ec06                	sd	ra,24(sp)
    80002ae6:	e822                	sd	s0,16(sp)
    80002ae8:	e426                	sd	s1,8(sp)
    80002aea:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002aec:	00013517          	auipc	a0,0x13
    80002af0:	cac50513          	addi	a0,a0,-852 # 80015798 <tickslock>
    80002af4:	95cfe0ef          	jal	80000c50 <acquire>
  xticks = ticks;
    80002af8:	00005797          	auipc	a5,0x5
    80002afc:	d707a783          	lw	a5,-656(a5) # 80007868 <ticks>
    80002b00:	84be                	mv	s1,a5
  release(&tickslock);
    80002b02:	00013517          	auipc	a0,0x13
    80002b06:	c9650513          	addi	a0,a0,-874 # 80015798 <tickslock>
    80002b0a:	9dafe0ef          	jal	80000ce4 <release>
  return xticks;
}
    80002b0e:	02049513          	slli	a0,s1,0x20
    80002b12:	9101                	srli	a0,a0,0x20
    80002b14:	60e2                	ld	ra,24(sp)
    80002b16:	6442                	ld	s0,16(sp)
    80002b18:	64a2                	ld	s1,8(sp)
    80002b1a:	6105                	addi	sp,sp,32
    80002b1c:	8082                	ret

0000000080002b1e <sys_kmemfree>:


uint64 sys_kmemfree(void)
{
    80002b1e:	1141                	addi	sp,sp,-16
    80002b20:	e406                	sd	ra,8(sp)
    80002b22:	e022                	sd	s0,0(sp)
    80002b24:	0800                	addi	s0,sp,16
  return (uint64) kmemfree();
    80002b26:	878fe0ef          	jal	80000b9e <kmemfree>
}
    80002b2a:	60a2                	ld	ra,8(sp)
    80002b2c:	6402                	ld	s0,0(sp)
    80002b2e:	0141                	addi	sp,sp,16
    80002b30:	8082                	ret

0000000080002b32 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002b32:	7179                	addi	sp,sp,-48
    80002b34:	f406                	sd	ra,40(sp)
    80002b36:	f022                	sd	s0,32(sp)
    80002b38:	ec26                	sd	s1,24(sp)
    80002b3a:	e84a                	sd	s2,16(sp)
    80002b3c:	e44e                	sd	s3,8(sp)
    80002b3e:	e052                	sd	s4,0(sp)
    80002b40:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002b42:	00005597          	auipc	a1,0x5
    80002b46:	84e58593          	addi	a1,a1,-1970 # 80007390 <etext+0x390>
    80002b4a:	00013517          	auipc	a0,0x13
    80002b4e:	c6650513          	addi	a0,a0,-922 # 800157b0 <bcache>
    80002b52:	874fe0ef          	jal	80000bc6 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002b56:	0001b797          	auipc	a5,0x1b
    80002b5a:	c5a78793          	addi	a5,a5,-934 # 8001d7b0 <bcache+0x8000>
    80002b5e:	0001b717          	auipc	a4,0x1b
    80002b62:	eba70713          	addi	a4,a4,-326 # 8001da18 <bcache+0x8268>
    80002b66:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002b6a:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002b6e:	00013497          	auipc	s1,0x13
    80002b72:	c5a48493          	addi	s1,s1,-934 # 800157c8 <bcache+0x18>
    b->next = bcache.head.next;
    80002b76:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002b78:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002b7a:	00005a17          	auipc	s4,0x5
    80002b7e:	81ea0a13          	addi	s4,s4,-2018 # 80007398 <etext+0x398>
    b->next = bcache.head.next;
    80002b82:	2b893783          	ld	a5,696(s2)
    80002b86:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002b88:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002b8c:	85d2                	mv	a1,s4
    80002b8e:	01048513          	addi	a0,s1,16
    80002b92:	328010ef          	jal	80003eba <initsleeplock>
    bcache.head.next->prev = b;
    80002b96:	2b893783          	ld	a5,696(s2)
    80002b9a:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002b9c:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002ba0:	45848493          	addi	s1,s1,1112
    80002ba4:	fd349fe3          	bne	s1,s3,80002b82 <binit+0x50>
  }
}
    80002ba8:	70a2                	ld	ra,40(sp)
    80002baa:	7402                	ld	s0,32(sp)
    80002bac:	64e2                	ld	s1,24(sp)
    80002bae:	6942                	ld	s2,16(sp)
    80002bb0:	69a2                	ld	s3,8(sp)
    80002bb2:	6a02                	ld	s4,0(sp)
    80002bb4:	6145                	addi	sp,sp,48
    80002bb6:	8082                	ret

0000000080002bb8 <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002bb8:	7179                	addi	sp,sp,-48
    80002bba:	f406                	sd	ra,40(sp)
    80002bbc:	f022                	sd	s0,32(sp)
    80002bbe:	ec26                	sd	s1,24(sp)
    80002bc0:	e84a                	sd	s2,16(sp)
    80002bc2:	e44e                	sd	s3,8(sp)
    80002bc4:	1800                	addi	s0,sp,48
    80002bc6:	892a                	mv	s2,a0
    80002bc8:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002bca:	00013517          	auipc	a0,0x13
    80002bce:	be650513          	addi	a0,a0,-1050 # 800157b0 <bcache>
    80002bd2:	87efe0ef          	jal	80000c50 <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002bd6:	0001b497          	auipc	s1,0x1b
    80002bda:	e924b483          	ld	s1,-366(s1) # 8001da68 <bcache+0x82b8>
    80002bde:	0001b797          	auipc	a5,0x1b
    80002be2:	e3a78793          	addi	a5,a5,-454 # 8001da18 <bcache+0x8268>
    80002be6:	02f48b63          	beq	s1,a5,80002c1c <bread+0x64>
    80002bea:	873e                	mv	a4,a5
    80002bec:	a021                	j	80002bf4 <bread+0x3c>
    80002bee:	68a4                	ld	s1,80(s1)
    80002bf0:	02e48663          	beq	s1,a4,80002c1c <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002bf4:	449c                	lw	a5,8(s1)
    80002bf6:	ff279ce3          	bne	a5,s2,80002bee <bread+0x36>
    80002bfa:	44dc                	lw	a5,12(s1)
    80002bfc:	ff3799e3          	bne	a5,s3,80002bee <bread+0x36>
      b->refcnt++;
    80002c00:	40bc                	lw	a5,64(s1)
    80002c02:	2785                	addiw	a5,a5,1
    80002c04:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c06:	00013517          	auipc	a0,0x13
    80002c0a:	baa50513          	addi	a0,a0,-1110 # 800157b0 <bcache>
    80002c0e:	8d6fe0ef          	jal	80000ce4 <release>
      acquiresleep(&b->lock);
    80002c12:	01048513          	addi	a0,s1,16
    80002c16:	2da010ef          	jal	80003ef0 <acquiresleep>
      return b;
    80002c1a:	a889                	j	80002c6c <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002c1c:	0001b497          	auipc	s1,0x1b
    80002c20:	e444b483          	ld	s1,-444(s1) # 8001da60 <bcache+0x82b0>
    80002c24:	0001b797          	auipc	a5,0x1b
    80002c28:	df478793          	addi	a5,a5,-524 # 8001da18 <bcache+0x8268>
    80002c2c:	00f48863          	beq	s1,a5,80002c3c <bread+0x84>
    80002c30:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002c32:	40bc                	lw	a5,64(s1)
    80002c34:	cb91                	beqz	a5,80002c48 <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002c36:	64a4                	ld	s1,72(s1)
    80002c38:	fee49de3          	bne	s1,a4,80002c32 <bread+0x7a>
  panic("bget: no buffers");
    80002c3c:	00004517          	auipc	a0,0x4
    80002c40:	76450513          	addi	a0,a0,1892 # 800073a0 <etext+0x3a0>
    80002c44:	be1fd0ef          	jal	80000824 <panic>
      b->dev = dev;
    80002c48:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80002c4c:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80002c50:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    80002c54:	4785                	li	a5,1
    80002c56:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002c58:	00013517          	auipc	a0,0x13
    80002c5c:	b5850513          	addi	a0,a0,-1192 # 800157b0 <bcache>
    80002c60:	884fe0ef          	jal	80000ce4 <release>
      acquiresleep(&b->lock);
    80002c64:	01048513          	addi	a0,s1,16
    80002c68:	288010ef          	jal	80003ef0 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80002c6c:	409c                	lw	a5,0(s1)
    80002c6e:	cb89                	beqz	a5,80002c80 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80002c70:	8526                	mv	a0,s1
    80002c72:	70a2                	ld	ra,40(sp)
    80002c74:	7402                	ld	s0,32(sp)
    80002c76:	64e2                	ld	s1,24(sp)
    80002c78:	6942                	ld	s2,16(sp)
    80002c7a:	69a2                	ld	s3,8(sp)
    80002c7c:	6145                	addi	sp,sp,48
    80002c7e:	8082                	ret
    virtio_disk_rw(b, 0);
    80002c80:	4581                	li	a1,0
    80002c82:	8526                	mv	a0,s1
    80002c84:	2ed020ef          	jal	80005770 <virtio_disk_rw>
    b->valid = 1;
    80002c88:	4785                	li	a5,1
    80002c8a:	c09c                	sw	a5,0(s1)
  return b;
    80002c8c:	b7d5                	j	80002c70 <bread+0xb8>

0000000080002c8e <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80002c8e:	1101                	addi	sp,sp,-32
    80002c90:	ec06                	sd	ra,24(sp)
    80002c92:	e822                	sd	s0,16(sp)
    80002c94:	e426                	sd	s1,8(sp)
    80002c96:	1000                	addi	s0,sp,32
    80002c98:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002c9a:	0541                	addi	a0,a0,16
    80002c9c:	2d2010ef          	jal	80003f6e <holdingsleep>
    80002ca0:	c911                	beqz	a0,80002cb4 <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80002ca2:	4585                	li	a1,1
    80002ca4:	8526                	mv	a0,s1
    80002ca6:	2cb020ef          	jal	80005770 <virtio_disk_rw>
}
    80002caa:	60e2                	ld	ra,24(sp)
    80002cac:	6442                	ld	s0,16(sp)
    80002cae:	64a2                	ld	s1,8(sp)
    80002cb0:	6105                	addi	sp,sp,32
    80002cb2:	8082                	ret
    panic("bwrite");
    80002cb4:	00004517          	auipc	a0,0x4
    80002cb8:	70450513          	addi	a0,a0,1796 # 800073b8 <etext+0x3b8>
    80002cbc:	b69fd0ef          	jal	80000824 <panic>

0000000080002cc0 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80002cc0:	1101                	addi	sp,sp,-32
    80002cc2:	ec06                	sd	ra,24(sp)
    80002cc4:	e822                	sd	s0,16(sp)
    80002cc6:	e426                	sd	s1,8(sp)
    80002cc8:	e04a                	sd	s2,0(sp)
    80002cca:	1000                	addi	s0,sp,32
    80002ccc:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80002cce:	01050913          	addi	s2,a0,16
    80002cd2:	854a                	mv	a0,s2
    80002cd4:	29a010ef          	jal	80003f6e <holdingsleep>
    80002cd8:	c125                	beqz	a0,80002d38 <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    80002cda:	854a                	mv	a0,s2
    80002cdc:	25a010ef          	jal	80003f36 <releasesleep>

  acquire(&bcache.lock);
    80002ce0:	00013517          	auipc	a0,0x13
    80002ce4:	ad050513          	addi	a0,a0,-1328 # 800157b0 <bcache>
    80002ce8:	f69fd0ef          	jal	80000c50 <acquire>
  b->refcnt--;
    80002cec:	40bc                	lw	a5,64(s1)
    80002cee:	37fd                	addiw	a5,a5,-1
    80002cf0:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    80002cf2:	e79d                	bnez	a5,80002d20 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    80002cf4:	68b8                	ld	a4,80(s1)
    80002cf6:	64bc                	ld	a5,72(s1)
    80002cf8:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    80002cfa:	68b8                	ld	a4,80(s1)
    80002cfc:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    80002cfe:	0001b797          	auipc	a5,0x1b
    80002d02:	ab278793          	addi	a5,a5,-1358 # 8001d7b0 <bcache+0x8000>
    80002d06:	2b87b703          	ld	a4,696(a5)
    80002d0a:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    80002d0c:	0001b717          	auipc	a4,0x1b
    80002d10:	d0c70713          	addi	a4,a4,-756 # 8001da18 <bcache+0x8268>
    80002d14:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    80002d16:	2b87b703          	ld	a4,696(a5)
    80002d1a:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    80002d1c:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    80002d20:	00013517          	auipc	a0,0x13
    80002d24:	a9050513          	addi	a0,a0,-1392 # 800157b0 <bcache>
    80002d28:	fbdfd0ef          	jal	80000ce4 <release>
}
    80002d2c:	60e2                	ld	ra,24(sp)
    80002d2e:	6442                	ld	s0,16(sp)
    80002d30:	64a2                	ld	s1,8(sp)
    80002d32:	6902                	ld	s2,0(sp)
    80002d34:	6105                	addi	sp,sp,32
    80002d36:	8082                	ret
    panic("brelse");
    80002d38:	00004517          	auipc	a0,0x4
    80002d3c:	68850513          	addi	a0,a0,1672 # 800073c0 <etext+0x3c0>
    80002d40:	ae5fd0ef          	jal	80000824 <panic>

0000000080002d44 <bpin>:

void
bpin(struct buf *b) {
    80002d44:	1101                	addi	sp,sp,-32
    80002d46:	ec06                	sd	ra,24(sp)
    80002d48:	e822                	sd	s0,16(sp)
    80002d4a:	e426                	sd	s1,8(sp)
    80002d4c:	1000                	addi	s0,sp,32
    80002d4e:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002d50:	00013517          	auipc	a0,0x13
    80002d54:	a6050513          	addi	a0,a0,-1440 # 800157b0 <bcache>
    80002d58:	ef9fd0ef          	jal	80000c50 <acquire>
  b->refcnt++;
    80002d5c:	40bc                	lw	a5,64(s1)
    80002d5e:	2785                	addiw	a5,a5,1
    80002d60:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002d62:	00013517          	auipc	a0,0x13
    80002d66:	a4e50513          	addi	a0,a0,-1458 # 800157b0 <bcache>
    80002d6a:	f7bfd0ef          	jal	80000ce4 <release>
}
    80002d6e:	60e2                	ld	ra,24(sp)
    80002d70:	6442                	ld	s0,16(sp)
    80002d72:	64a2                	ld	s1,8(sp)
    80002d74:	6105                	addi	sp,sp,32
    80002d76:	8082                	ret

0000000080002d78 <bunpin>:

void
bunpin(struct buf *b) {
    80002d78:	1101                	addi	sp,sp,-32
    80002d7a:	ec06                	sd	ra,24(sp)
    80002d7c:	e822                	sd	s0,16(sp)
    80002d7e:	e426                	sd	s1,8(sp)
    80002d80:	1000                	addi	s0,sp,32
    80002d82:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80002d84:	00013517          	auipc	a0,0x13
    80002d88:	a2c50513          	addi	a0,a0,-1492 # 800157b0 <bcache>
    80002d8c:	ec5fd0ef          	jal	80000c50 <acquire>
  b->refcnt--;
    80002d90:	40bc                	lw	a5,64(s1)
    80002d92:	37fd                	addiw	a5,a5,-1
    80002d94:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80002d96:	00013517          	auipc	a0,0x13
    80002d9a:	a1a50513          	addi	a0,a0,-1510 # 800157b0 <bcache>
    80002d9e:	f47fd0ef          	jal	80000ce4 <release>
}
    80002da2:	60e2                	ld	ra,24(sp)
    80002da4:	6442                	ld	s0,16(sp)
    80002da6:	64a2                	ld	s1,8(sp)
    80002da8:	6105                	addi	sp,sp,32
    80002daa:	8082                	ret

0000000080002dac <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80002dac:	1101                	addi	sp,sp,-32
    80002dae:	ec06                	sd	ra,24(sp)
    80002db0:	e822                	sd	s0,16(sp)
    80002db2:	e426                	sd	s1,8(sp)
    80002db4:	e04a                	sd	s2,0(sp)
    80002db6:	1000                	addi	s0,sp,32
    80002db8:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80002dba:	00d5d79b          	srliw	a5,a1,0xd
    80002dbe:	0001b597          	auipc	a1,0x1b
    80002dc2:	0ce5a583          	lw	a1,206(a1) # 8001de8c <sb+0x1c>
    80002dc6:	9dbd                	addw	a1,a1,a5
    80002dc8:	df1ff0ef          	jal	80002bb8 <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80002dcc:	0074f713          	andi	a4,s1,7
    80002dd0:	4785                	li	a5,1
    80002dd2:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    80002dd6:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    80002dd8:	90d9                	srli	s1,s1,0x36
    80002dda:	00950733          	add	a4,a0,s1
    80002dde:	05874703          	lbu	a4,88(a4)
    80002de2:	00e7f6b3          	and	a3,a5,a4
    80002de6:	c29d                	beqz	a3,80002e0c <bfree+0x60>
    80002de8:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    80002dea:	94aa                	add	s1,s1,a0
    80002dec:	fff7c793          	not	a5,a5
    80002df0:	8f7d                	and	a4,a4,a5
    80002df2:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    80002df6:	000010ef          	jal	80003df6 <log_write>
  brelse(bp);
    80002dfa:	854a                	mv	a0,s2
    80002dfc:	ec5ff0ef          	jal	80002cc0 <brelse>
}
    80002e00:	60e2                	ld	ra,24(sp)
    80002e02:	6442                	ld	s0,16(sp)
    80002e04:	64a2                	ld	s1,8(sp)
    80002e06:	6902                	ld	s2,0(sp)
    80002e08:	6105                	addi	sp,sp,32
    80002e0a:	8082                	ret
    panic("freeing free block");
    80002e0c:	00004517          	auipc	a0,0x4
    80002e10:	5bc50513          	addi	a0,a0,1468 # 800073c8 <etext+0x3c8>
    80002e14:	a11fd0ef          	jal	80000824 <panic>

0000000080002e18 <balloc>:
{
    80002e18:	715d                	addi	sp,sp,-80
    80002e1a:	e486                	sd	ra,72(sp)
    80002e1c:	e0a2                	sd	s0,64(sp)
    80002e1e:	fc26                	sd	s1,56(sp)
    80002e20:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    80002e22:	0001b797          	auipc	a5,0x1b
    80002e26:	0527a783          	lw	a5,82(a5) # 8001de74 <sb+0x4>
    80002e2a:	0e078263          	beqz	a5,80002f0e <balloc+0xf6>
    80002e2e:	f84a                	sd	s2,48(sp)
    80002e30:	f44e                	sd	s3,40(sp)
    80002e32:	f052                	sd	s4,32(sp)
    80002e34:	ec56                	sd	s5,24(sp)
    80002e36:	e85a                	sd	s6,16(sp)
    80002e38:	e45e                	sd	s7,8(sp)
    80002e3a:	e062                	sd	s8,0(sp)
    80002e3c:	8baa                	mv	s7,a0
    80002e3e:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80002e40:	0001bb17          	auipc	s6,0x1b
    80002e44:	030b0b13          	addi	s6,s6,48 # 8001de70 <sb>
      m = 1 << (bi % 8);
    80002e48:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002e4a:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80002e4c:	6c09                	lui	s8,0x2
    80002e4e:	a09d                	j	80002eb4 <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    80002e50:	97ca                	add	a5,a5,s2
    80002e52:	8e55                	or	a2,a2,a3
    80002e54:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    80002e58:	854a                	mv	a0,s2
    80002e5a:	79d000ef          	jal	80003df6 <log_write>
        brelse(bp);
    80002e5e:	854a                	mv	a0,s2
    80002e60:	e61ff0ef          	jal	80002cc0 <brelse>
  bp = bread(dev, bno);
    80002e64:	85a6                	mv	a1,s1
    80002e66:	855e                	mv	a0,s7
    80002e68:	d51ff0ef          	jal	80002bb8 <bread>
    80002e6c:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80002e6e:	40000613          	li	a2,1024
    80002e72:	4581                	li	a1,0
    80002e74:	05850513          	addi	a0,a0,88
    80002e78:	ea9fd0ef          	jal	80000d20 <memset>
  log_write(bp);
    80002e7c:	854a                	mv	a0,s2
    80002e7e:	779000ef          	jal	80003df6 <log_write>
  brelse(bp);
    80002e82:	854a                	mv	a0,s2
    80002e84:	e3dff0ef          	jal	80002cc0 <brelse>
}
    80002e88:	7942                	ld	s2,48(sp)
    80002e8a:	79a2                	ld	s3,40(sp)
    80002e8c:	7a02                	ld	s4,32(sp)
    80002e8e:	6ae2                	ld	s5,24(sp)
    80002e90:	6b42                	ld	s6,16(sp)
    80002e92:	6ba2                	ld	s7,8(sp)
    80002e94:	6c02                	ld	s8,0(sp)
}
    80002e96:	8526                	mv	a0,s1
    80002e98:	60a6                	ld	ra,72(sp)
    80002e9a:	6406                	ld	s0,64(sp)
    80002e9c:	74e2                	ld	s1,56(sp)
    80002e9e:	6161                	addi	sp,sp,80
    80002ea0:	8082                	ret
    brelse(bp);
    80002ea2:	854a                	mv	a0,s2
    80002ea4:	e1dff0ef          	jal	80002cc0 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    80002ea8:	015c0abb          	addw	s5,s8,s5
    80002eac:	004b2783          	lw	a5,4(s6)
    80002eb0:	04faf863          	bgeu	s5,a5,80002f00 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    80002eb4:	40dad59b          	sraiw	a1,s5,0xd
    80002eb8:	01cb2783          	lw	a5,28(s6)
    80002ebc:	9dbd                	addw	a1,a1,a5
    80002ebe:	855e                	mv	a0,s7
    80002ec0:	cf9ff0ef          	jal	80002bb8 <bread>
    80002ec4:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002ec6:	004b2503          	lw	a0,4(s6)
    80002eca:	84d6                	mv	s1,s5
    80002ecc:	4701                	li	a4,0
    80002ece:	fca4fae3          	bgeu	s1,a0,80002ea2 <balloc+0x8a>
      m = 1 << (bi % 8);
    80002ed2:	00777693          	andi	a3,a4,7
    80002ed6:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    80002eda:	41f7579b          	sraiw	a5,a4,0x1f
    80002ede:	01d7d79b          	srliw	a5,a5,0x1d
    80002ee2:	9fb9                	addw	a5,a5,a4
    80002ee4:	4037d79b          	sraiw	a5,a5,0x3
    80002ee8:	00f90633          	add	a2,s2,a5
    80002eec:	05864603          	lbu	a2,88(a2)
    80002ef0:	00c6f5b3          	and	a1,a3,a2
    80002ef4:	ddb1                	beqz	a1,80002e50 <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80002ef6:	2705                	addiw	a4,a4,1
    80002ef8:	2485                	addiw	s1,s1,1
    80002efa:	fd471ae3          	bne	a4,s4,80002ece <balloc+0xb6>
    80002efe:	b755                	j	80002ea2 <balloc+0x8a>
    80002f00:	7942                	ld	s2,48(sp)
    80002f02:	79a2                	ld	s3,40(sp)
    80002f04:	7a02                	ld	s4,32(sp)
    80002f06:	6ae2                	ld	s5,24(sp)
    80002f08:	6b42                	ld	s6,16(sp)
    80002f0a:	6ba2                	ld	s7,8(sp)
    80002f0c:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    80002f0e:	00004517          	auipc	a0,0x4
    80002f12:	4d250513          	addi	a0,a0,1234 # 800073e0 <etext+0x3e0>
    80002f16:	de4fd0ef          	jal	800004fa <printf>
  return 0;
    80002f1a:	4481                	li	s1,0
    80002f1c:	bfad                	j	80002e96 <balloc+0x7e>

0000000080002f1e <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    80002f1e:	7179                	addi	sp,sp,-48
    80002f20:	f406                	sd	ra,40(sp)
    80002f22:	f022                	sd	s0,32(sp)
    80002f24:	ec26                	sd	s1,24(sp)
    80002f26:	e84a                	sd	s2,16(sp)
    80002f28:	e44e                	sd	s3,8(sp)
    80002f2a:	1800                	addi	s0,sp,48
    80002f2c:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    80002f2e:	47ad                	li	a5,11
    80002f30:	02b7e363          	bltu	a5,a1,80002f56 <bmap+0x38>
    if((addr = ip->addrs[bn]) == 0){
    80002f34:	02059793          	slli	a5,a1,0x20
    80002f38:	01e7d593          	srli	a1,a5,0x1e
    80002f3c:	00b509b3          	add	s3,a0,a1
    80002f40:	0509a483          	lw	s1,80(s3)
    80002f44:	e0b5                	bnez	s1,80002fa8 <bmap+0x8a>
      addr = balloc(ip->dev);
    80002f46:	4108                	lw	a0,0(a0)
    80002f48:	ed1ff0ef          	jal	80002e18 <balloc>
    80002f4c:	84aa                	mv	s1,a0
      if(addr == 0)
    80002f4e:	cd29                	beqz	a0,80002fa8 <bmap+0x8a>
        return 0;
      ip->addrs[bn] = addr;
    80002f50:	04a9a823          	sw	a0,80(s3)
    80002f54:	a891                	j	80002fa8 <bmap+0x8a>
    }
    return addr;
  }
  bn -= NDIRECT;
    80002f56:	ff45879b          	addiw	a5,a1,-12
    80002f5a:	873e                	mv	a4,a5
    80002f5c:	89be                	mv	s3,a5

  if(bn < NINDIRECT){
    80002f5e:	0ff00793          	li	a5,255
    80002f62:	06e7e763          	bltu	a5,a4,80002fd0 <bmap+0xb2>
    // Load indirect block, allocating if necessary.
    if((addr = ip->addrs[NDIRECT]) == 0){
    80002f66:	08052483          	lw	s1,128(a0)
    80002f6a:	e891                	bnez	s1,80002f7e <bmap+0x60>
      addr = balloc(ip->dev);
    80002f6c:	4108                	lw	a0,0(a0)
    80002f6e:	eabff0ef          	jal	80002e18 <balloc>
    80002f72:	84aa                	mv	s1,a0
      if(addr == 0)
    80002f74:	c915                	beqz	a0,80002fa8 <bmap+0x8a>
    80002f76:	e052                	sd	s4,0(sp)
        return 0;
      ip->addrs[NDIRECT] = addr;
    80002f78:	08a92023          	sw	a0,128(s2)
    80002f7c:	a011                	j	80002f80 <bmap+0x62>
    80002f7e:	e052                	sd	s4,0(sp)
    }
    bp = bread(ip->dev, addr);
    80002f80:	85a6                	mv	a1,s1
    80002f82:	00092503          	lw	a0,0(s2)
    80002f86:	c33ff0ef          	jal	80002bb8 <bread>
    80002f8a:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80002f8c:	05850793          	addi	a5,a0,88
    if((addr = a[bn]) == 0){
    80002f90:	02099713          	slli	a4,s3,0x20
    80002f94:	01e75593          	srli	a1,a4,0x1e
    80002f98:	97ae                	add	a5,a5,a1
    80002f9a:	89be                	mv	s3,a5
    80002f9c:	4384                	lw	s1,0(a5)
    80002f9e:	cc89                	beqz	s1,80002fb8 <bmap+0x9a>
      if(addr){
        a[bn] = addr;
        log_write(bp);
      }
    }
    brelse(bp);
    80002fa0:	8552                	mv	a0,s4
    80002fa2:	d1fff0ef          	jal	80002cc0 <brelse>
    return addr;
    80002fa6:	6a02                	ld	s4,0(sp)
  }

  panic("bmap: out of range");
}
    80002fa8:	8526                	mv	a0,s1
    80002faa:	70a2                	ld	ra,40(sp)
    80002fac:	7402                	ld	s0,32(sp)
    80002fae:	64e2                	ld	s1,24(sp)
    80002fb0:	6942                	ld	s2,16(sp)
    80002fb2:	69a2                	ld	s3,8(sp)
    80002fb4:	6145                	addi	sp,sp,48
    80002fb6:	8082                	ret
      addr = balloc(ip->dev);
    80002fb8:	00092503          	lw	a0,0(s2)
    80002fbc:	e5dff0ef          	jal	80002e18 <balloc>
    80002fc0:	84aa                	mv	s1,a0
      if(addr){
    80002fc2:	dd79                	beqz	a0,80002fa0 <bmap+0x82>
        a[bn] = addr;
    80002fc4:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    80002fc8:	8552                	mv	a0,s4
    80002fca:	62d000ef          	jal	80003df6 <log_write>
    80002fce:	bfc9                	j	80002fa0 <bmap+0x82>
    80002fd0:	e052                	sd	s4,0(sp)
  panic("bmap: out of range");
    80002fd2:	00004517          	auipc	a0,0x4
    80002fd6:	42650513          	addi	a0,a0,1062 # 800073f8 <etext+0x3f8>
    80002fda:	84bfd0ef          	jal	80000824 <panic>

0000000080002fde <iget>:
{
    80002fde:	7179                	addi	sp,sp,-48
    80002fe0:	f406                	sd	ra,40(sp)
    80002fe2:	f022                	sd	s0,32(sp)
    80002fe4:	ec26                	sd	s1,24(sp)
    80002fe6:	e84a                	sd	s2,16(sp)
    80002fe8:	e44e                	sd	s3,8(sp)
    80002fea:	e052                	sd	s4,0(sp)
    80002fec:	1800                	addi	s0,sp,48
    80002fee:	892a                	mv	s2,a0
    80002ff0:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    80002ff2:	0001b517          	auipc	a0,0x1b
    80002ff6:	e9e50513          	addi	a0,a0,-354 # 8001de90 <itable>
    80002ffa:	c57fd0ef          	jal	80000c50 <acquire>
  empty = 0;
    80002ffe:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003000:	0001b497          	auipc	s1,0x1b
    80003004:	ea848493          	addi	s1,s1,-344 # 8001dea8 <itable+0x18>
    80003008:	0001d697          	auipc	a3,0x1d
    8000300c:	93068693          	addi	a3,a3,-1744 # 8001f938 <log>
    80003010:	a809                	j	80003022 <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    80003012:	e781                	bnez	a5,8000301a <iget+0x3c>
    80003014:	00099363          	bnez	s3,8000301a <iget+0x3c>
      empty = ip;
    80003018:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    8000301a:	08848493          	addi	s1,s1,136
    8000301e:	02d48563          	beq	s1,a3,80003048 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    80003022:	449c                	lw	a5,8(s1)
    80003024:	fef057e3          	blez	a5,80003012 <iget+0x34>
    80003028:	4098                	lw	a4,0(s1)
    8000302a:	ff2718e3          	bne	a4,s2,8000301a <iget+0x3c>
    8000302e:	40d8                	lw	a4,4(s1)
    80003030:	ff4715e3          	bne	a4,s4,8000301a <iget+0x3c>
      ip->ref++;
    80003034:	2785                	addiw	a5,a5,1
    80003036:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    80003038:	0001b517          	auipc	a0,0x1b
    8000303c:	e5850513          	addi	a0,a0,-424 # 8001de90 <itable>
    80003040:	ca5fd0ef          	jal	80000ce4 <release>
      return ip;
    80003044:	89a6                	mv	s3,s1
    80003046:	a015                	j	8000306a <iget+0x8c>
  if(empty == 0)
    80003048:	02098a63          	beqz	s3,8000307c <iget+0x9e>
  ip->dev = dev;
    8000304c:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    80003050:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    80003054:	4785                	li	a5,1
    80003056:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    8000305a:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    8000305e:	0001b517          	auipc	a0,0x1b
    80003062:	e3250513          	addi	a0,a0,-462 # 8001de90 <itable>
    80003066:	c7ffd0ef          	jal	80000ce4 <release>
}
    8000306a:	854e                	mv	a0,s3
    8000306c:	70a2                	ld	ra,40(sp)
    8000306e:	7402                	ld	s0,32(sp)
    80003070:	64e2                	ld	s1,24(sp)
    80003072:	6942                	ld	s2,16(sp)
    80003074:	69a2                	ld	s3,8(sp)
    80003076:	6a02                	ld	s4,0(sp)
    80003078:	6145                	addi	sp,sp,48
    8000307a:	8082                	ret
    panic("iget: no inodes");
    8000307c:	00004517          	auipc	a0,0x4
    80003080:	39450513          	addi	a0,a0,916 # 80007410 <etext+0x410>
    80003084:	fa0fd0ef          	jal	80000824 <panic>

0000000080003088 <iinit>:
{
    80003088:	7179                	addi	sp,sp,-48
    8000308a:	f406                	sd	ra,40(sp)
    8000308c:	f022                	sd	s0,32(sp)
    8000308e:	ec26                	sd	s1,24(sp)
    80003090:	e84a                	sd	s2,16(sp)
    80003092:	e44e                	sd	s3,8(sp)
    80003094:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    80003096:	00004597          	auipc	a1,0x4
    8000309a:	38a58593          	addi	a1,a1,906 # 80007420 <etext+0x420>
    8000309e:	0001b517          	auipc	a0,0x1b
    800030a2:	df250513          	addi	a0,a0,-526 # 8001de90 <itable>
    800030a6:	b21fd0ef          	jal	80000bc6 <initlock>
  for(i = 0; i < NINODE; i++) {
    800030aa:	0001b497          	auipc	s1,0x1b
    800030ae:	e0e48493          	addi	s1,s1,-498 # 8001deb8 <itable+0x28>
    800030b2:	0001d997          	auipc	s3,0x1d
    800030b6:	89698993          	addi	s3,s3,-1898 # 8001f948 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    800030ba:	00004917          	auipc	s2,0x4
    800030be:	36e90913          	addi	s2,s2,878 # 80007428 <etext+0x428>
    800030c2:	85ca                	mv	a1,s2
    800030c4:	8526                	mv	a0,s1
    800030c6:	5f5000ef          	jal	80003eba <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    800030ca:	08848493          	addi	s1,s1,136
    800030ce:	ff349ae3          	bne	s1,s3,800030c2 <iinit+0x3a>
}
    800030d2:	70a2                	ld	ra,40(sp)
    800030d4:	7402                	ld	s0,32(sp)
    800030d6:	64e2                	ld	s1,24(sp)
    800030d8:	6942                	ld	s2,16(sp)
    800030da:	69a2                	ld	s3,8(sp)
    800030dc:	6145                	addi	sp,sp,48
    800030de:	8082                	ret

00000000800030e0 <ialloc>:
{
    800030e0:	7139                	addi	sp,sp,-64
    800030e2:	fc06                	sd	ra,56(sp)
    800030e4:	f822                	sd	s0,48(sp)
    800030e6:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    800030e8:	0001b717          	auipc	a4,0x1b
    800030ec:	d9472703          	lw	a4,-620(a4) # 8001de7c <sb+0xc>
    800030f0:	4785                	li	a5,1
    800030f2:	06e7f063          	bgeu	a5,a4,80003152 <ialloc+0x72>
    800030f6:	f426                	sd	s1,40(sp)
    800030f8:	f04a                	sd	s2,32(sp)
    800030fa:	ec4e                	sd	s3,24(sp)
    800030fc:	e852                	sd	s4,16(sp)
    800030fe:	e456                	sd	s5,8(sp)
    80003100:	e05a                	sd	s6,0(sp)
    80003102:	8aaa                	mv	s5,a0
    80003104:	8b2e                	mv	s6,a1
    80003106:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80003108:	0001ba17          	auipc	s4,0x1b
    8000310c:	d68a0a13          	addi	s4,s4,-664 # 8001de70 <sb>
    80003110:	00495593          	srli	a1,s2,0x4
    80003114:	018a2783          	lw	a5,24(s4)
    80003118:	9dbd                	addw	a1,a1,a5
    8000311a:	8556                	mv	a0,s5
    8000311c:	a9dff0ef          	jal	80002bb8 <bread>
    80003120:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    80003122:	05850993          	addi	s3,a0,88
    80003126:	00f97793          	andi	a5,s2,15
    8000312a:	079a                	slli	a5,a5,0x6
    8000312c:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    8000312e:	00099783          	lh	a5,0(s3)
    80003132:	cb9d                	beqz	a5,80003168 <ialloc+0x88>
    brelse(bp);
    80003134:	b8dff0ef          	jal	80002cc0 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    80003138:	0905                	addi	s2,s2,1
    8000313a:	00ca2703          	lw	a4,12(s4)
    8000313e:	0009079b          	sext.w	a5,s2
    80003142:	fce7e7e3          	bltu	a5,a4,80003110 <ialloc+0x30>
    80003146:	74a2                	ld	s1,40(sp)
    80003148:	7902                	ld	s2,32(sp)
    8000314a:	69e2                	ld	s3,24(sp)
    8000314c:	6a42                	ld	s4,16(sp)
    8000314e:	6aa2                	ld	s5,8(sp)
    80003150:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    80003152:	00004517          	auipc	a0,0x4
    80003156:	2de50513          	addi	a0,a0,734 # 80007430 <etext+0x430>
    8000315a:	ba0fd0ef          	jal	800004fa <printf>
  return 0;
    8000315e:	4501                	li	a0,0
}
    80003160:	70e2                	ld	ra,56(sp)
    80003162:	7442                	ld	s0,48(sp)
    80003164:	6121                	addi	sp,sp,64
    80003166:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    80003168:	04000613          	li	a2,64
    8000316c:	4581                	li	a1,0
    8000316e:	854e                	mv	a0,s3
    80003170:	bb1fd0ef          	jal	80000d20 <memset>
      dip->type = type;
    80003174:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003178:	8526                	mv	a0,s1
    8000317a:	47d000ef          	jal	80003df6 <log_write>
      brelse(bp);
    8000317e:	8526                	mv	a0,s1
    80003180:	b41ff0ef          	jal	80002cc0 <brelse>
      return iget(dev, inum);
    80003184:	0009059b          	sext.w	a1,s2
    80003188:	8556                	mv	a0,s5
    8000318a:	e55ff0ef          	jal	80002fde <iget>
    8000318e:	74a2                	ld	s1,40(sp)
    80003190:	7902                	ld	s2,32(sp)
    80003192:	69e2                	ld	s3,24(sp)
    80003194:	6a42                	ld	s4,16(sp)
    80003196:	6aa2                	ld	s5,8(sp)
    80003198:	6b02                	ld	s6,0(sp)
    8000319a:	b7d9                	j	80003160 <ialloc+0x80>

000000008000319c <iupdate>:
{
    8000319c:	1101                	addi	sp,sp,-32
    8000319e:	ec06                	sd	ra,24(sp)
    800031a0:	e822                	sd	s0,16(sp)
    800031a2:	e426                	sd	s1,8(sp)
    800031a4:	e04a                	sd	s2,0(sp)
    800031a6:	1000                	addi	s0,sp,32
    800031a8:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    800031aa:	415c                	lw	a5,4(a0)
    800031ac:	0047d79b          	srliw	a5,a5,0x4
    800031b0:	0001b597          	auipc	a1,0x1b
    800031b4:	cd85a583          	lw	a1,-808(a1) # 8001de88 <sb+0x18>
    800031b8:	9dbd                	addw	a1,a1,a5
    800031ba:	4108                	lw	a0,0(a0)
    800031bc:	9fdff0ef          	jal	80002bb8 <bread>
    800031c0:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    800031c2:	05850793          	addi	a5,a0,88
    800031c6:	40d8                	lw	a4,4(s1)
    800031c8:	8b3d                	andi	a4,a4,15
    800031ca:	071a                	slli	a4,a4,0x6
    800031cc:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    800031ce:	04449703          	lh	a4,68(s1)
    800031d2:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    800031d6:	04649703          	lh	a4,70(s1)
    800031da:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    800031de:	04849703          	lh	a4,72(s1)
    800031e2:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    800031e6:	04a49703          	lh	a4,74(s1)
    800031ea:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    800031ee:	44f8                	lw	a4,76(s1)
    800031f0:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    800031f2:	03400613          	li	a2,52
    800031f6:	05048593          	addi	a1,s1,80
    800031fa:	00c78513          	addi	a0,a5,12
    800031fe:	b83fd0ef          	jal	80000d80 <memmove>
  log_write(bp);
    80003202:	854a                	mv	a0,s2
    80003204:	3f3000ef          	jal	80003df6 <log_write>
  brelse(bp);
    80003208:	854a                	mv	a0,s2
    8000320a:	ab7ff0ef          	jal	80002cc0 <brelse>
}
    8000320e:	60e2                	ld	ra,24(sp)
    80003210:	6442                	ld	s0,16(sp)
    80003212:	64a2                	ld	s1,8(sp)
    80003214:	6902                	ld	s2,0(sp)
    80003216:	6105                	addi	sp,sp,32
    80003218:	8082                	ret

000000008000321a <idup>:
{
    8000321a:	1101                	addi	sp,sp,-32
    8000321c:	ec06                	sd	ra,24(sp)
    8000321e:	e822                	sd	s0,16(sp)
    80003220:	e426                	sd	s1,8(sp)
    80003222:	1000                	addi	s0,sp,32
    80003224:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    80003226:	0001b517          	auipc	a0,0x1b
    8000322a:	c6a50513          	addi	a0,a0,-918 # 8001de90 <itable>
    8000322e:	a23fd0ef          	jal	80000c50 <acquire>
  ip->ref++;
    80003232:	449c                	lw	a5,8(s1)
    80003234:	2785                	addiw	a5,a5,1
    80003236:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    80003238:	0001b517          	auipc	a0,0x1b
    8000323c:	c5850513          	addi	a0,a0,-936 # 8001de90 <itable>
    80003240:	aa5fd0ef          	jal	80000ce4 <release>
}
    80003244:	8526                	mv	a0,s1
    80003246:	60e2                	ld	ra,24(sp)
    80003248:	6442                	ld	s0,16(sp)
    8000324a:	64a2                	ld	s1,8(sp)
    8000324c:	6105                	addi	sp,sp,32
    8000324e:	8082                	ret

0000000080003250 <ilock>:
{
    80003250:	1101                	addi	sp,sp,-32
    80003252:	ec06                	sd	ra,24(sp)
    80003254:	e822                	sd	s0,16(sp)
    80003256:	e426                	sd	s1,8(sp)
    80003258:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    8000325a:	cd19                	beqz	a0,80003278 <ilock+0x28>
    8000325c:	84aa                	mv	s1,a0
    8000325e:	451c                	lw	a5,8(a0)
    80003260:	00f05c63          	blez	a5,80003278 <ilock+0x28>
  acquiresleep(&ip->lock);
    80003264:	0541                	addi	a0,a0,16
    80003266:	48b000ef          	jal	80003ef0 <acquiresleep>
  if(ip->valid == 0){
    8000326a:	40bc                	lw	a5,64(s1)
    8000326c:	cf89                	beqz	a5,80003286 <ilock+0x36>
}
    8000326e:	60e2                	ld	ra,24(sp)
    80003270:	6442                	ld	s0,16(sp)
    80003272:	64a2                	ld	s1,8(sp)
    80003274:	6105                	addi	sp,sp,32
    80003276:	8082                	ret
    80003278:	e04a                	sd	s2,0(sp)
    panic("ilock");
    8000327a:	00004517          	auipc	a0,0x4
    8000327e:	1ce50513          	addi	a0,a0,462 # 80007448 <etext+0x448>
    80003282:	da2fd0ef          	jal	80000824 <panic>
    80003286:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003288:	40dc                	lw	a5,4(s1)
    8000328a:	0047d79b          	srliw	a5,a5,0x4
    8000328e:	0001b597          	auipc	a1,0x1b
    80003292:	bfa5a583          	lw	a1,-1030(a1) # 8001de88 <sb+0x18>
    80003296:	9dbd                	addw	a1,a1,a5
    80003298:	4088                	lw	a0,0(s1)
    8000329a:	91fff0ef          	jal	80002bb8 <bread>
    8000329e:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    800032a0:	05850593          	addi	a1,a0,88
    800032a4:	40dc                	lw	a5,4(s1)
    800032a6:	8bbd                	andi	a5,a5,15
    800032a8:	079a                	slli	a5,a5,0x6
    800032aa:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    800032ac:	00059783          	lh	a5,0(a1)
    800032b0:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    800032b4:	00259783          	lh	a5,2(a1)
    800032b8:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    800032bc:	00459783          	lh	a5,4(a1)
    800032c0:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    800032c4:	00659783          	lh	a5,6(a1)
    800032c8:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    800032cc:	459c                	lw	a5,8(a1)
    800032ce:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    800032d0:	03400613          	li	a2,52
    800032d4:	05b1                	addi	a1,a1,12
    800032d6:	05048513          	addi	a0,s1,80
    800032da:	aa7fd0ef          	jal	80000d80 <memmove>
    brelse(bp);
    800032de:	854a                	mv	a0,s2
    800032e0:	9e1ff0ef          	jal	80002cc0 <brelse>
    ip->valid = 1;
    800032e4:	4785                	li	a5,1
    800032e6:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    800032e8:	04449783          	lh	a5,68(s1)
    800032ec:	c399                	beqz	a5,800032f2 <ilock+0xa2>
    800032ee:	6902                	ld	s2,0(sp)
    800032f0:	bfbd                	j	8000326e <ilock+0x1e>
      panic("ilock: no type");
    800032f2:	00004517          	auipc	a0,0x4
    800032f6:	15e50513          	addi	a0,a0,350 # 80007450 <etext+0x450>
    800032fa:	d2afd0ef          	jal	80000824 <panic>

00000000800032fe <iunlock>:
{
    800032fe:	1101                	addi	sp,sp,-32
    80003300:	ec06                	sd	ra,24(sp)
    80003302:	e822                	sd	s0,16(sp)
    80003304:	e426                	sd	s1,8(sp)
    80003306:	e04a                	sd	s2,0(sp)
    80003308:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    8000330a:	c505                	beqz	a0,80003332 <iunlock+0x34>
    8000330c:	84aa                	mv	s1,a0
    8000330e:	01050913          	addi	s2,a0,16
    80003312:	854a                	mv	a0,s2
    80003314:	45b000ef          	jal	80003f6e <holdingsleep>
    80003318:	cd09                	beqz	a0,80003332 <iunlock+0x34>
    8000331a:	449c                	lw	a5,8(s1)
    8000331c:	00f05b63          	blez	a5,80003332 <iunlock+0x34>
  releasesleep(&ip->lock);
    80003320:	854a                	mv	a0,s2
    80003322:	415000ef          	jal	80003f36 <releasesleep>
}
    80003326:	60e2                	ld	ra,24(sp)
    80003328:	6442                	ld	s0,16(sp)
    8000332a:	64a2                	ld	s1,8(sp)
    8000332c:	6902                	ld	s2,0(sp)
    8000332e:	6105                	addi	sp,sp,32
    80003330:	8082                	ret
    panic("iunlock");
    80003332:	00004517          	auipc	a0,0x4
    80003336:	12e50513          	addi	a0,a0,302 # 80007460 <etext+0x460>
    8000333a:	ceafd0ef          	jal	80000824 <panic>

000000008000333e <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    8000333e:	7179                	addi	sp,sp,-48
    80003340:	f406                	sd	ra,40(sp)
    80003342:	f022                	sd	s0,32(sp)
    80003344:	ec26                	sd	s1,24(sp)
    80003346:	e84a                	sd	s2,16(sp)
    80003348:	e44e                	sd	s3,8(sp)
    8000334a:	1800                	addi	s0,sp,48
    8000334c:	89aa                	mv	s3,a0
  int i, j;
  struct buf *bp;
  uint *a;

  for(i = 0; i < NDIRECT; i++){
    8000334e:	05050493          	addi	s1,a0,80
    80003352:	08050913          	addi	s2,a0,128
    80003356:	a021                	j	8000335e <itrunc+0x20>
    80003358:	0491                	addi	s1,s1,4
    8000335a:	01248b63          	beq	s1,s2,80003370 <itrunc+0x32>
    if(ip->addrs[i]){
    8000335e:	408c                	lw	a1,0(s1)
    80003360:	dde5                	beqz	a1,80003358 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    80003362:	0009a503          	lw	a0,0(s3)
    80003366:	a47ff0ef          	jal	80002dac <bfree>
      ip->addrs[i] = 0;
    8000336a:	0004a023          	sw	zero,0(s1)
    8000336e:	b7ed                	j	80003358 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    80003370:	0809a583          	lw	a1,128(s3)
    80003374:	ed89                	bnez	a1,8000338e <itrunc+0x50>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  ip->size = 0;
    80003376:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    8000337a:	854e                	mv	a0,s3
    8000337c:	e21ff0ef          	jal	8000319c <iupdate>
}
    80003380:	70a2                	ld	ra,40(sp)
    80003382:	7402                	ld	s0,32(sp)
    80003384:	64e2                	ld	s1,24(sp)
    80003386:	6942                	ld	s2,16(sp)
    80003388:	69a2                	ld	s3,8(sp)
    8000338a:	6145                	addi	sp,sp,48
    8000338c:	8082                	ret
    8000338e:	e052                	sd	s4,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    80003390:	0009a503          	lw	a0,0(s3)
    80003394:	825ff0ef          	jal	80002bb8 <bread>
    80003398:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    8000339a:	05850493          	addi	s1,a0,88
    8000339e:	45850913          	addi	s2,a0,1112
    800033a2:	a021                	j	800033aa <itrunc+0x6c>
    800033a4:	0491                	addi	s1,s1,4
    800033a6:	01248963          	beq	s1,s2,800033b8 <itrunc+0x7a>
      if(a[j])
    800033aa:	408c                	lw	a1,0(s1)
    800033ac:	dde5                	beqz	a1,800033a4 <itrunc+0x66>
        bfree(ip->dev, a[j]);
    800033ae:	0009a503          	lw	a0,0(s3)
    800033b2:	9fbff0ef          	jal	80002dac <bfree>
    800033b6:	b7fd                	j	800033a4 <itrunc+0x66>
    brelse(bp);
    800033b8:	8552                	mv	a0,s4
    800033ba:	907ff0ef          	jal	80002cc0 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    800033be:	0809a583          	lw	a1,128(s3)
    800033c2:	0009a503          	lw	a0,0(s3)
    800033c6:	9e7ff0ef          	jal	80002dac <bfree>
    ip->addrs[NDIRECT] = 0;
    800033ca:	0809a023          	sw	zero,128(s3)
    800033ce:	6a02                	ld	s4,0(sp)
    800033d0:	b75d                	j	80003376 <itrunc+0x38>

00000000800033d2 <iput>:
{
    800033d2:	1101                	addi	sp,sp,-32
    800033d4:	ec06                	sd	ra,24(sp)
    800033d6:	e822                	sd	s0,16(sp)
    800033d8:	e426                	sd	s1,8(sp)
    800033da:	1000                	addi	s0,sp,32
    800033dc:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800033de:	0001b517          	auipc	a0,0x1b
    800033e2:	ab250513          	addi	a0,a0,-1358 # 8001de90 <itable>
    800033e6:	86bfd0ef          	jal	80000c50 <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    800033ea:	4498                	lw	a4,8(s1)
    800033ec:	4785                	li	a5,1
    800033ee:	02f70063          	beq	a4,a5,8000340e <iput+0x3c>
  ip->ref--;
    800033f2:	449c                	lw	a5,8(s1)
    800033f4:	37fd                	addiw	a5,a5,-1
    800033f6:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800033f8:	0001b517          	auipc	a0,0x1b
    800033fc:	a9850513          	addi	a0,a0,-1384 # 8001de90 <itable>
    80003400:	8e5fd0ef          	jal	80000ce4 <release>
}
    80003404:	60e2                	ld	ra,24(sp)
    80003406:	6442                	ld	s0,16(sp)
    80003408:	64a2                	ld	s1,8(sp)
    8000340a:	6105                	addi	sp,sp,32
    8000340c:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    8000340e:	40bc                	lw	a5,64(s1)
    80003410:	d3ed                	beqz	a5,800033f2 <iput+0x20>
    80003412:	04a49783          	lh	a5,74(s1)
    80003416:	fff1                	bnez	a5,800033f2 <iput+0x20>
    80003418:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    8000341a:	01048793          	addi	a5,s1,16
    8000341e:	893e                	mv	s2,a5
    80003420:	853e                	mv	a0,a5
    80003422:	2cf000ef          	jal	80003ef0 <acquiresleep>
    release(&itable.lock);
    80003426:	0001b517          	auipc	a0,0x1b
    8000342a:	a6a50513          	addi	a0,a0,-1430 # 8001de90 <itable>
    8000342e:	8b7fd0ef          	jal	80000ce4 <release>
    itrunc(ip);
    80003432:	8526                	mv	a0,s1
    80003434:	f0bff0ef          	jal	8000333e <itrunc>
    ip->type = 0;
    80003438:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    8000343c:	8526                	mv	a0,s1
    8000343e:	d5fff0ef          	jal	8000319c <iupdate>
    ip->valid = 0;
    80003442:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    80003446:	854a                	mv	a0,s2
    80003448:	2ef000ef          	jal	80003f36 <releasesleep>
    acquire(&itable.lock);
    8000344c:	0001b517          	auipc	a0,0x1b
    80003450:	a4450513          	addi	a0,a0,-1468 # 8001de90 <itable>
    80003454:	ffcfd0ef          	jal	80000c50 <acquire>
    80003458:	6902                	ld	s2,0(sp)
    8000345a:	bf61                	j	800033f2 <iput+0x20>

000000008000345c <iunlockput>:
{
    8000345c:	1101                	addi	sp,sp,-32
    8000345e:	ec06                	sd	ra,24(sp)
    80003460:	e822                	sd	s0,16(sp)
    80003462:	e426                	sd	s1,8(sp)
    80003464:	1000                	addi	s0,sp,32
    80003466:	84aa                	mv	s1,a0
  iunlock(ip);
    80003468:	e97ff0ef          	jal	800032fe <iunlock>
  iput(ip);
    8000346c:	8526                	mv	a0,s1
    8000346e:	f65ff0ef          	jal	800033d2 <iput>
}
    80003472:	60e2                	ld	ra,24(sp)
    80003474:	6442                	ld	s0,16(sp)
    80003476:	64a2                	ld	s1,8(sp)
    80003478:	6105                	addi	sp,sp,32
    8000347a:	8082                	ret

000000008000347c <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    8000347c:	0001b717          	auipc	a4,0x1b
    80003480:	a0072703          	lw	a4,-1536(a4) # 8001de7c <sb+0xc>
    80003484:	4785                	li	a5,1
    80003486:	0ae7fe63          	bgeu	a5,a4,80003542 <ireclaim+0xc6>
{
    8000348a:	7139                	addi	sp,sp,-64
    8000348c:	fc06                	sd	ra,56(sp)
    8000348e:	f822                	sd	s0,48(sp)
    80003490:	f426                	sd	s1,40(sp)
    80003492:	f04a                	sd	s2,32(sp)
    80003494:	ec4e                	sd	s3,24(sp)
    80003496:	e852                	sd	s4,16(sp)
    80003498:	e456                	sd	s5,8(sp)
    8000349a:	e05a                	sd	s6,0(sp)
    8000349c:	0080                	addi	s0,sp,64
    8000349e:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800034a0:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800034a2:	0001ba17          	auipc	s4,0x1b
    800034a6:	9cea0a13          	addi	s4,s4,-1586 # 8001de70 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    800034aa:	00004b17          	auipc	s6,0x4
    800034ae:	fbeb0b13          	addi	s6,s6,-66 # 80007468 <etext+0x468>
    800034b2:	a099                	j	800034f8 <ireclaim+0x7c>
    800034b4:	85ce                	mv	a1,s3
    800034b6:	855a                	mv	a0,s6
    800034b8:	842fd0ef          	jal	800004fa <printf>
      ip = iget(dev, inum);
    800034bc:	85ce                	mv	a1,s3
    800034be:	8556                	mv	a0,s5
    800034c0:	b1fff0ef          	jal	80002fde <iget>
    800034c4:	89aa                	mv	s3,a0
    brelse(bp);
    800034c6:	854a                	mv	a0,s2
    800034c8:	ff8ff0ef          	jal	80002cc0 <brelse>
    if (ip) {
    800034cc:	00098f63          	beqz	s3,800034ea <ireclaim+0x6e>
      begin_op();
    800034d0:	78c000ef          	jal	80003c5c <begin_op>
      ilock(ip);
    800034d4:	854e                	mv	a0,s3
    800034d6:	d7bff0ef          	jal	80003250 <ilock>
      iunlock(ip);
    800034da:	854e                	mv	a0,s3
    800034dc:	e23ff0ef          	jal	800032fe <iunlock>
      iput(ip);
    800034e0:	854e                	mv	a0,s3
    800034e2:	ef1ff0ef          	jal	800033d2 <iput>
      end_op();
    800034e6:	7e6000ef          	jal	80003ccc <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800034ea:	0485                	addi	s1,s1,1
    800034ec:	00ca2703          	lw	a4,12(s4)
    800034f0:	0004879b          	sext.w	a5,s1
    800034f4:	02e7fd63          	bgeu	a5,a4,8000352e <ireclaim+0xb2>
    800034f8:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800034fc:	0044d593          	srli	a1,s1,0x4
    80003500:	018a2783          	lw	a5,24(s4)
    80003504:	9dbd                	addw	a1,a1,a5
    80003506:	8556                	mv	a0,s5
    80003508:	eb0ff0ef          	jal	80002bb8 <bread>
    8000350c:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    8000350e:	05850793          	addi	a5,a0,88
    80003512:	00f9f713          	andi	a4,s3,15
    80003516:	071a                	slli	a4,a4,0x6
    80003518:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    8000351a:	00079703          	lh	a4,0(a5)
    8000351e:	c701                	beqz	a4,80003526 <ireclaim+0xaa>
    80003520:	00679783          	lh	a5,6(a5)
    80003524:	dbc1                	beqz	a5,800034b4 <ireclaim+0x38>
    brelse(bp);
    80003526:	854a                	mv	a0,s2
    80003528:	f98ff0ef          	jal	80002cc0 <brelse>
    if (ip) {
    8000352c:	bf7d                	j	800034ea <ireclaim+0x6e>
}
    8000352e:	70e2                	ld	ra,56(sp)
    80003530:	7442                	ld	s0,48(sp)
    80003532:	74a2                	ld	s1,40(sp)
    80003534:	7902                	ld	s2,32(sp)
    80003536:	69e2                	ld	s3,24(sp)
    80003538:	6a42                	ld	s4,16(sp)
    8000353a:	6aa2                	ld	s5,8(sp)
    8000353c:	6b02                	ld	s6,0(sp)
    8000353e:	6121                	addi	sp,sp,64
    80003540:	8082                	ret
    80003542:	8082                	ret

0000000080003544 <fsinit>:
fsinit(int dev) {
    80003544:	1101                	addi	sp,sp,-32
    80003546:	ec06                	sd	ra,24(sp)
    80003548:	e822                	sd	s0,16(sp)
    8000354a:	e426                	sd	s1,8(sp)
    8000354c:	e04a                	sd	s2,0(sp)
    8000354e:	1000                	addi	s0,sp,32
    80003550:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80003552:	4585                	li	a1,1
    80003554:	e64ff0ef          	jal	80002bb8 <bread>
    80003558:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    8000355a:	02000613          	li	a2,32
    8000355e:	05850593          	addi	a1,a0,88
    80003562:	0001b517          	auipc	a0,0x1b
    80003566:	90e50513          	addi	a0,a0,-1778 # 8001de70 <sb>
    8000356a:	817fd0ef          	jal	80000d80 <memmove>
  brelse(bp);
    8000356e:	8526                	mv	a0,s1
    80003570:	f50ff0ef          	jal	80002cc0 <brelse>
  if(sb.magic != FSMAGIC)
    80003574:	0001b717          	auipc	a4,0x1b
    80003578:	8fc72703          	lw	a4,-1796(a4) # 8001de70 <sb>
    8000357c:	102037b7          	lui	a5,0x10203
    80003580:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003584:	02f71263          	bne	a4,a5,800035a8 <fsinit+0x64>
  initlog(dev, &sb);
    80003588:	0001b597          	auipc	a1,0x1b
    8000358c:	8e858593          	addi	a1,a1,-1816 # 8001de70 <sb>
    80003590:	854a                	mv	a0,s2
    80003592:	648000ef          	jal	80003bda <initlog>
  ireclaim(dev);
    80003596:	854a                	mv	a0,s2
    80003598:	ee5ff0ef          	jal	8000347c <ireclaim>
}
    8000359c:	60e2                	ld	ra,24(sp)
    8000359e:	6442                	ld	s0,16(sp)
    800035a0:	64a2                	ld	s1,8(sp)
    800035a2:	6902                	ld	s2,0(sp)
    800035a4:	6105                	addi	sp,sp,32
    800035a6:	8082                	ret
    panic("invalid file system");
    800035a8:	00004517          	auipc	a0,0x4
    800035ac:	ee050513          	addi	a0,a0,-288 # 80007488 <etext+0x488>
    800035b0:	a74fd0ef          	jal	80000824 <panic>

00000000800035b4 <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    800035b4:	1141                	addi	sp,sp,-16
    800035b6:	e406                	sd	ra,8(sp)
    800035b8:	e022                	sd	s0,0(sp)
    800035ba:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    800035bc:	411c                	lw	a5,0(a0)
    800035be:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    800035c0:	415c                	lw	a5,4(a0)
    800035c2:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    800035c4:	04451783          	lh	a5,68(a0)
    800035c8:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    800035cc:	04a51783          	lh	a5,74(a0)
    800035d0:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    800035d4:	04c56783          	lwu	a5,76(a0)
    800035d8:	e99c                	sd	a5,16(a1)
}
    800035da:	60a2                	ld	ra,8(sp)
    800035dc:	6402                	ld	s0,0(sp)
    800035de:	0141                	addi	sp,sp,16
    800035e0:	8082                	ret

00000000800035e2 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800035e2:	457c                	lw	a5,76(a0)
    800035e4:	0ed7e663          	bltu	a5,a3,800036d0 <readi+0xee>
{
    800035e8:	7159                	addi	sp,sp,-112
    800035ea:	f486                	sd	ra,104(sp)
    800035ec:	f0a2                	sd	s0,96(sp)
    800035ee:	eca6                	sd	s1,88(sp)
    800035f0:	e0d2                	sd	s4,64(sp)
    800035f2:	fc56                	sd	s5,56(sp)
    800035f4:	f85a                	sd	s6,48(sp)
    800035f6:	f45e                	sd	s7,40(sp)
    800035f8:	1880                	addi	s0,sp,112
    800035fa:	8b2a                	mv	s6,a0
    800035fc:	8bae                	mv	s7,a1
    800035fe:	8a32                	mv	s4,a2
    80003600:	84b6                	mv	s1,a3
    80003602:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003604:	9f35                	addw	a4,a4,a3
    return 0;
    80003606:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003608:	0ad76b63          	bltu	a4,a3,800036be <readi+0xdc>
    8000360c:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    8000360e:	00e7f463          	bgeu	a5,a4,80003616 <readi+0x34>
    n = ip->size - off;
    80003612:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003616:	080a8b63          	beqz	s5,800036ac <readi+0xca>
    8000361a:	e8ca                	sd	s2,80(sp)
    8000361c:	f062                	sd	s8,32(sp)
    8000361e:	ec66                	sd	s9,24(sp)
    80003620:	e86a                	sd	s10,16(sp)
    80003622:	e46e                	sd	s11,8(sp)
    80003624:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003626:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    8000362a:	5c7d                	li	s8,-1
    8000362c:	a80d                	j	8000365e <readi+0x7c>
    8000362e:	020d1d93          	slli	s11,s10,0x20
    80003632:	020ddd93          	srli	s11,s11,0x20
    80003636:	05890613          	addi	a2,s2,88
    8000363a:	86ee                	mv	a3,s11
    8000363c:	963e                	add	a2,a2,a5
    8000363e:	85d2                	mv	a1,s4
    80003640:	855e                	mv	a0,s7
    80003642:	c7ffe0ef          	jal	800022c0 <either_copyout>
    80003646:	05850363          	beq	a0,s8,8000368c <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    8000364a:	854a                	mv	a0,s2
    8000364c:	e74ff0ef          	jal	80002cc0 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003650:	013d09bb          	addw	s3,s10,s3
    80003654:	009d04bb          	addw	s1,s10,s1
    80003658:	9a6e                	add	s4,s4,s11
    8000365a:	0559f363          	bgeu	s3,s5,800036a0 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    8000365e:	00a4d59b          	srliw	a1,s1,0xa
    80003662:	855a                	mv	a0,s6
    80003664:	8bbff0ef          	jal	80002f1e <bmap>
    80003668:	85aa                	mv	a1,a0
    if(addr == 0)
    8000366a:	c139                	beqz	a0,800036b0 <readi+0xce>
    bp = bread(ip->dev, addr);
    8000366c:	000b2503          	lw	a0,0(s6)
    80003670:	d48ff0ef          	jal	80002bb8 <bread>
    80003674:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003676:	3ff4f793          	andi	a5,s1,1023
    8000367a:	40fc873b          	subw	a4,s9,a5
    8000367e:	413a86bb          	subw	a3,s5,s3
    80003682:	8d3a                	mv	s10,a4
    80003684:	fae6f5e3          	bgeu	a3,a4,8000362e <readi+0x4c>
    80003688:	8d36                	mv	s10,a3
    8000368a:	b755                	j	8000362e <readi+0x4c>
      brelse(bp);
    8000368c:	854a                	mv	a0,s2
    8000368e:	e32ff0ef          	jal	80002cc0 <brelse>
      tot = -1;
    80003692:	59fd                	li	s3,-1
      break;
    80003694:	6946                	ld	s2,80(sp)
    80003696:	7c02                	ld	s8,32(sp)
    80003698:	6ce2                	ld	s9,24(sp)
    8000369a:	6d42                	ld	s10,16(sp)
    8000369c:	6da2                	ld	s11,8(sp)
    8000369e:	a831                	j	800036ba <readi+0xd8>
    800036a0:	6946                	ld	s2,80(sp)
    800036a2:	7c02                	ld	s8,32(sp)
    800036a4:	6ce2                	ld	s9,24(sp)
    800036a6:	6d42                	ld	s10,16(sp)
    800036a8:	6da2                	ld	s11,8(sp)
    800036aa:	a801                	j	800036ba <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    800036ac:	89d6                	mv	s3,s5
    800036ae:	a031                	j	800036ba <readi+0xd8>
    800036b0:	6946                	ld	s2,80(sp)
    800036b2:	7c02                	ld	s8,32(sp)
    800036b4:	6ce2                	ld	s9,24(sp)
    800036b6:	6d42                	ld	s10,16(sp)
    800036b8:	6da2                	ld	s11,8(sp)
  }
  return tot;
    800036ba:	854e                	mv	a0,s3
    800036bc:	69a6                	ld	s3,72(sp)
}
    800036be:	70a6                	ld	ra,104(sp)
    800036c0:	7406                	ld	s0,96(sp)
    800036c2:	64e6                	ld	s1,88(sp)
    800036c4:	6a06                	ld	s4,64(sp)
    800036c6:	7ae2                	ld	s5,56(sp)
    800036c8:	7b42                	ld	s6,48(sp)
    800036ca:	7ba2                	ld	s7,40(sp)
    800036cc:	6165                	addi	sp,sp,112
    800036ce:	8082                	ret
    return 0;
    800036d0:	4501                	li	a0,0
}
    800036d2:	8082                	ret

00000000800036d4 <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    800036d4:	457c                	lw	a5,76(a0)
    800036d6:	0ed7eb63          	bltu	a5,a3,800037cc <writei+0xf8>
{
    800036da:	7159                	addi	sp,sp,-112
    800036dc:	f486                	sd	ra,104(sp)
    800036de:	f0a2                	sd	s0,96(sp)
    800036e0:	e8ca                	sd	s2,80(sp)
    800036e2:	e0d2                	sd	s4,64(sp)
    800036e4:	fc56                	sd	s5,56(sp)
    800036e6:	f85a                	sd	s6,48(sp)
    800036e8:	f45e                	sd	s7,40(sp)
    800036ea:	1880                	addi	s0,sp,112
    800036ec:	8aaa                	mv	s5,a0
    800036ee:	8bae                	mv	s7,a1
    800036f0:	8a32                	mv	s4,a2
    800036f2:	8936                	mv	s2,a3
    800036f4:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    800036f6:	00e687bb          	addw	a5,a3,a4
    return -1;
  if(off + n > MAXFILE*BSIZE)
    800036fa:	00043737          	lui	a4,0x43
    800036fe:	0cf76963          	bltu	a4,a5,800037d0 <writei+0xfc>
    80003702:	0cd7e763          	bltu	a5,a3,800037d0 <writei+0xfc>
    80003706:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003708:	0a0b0a63          	beqz	s6,800037bc <writei+0xe8>
    8000370c:	eca6                	sd	s1,88(sp)
    8000370e:	f062                	sd	s8,32(sp)
    80003710:	ec66                	sd	s9,24(sp)
    80003712:	e86a                	sd	s10,16(sp)
    80003714:	e46e                	sd	s11,8(sp)
    80003716:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003718:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    8000371c:	5c7d                	li	s8,-1
    8000371e:	a825                	j	80003756 <writei+0x82>
    80003720:	020d1d93          	slli	s11,s10,0x20
    80003724:	020ddd93          	srli	s11,s11,0x20
    80003728:	05848513          	addi	a0,s1,88
    8000372c:	86ee                	mv	a3,s11
    8000372e:	8652                	mv	a2,s4
    80003730:	85de                	mv	a1,s7
    80003732:	953e                	add	a0,a0,a5
    80003734:	bd7fe0ef          	jal	8000230a <either_copyin>
    80003738:	05850663          	beq	a0,s8,80003784 <writei+0xb0>
      brelse(bp);
      break;
    }
    log_write(bp);
    8000373c:	8526                	mv	a0,s1
    8000373e:	6b8000ef          	jal	80003df6 <log_write>
    brelse(bp);
    80003742:	8526                	mv	a0,s1
    80003744:	d7cff0ef          	jal	80002cc0 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003748:	013d09bb          	addw	s3,s10,s3
    8000374c:	012d093b          	addw	s2,s10,s2
    80003750:	9a6e                	add	s4,s4,s11
    80003752:	0369fc63          	bgeu	s3,s6,8000378a <writei+0xb6>
    uint addr = bmap(ip, off/BSIZE);
    80003756:	00a9559b          	srliw	a1,s2,0xa
    8000375a:	8556                	mv	a0,s5
    8000375c:	fc2ff0ef          	jal	80002f1e <bmap>
    80003760:	85aa                	mv	a1,a0
    if(addr == 0)
    80003762:	c505                	beqz	a0,8000378a <writei+0xb6>
    bp = bread(ip->dev, addr);
    80003764:	000aa503          	lw	a0,0(s5)
    80003768:	c50ff0ef          	jal	80002bb8 <bread>
    8000376c:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    8000376e:	3ff97793          	andi	a5,s2,1023
    80003772:	40fc873b          	subw	a4,s9,a5
    80003776:	413b06bb          	subw	a3,s6,s3
    8000377a:	8d3a                	mv	s10,a4
    8000377c:	fae6f2e3          	bgeu	a3,a4,80003720 <writei+0x4c>
    80003780:	8d36                	mv	s10,a3
    80003782:	bf79                	j	80003720 <writei+0x4c>
      brelse(bp);
    80003784:	8526                	mv	a0,s1
    80003786:	d3aff0ef          	jal	80002cc0 <brelse>
  }

  if(off > ip->size)
    8000378a:	04caa783          	lw	a5,76(s5)
    8000378e:	0327f963          	bgeu	a5,s2,800037c0 <writei+0xec>
    ip->size = off;
    80003792:	052aa623          	sw	s2,76(s5)
    80003796:	64e6                	ld	s1,88(sp)
    80003798:	7c02                	ld	s8,32(sp)
    8000379a:	6ce2                	ld	s9,24(sp)
    8000379c:	6d42                	ld	s10,16(sp)
    8000379e:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    800037a0:	8556                	mv	a0,s5
    800037a2:	9fbff0ef          	jal	8000319c <iupdate>

  return tot;
    800037a6:	854e                	mv	a0,s3
    800037a8:	69a6                	ld	s3,72(sp)
}
    800037aa:	70a6                	ld	ra,104(sp)
    800037ac:	7406                	ld	s0,96(sp)
    800037ae:	6946                	ld	s2,80(sp)
    800037b0:	6a06                	ld	s4,64(sp)
    800037b2:	7ae2                	ld	s5,56(sp)
    800037b4:	7b42                	ld	s6,48(sp)
    800037b6:	7ba2                	ld	s7,40(sp)
    800037b8:	6165                	addi	sp,sp,112
    800037ba:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    800037bc:	89da                	mv	s3,s6
    800037be:	b7cd                	j	800037a0 <writei+0xcc>
    800037c0:	64e6                	ld	s1,88(sp)
    800037c2:	7c02                	ld	s8,32(sp)
    800037c4:	6ce2                	ld	s9,24(sp)
    800037c6:	6d42                	ld	s10,16(sp)
    800037c8:	6da2                	ld	s11,8(sp)
    800037ca:	bfd9                	j	800037a0 <writei+0xcc>
    return -1;
    800037cc:	557d                	li	a0,-1
}
    800037ce:	8082                	ret
    return -1;
    800037d0:	557d                	li	a0,-1
    800037d2:	bfe1                	j	800037aa <writei+0xd6>

00000000800037d4 <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    800037d4:	1141                	addi	sp,sp,-16
    800037d6:	e406                	sd	ra,8(sp)
    800037d8:	e022                	sd	s0,0(sp)
    800037da:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    800037dc:	4639                	li	a2,14
    800037de:	e16fd0ef          	jal	80000df4 <strncmp>
}
    800037e2:	60a2                	ld	ra,8(sp)
    800037e4:	6402                	ld	s0,0(sp)
    800037e6:	0141                	addi	sp,sp,16
    800037e8:	8082                	ret

00000000800037ea <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    800037ea:	711d                	addi	sp,sp,-96
    800037ec:	ec86                	sd	ra,88(sp)
    800037ee:	e8a2                	sd	s0,80(sp)
    800037f0:	e4a6                	sd	s1,72(sp)
    800037f2:	e0ca                	sd	s2,64(sp)
    800037f4:	fc4e                	sd	s3,56(sp)
    800037f6:	f852                	sd	s4,48(sp)
    800037f8:	f456                	sd	s5,40(sp)
    800037fa:	f05a                	sd	s6,32(sp)
    800037fc:	ec5e                	sd	s7,24(sp)
    800037fe:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003800:	04451703          	lh	a4,68(a0)
    80003804:	4785                	li	a5,1
    80003806:	00f71f63          	bne	a4,a5,80003824 <dirlookup+0x3a>
    8000380a:	892a                	mv	s2,a0
    8000380c:	8aae                	mv	s5,a1
    8000380e:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003810:	457c                	lw	a5,76(a0)
    80003812:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003814:	fa040a13          	addi	s4,s0,-96
    80003818:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    8000381a:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    8000381e:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003820:	e39d                	bnez	a5,80003846 <dirlookup+0x5c>
    80003822:	a8b9                	j	80003880 <dirlookup+0x96>
    panic("dirlookup not DIR");
    80003824:	00004517          	auipc	a0,0x4
    80003828:	c7c50513          	addi	a0,a0,-900 # 800074a0 <etext+0x4a0>
    8000382c:	ff9fc0ef          	jal	80000824 <panic>
      panic("dirlookup read");
    80003830:	00004517          	auipc	a0,0x4
    80003834:	c8850513          	addi	a0,a0,-888 # 800074b8 <etext+0x4b8>
    80003838:	fedfc0ef          	jal	80000824 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    8000383c:	24c1                	addiw	s1,s1,16
    8000383e:	04c92783          	lw	a5,76(s2)
    80003842:	02f4fe63          	bgeu	s1,a5,8000387e <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003846:	874e                	mv	a4,s3
    80003848:	86a6                	mv	a3,s1
    8000384a:	8652                	mv	a2,s4
    8000384c:	4581                	li	a1,0
    8000384e:	854a                	mv	a0,s2
    80003850:	d93ff0ef          	jal	800035e2 <readi>
    80003854:	fd351ee3          	bne	a0,s3,80003830 <dirlookup+0x46>
    if(de.inum == 0)
    80003858:	fa045783          	lhu	a5,-96(s0)
    8000385c:	d3e5                	beqz	a5,8000383c <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    8000385e:	85da                	mv	a1,s6
    80003860:	8556                	mv	a0,s5
    80003862:	f73ff0ef          	jal	800037d4 <namecmp>
    80003866:	f979                	bnez	a0,8000383c <dirlookup+0x52>
      if(poff)
    80003868:	000b8463          	beqz	s7,80003870 <dirlookup+0x86>
        *poff = off;
    8000386c:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80003870:	fa045583          	lhu	a1,-96(s0)
    80003874:	00092503          	lw	a0,0(s2)
    80003878:	f66ff0ef          	jal	80002fde <iget>
    8000387c:	a011                	j	80003880 <dirlookup+0x96>
  return 0;
    8000387e:	4501                	li	a0,0
}
    80003880:	60e6                	ld	ra,88(sp)
    80003882:	6446                	ld	s0,80(sp)
    80003884:	64a6                	ld	s1,72(sp)
    80003886:	6906                	ld	s2,64(sp)
    80003888:	79e2                	ld	s3,56(sp)
    8000388a:	7a42                	ld	s4,48(sp)
    8000388c:	7aa2                	ld	s5,40(sp)
    8000388e:	7b02                	ld	s6,32(sp)
    80003890:	6be2                	ld	s7,24(sp)
    80003892:	6125                	addi	sp,sp,96
    80003894:	8082                	ret

0000000080003896 <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003896:	711d                	addi	sp,sp,-96
    80003898:	ec86                	sd	ra,88(sp)
    8000389a:	e8a2                	sd	s0,80(sp)
    8000389c:	e4a6                	sd	s1,72(sp)
    8000389e:	e0ca                	sd	s2,64(sp)
    800038a0:	fc4e                	sd	s3,56(sp)
    800038a2:	f852                	sd	s4,48(sp)
    800038a4:	f456                	sd	s5,40(sp)
    800038a6:	f05a                	sd	s6,32(sp)
    800038a8:	ec5e                	sd	s7,24(sp)
    800038aa:	e862                	sd	s8,16(sp)
    800038ac:	e466                	sd	s9,8(sp)
    800038ae:	e06a                	sd	s10,0(sp)
    800038b0:	1080                	addi	s0,sp,96
    800038b2:	84aa                	mv	s1,a0
    800038b4:	8b2e                	mv	s6,a1
    800038b6:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    800038b8:	00054703          	lbu	a4,0(a0)
    800038bc:	02f00793          	li	a5,47
    800038c0:	00f70f63          	beq	a4,a5,800038de <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    800038c4:	892fe0ef          	jal	80001956 <myproc>
    800038c8:	15053503          	ld	a0,336(a0)
    800038cc:	94fff0ef          	jal	8000321a <idup>
    800038d0:	8a2a                	mv	s4,a0
  while(*path == '/')
    800038d2:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    800038d6:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    800038d8:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    800038da:	4b85                	li	s7,1
    800038dc:	a879                	j	8000397a <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    800038de:	4585                	li	a1,1
    800038e0:	852e                	mv	a0,a1
    800038e2:	efcff0ef          	jal	80002fde <iget>
    800038e6:	8a2a                	mv	s4,a0
    800038e8:	b7ed                	j	800038d2 <namex+0x3c>
      iunlockput(ip);
    800038ea:	8552                	mv	a0,s4
    800038ec:	b71ff0ef          	jal	8000345c <iunlockput>
      return 0;
    800038f0:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    800038f2:	8552                	mv	a0,s4
    800038f4:	60e6                	ld	ra,88(sp)
    800038f6:	6446                	ld	s0,80(sp)
    800038f8:	64a6                	ld	s1,72(sp)
    800038fa:	6906                	ld	s2,64(sp)
    800038fc:	79e2                	ld	s3,56(sp)
    800038fe:	7a42                	ld	s4,48(sp)
    80003900:	7aa2                	ld	s5,40(sp)
    80003902:	7b02                	ld	s6,32(sp)
    80003904:	6be2                	ld	s7,24(sp)
    80003906:	6c42                	ld	s8,16(sp)
    80003908:	6ca2                	ld	s9,8(sp)
    8000390a:	6d02                	ld	s10,0(sp)
    8000390c:	6125                	addi	sp,sp,96
    8000390e:	8082                	ret
      iunlock(ip);
    80003910:	8552                	mv	a0,s4
    80003912:	9edff0ef          	jal	800032fe <iunlock>
      return ip;
    80003916:	bff1                	j	800038f2 <namex+0x5c>
      iunlockput(ip);
    80003918:	8552                	mv	a0,s4
    8000391a:	b43ff0ef          	jal	8000345c <iunlockput>
      return 0;
    8000391e:	8a4a                	mv	s4,s2
    80003920:	bfc9                	j	800038f2 <namex+0x5c>
  len = path - s;
    80003922:	40990633          	sub	a2,s2,s1
    80003926:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    8000392a:	09ac5463          	bge	s8,s10,800039b2 <namex+0x11c>
    memmove(name, s, DIRSIZ);
    8000392e:	8666                	mv	a2,s9
    80003930:	85a6                	mv	a1,s1
    80003932:	8556                	mv	a0,s5
    80003934:	c4cfd0ef          	jal	80000d80 <memmove>
    80003938:	84ca                	mv	s1,s2
  while(*path == '/')
    8000393a:	0004c783          	lbu	a5,0(s1)
    8000393e:	01379763          	bne	a5,s3,8000394c <namex+0xb6>
    path++;
    80003942:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003944:	0004c783          	lbu	a5,0(s1)
    80003948:	ff378de3          	beq	a5,s3,80003942 <namex+0xac>
    ilock(ip);
    8000394c:	8552                	mv	a0,s4
    8000394e:	903ff0ef          	jal	80003250 <ilock>
    if(ip->type != T_DIR){
    80003952:	044a1783          	lh	a5,68(s4)
    80003956:	f9779ae3          	bne	a5,s7,800038ea <namex+0x54>
    if(nameiparent && *path == '\0'){
    8000395a:	000b0563          	beqz	s6,80003964 <namex+0xce>
    8000395e:	0004c783          	lbu	a5,0(s1)
    80003962:	d7dd                	beqz	a5,80003910 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003964:	4601                	li	a2,0
    80003966:	85d6                	mv	a1,s5
    80003968:	8552                	mv	a0,s4
    8000396a:	e81ff0ef          	jal	800037ea <dirlookup>
    8000396e:	892a                	mv	s2,a0
    80003970:	d545                	beqz	a0,80003918 <namex+0x82>
    iunlockput(ip);
    80003972:	8552                	mv	a0,s4
    80003974:	ae9ff0ef          	jal	8000345c <iunlockput>
    ip = next;
    80003978:	8a4a                	mv	s4,s2
  while(*path == '/')
    8000397a:	0004c783          	lbu	a5,0(s1)
    8000397e:	01379763          	bne	a5,s3,8000398c <namex+0xf6>
    path++;
    80003982:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003984:	0004c783          	lbu	a5,0(s1)
    80003988:	ff378de3          	beq	a5,s3,80003982 <namex+0xec>
  if(*path == 0)
    8000398c:	cf8d                	beqz	a5,800039c6 <namex+0x130>
  while(*path != '/' && *path != 0)
    8000398e:	0004c783          	lbu	a5,0(s1)
    80003992:	fd178713          	addi	a4,a5,-47
    80003996:	cb19                	beqz	a4,800039ac <namex+0x116>
    80003998:	cb91                	beqz	a5,800039ac <namex+0x116>
    8000399a:	8926                	mv	s2,s1
    path++;
    8000399c:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    8000399e:	00094783          	lbu	a5,0(s2)
    800039a2:	fd178713          	addi	a4,a5,-47
    800039a6:	df35                	beqz	a4,80003922 <namex+0x8c>
    800039a8:	fbf5                	bnez	a5,8000399c <namex+0x106>
    800039aa:	bfa5                	j	80003922 <namex+0x8c>
    800039ac:	8926                	mv	s2,s1
  len = path - s;
    800039ae:	4d01                	li	s10,0
    800039b0:	4601                	li	a2,0
    memmove(name, s, len);
    800039b2:	2601                	sext.w	a2,a2
    800039b4:	85a6                	mv	a1,s1
    800039b6:	8556                	mv	a0,s5
    800039b8:	bc8fd0ef          	jal	80000d80 <memmove>
    name[len] = 0;
    800039bc:	9d56                	add	s10,s10,s5
    800039be:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7ffde488>
    800039c2:	84ca                	mv	s1,s2
    800039c4:	bf9d                	j	8000393a <namex+0xa4>
  if(nameiparent){
    800039c6:	f20b06e3          	beqz	s6,800038f2 <namex+0x5c>
    iput(ip);
    800039ca:	8552                	mv	a0,s4
    800039cc:	a07ff0ef          	jal	800033d2 <iput>
    return 0;
    800039d0:	4a01                	li	s4,0
    800039d2:	b705                	j	800038f2 <namex+0x5c>

00000000800039d4 <dirlink>:
{
    800039d4:	715d                	addi	sp,sp,-80
    800039d6:	e486                	sd	ra,72(sp)
    800039d8:	e0a2                	sd	s0,64(sp)
    800039da:	f84a                	sd	s2,48(sp)
    800039dc:	ec56                	sd	s5,24(sp)
    800039de:	e85a                	sd	s6,16(sp)
    800039e0:	0880                	addi	s0,sp,80
    800039e2:	892a                	mv	s2,a0
    800039e4:	8aae                	mv	s5,a1
    800039e6:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    800039e8:	4601                	li	a2,0
    800039ea:	e01ff0ef          	jal	800037ea <dirlookup>
    800039ee:	ed1d                	bnez	a0,80003a2c <dirlink+0x58>
    800039f0:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    800039f2:	04c92483          	lw	s1,76(s2)
    800039f6:	c4b9                	beqz	s1,80003a44 <dirlink+0x70>
    800039f8:	f44e                	sd	s3,40(sp)
    800039fa:	f052                	sd	s4,32(sp)
    800039fc:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800039fe:	fb040a13          	addi	s4,s0,-80
    80003a02:	49c1                	li	s3,16
    80003a04:	874e                	mv	a4,s3
    80003a06:	86a6                	mv	a3,s1
    80003a08:	8652                	mv	a2,s4
    80003a0a:	4581                	li	a1,0
    80003a0c:	854a                	mv	a0,s2
    80003a0e:	bd5ff0ef          	jal	800035e2 <readi>
    80003a12:	03351163          	bne	a0,s3,80003a34 <dirlink+0x60>
    if(de.inum == 0)
    80003a16:	fb045783          	lhu	a5,-80(s0)
    80003a1a:	c39d                	beqz	a5,80003a40 <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003a1c:	24c1                	addiw	s1,s1,16
    80003a1e:	04c92783          	lw	a5,76(s2)
    80003a22:	fef4e1e3          	bltu	s1,a5,80003a04 <dirlink+0x30>
    80003a26:	79a2                	ld	s3,40(sp)
    80003a28:	7a02                	ld	s4,32(sp)
    80003a2a:	a829                	j	80003a44 <dirlink+0x70>
    iput(ip);
    80003a2c:	9a7ff0ef          	jal	800033d2 <iput>
    return -1;
    80003a30:	557d                	li	a0,-1
    80003a32:	a83d                	j	80003a70 <dirlink+0x9c>
      panic("dirlink read");
    80003a34:	00004517          	auipc	a0,0x4
    80003a38:	a9450513          	addi	a0,a0,-1388 # 800074c8 <etext+0x4c8>
    80003a3c:	de9fc0ef          	jal	80000824 <panic>
    80003a40:	79a2                	ld	s3,40(sp)
    80003a42:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003a44:	4639                	li	a2,14
    80003a46:	85d6                	mv	a1,s5
    80003a48:	fb240513          	addi	a0,s0,-78
    80003a4c:	be2fd0ef          	jal	80000e2e <strncpy>
  de.inum = inum;
    80003a50:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003a54:	4741                	li	a4,16
    80003a56:	86a6                	mv	a3,s1
    80003a58:	fb040613          	addi	a2,s0,-80
    80003a5c:	4581                	li	a1,0
    80003a5e:	854a                	mv	a0,s2
    80003a60:	c75ff0ef          	jal	800036d4 <writei>
    80003a64:	1541                	addi	a0,a0,-16
    80003a66:	00a03533          	snez	a0,a0
    80003a6a:	40a0053b          	negw	a0,a0
    80003a6e:	74e2                	ld	s1,56(sp)
}
    80003a70:	60a6                	ld	ra,72(sp)
    80003a72:	6406                	ld	s0,64(sp)
    80003a74:	7942                	ld	s2,48(sp)
    80003a76:	6ae2                	ld	s5,24(sp)
    80003a78:	6b42                	ld	s6,16(sp)
    80003a7a:	6161                	addi	sp,sp,80
    80003a7c:	8082                	ret

0000000080003a7e <namei>:

struct inode*
namei(char *path)
{
    80003a7e:	1101                	addi	sp,sp,-32
    80003a80:	ec06                	sd	ra,24(sp)
    80003a82:	e822                	sd	s0,16(sp)
    80003a84:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003a86:	fe040613          	addi	a2,s0,-32
    80003a8a:	4581                	li	a1,0
    80003a8c:	e0bff0ef          	jal	80003896 <namex>
}
    80003a90:	60e2                	ld	ra,24(sp)
    80003a92:	6442                	ld	s0,16(sp)
    80003a94:	6105                	addi	sp,sp,32
    80003a96:	8082                	ret

0000000080003a98 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003a98:	1141                	addi	sp,sp,-16
    80003a9a:	e406                	sd	ra,8(sp)
    80003a9c:	e022                	sd	s0,0(sp)
    80003a9e:	0800                	addi	s0,sp,16
    80003aa0:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003aa2:	4585                	li	a1,1
    80003aa4:	df3ff0ef          	jal	80003896 <namex>
}
    80003aa8:	60a2                	ld	ra,8(sp)
    80003aaa:	6402                	ld	s0,0(sp)
    80003aac:	0141                	addi	sp,sp,16
    80003aae:	8082                	ret

0000000080003ab0 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003ab0:	1101                	addi	sp,sp,-32
    80003ab2:	ec06                	sd	ra,24(sp)
    80003ab4:	e822                	sd	s0,16(sp)
    80003ab6:	e426                	sd	s1,8(sp)
    80003ab8:	e04a                	sd	s2,0(sp)
    80003aba:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003abc:	0001c917          	auipc	s2,0x1c
    80003ac0:	e7c90913          	addi	s2,s2,-388 # 8001f938 <log>
    80003ac4:	01892583          	lw	a1,24(s2)
    80003ac8:	02492503          	lw	a0,36(s2)
    80003acc:	8ecff0ef          	jal	80002bb8 <bread>
    80003ad0:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003ad2:	02892603          	lw	a2,40(s2)
    80003ad6:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003ad8:	00c05f63          	blez	a2,80003af6 <write_head+0x46>
    80003adc:	0001c717          	auipc	a4,0x1c
    80003ae0:	e8870713          	addi	a4,a4,-376 # 8001f964 <log+0x2c>
    80003ae4:	87aa                	mv	a5,a0
    80003ae6:	060a                	slli	a2,a2,0x2
    80003ae8:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80003aea:	4314                	lw	a3,0(a4)
    80003aec:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80003aee:	0711                	addi	a4,a4,4
    80003af0:	0791                	addi	a5,a5,4
    80003af2:	fec79ce3          	bne	a5,a2,80003aea <write_head+0x3a>
  }
  bwrite(buf);
    80003af6:	8526                	mv	a0,s1
    80003af8:	996ff0ef          	jal	80002c8e <bwrite>
  brelse(buf);
    80003afc:	8526                	mv	a0,s1
    80003afe:	9c2ff0ef          	jal	80002cc0 <brelse>
}
    80003b02:	60e2                	ld	ra,24(sp)
    80003b04:	6442                	ld	s0,16(sp)
    80003b06:	64a2                	ld	s1,8(sp)
    80003b08:	6902                	ld	s2,0(sp)
    80003b0a:	6105                	addi	sp,sp,32
    80003b0c:	8082                	ret

0000000080003b0e <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80003b0e:	0001c797          	auipc	a5,0x1c
    80003b12:	e527a783          	lw	a5,-430(a5) # 8001f960 <log+0x28>
    80003b16:	0cf05163          	blez	a5,80003bd8 <install_trans+0xca>
{
    80003b1a:	715d                	addi	sp,sp,-80
    80003b1c:	e486                	sd	ra,72(sp)
    80003b1e:	e0a2                	sd	s0,64(sp)
    80003b20:	fc26                	sd	s1,56(sp)
    80003b22:	f84a                	sd	s2,48(sp)
    80003b24:	f44e                	sd	s3,40(sp)
    80003b26:	f052                	sd	s4,32(sp)
    80003b28:	ec56                	sd	s5,24(sp)
    80003b2a:	e85a                	sd	s6,16(sp)
    80003b2c:	e45e                	sd	s7,8(sp)
    80003b2e:	e062                	sd	s8,0(sp)
    80003b30:	0880                	addi	s0,sp,80
    80003b32:	8b2a                	mv	s6,a0
    80003b34:	0001ca97          	auipc	s5,0x1c
    80003b38:	e30a8a93          	addi	s5,s5,-464 # 8001f964 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003b3c:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003b3e:	00004c17          	auipc	s8,0x4
    80003b42:	99ac0c13          	addi	s8,s8,-1638 # 800074d8 <etext+0x4d8>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003b46:	0001ca17          	auipc	s4,0x1c
    80003b4a:	df2a0a13          	addi	s4,s4,-526 # 8001f938 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003b4e:	40000b93          	li	s7,1024
    80003b52:	a025                	j	80003b7a <install_trans+0x6c>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80003b54:	000aa603          	lw	a2,0(s5)
    80003b58:	85ce                	mv	a1,s3
    80003b5a:	8562                	mv	a0,s8
    80003b5c:	99ffc0ef          	jal	800004fa <printf>
    80003b60:	a839                	j	80003b7e <install_trans+0x70>
    brelse(lbuf);
    80003b62:	854a                	mv	a0,s2
    80003b64:	95cff0ef          	jal	80002cc0 <brelse>
    brelse(dbuf);
    80003b68:	8526                	mv	a0,s1
    80003b6a:	956ff0ef          	jal	80002cc0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003b6e:	2985                	addiw	s3,s3,1
    80003b70:	0a91                	addi	s5,s5,4
    80003b72:	028a2783          	lw	a5,40(s4)
    80003b76:	04f9d563          	bge	s3,a5,80003bc0 <install_trans+0xb2>
    if(recovering) {
    80003b7a:	fc0b1de3          	bnez	s6,80003b54 <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80003b7e:	018a2583          	lw	a1,24(s4)
    80003b82:	013585bb          	addw	a1,a1,s3
    80003b86:	2585                	addiw	a1,a1,1
    80003b88:	024a2503          	lw	a0,36(s4)
    80003b8c:	82cff0ef          	jal	80002bb8 <bread>
    80003b90:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    80003b92:	000aa583          	lw	a1,0(s5)
    80003b96:	024a2503          	lw	a0,36(s4)
    80003b9a:	81eff0ef          	jal	80002bb8 <bread>
    80003b9e:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80003ba0:	865e                	mv	a2,s7
    80003ba2:	05890593          	addi	a1,s2,88
    80003ba6:	05850513          	addi	a0,a0,88
    80003baa:	9d6fd0ef          	jal	80000d80 <memmove>
    bwrite(dbuf);  // write dst to disk
    80003bae:	8526                	mv	a0,s1
    80003bb0:	8deff0ef          	jal	80002c8e <bwrite>
    if(recovering == 0)
    80003bb4:	fa0b17e3          	bnez	s6,80003b62 <install_trans+0x54>
      bunpin(dbuf);
    80003bb8:	8526                	mv	a0,s1
    80003bba:	9beff0ef          	jal	80002d78 <bunpin>
    80003bbe:	b755                	j	80003b62 <install_trans+0x54>
}
    80003bc0:	60a6                	ld	ra,72(sp)
    80003bc2:	6406                	ld	s0,64(sp)
    80003bc4:	74e2                	ld	s1,56(sp)
    80003bc6:	7942                	ld	s2,48(sp)
    80003bc8:	79a2                	ld	s3,40(sp)
    80003bca:	7a02                	ld	s4,32(sp)
    80003bcc:	6ae2                	ld	s5,24(sp)
    80003bce:	6b42                	ld	s6,16(sp)
    80003bd0:	6ba2                	ld	s7,8(sp)
    80003bd2:	6c02                	ld	s8,0(sp)
    80003bd4:	6161                	addi	sp,sp,80
    80003bd6:	8082                	ret
    80003bd8:	8082                	ret

0000000080003bda <initlog>:
{
    80003bda:	7179                	addi	sp,sp,-48
    80003bdc:	f406                	sd	ra,40(sp)
    80003bde:	f022                	sd	s0,32(sp)
    80003be0:	ec26                	sd	s1,24(sp)
    80003be2:	e84a                	sd	s2,16(sp)
    80003be4:	e44e                	sd	s3,8(sp)
    80003be6:	1800                	addi	s0,sp,48
    80003be8:	84aa                	mv	s1,a0
    80003bea:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80003bec:	0001c917          	auipc	s2,0x1c
    80003bf0:	d4c90913          	addi	s2,s2,-692 # 8001f938 <log>
    80003bf4:	00004597          	auipc	a1,0x4
    80003bf8:	90458593          	addi	a1,a1,-1788 # 800074f8 <etext+0x4f8>
    80003bfc:	854a                	mv	a0,s2
    80003bfe:	fc9fc0ef          	jal	80000bc6 <initlock>
  log.start = sb->logstart;
    80003c02:	0149a583          	lw	a1,20(s3)
    80003c06:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80003c0a:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80003c0e:	8526                	mv	a0,s1
    80003c10:	fa9fe0ef          	jal	80002bb8 <bread>
  log.lh.n = lh->n;
    80003c14:	4d30                	lw	a2,88(a0)
    80003c16:	02c92423          	sw	a2,40(s2)
  for (i = 0; i < log.lh.n; i++) {
    80003c1a:	00c05f63          	blez	a2,80003c38 <initlog+0x5e>
    80003c1e:	87aa                	mv	a5,a0
    80003c20:	0001c717          	auipc	a4,0x1c
    80003c24:	d4470713          	addi	a4,a4,-700 # 8001f964 <log+0x2c>
    80003c28:	060a                	slli	a2,a2,0x2
    80003c2a:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80003c2c:	4ff4                	lw	a3,92(a5)
    80003c2e:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80003c30:	0791                	addi	a5,a5,4
    80003c32:	0711                	addi	a4,a4,4
    80003c34:	fec79ce3          	bne	a5,a2,80003c2c <initlog+0x52>
  brelse(buf);
    80003c38:	888ff0ef          	jal	80002cc0 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80003c3c:	4505                	li	a0,1
    80003c3e:	ed1ff0ef          	jal	80003b0e <install_trans>
  log.lh.n = 0;
    80003c42:	0001c797          	auipc	a5,0x1c
    80003c46:	d007af23          	sw	zero,-738(a5) # 8001f960 <log+0x28>
  write_head(); // clear the log
    80003c4a:	e67ff0ef          	jal	80003ab0 <write_head>
}
    80003c4e:	70a2                	ld	ra,40(sp)
    80003c50:	7402                	ld	s0,32(sp)
    80003c52:	64e2                	ld	s1,24(sp)
    80003c54:	6942                	ld	s2,16(sp)
    80003c56:	69a2                	ld	s3,8(sp)
    80003c58:	6145                	addi	sp,sp,48
    80003c5a:	8082                	ret

0000000080003c5c <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80003c5c:	1101                	addi	sp,sp,-32
    80003c5e:	ec06                	sd	ra,24(sp)
    80003c60:	e822                	sd	s0,16(sp)
    80003c62:	e426                	sd	s1,8(sp)
    80003c64:	e04a                	sd	s2,0(sp)
    80003c66:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80003c68:	0001c517          	auipc	a0,0x1c
    80003c6c:	cd050513          	addi	a0,a0,-816 # 8001f938 <log>
    80003c70:	fe1fc0ef          	jal	80000c50 <acquire>
  while(1){
    if(log.committing){
    80003c74:	0001c497          	auipc	s1,0x1c
    80003c78:	cc448493          	addi	s1,s1,-828 # 8001f938 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003c7c:	4979                	li	s2,30
    80003c7e:	a029                	j	80003c88 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80003c80:	85a6                	mv	a1,s1
    80003c82:	8526                	mv	a0,s1
    80003c84:	ae2fe0ef          	jal	80001f66 <sleep>
    if(log.committing){
    80003c88:	509c                	lw	a5,32(s1)
    80003c8a:	fbfd                	bnez	a5,80003c80 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80003c8c:	4cd8                	lw	a4,28(s1)
    80003c8e:	2705                	addiw	a4,a4,1
    80003c90:	0027179b          	slliw	a5,a4,0x2
    80003c94:	9fb9                	addw	a5,a5,a4
    80003c96:	0017979b          	slliw	a5,a5,0x1
    80003c9a:	5494                	lw	a3,40(s1)
    80003c9c:	9fb5                	addw	a5,a5,a3
    80003c9e:	00f95763          	bge	s2,a5,80003cac <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    80003ca2:	85a6                	mv	a1,s1
    80003ca4:	8526                	mv	a0,s1
    80003ca6:	ac0fe0ef          	jal	80001f66 <sleep>
    80003caa:	bff9                	j	80003c88 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    80003cac:	0001c797          	auipc	a5,0x1c
    80003cb0:	cae7a423          	sw	a4,-856(a5) # 8001f954 <log+0x1c>
      release(&log.lock);
    80003cb4:	0001c517          	auipc	a0,0x1c
    80003cb8:	c8450513          	addi	a0,a0,-892 # 8001f938 <log>
    80003cbc:	828fd0ef          	jal	80000ce4 <release>
      break;
    }
  }
}
    80003cc0:	60e2                	ld	ra,24(sp)
    80003cc2:	6442                	ld	s0,16(sp)
    80003cc4:	64a2                	ld	s1,8(sp)
    80003cc6:	6902                	ld	s2,0(sp)
    80003cc8:	6105                	addi	sp,sp,32
    80003cca:	8082                	ret

0000000080003ccc <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    80003ccc:	7139                	addi	sp,sp,-64
    80003cce:	fc06                	sd	ra,56(sp)
    80003cd0:	f822                	sd	s0,48(sp)
    80003cd2:	f426                	sd	s1,40(sp)
    80003cd4:	f04a                	sd	s2,32(sp)
    80003cd6:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    80003cd8:	0001c497          	auipc	s1,0x1c
    80003cdc:	c6048493          	addi	s1,s1,-928 # 8001f938 <log>
    80003ce0:	8526                	mv	a0,s1
    80003ce2:	f6ffc0ef          	jal	80000c50 <acquire>
  log.outstanding -= 1;
    80003ce6:	4cdc                	lw	a5,28(s1)
    80003ce8:	37fd                	addiw	a5,a5,-1
    80003cea:	893e                	mv	s2,a5
    80003cec:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80003cee:	509c                	lw	a5,32(s1)
    80003cf0:	e7b1                	bnez	a5,80003d3c <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    80003cf2:	04091e63          	bnez	s2,80003d4e <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    80003cf6:	0001c497          	auipc	s1,0x1c
    80003cfa:	c4248493          	addi	s1,s1,-958 # 8001f938 <log>
    80003cfe:	4785                	li	a5,1
    80003d00:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    80003d02:	8526                	mv	a0,s1
    80003d04:	fe1fc0ef          	jal	80000ce4 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80003d08:	549c                	lw	a5,40(s1)
    80003d0a:	06f04463          	bgtz	a5,80003d72 <end_op+0xa6>
    acquire(&log.lock);
    80003d0e:	0001c517          	auipc	a0,0x1c
    80003d12:	c2a50513          	addi	a0,a0,-982 # 8001f938 <log>
    80003d16:	f3bfc0ef          	jal	80000c50 <acquire>
    log.committing = 0;
    80003d1a:	0001c797          	auipc	a5,0x1c
    80003d1e:	c207af23          	sw	zero,-962(a5) # 8001f958 <log+0x20>
    wakeup(&log);
    80003d22:	0001c517          	auipc	a0,0x1c
    80003d26:	c1650513          	addi	a0,a0,-1002 # 8001f938 <log>
    80003d2a:	a88fe0ef          	jal	80001fb2 <wakeup>
    release(&log.lock);
    80003d2e:	0001c517          	auipc	a0,0x1c
    80003d32:	c0a50513          	addi	a0,a0,-1014 # 8001f938 <log>
    80003d36:	faffc0ef          	jal	80000ce4 <release>
}
    80003d3a:	a035                	j	80003d66 <end_op+0x9a>
    80003d3c:	ec4e                	sd	s3,24(sp)
    80003d3e:	e852                	sd	s4,16(sp)
    80003d40:	e456                	sd	s5,8(sp)
    panic("log.committing");
    80003d42:	00003517          	auipc	a0,0x3
    80003d46:	7be50513          	addi	a0,a0,1982 # 80007500 <etext+0x500>
    80003d4a:	adbfc0ef          	jal	80000824 <panic>
    wakeup(&log);
    80003d4e:	0001c517          	auipc	a0,0x1c
    80003d52:	bea50513          	addi	a0,a0,-1046 # 8001f938 <log>
    80003d56:	a5cfe0ef          	jal	80001fb2 <wakeup>
  release(&log.lock);
    80003d5a:	0001c517          	auipc	a0,0x1c
    80003d5e:	bde50513          	addi	a0,a0,-1058 # 8001f938 <log>
    80003d62:	f83fc0ef          	jal	80000ce4 <release>
}
    80003d66:	70e2                	ld	ra,56(sp)
    80003d68:	7442                	ld	s0,48(sp)
    80003d6a:	74a2                	ld	s1,40(sp)
    80003d6c:	7902                	ld	s2,32(sp)
    80003d6e:	6121                	addi	sp,sp,64
    80003d70:	8082                	ret
    80003d72:	ec4e                	sd	s3,24(sp)
    80003d74:	e852                	sd	s4,16(sp)
    80003d76:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80003d78:	0001ca97          	auipc	s5,0x1c
    80003d7c:	beca8a93          	addi	s5,s5,-1044 # 8001f964 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80003d80:	0001ca17          	auipc	s4,0x1c
    80003d84:	bb8a0a13          	addi	s4,s4,-1096 # 8001f938 <log>
    80003d88:	018a2583          	lw	a1,24(s4)
    80003d8c:	012585bb          	addw	a1,a1,s2
    80003d90:	2585                	addiw	a1,a1,1
    80003d92:	024a2503          	lw	a0,36(s4)
    80003d96:	e23fe0ef          	jal	80002bb8 <bread>
    80003d9a:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    80003d9c:	000aa583          	lw	a1,0(s5)
    80003da0:	024a2503          	lw	a0,36(s4)
    80003da4:	e15fe0ef          	jal	80002bb8 <bread>
    80003da8:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    80003daa:	40000613          	li	a2,1024
    80003dae:	05850593          	addi	a1,a0,88
    80003db2:	05848513          	addi	a0,s1,88
    80003db6:	fcbfc0ef          	jal	80000d80 <memmove>
    bwrite(to);  // write the log
    80003dba:	8526                	mv	a0,s1
    80003dbc:	ed3fe0ef          	jal	80002c8e <bwrite>
    brelse(from);
    80003dc0:	854e                	mv	a0,s3
    80003dc2:	efffe0ef          	jal	80002cc0 <brelse>
    brelse(to);
    80003dc6:	8526                	mv	a0,s1
    80003dc8:	ef9fe0ef          	jal	80002cc0 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80003dcc:	2905                	addiw	s2,s2,1
    80003dce:	0a91                	addi	s5,s5,4
    80003dd0:	028a2783          	lw	a5,40(s4)
    80003dd4:	faf94ae3          	blt	s2,a5,80003d88 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    80003dd8:	cd9ff0ef          	jal	80003ab0 <write_head>
    install_trans(0); // Now install writes to home locations
    80003ddc:	4501                	li	a0,0
    80003dde:	d31ff0ef          	jal	80003b0e <install_trans>
    log.lh.n = 0;
    80003de2:	0001c797          	auipc	a5,0x1c
    80003de6:	b607af23          	sw	zero,-1154(a5) # 8001f960 <log+0x28>
    write_head();    // Erase the transaction from the log
    80003dea:	cc7ff0ef          	jal	80003ab0 <write_head>
    80003dee:	69e2                	ld	s3,24(sp)
    80003df0:	6a42                	ld	s4,16(sp)
    80003df2:	6aa2                	ld	s5,8(sp)
    80003df4:	bf29                	j	80003d0e <end_op+0x42>

0000000080003df6 <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    80003df6:	1101                	addi	sp,sp,-32
    80003df8:	ec06                	sd	ra,24(sp)
    80003dfa:	e822                	sd	s0,16(sp)
    80003dfc:	e426                	sd	s1,8(sp)
    80003dfe:	1000                	addi	s0,sp,32
    80003e00:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    80003e02:	0001c517          	auipc	a0,0x1c
    80003e06:	b3650513          	addi	a0,a0,-1226 # 8001f938 <log>
    80003e0a:	e47fc0ef          	jal	80000c50 <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80003e0e:	0001c617          	auipc	a2,0x1c
    80003e12:	b5262603          	lw	a2,-1198(a2) # 8001f960 <log+0x28>
    80003e16:	47f5                	li	a5,29
    80003e18:	04c7cd63          	blt	a5,a2,80003e72 <log_write+0x7c>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80003e1c:	0001c797          	auipc	a5,0x1c
    80003e20:	b387a783          	lw	a5,-1224(a5) # 8001f954 <log+0x1c>
    80003e24:	04f05d63          	blez	a5,80003e7e <log_write+0x88>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80003e28:	4781                	li	a5,0
    80003e2a:	06c05063          	blez	a2,80003e8a <log_write+0x94>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003e2e:	44cc                	lw	a1,12(s1)
    80003e30:	0001c717          	auipc	a4,0x1c
    80003e34:	b3470713          	addi	a4,a4,-1228 # 8001f964 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    80003e38:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80003e3a:	4314                	lw	a3,0(a4)
    80003e3c:	04b68763          	beq	a3,a1,80003e8a <log_write+0x94>
  for (i = 0; i < log.lh.n; i++) {
    80003e40:	2785                	addiw	a5,a5,1
    80003e42:	0711                	addi	a4,a4,4
    80003e44:	fef61be3          	bne	a2,a5,80003e3a <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80003e48:	060a                	slli	a2,a2,0x2
    80003e4a:	02060613          	addi	a2,a2,32
    80003e4e:	0001c797          	auipc	a5,0x1c
    80003e52:	aea78793          	addi	a5,a5,-1302 # 8001f938 <log>
    80003e56:	97b2                	add	a5,a5,a2
    80003e58:	44d8                	lw	a4,12(s1)
    80003e5a:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80003e5c:	8526                	mv	a0,s1
    80003e5e:	ee7fe0ef          	jal	80002d44 <bpin>
    log.lh.n++;
    80003e62:	0001c717          	auipc	a4,0x1c
    80003e66:	ad670713          	addi	a4,a4,-1322 # 8001f938 <log>
    80003e6a:	571c                	lw	a5,40(a4)
    80003e6c:	2785                	addiw	a5,a5,1
    80003e6e:	d71c                	sw	a5,40(a4)
    80003e70:	a815                	j	80003ea4 <log_write+0xae>
    panic("too big a transaction");
    80003e72:	00003517          	auipc	a0,0x3
    80003e76:	69e50513          	addi	a0,a0,1694 # 80007510 <etext+0x510>
    80003e7a:	9abfc0ef          	jal	80000824 <panic>
    panic("log_write outside of trans");
    80003e7e:	00003517          	auipc	a0,0x3
    80003e82:	6aa50513          	addi	a0,a0,1706 # 80007528 <etext+0x528>
    80003e86:	99ffc0ef          	jal	80000824 <panic>
  log.lh.block[i] = b->blockno;
    80003e8a:	00279693          	slli	a3,a5,0x2
    80003e8e:	02068693          	addi	a3,a3,32
    80003e92:	0001c717          	auipc	a4,0x1c
    80003e96:	aa670713          	addi	a4,a4,-1370 # 8001f938 <log>
    80003e9a:	9736                	add	a4,a4,a3
    80003e9c:	44d4                	lw	a3,12(s1)
    80003e9e:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    80003ea0:	faf60ee3          	beq	a2,a5,80003e5c <log_write+0x66>
  }
  release(&log.lock);
    80003ea4:	0001c517          	auipc	a0,0x1c
    80003ea8:	a9450513          	addi	a0,a0,-1388 # 8001f938 <log>
    80003eac:	e39fc0ef          	jal	80000ce4 <release>
}
    80003eb0:	60e2                	ld	ra,24(sp)
    80003eb2:	6442                	ld	s0,16(sp)
    80003eb4:	64a2                	ld	s1,8(sp)
    80003eb6:	6105                	addi	sp,sp,32
    80003eb8:	8082                	ret

0000000080003eba <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    80003eba:	1101                	addi	sp,sp,-32
    80003ebc:	ec06                	sd	ra,24(sp)
    80003ebe:	e822                	sd	s0,16(sp)
    80003ec0:	e426                	sd	s1,8(sp)
    80003ec2:	e04a                	sd	s2,0(sp)
    80003ec4:	1000                	addi	s0,sp,32
    80003ec6:	84aa                	mv	s1,a0
    80003ec8:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    80003eca:	00003597          	auipc	a1,0x3
    80003ece:	67e58593          	addi	a1,a1,1662 # 80007548 <etext+0x548>
    80003ed2:	0521                	addi	a0,a0,8
    80003ed4:	cf3fc0ef          	jal	80000bc6 <initlock>
  lk->name = name;
    80003ed8:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    80003edc:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003ee0:	0204a423          	sw	zero,40(s1)
}
    80003ee4:	60e2                	ld	ra,24(sp)
    80003ee6:	6442                	ld	s0,16(sp)
    80003ee8:	64a2                	ld	s1,8(sp)
    80003eea:	6902                	ld	s2,0(sp)
    80003eec:	6105                	addi	sp,sp,32
    80003eee:	8082                	ret

0000000080003ef0 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80003ef0:	1101                	addi	sp,sp,-32
    80003ef2:	ec06                	sd	ra,24(sp)
    80003ef4:	e822                	sd	s0,16(sp)
    80003ef6:	e426                	sd	s1,8(sp)
    80003ef8:	e04a                	sd	s2,0(sp)
    80003efa:	1000                	addi	s0,sp,32
    80003efc:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003efe:	00850913          	addi	s2,a0,8
    80003f02:	854a                	mv	a0,s2
    80003f04:	d4dfc0ef          	jal	80000c50 <acquire>
  while (lk->locked) {
    80003f08:	409c                	lw	a5,0(s1)
    80003f0a:	c799                	beqz	a5,80003f18 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80003f0c:	85ca                	mv	a1,s2
    80003f0e:	8526                	mv	a0,s1
    80003f10:	856fe0ef          	jal	80001f66 <sleep>
  while (lk->locked) {
    80003f14:	409c                	lw	a5,0(s1)
    80003f16:	fbfd                	bnez	a5,80003f0c <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80003f18:	4785                	li	a5,1
    80003f1a:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80003f1c:	a3bfd0ef          	jal	80001956 <myproc>
    80003f20:	591c                	lw	a5,48(a0)
    80003f22:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    80003f24:	854a                	mv	a0,s2
    80003f26:	dbffc0ef          	jal	80000ce4 <release>
}
    80003f2a:	60e2                	ld	ra,24(sp)
    80003f2c:	6442                	ld	s0,16(sp)
    80003f2e:	64a2                	ld	s1,8(sp)
    80003f30:	6902                	ld	s2,0(sp)
    80003f32:	6105                	addi	sp,sp,32
    80003f34:	8082                	ret

0000000080003f36 <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    80003f36:	1101                	addi	sp,sp,-32
    80003f38:	ec06                	sd	ra,24(sp)
    80003f3a:	e822                	sd	s0,16(sp)
    80003f3c:	e426                	sd	s1,8(sp)
    80003f3e:	e04a                	sd	s2,0(sp)
    80003f40:	1000                	addi	s0,sp,32
    80003f42:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80003f44:	00850913          	addi	s2,a0,8
    80003f48:	854a                	mv	a0,s2
    80003f4a:	d07fc0ef          	jal	80000c50 <acquire>
  lk->locked = 0;
    80003f4e:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    80003f52:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    80003f56:	8526                	mv	a0,s1
    80003f58:	85afe0ef          	jal	80001fb2 <wakeup>
  release(&lk->lk);
    80003f5c:	854a                	mv	a0,s2
    80003f5e:	d87fc0ef          	jal	80000ce4 <release>
}
    80003f62:	60e2                	ld	ra,24(sp)
    80003f64:	6442                	ld	s0,16(sp)
    80003f66:	64a2                	ld	s1,8(sp)
    80003f68:	6902                	ld	s2,0(sp)
    80003f6a:	6105                	addi	sp,sp,32
    80003f6c:	8082                	ret

0000000080003f6e <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80003f6e:	7179                	addi	sp,sp,-48
    80003f70:	f406                	sd	ra,40(sp)
    80003f72:	f022                	sd	s0,32(sp)
    80003f74:	ec26                	sd	s1,24(sp)
    80003f76:	e84a                	sd	s2,16(sp)
    80003f78:	1800                	addi	s0,sp,48
    80003f7a:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80003f7c:	00850913          	addi	s2,a0,8
    80003f80:	854a                	mv	a0,s2
    80003f82:	ccffc0ef          	jal	80000c50 <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    80003f86:	409c                	lw	a5,0(s1)
    80003f88:	ef81                	bnez	a5,80003fa0 <holdingsleep+0x32>
    80003f8a:	4481                	li	s1,0
  release(&lk->lk);
    80003f8c:	854a                	mv	a0,s2
    80003f8e:	d57fc0ef          	jal	80000ce4 <release>
  return r;
}
    80003f92:	8526                	mv	a0,s1
    80003f94:	70a2                	ld	ra,40(sp)
    80003f96:	7402                	ld	s0,32(sp)
    80003f98:	64e2                	ld	s1,24(sp)
    80003f9a:	6942                	ld	s2,16(sp)
    80003f9c:	6145                	addi	sp,sp,48
    80003f9e:	8082                	ret
    80003fa0:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    80003fa2:	0284a983          	lw	s3,40(s1)
    80003fa6:	9b1fd0ef          	jal	80001956 <myproc>
    80003faa:	5904                	lw	s1,48(a0)
    80003fac:	413484b3          	sub	s1,s1,s3
    80003fb0:	0014b493          	seqz	s1,s1
    80003fb4:	69a2                	ld	s3,8(sp)
    80003fb6:	bfd9                	j	80003f8c <holdingsleep+0x1e>

0000000080003fb8 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    80003fb8:	1141                	addi	sp,sp,-16
    80003fba:	e406                	sd	ra,8(sp)
    80003fbc:	e022                	sd	s0,0(sp)
    80003fbe:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    80003fc0:	00003597          	auipc	a1,0x3
    80003fc4:	59858593          	addi	a1,a1,1432 # 80007558 <etext+0x558>
    80003fc8:	0001c517          	auipc	a0,0x1c
    80003fcc:	ab850513          	addi	a0,a0,-1352 # 8001fa80 <ftable>
    80003fd0:	bf7fc0ef          	jal	80000bc6 <initlock>
}
    80003fd4:	60a2                	ld	ra,8(sp)
    80003fd6:	6402                	ld	s0,0(sp)
    80003fd8:	0141                	addi	sp,sp,16
    80003fda:	8082                	ret

0000000080003fdc <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    80003fdc:	1101                	addi	sp,sp,-32
    80003fde:	ec06                	sd	ra,24(sp)
    80003fe0:	e822                	sd	s0,16(sp)
    80003fe2:	e426                	sd	s1,8(sp)
    80003fe4:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    80003fe6:	0001c517          	auipc	a0,0x1c
    80003fea:	a9a50513          	addi	a0,a0,-1382 # 8001fa80 <ftable>
    80003fee:	c63fc0ef          	jal	80000c50 <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80003ff2:	0001c497          	auipc	s1,0x1c
    80003ff6:	aa648493          	addi	s1,s1,-1370 # 8001fa98 <ftable+0x18>
    80003ffa:	0001d717          	auipc	a4,0x1d
    80003ffe:	a3e70713          	addi	a4,a4,-1474 # 80020a38 <disk>
    if(f->ref == 0){
    80004002:	40dc                	lw	a5,4(s1)
    80004004:	cf89                	beqz	a5,8000401e <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    80004006:	02848493          	addi	s1,s1,40
    8000400a:	fee49ce3          	bne	s1,a4,80004002 <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    8000400e:	0001c517          	auipc	a0,0x1c
    80004012:	a7250513          	addi	a0,a0,-1422 # 8001fa80 <ftable>
    80004016:	ccffc0ef          	jal	80000ce4 <release>
  return 0;
    8000401a:	4481                	li	s1,0
    8000401c:	a809                	j	8000402e <filealloc+0x52>
      f->ref = 1;
    8000401e:	4785                	li	a5,1
    80004020:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    80004022:	0001c517          	auipc	a0,0x1c
    80004026:	a5e50513          	addi	a0,a0,-1442 # 8001fa80 <ftable>
    8000402a:	cbbfc0ef          	jal	80000ce4 <release>
}
    8000402e:	8526                	mv	a0,s1
    80004030:	60e2                	ld	ra,24(sp)
    80004032:	6442                	ld	s0,16(sp)
    80004034:	64a2                	ld	s1,8(sp)
    80004036:	6105                	addi	sp,sp,32
    80004038:	8082                	ret

000000008000403a <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    8000403a:	1101                	addi	sp,sp,-32
    8000403c:	ec06                	sd	ra,24(sp)
    8000403e:	e822                	sd	s0,16(sp)
    80004040:	e426                	sd	s1,8(sp)
    80004042:	1000                	addi	s0,sp,32
    80004044:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    80004046:	0001c517          	auipc	a0,0x1c
    8000404a:	a3a50513          	addi	a0,a0,-1478 # 8001fa80 <ftable>
    8000404e:	c03fc0ef          	jal	80000c50 <acquire>
  if(f->ref < 1)
    80004052:	40dc                	lw	a5,4(s1)
    80004054:	02f05063          	blez	a5,80004074 <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004058:	2785                	addiw	a5,a5,1
    8000405a:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    8000405c:	0001c517          	auipc	a0,0x1c
    80004060:	a2450513          	addi	a0,a0,-1500 # 8001fa80 <ftable>
    80004064:	c81fc0ef          	jal	80000ce4 <release>
  return f;
}
    80004068:	8526                	mv	a0,s1
    8000406a:	60e2                	ld	ra,24(sp)
    8000406c:	6442                	ld	s0,16(sp)
    8000406e:	64a2                	ld	s1,8(sp)
    80004070:	6105                	addi	sp,sp,32
    80004072:	8082                	ret
    panic("filedup");
    80004074:	00003517          	auipc	a0,0x3
    80004078:	4ec50513          	addi	a0,a0,1260 # 80007560 <etext+0x560>
    8000407c:	fa8fc0ef          	jal	80000824 <panic>

0000000080004080 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004080:	7139                	addi	sp,sp,-64
    80004082:	fc06                	sd	ra,56(sp)
    80004084:	f822                	sd	s0,48(sp)
    80004086:	f426                	sd	s1,40(sp)
    80004088:	0080                	addi	s0,sp,64
    8000408a:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    8000408c:	0001c517          	auipc	a0,0x1c
    80004090:	9f450513          	addi	a0,a0,-1548 # 8001fa80 <ftable>
    80004094:	bbdfc0ef          	jal	80000c50 <acquire>
  if(f->ref < 1)
    80004098:	40dc                	lw	a5,4(s1)
    8000409a:	04f05a63          	blez	a5,800040ee <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    8000409e:	37fd                	addiw	a5,a5,-1
    800040a0:	c0dc                	sw	a5,4(s1)
    800040a2:	06f04063          	bgtz	a5,80004102 <fileclose+0x82>
    800040a6:	f04a                	sd	s2,32(sp)
    800040a8:	ec4e                	sd	s3,24(sp)
    800040aa:	e852                	sd	s4,16(sp)
    800040ac:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800040ae:	0004a903          	lw	s2,0(s1)
    800040b2:	0094c783          	lbu	a5,9(s1)
    800040b6:	89be                	mv	s3,a5
    800040b8:	689c                	ld	a5,16(s1)
    800040ba:	8a3e                	mv	s4,a5
    800040bc:	6c9c                	ld	a5,24(s1)
    800040be:	8abe                	mv	s5,a5
  f->ref = 0;
    800040c0:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800040c4:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800040c8:	0001c517          	auipc	a0,0x1c
    800040cc:	9b850513          	addi	a0,a0,-1608 # 8001fa80 <ftable>
    800040d0:	c15fc0ef          	jal	80000ce4 <release>

  if(ff.type == FD_PIPE){
    800040d4:	4785                	li	a5,1
    800040d6:	04f90163          	beq	s2,a5,80004118 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    800040da:	ffe9079b          	addiw	a5,s2,-2
    800040de:	4705                	li	a4,1
    800040e0:	04f77563          	bgeu	a4,a5,8000412a <fileclose+0xaa>
    800040e4:	7902                	ld	s2,32(sp)
    800040e6:	69e2                	ld	s3,24(sp)
    800040e8:	6a42                	ld	s4,16(sp)
    800040ea:	6aa2                	ld	s5,8(sp)
    800040ec:	a00d                	j	8000410e <fileclose+0x8e>
    800040ee:	f04a                	sd	s2,32(sp)
    800040f0:	ec4e                	sd	s3,24(sp)
    800040f2:	e852                	sd	s4,16(sp)
    800040f4:	e456                	sd	s5,8(sp)
    panic("fileclose");
    800040f6:	00003517          	auipc	a0,0x3
    800040fa:	47250513          	addi	a0,a0,1138 # 80007568 <etext+0x568>
    800040fe:	f26fc0ef          	jal	80000824 <panic>
    release(&ftable.lock);
    80004102:	0001c517          	auipc	a0,0x1c
    80004106:	97e50513          	addi	a0,a0,-1666 # 8001fa80 <ftable>
    8000410a:	bdbfc0ef          	jal	80000ce4 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    8000410e:	70e2                	ld	ra,56(sp)
    80004110:	7442                	ld	s0,48(sp)
    80004112:	74a2                	ld	s1,40(sp)
    80004114:	6121                	addi	sp,sp,64
    80004116:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004118:	85ce                	mv	a1,s3
    8000411a:	8552                	mv	a0,s4
    8000411c:	348000ef          	jal	80004464 <pipeclose>
    80004120:	7902                	ld	s2,32(sp)
    80004122:	69e2                	ld	s3,24(sp)
    80004124:	6a42                	ld	s4,16(sp)
    80004126:	6aa2                	ld	s5,8(sp)
    80004128:	b7dd                	j	8000410e <fileclose+0x8e>
    begin_op();
    8000412a:	b33ff0ef          	jal	80003c5c <begin_op>
    iput(ff.ip);
    8000412e:	8556                	mv	a0,s5
    80004130:	aa2ff0ef          	jal	800033d2 <iput>
    end_op();
    80004134:	b99ff0ef          	jal	80003ccc <end_op>
    80004138:	7902                	ld	s2,32(sp)
    8000413a:	69e2                	ld	s3,24(sp)
    8000413c:	6a42                	ld	s4,16(sp)
    8000413e:	6aa2                	ld	s5,8(sp)
    80004140:	b7f9                	j	8000410e <fileclose+0x8e>

0000000080004142 <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    80004142:	715d                	addi	sp,sp,-80
    80004144:	e486                	sd	ra,72(sp)
    80004146:	e0a2                	sd	s0,64(sp)
    80004148:	fc26                	sd	s1,56(sp)
    8000414a:	f052                	sd	s4,32(sp)
    8000414c:	0880                	addi	s0,sp,80
    8000414e:	84aa                	mv	s1,a0
    80004150:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    80004152:	805fd0ef          	jal	80001956 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    80004156:	409c                	lw	a5,0(s1)
    80004158:	37f9                	addiw	a5,a5,-2
    8000415a:	4705                	li	a4,1
    8000415c:	04f76263          	bltu	a4,a5,800041a0 <filestat+0x5e>
    80004160:	f84a                	sd	s2,48(sp)
    80004162:	f44e                	sd	s3,40(sp)
    80004164:	89aa                	mv	s3,a0
    ilock(f->ip);
    80004166:	6c88                	ld	a0,24(s1)
    80004168:	8e8ff0ef          	jal	80003250 <ilock>
    stati(f->ip, &st);
    8000416c:	fb840913          	addi	s2,s0,-72
    80004170:	85ca                	mv	a1,s2
    80004172:	6c88                	ld	a0,24(s1)
    80004174:	c40ff0ef          	jal	800035b4 <stati>
    iunlock(f->ip);
    80004178:	6c88                	ld	a0,24(s1)
    8000417a:	984ff0ef          	jal	800032fe <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    8000417e:	46e1                	li	a3,24
    80004180:	864a                	mv	a2,s2
    80004182:	85d2                	mv	a1,s4
    80004184:	0509b503          	ld	a0,80(s3)
    80004188:	cf4fd0ef          	jal	8000167c <copyout>
    8000418c:	41f5551b          	sraiw	a0,a0,0x1f
    80004190:	7942                	ld	s2,48(sp)
    80004192:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    80004194:	60a6                	ld	ra,72(sp)
    80004196:	6406                	ld	s0,64(sp)
    80004198:	74e2                	ld	s1,56(sp)
    8000419a:	7a02                	ld	s4,32(sp)
    8000419c:	6161                	addi	sp,sp,80
    8000419e:	8082                	ret
  return -1;
    800041a0:	557d                	li	a0,-1
    800041a2:	bfcd                	j	80004194 <filestat+0x52>

00000000800041a4 <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800041a4:	7179                	addi	sp,sp,-48
    800041a6:	f406                	sd	ra,40(sp)
    800041a8:	f022                	sd	s0,32(sp)
    800041aa:	e84a                	sd	s2,16(sp)
    800041ac:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    800041ae:	00854783          	lbu	a5,8(a0)
    800041b2:	cfd1                	beqz	a5,8000424e <fileread+0xaa>
    800041b4:	ec26                	sd	s1,24(sp)
    800041b6:	e44e                	sd	s3,8(sp)
    800041b8:	84aa                	mv	s1,a0
    800041ba:	892e                	mv	s2,a1
    800041bc:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    800041be:	411c                	lw	a5,0(a0)
    800041c0:	4705                	li	a4,1
    800041c2:	04e78363          	beq	a5,a4,80004208 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800041c6:	470d                	li	a4,3
    800041c8:	04e78763          	beq	a5,a4,80004216 <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800041cc:	4709                	li	a4,2
    800041ce:	06e79a63          	bne	a5,a4,80004242 <fileread+0x9e>
    ilock(f->ip);
    800041d2:	6d08                	ld	a0,24(a0)
    800041d4:	87cff0ef          	jal	80003250 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800041d8:	874e                	mv	a4,s3
    800041da:	5094                	lw	a3,32(s1)
    800041dc:	864a                	mv	a2,s2
    800041de:	4585                	li	a1,1
    800041e0:	6c88                	ld	a0,24(s1)
    800041e2:	c00ff0ef          	jal	800035e2 <readi>
    800041e6:	892a                	mv	s2,a0
    800041e8:	00a05563          	blez	a0,800041f2 <fileread+0x4e>
      f->off += r;
    800041ec:	509c                	lw	a5,32(s1)
    800041ee:	9fa9                	addw	a5,a5,a0
    800041f0:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    800041f2:	6c88                	ld	a0,24(s1)
    800041f4:	90aff0ef          	jal	800032fe <iunlock>
    800041f8:	64e2                	ld	s1,24(sp)
    800041fa:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    800041fc:	854a                	mv	a0,s2
    800041fe:	70a2                	ld	ra,40(sp)
    80004200:	7402                	ld	s0,32(sp)
    80004202:	6942                	ld	s2,16(sp)
    80004204:	6145                	addi	sp,sp,48
    80004206:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004208:	6908                	ld	a0,16(a0)
    8000420a:	3b0000ef          	jal	800045ba <piperead>
    8000420e:	892a                	mv	s2,a0
    80004210:	64e2                	ld	s1,24(sp)
    80004212:	69a2                	ld	s3,8(sp)
    80004214:	b7e5                	j	800041fc <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    80004216:	02451783          	lh	a5,36(a0)
    8000421a:	03079693          	slli	a3,a5,0x30
    8000421e:	92c1                	srli	a3,a3,0x30
    80004220:	4725                	li	a4,9
    80004222:	02d76963          	bltu	a4,a3,80004254 <fileread+0xb0>
    80004226:	0792                	slli	a5,a5,0x4
    80004228:	0001b717          	auipc	a4,0x1b
    8000422c:	7b870713          	addi	a4,a4,1976 # 8001f9e0 <devsw>
    80004230:	97ba                	add	a5,a5,a4
    80004232:	639c                	ld	a5,0(a5)
    80004234:	c78d                	beqz	a5,8000425e <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    80004236:	4505                	li	a0,1
    80004238:	9782                	jalr	a5
    8000423a:	892a                	mv	s2,a0
    8000423c:	64e2                	ld	s1,24(sp)
    8000423e:	69a2                	ld	s3,8(sp)
    80004240:	bf75                	j	800041fc <fileread+0x58>
    panic("fileread");
    80004242:	00003517          	auipc	a0,0x3
    80004246:	33650513          	addi	a0,a0,822 # 80007578 <etext+0x578>
    8000424a:	ddafc0ef          	jal	80000824 <panic>
    return -1;
    8000424e:	57fd                	li	a5,-1
    80004250:	893e                	mv	s2,a5
    80004252:	b76d                	j	800041fc <fileread+0x58>
      return -1;
    80004254:	57fd                	li	a5,-1
    80004256:	893e                	mv	s2,a5
    80004258:	64e2                	ld	s1,24(sp)
    8000425a:	69a2                	ld	s3,8(sp)
    8000425c:	b745                	j	800041fc <fileread+0x58>
    8000425e:	57fd                	li	a5,-1
    80004260:	893e                	mv	s2,a5
    80004262:	64e2                	ld	s1,24(sp)
    80004264:	69a2                	ld	s3,8(sp)
    80004266:	bf59                	j	800041fc <fileread+0x58>

0000000080004268 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80004268:	00954783          	lbu	a5,9(a0)
    8000426c:	10078f63          	beqz	a5,8000438a <filewrite+0x122>
{
    80004270:	711d                	addi	sp,sp,-96
    80004272:	ec86                	sd	ra,88(sp)
    80004274:	e8a2                	sd	s0,80(sp)
    80004276:	e0ca                	sd	s2,64(sp)
    80004278:	f456                	sd	s5,40(sp)
    8000427a:	f05a                	sd	s6,32(sp)
    8000427c:	1080                	addi	s0,sp,96
    8000427e:	892a                	mv	s2,a0
    80004280:	8b2e                	mv	s6,a1
    80004282:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    80004284:	411c                	lw	a5,0(a0)
    80004286:	4705                	li	a4,1
    80004288:	02e78a63          	beq	a5,a4,800042bc <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    8000428c:	470d                	li	a4,3
    8000428e:	02e78b63          	beq	a5,a4,800042c4 <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    80004292:	4709                	li	a4,2
    80004294:	0ce79f63          	bne	a5,a4,80004372 <filewrite+0x10a>
    80004298:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    8000429a:	0ac05a63          	blez	a2,8000434e <filewrite+0xe6>
    8000429e:	e4a6                	sd	s1,72(sp)
    800042a0:	fc4e                	sd	s3,56(sp)
    800042a2:	ec5e                	sd	s7,24(sp)
    800042a4:	e862                	sd	s8,16(sp)
    800042a6:	e466                	sd	s9,8(sp)
    int i = 0;
    800042a8:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    800042aa:	6b85                	lui	s7,0x1
    800042ac:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800042b0:	6785                	lui	a5,0x1
    800042b2:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    800042b6:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800042b8:	4c05                	li	s8,1
    800042ba:	a8ad                	j	80004334 <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800042bc:	6908                	ld	a0,16(a0)
    800042be:	204000ef          	jal	800044c2 <pipewrite>
    800042c2:	a04d                	j	80004364 <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800042c4:	02451783          	lh	a5,36(a0)
    800042c8:	03079693          	slli	a3,a5,0x30
    800042cc:	92c1                	srli	a3,a3,0x30
    800042ce:	4725                	li	a4,9
    800042d0:	0ad76f63          	bltu	a4,a3,8000438e <filewrite+0x126>
    800042d4:	0792                	slli	a5,a5,0x4
    800042d6:	0001b717          	auipc	a4,0x1b
    800042da:	70a70713          	addi	a4,a4,1802 # 8001f9e0 <devsw>
    800042de:	97ba                	add	a5,a5,a4
    800042e0:	679c                	ld	a5,8(a5)
    800042e2:	cbc5                	beqz	a5,80004392 <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    800042e4:	4505                	li	a0,1
    800042e6:	9782                	jalr	a5
    800042e8:	a8b5                	j	80004364 <filewrite+0xfc>
      if(n1 > max)
    800042ea:	2981                	sext.w	s3,s3
      begin_op();
    800042ec:	971ff0ef          	jal	80003c5c <begin_op>
      ilock(f->ip);
    800042f0:	01893503          	ld	a0,24(s2)
    800042f4:	f5dfe0ef          	jal	80003250 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800042f8:	874e                	mv	a4,s3
    800042fa:	02092683          	lw	a3,32(s2)
    800042fe:	016a0633          	add	a2,s4,s6
    80004302:	85e2                	mv	a1,s8
    80004304:	01893503          	ld	a0,24(s2)
    80004308:	bccff0ef          	jal	800036d4 <writei>
    8000430c:	84aa                	mv	s1,a0
    8000430e:	00a05763          	blez	a0,8000431c <filewrite+0xb4>
        f->off += r;
    80004312:	02092783          	lw	a5,32(s2)
    80004316:	9fa9                	addw	a5,a5,a0
    80004318:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    8000431c:	01893503          	ld	a0,24(s2)
    80004320:	fdffe0ef          	jal	800032fe <iunlock>
      end_op();
    80004324:	9a9ff0ef          	jal	80003ccc <end_op>

      if(r != n1){
    80004328:	02999563          	bne	s3,s1,80004352 <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    8000432c:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    80004330:	015a5963          	bge	s4,s5,80004342 <filewrite+0xda>
      int n1 = n - i;
    80004334:	414a87bb          	subw	a5,s5,s4
    80004338:	89be                	mv	s3,a5
      if(n1 > max)
    8000433a:	fafbd8e3          	bge	s7,a5,800042ea <filewrite+0x82>
    8000433e:	89e6                	mv	s3,s9
    80004340:	b76d                	j	800042ea <filewrite+0x82>
    80004342:	64a6                	ld	s1,72(sp)
    80004344:	79e2                	ld	s3,56(sp)
    80004346:	6be2                	ld	s7,24(sp)
    80004348:	6c42                	ld	s8,16(sp)
    8000434a:	6ca2                	ld	s9,8(sp)
    8000434c:	a801                	j	8000435c <filewrite+0xf4>
    int i = 0;
    8000434e:	4a01                	li	s4,0
    80004350:	a031                	j	8000435c <filewrite+0xf4>
    80004352:	64a6                	ld	s1,72(sp)
    80004354:	79e2                	ld	s3,56(sp)
    80004356:	6be2                	ld	s7,24(sp)
    80004358:	6c42                	ld	s8,16(sp)
    8000435a:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    8000435c:	034a9d63          	bne	s5,s4,80004396 <filewrite+0x12e>
    80004360:	8556                	mv	a0,s5
    80004362:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    80004364:	60e6                	ld	ra,88(sp)
    80004366:	6446                	ld	s0,80(sp)
    80004368:	6906                	ld	s2,64(sp)
    8000436a:	7aa2                	ld	s5,40(sp)
    8000436c:	7b02                	ld	s6,32(sp)
    8000436e:	6125                	addi	sp,sp,96
    80004370:	8082                	ret
    80004372:	e4a6                	sd	s1,72(sp)
    80004374:	fc4e                	sd	s3,56(sp)
    80004376:	f852                	sd	s4,48(sp)
    80004378:	ec5e                	sd	s7,24(sp)
    8000437a:	e862                	sd	s8,16(sp)
    8000437c:	e466                	sd	s9,8(sp)
    panic("filewrite");
    8000437e:	00003517          	auipc	a0,0x3
    80004382:	20a50513          	addi	a0,a0,522 # 80007588 <etext+0x588>
    80004386:	c9efc0ef          	jal	80000824 <panic>
    return -1;
    8000438a:	557d                	li	a0,-1
}
    8000438c:	8082                	ret
      return -1;
    8000438e:	557d                	li	a0,-1
    80004390:	bfd1                	j	80004364 <filewrite+0xfc>
    80004392:	557d                	li	a0,-1
    80004394:	bfc1                	j	80004364 <filewrite+0xfc>
    ret = (i == n ? n : -1);
    80004396:	557d                	li	a0,-1
    80004398:	7a42                	ld	s4,48(sp)
    8000439a:	b7e9                	j	80004364 <filewrite+0xfc>

000000008000439c <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    8000439c:	7179                	addi	sp,sp,-48
    8000439e:	f406                	sd	ra,40(sp)
    800043a0:	f022                	sd	s0,32(sp)
    800043a2:	ec26                	sd	s1,24(sp)
    800043a4:	e052                	sd	s4,0(sp)
    800043a6:	1800                	addi	s0,sp,48
    800043a8:	84aa                	mv	s1,a0
    800043aa:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800043ac:	0005b023          	sd	zero,0(a1)
    800043b0:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800043b4:	c29ff0ef          	jal	80003fdc <filealloc>
    800043b8:	e088                	sd	a0,0(s1)
    800043ba:	c549                	beqz	a0,80004444 <pipealloc+0xa8>
    800043bc:	c21ff0ef          	jal	80003fdc <filealloc>
    800043c0:	00aa3023          	sd	a0,0(s4)
    800043c4:	cd25                	beqz	a0,8000443c <pipealloc+0xa0>
    800043c6:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800043c8:	f7cfc0ef          	jal	80000b44 <kalloc>
    800043cc:	892a                	mv	s2,a0
    800043ce:	c12d                	beqz	a0,80004430 <pipealloc+0x94>
    800043d0:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800043d2:	4985                	li	s3,1
    800043d4:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800043d8:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800043dc:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800043e0:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800043e4:	00003597          	auipc	a1,0x3
    800043e8:	1b458593          	addi	a1,a1,436 # 80007598 <etext+0x598>
    800043ec:	fdafc0ef          	jal	80000bc6 <initlock>
  (*f0)->type = FD_PIPE;
    800043f0:	609c                	ld	a5,0(s1)
    800043f2:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    800043f6:	609c                	ld	a5,0(s1)
    800043f8:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    800043fc:	609c                	ld	a5,0(s1)
    800043fe:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    80004402:	609c                	ld	a5,0(s1)
    80004404:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004408:	000a3783          	ld	a5,0(s4)
    8000440c:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004410:	000a3783          	ld	a5,0(s4)
    80004414:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004418:	000a3783          	ld	a5,0(s4)
    8000441c:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004420:	000a3783          	ld	a5,0(s4)
    80004424:	0127b823          	sd	s2,16(a5)
  return 0;
    80004428:	4501                	li	a0,0
    8000442a:	6942                	ld	s2,16(sp)
    8000442c:	69a2                	ld	s3,8(sp)
    8000442e:	a01d                	j	80004454 <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004430:	6088                	ld	a0,0(s1)
    80004432:	c119                	beqz	a0,80004438 <pipealloc+0x9c>
    80004434:	6942                	ld	s2,16(sp)
    80004436:	a029                	j	80004440 <pipealloc+0xa4>
    80004438:	6942                	ld	s2,16(sp)
    8000443a:	a029                	j	80004444 <pipealloc+0xa8>
    8000443c:	6088                	ld	a0,0(s1)
    8000443e:	c10d                	beqz	a0,80004460 <pipealloc+0xc4>
    fileclose(*f0);
    80004440:	c41ff0ef          	jal	80004080 <fileclose>
  if(*f1)
    80004444:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004448:	557d                	li	a0,-1
  if(*f1)
    8000444a:	c789                	beqz	a5,80004454 <pipealloc+0xb8>
    fileclose(*f1);
    8000444c:	853e                	mv	a0,a5
    8000444e:	c33ff0ef          	jal	80004080 <fileclose>
  return -1;
    80004452:	557d                	li	a0,-1
}
    80004454:	70a2                	ld	ra,40(sp)
    80004456:	7402                	ld	s0,32(sp)
    80004458:	64e2                	ld	s1,24(sp)
    8000445a:	6a02                	ld	s4,0(sp)
    8000445c:	6145                	addi	sp,sp,48
    8000445e:	8082                	ret
  return -1;
    80004460:	557d                	li	a0,-1
    80004462:	bfcd                	j	80004454 <pipealloc+0xb8>

0000000080004464 <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    80004464:	1101                	addi	sp,sp,-32
    80004466:	ec06                	sd	ra,24(sp)
    80004468:	e822                	sd	s0,16(sp)
    8000446a:	e426                	sd	s1,8(sp)
    8000446c:	e04a                	sd	s2,0(sp)
    8000446e:	1000                	addi	s0,sp,32
    80004470:	84aa                	mv	s1,a0
    80004472:	892e                	mv	s2,a1
  acquire(&pi->lock);
    80004474:	fdcfc0ef          	jal	80000c50 <acquire>
  if(writable){
    80004478:	02090763          	beqz	s2,800044a6 <pipeclose+0x42>
    pi->writeopen = 0;
    8000447c:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004480:	21848513          	addi	a0,s1,536
    80004484:	b2ffd0ef          	jal	80001fb2 <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    80004488:	2204a783          	lw	a5,544(s1)
    8000448c:	e781                	bnez	a5,80004494 <pipeclose+0x30>
    8000448e:	2244a783          	lw	a5,548(s1)
    80004492:	c38d                	beqz	a5,800044b4 <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    80004494:	8526                	mv	a0,s1
    80004496:	84ffc0ef          	jal	80000ce4 <release>
}
    8000449a:	60e2                	ld	ra,24(sp)
    8000449c:	6442                	ld	s0,16(sp)
    8000449e:	64a2                	ld	s1,8(sp)
    800044a0:	6902                	ld	s2,0(sp)
    800044a2:	6105                	addi	sp,sp,32
    800044a4:	8082                	ret
    pi->readopen = 0;
    800044a6:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800044aa:	21c48513          	addi	a0,s1,540
    800044ae:	b05fd0ef          	jal	80001fb2 <wakeup>
    800044b2:	bfd9                	j	80004488 <pipeclose+0x24>
    release(&pi->lock);
    800044b4:	8526                	mv	a0,s1
    800044b6:	82ffc0ef          	jal	80000ce4 <release>
    kfree((char*)pi);
    800044ba:	8526                	mv	a0,s1
    800044bc:	da0fc0ef          	jal	80000a5c <kfree>
    800044c0:	bfe9                	j	8000449a <pipeclose+0x36>

00000000800044c2 <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800044c2:	7159                	addi	sp,sp,-112
    800044c4:	f486                	sd	ra,104(sp)
    800044c6:	f0a2                	sd	s0,96(sp)
    800044c8:	eca6                	sd	s1,88(sp)
    800044ca:	e8ca                	sd	s2,80(sp)
    800044cc:	e4ce                	sd	s3,72(sp)
    800044ce:	e0d2                	sd	s4,64(sp)
    800044d0:	fc56                	sd	s5,56(sp)
    800044d2:	1880                	addi	s0,sp,112
    800044d4:	84aa                	mv	s1,a0
    800044d6:	8aae                	mv	s5,a1
    800044d8:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800044da:	c7cfd0ef          	jal	80001956 <myproc>
    800044de:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800044e0:	8526                	mv	a0,s1
    800044e2:	f6efc0ef          	jal	80000c50 <acquire>
  while(i < n){
    800044e6:	0d405263          	blez	s4,800045aa <pipewrite+0xe8>
    800044ea:	f85a                	sd	s6,48(sp)
    800044ec:	f45e                	sd	s7,40(sp)
    800044ee:	f062                	sd	s8,32(sp)
    800044f0:	ec66                	sd	s9,24(sp)
    800044f2:	e86a                	sd	s10,16(sp)
  int i = 0;
    800044f4:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    800044f6:	f9f40c13          	addi	s8,s0,-97
    800044fa:	4b85                	li	s7,1
    800044fc:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    800044fe:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004502:	21c48c93          	addi	s9,s1,540
    80004506:	a82d                	j	80004540 <pipewrite+0x7e>
      release(&pi->lock);
    80004508:	8526                	mv	a0,s1
    8000450a:	fdafc0ef          	jal	80000ce4 <release>
      return -1;
    8000450e:	597d                	li	s2,-1
    80004510:	7b42                	ld	s6,48(sp)
    80004512:	7ba2                	ld	s7,40(sp)
    80004514:	7c02                	ld	s8,32(sp)
    80004516:	6ce2                	ld	s9,24(sp)
    80004518:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    8000451a:	854a                	mv	a0,s2
    8000451c:	70a6                	ld	ra,104(sp)
    8000451e:	7406                	ld	s0,96(sp)
    80004520:	64e6                	ld	s1,88(sp)
    80004522:	6946                	ld	s2,80(sp)
    80004524:	69a6                	ld	s3,72(sp)
    80004526:	6a06                	ld	s4,64(sp)
    80004528:	7ae2                	ld	s5,56(sp)
    8000452a:	6165                	addi	sp,sp,112
    8000452c:	8082                	ret
      wakeup(&pi->nread);
    8000452e:	856a                	mv	a0,s10
    80004530:	a83fd0ef          	jal	80001fb2 <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004534:	85a6                	mv	a1,s1
    80004536:	8566                	mv	a0,s9
    80004538:	a2ffd0ef          	jal	80001f66 <sleep>
  while(i < n){
    8000453c:	05495a63          	bge	s2,s4,80004590 <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    80004540:	2204a783          	lw	a5,544(s1)
    80004544:	d3f1                	beqz	a5,80004508 <pipewrite+0x46>
    80004546:	854e                	mv	a0,s3
    80004548:	c5bfd0ef          	jal	800021a2 <killed>
    8000454c:	fd55                	bnez	a0,80004508 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    8000454e:	2184a783          	lw	a5,536(s1)
    80004552:	21c4a703          	lw	a4,540(s1)
    80004556:	2007879b          	addiw	a5,a5,512
    8000455a:	fcf70ae3          	beq	a4,a5,8000452e <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    8000455e:	86de                	mv	a3,s7
    80004560:	01590633          	add	a2,s2,s5
    80004564:	85e2                	mv	a1,s8
    80004566:	0509b503          	ld	a0,80(s3)
    8000456a:	9d0fd0ef          	jal	8000173a <copyin>
    8000456e:	05650063          	beq	a0,s6,800045ae <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004572:	21c4a783          	lw	a5,540(s1)
    80004576:	0017871b          	addiw	a4,a5,1
    8000457a:	20e4ae23          	sw	a4,540(s1)
    8000457e:	1ff7f793          	andi	a5,a5,511
    80004582:	97a6                	add	a5,a5,s1
    80004584:	f9f44703          	lbu	a4,-97(s0)
    80004588:	00e78c23          	sb	a4,24(a5)
      i++;
    8000458c:	2905                	addiw	s2,s2,1
    8000458e:	b77d                	j	8000453c <pipewrite+0x7a>
    80004590:	7b42                	ld	s6,48(sp)
    80004592:	7ba2                	ld	s7,40(sp)
    80004594:	7c02                	ld	s8,32(sp)
    80004596:	6ce2                	ld	s9,24(sp)
    80004598:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    8000459a:	21848513          	addi	a0,s1,536
    8000459e:	a15fd0ef          	jal	80001fb2 <wakeup>
  release(&pi->lock);
    800045a2:	8526                	mv	a0,s1
    800045a4:	f40fc0ef          	jal	80000ce4 <release>
  return i;
    800045a8:	bf8d                	j	8000451a <pipewrite+0x58>
  int i = 0;
    800045aa:	4901                	li	s2,0
    800045ac:	b7fd                	j	8000459a <pipewrite+0xd8>
    800045ae:	7b42                	ld	s6,48(sp)
    800045b0:	7ba2                	ld	s7,40(sp)
    800045b2:	7c02                	ld	s8,32(sp)
    800045b4:	6ce2                	ld	s9,24(sp)
    800045b6:	6d42                	ld	s10,16(sp)
    800045b8:	b7cd                	j	8000459a <pipewrite+0xd8>

00000000800045ba <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    800045ba:	711d                	addi	sp,sp,-96
    800045bc:	ec86                	sd	ra,88(sp)
    800045be:	e8a2                	sd	s0,80(sp)
    800045c0:	e4a6                	sd	s1,72(sp)
    800045c2:	e0ca                	sd	s2,64(sp)
    800045c4:	fc4e                	sd	s3,56(sp)
    800045c6:	f852                	sd	s4,48(sp)
    800045c8:	f456                	sd	s5,40(sp)
    800045ca:	1080                	addi	s0,sp,96
    800045cc:	84aa                	mv	s1,a0
    800045ce:	892e                	mv	s2,a1
    800045d0:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    800045d2:	b84fd0ef          	jal	80001956 <myproc>
    800045d6:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    800045d8:	8526                	mv	a0,s1
    800045da:	e76fc0ef          	jal	80000c50 <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800045de:	2184a703          	lw	a4,536(s1)
    800045e2:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800045e6:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    800045ea:	02f71763          	bne	a4,a5,80004618 <piperead+0x5e>
    800045ee:	2244a783          	lw	a5,548(s1)
    800045f2:	cf85                	beqz	a5,8000462a <piperead+0x70>
    if(killed(pr)){
    800045f4:	8552                	mv	a0,s4
    800045f6:	badfd0ef          	jal	800021a2 <killed>
    800045fa:	e11d                	bnez	a0,80004620 <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    800045fc:	85a6                	mv	a1,s1
    800045fe:	854e                	mv	a0,s3
    80004600:	967fd0ef          	jal	80001f66 <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004604:	2184a703          	lw	a4,536(s1)
    80004608:	21c4a783          	lw	a5,540(s1)
    8000460c:	fef701e3          	beq	a4,a5,800045ee <piperead+0x34>
    80004610:	f05a                	sd	s6,32(sp)
    80004612:	ec5e                	sd	s7,24(sp)
    80004614:	e862                	sd	s8,16(sp)
    80004616:	a829                	j	80004630 <piperead+0x76>
    80004618:	f05a                	sd	s6,32(sp)
    8000461a:	ec5e                	sd	s7,24(sp)
    8000461c:	e862                	sd	s8,16(sp)
    8000461e:	a809                	j	80004630 <piperead+0x76>
      release(&pi->lock);
    80004620:	8526                	mv	a0,s1
    80004622:	ec2fc0ef          	jal	80000ce4 <release>
      return -1;
    80004626:	59fd                	li	s3,-1
    80004628:	a0a5                	j	80004690 <piperead+0xd6>
    8000462a:	f05a                	sd	s6,32(sp)
    8000462c:	ec5e                	sd	s7,24(sp)
    8000462e:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004630:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004632:	faf40c13          	addi	s8,s0,-81
    80004636:	4b85                	li	s7,1
    80004638:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    8000463a:	05505163          	blez	s5,8000467c <piperead+0xc2>
    if(pi->nread == pi->nwrite)
    8000463e:	2184a783          	lw	a5,536(s1)
    80004642:	21c4a703          	lw	a4,540(s1)
    80004646:	02f70b63          	beq	a4,a5,8000467c <piperead+0xc2>
    ch = pi->data[pi->nread % PIPESIZE];
    8000464a:	1ff7f793          	andi	a5,a5,511
    8000464e:	97a6                	add	a5,a5,s1
    80004650:	0187c783          	lbu	a5,24(a5)
    80004654:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1) {
    80004658:	86de                	mv	a3,s7
    8000465a:	8662                	mv	a2,s8
    8000465c:	85ca                	mv	a1,s2
    8000465e:	050a3503          	ld	a0,80(s4)
    80004662:	81afd0ef          	jal	8000167c <copyout>
    80004666:	03650f63          	beq	a0,s6,800046a4 <piperead+0xea>
      if(i == 0)
        i = -1;
      break;
    }
    pi->nread++;
    8000466a:	2184a783          	lw	a5,536(s1)
    8000466e:	2785                	addiw	a5,a5,1
    80004670:	20f4ac23          	sw	a5,536(s1)
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004674:	2985                	addiw	s3,s3,1
    80004676:	0905                	addi	s2,s2,1
    80004678:	fd3a93e3          	bne	s5,s3,8000463e <piperead+0x84>
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    8000467c:	21c48513          	addi	a0,s1,540
    80004680:	933fd0ef          	jal	80001fb2 <wakeup>
  release(&pi->lock);
    80004684:	8526                	mv	a0,s1
    80004686:	e5efc0ef          	jal	80000ce4 <release>
    8000468a:	7b02                	ld	s6,32(sp)
    8000468c:	6be2                	ld	s7,24(sp)
    8000468e:	6c42                	ld	s8,16(sp)
  return i;
}
    80004690:	854e                	mv	a0,s3
    80004692:	60e6                	ld	ra,88(sp)
    80004694:	6446                	ld	s0,80(sp)
    80004696:	64a6                	ld	s1,72(sp)
    80004698:	6906                	ld	s2,64(sp)
    8000469a:	79e2                	ld	s3,56(sp)
    8000469c:	7a42                	ld	s4,48(sp)
    8000469e:	7aa2                	ld	s5,40(sp)
    800046a0:	6125                	addi	sp,sp,96
    800046a2:	8082                	ret
      if(i == 0)
    800046a4:	fc099ce3          	bnez	s3,8000467c <piperead+0xc2>
        i = -1;
    800046a8:	89aa                	mv	s3,a0
    800046aa:	bfc9                	j	8000467c <piperead+0xc2>

00000000800046ac <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    800046ac:	1141                	addi	sp,sp,-16
    800046ae:	e406                	sd	ra,8(sp)
    800046b0:	e022                	sd	s0,0(sp)
    800046b2:	0800                	addi	s0,sp,16
    800046b4:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    800046b6:	0035151b          	slliw	a0,a0,0x3
    800046ba:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    800046bc:	8b89                	andi	a5,a5,2
    800046be:	c399                	beqz	a5,800046c4 <flags2perm+0x18>
      perm |= PTE_W;
    800046c0:	00456513          	ori	a0,a0,4
    return perm;
}
    800046c4:	60a2                	ld	ra,8(sp)
    800046c6:	6402                	ld	s0,0(sp)
    800046c8:	0141                	addi	sp,sp,16
    800046ca:	8082                	ret

00000000800046cc <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    800046cc:	de010113          	addi	sp,sp,-544
    800046d0:	20113c23          	sd	ra,536(sp)
    800046d4:	20813823          	sd	s0,528(sp)
    800046d8:	20913423          	sd	s1,520(sp)
    800046dc:	21213023          	sd	s2,512(sp)
    800046e0:	1400                	addi	s0,sp,544
    800046e2:	892a                	mv	s2,a0
    800046e4:	dea43823          	sd	a0,-528(s0)
    800046e8:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    800046ec:	a6afd0ef          	jal	80001956 <myproc>
    800046f0:	84aa                	mv	s1,a0

  begin_op();
    800046f2:	d6aff0ef          	jal	80003c5c <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    800046f6:	854a                	mv	a0,s2
    800046f8:	b86ff0ef          	jal	80003a7e <namei>
    800046fc:	cd21                	beqz	a0,80004754 <kexec+0x88>
    800046fe:	fbd2                	sd	s4,496(sp)
    80004700:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004702:	b4ffe0ef          	jal	80003250 <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004706:	04000713          	li	a4,64
    8000470a:	4681                	li	a3,0
    8000470c:	e5040613          	addi	a2,s0,-432
    80004710:	4581                	li	a1,0
    80004712:	8552                	mv	a0,s4
    80004714:	ecffe0ef          	jal	800035e2 <readi>
    80004718:	04000793          	li	a5,64
    8000471c:	00f51a63          	bne	a0,a5,80004730 <kexec+0x64>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    80004720:	e5042703          	lw	a4,-432(s0)
    80004724:	464c47b7          	lui	a5,0x464c4
    80004728:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    8000472c:	02f70863          	beq	a4,a5,8000475c <kexec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004730:	8552                	mv	a0,s4
    80004732:	d2bfe0ef          	jal	8000345c <iunlockput>
    end_op();
    80004736:	d96ff0ef          	jal	80003ccc <end_op>
  }
  return -1;
    8000473a:	557d                	li	a0,-1
    8000473c:	7a5e                	ld	s4,496(sp)
}
    8000473e:	21813083          	ld	ra,536(sp)
    80004742:	21013403          	ld	s0,528(sp)
    80004746:	20813483          	ld	s1,520(sp)
    8000474a:	20013903          	ld	s2,512(sp)
    8000474e:	22010113          	addi	sp,sp,544
    80004752:	8082                	ret
    end_op();
    80004754:	d78ff0ef          	jal	80003ccc <end_op>
    return -1;
    80004758:	557d                	li	a0,-1
    8000475a:	b7d5                	j	8000473e <kexec+0x72>
    8000475c:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    8000475e:	8526                	mv	a0,s1
    80004760:	b00fd0ef          	jal	80001a60 <proc_pagetable>
    80004764:	8b2a                	mv	s6,a0
    80004766:	26050f63          	beqz	a0,800049e4 <kexec+0x318>
    8000476a:	ffce                	sd	s3,504(sp)
    8000476c:	f7d6                	sd	s5,488(sp)
    8000476e:	efde                	sd	s7,472(sp)
    80004770:	ebe2                	sd	s8,464(sp)
    80004772:	e7e6                	sd	s9,456(sp)
    80004774:	e3ea                	sd	s10,448(sp)
    80004776:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004778:	e8845783          	lhu	a5,-376(s0)
    8000477c:	0e078963          	beqz	a5,8000486e <kexec+0x1a2>
    80004780:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004784:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004786:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004788:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    8000478c:	6c85                	lui	s9,0x1
    8000478e:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80004792:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80004796:	6a85                	lui	s5,0x1
    80004798:	a085                	j	800047f8 <kexec+0x12c>
      panic("loadseg: address should exist");
    8000479a:	00003517          	auipc	a0,0x3
    8000479e:	e0650513          	addi	a0,a0,-506 # 800075a0 <etext+0x5a0>
    800047a2:	882fc0ef          	jal	80000824 <panic>
    if(sz - i < PGSIZE)
    800047a6:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    800047a8:	874a                	mv	a4,s2
    800047aa:	009b86bb          	addw	a3,s7,s1
    800047ae:	4581                	li	a1,0
    800047b0:	8552                	mv	a0,s4
    800047b2:	e31fe0ef          	jal	800035e2 <readi>
    800047b6:	22a91b63          	bne	s2,a0,800049ec <kexec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    800047ba:	009a84bb          	addw	s1,s5,s1
    800047be:	0334f263          	bgeu	s1,s3,800047e2 <kexec+0x116>
    pa = walkaddr(pagetable, va + i);
    800047c2:	02049593          	slli	a1,s1,0x20
    800047c6:	9181                	srli	a1,a1,0x20
    800047c8:	95e2                	add	a1,a1,s8
    800047ca:	855a                	mv	a0,s6
    800047cc:	883fc0ef          	jal	8000104e <walkaddr>
    800047d0:	862a                	mv	a2,a0
    if(pa == 0)
    800047d2:	d561                	beqz	a0,8000479a <kexec+0xce>
    if(sz - i < PGSIZE)
    800047d4:	409987bb          	subw	a5,s3,s1
    800047d8:	893e                	mv	s2,a5
    800047da:	fcfcf6e3          	bgeu	s9,a5,800047a6 <kexec+0xda>
    800047de:	8956                	mv	s2,s5
    800047e0:	b7d9                	j	800047a6 <kexec+0xda>
    sz = sz1;
    800047e2:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    800047e6:	2d05                	addiw	s10,s10,1
    800047e8:	e0843783          	ld	a5,-504(s0)
    800047ec:	0387869b          	addiw	a3,a5,56
    800047f0:	e8845783          	lhu	a5,-376(s0)
    800047f4:	06fd5e63          	bge	s10,a5,80004870 <kexec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    800047f8:	e0d43423          	sd	a3,-504(s0)
    800047fc:	876e                	mv	a4,s11
    800047fe:	e1840613          	addi	a2,s0,-488
    80004802:	4581                	li	a1,0
    80004804:	8552                	mv	a0,s4
    80004806:	dddfe0ef          	jal	800035e2 <readi>
    8000480a:	1db51f63          	bne	a0,s11,800049e8 <kexec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    8000480e:	e1842783          	lw	a5,-488(s0)
    80004812:	4705                	li	a4,1
    80004814:	fce799e3          	bne	a5,a4,800047e6 <kexec+0x11a>
    if(ph.memsz < ph.filesz)
    80004818:	e4043483          	ld	s1,-448(s0)
    8000481c:	e3843783          	ld	a5,-456(s0)
    80004820:	1ef4e463          	bltu	s1,a5,80004a08 <kexec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004824:	e2843783          	ld	a5,-472(s0)
    80004828:	94be                	add	s1,s1,a5
    8000482a:	1ef4e263          	bltu	s1,a5,80004a0e <kexec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    8000482e:	de843703          	ld	a4,-536(s0)
    80004832:	8ff9                	and	a5,a5,a4
    80004834:	1e079063          	bnez	a5,80004a14 <kexec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004838:	e1c42503          	lw	a0,-484(s0)
    8000483c:	e71ff0ef          	jal	800046ac <flags2perm>
    80004840:	86aa                	mv	a3,a0
    80004842:	8626                	mv	a2,s1
    80004844:	85ca                	mv	a1,s2
    80004846:	855a                	mv	a0,s6
    80004848:	addfc0ef          	jal	80001324 <uvmalloc>
    8000484c:	dea43c23          	sd	a0,-520(s0)
    80004850:	1c050563          	beqz	a0,80004a1a <kexec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004854:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004858:	00098863          	beqz	s3,80004868 <kexec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    8000485c:	e2843c03          	ld	s8,-472(s0)
    80004860:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004864:	4481                	li	s1,0
    80004866:	bfb1                	j	800047c2 <kexec+0xf6>
    sz = sz1;
    80004868:	df843903          	ld	s2,-520(s0)
    8000486c:	bfad                	j	800047e6 <kexec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    8000486e:	4901                	li	s2,0
  iunlockput(ip);
    80004870:	8552                	mv	a0,s4
    80004872:	bebfe0ef          	jal	8000345c <iunlockput>
  end_op();
    80004876:	c56ff0ef          	jal	80003ccc <end_op>
  p = myproc();
    8000487a:	8dcfd0ef          	jal	80001956 <myproc>
    8000487e:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004880:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80004884:	6985                	lui	s3,0x1
    80004886:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80004888:	99ca                	add	s3,s3,s2
    8000488a:	77fd                	lui	a5,0xfffff
    8000488c:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004890:	4691                	li	a3,4
    80004892:	6609                	lui	a2,0x2
    80004894:	964e                	add	a2,a2,s3
    80004896:	85ce                	mv	a1,s3
    80004898:	855a                	mv	a0,s6
    8000489a:	a8bfc0ef          	jal	80001324 <uvmalloc>
    8000489e:	8a2a                	mv	s4,a0
    800048a0:	e105                	bnez	a0,800048c0 <kexec+0x1f4>
    proc_freepagetable(pagetable, sz);
    800048a2:	85ce                	mv	a1,s3
    800048a4:	855a                	mv	a0,s6
    800048a6:	a3efd0ef          	jal	80001ae4 <proc_freepagetable>
  return -1;
    800048aa:	557d                	li	a0,-1
    800048ac:	79fe                	ld	s3,504(sp)
    800048ae:	7a5e                	ld	s4,496(sp)
    800048b0:	7abe                	ld	s5,488(sp)
    800048b2:	7b1e                	ld	s6,480(sp)
    800048b4:	6bfe                	ld	s7,472(sp)
    800048b6:	6c5e                	ld	s8,464(sp)
    800048b8:	6cbe                	ld	s9,456(sp)
    800048ba:	6d1e                	ld	s10,448(sp)
    800048bc:	7dfa                	ld	s11,440(sp)
    800048be:	b541                	j	8000473e <kexec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    800048c0:	75f9                	lui	a1,0xffffe
    800048c2:	95aa                	add	a1,a1,a0
    800048c4:	855a                	mv	a0,s6
    800048c6:	c31fc0ef          	jal	800014f6 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    800048ca:	800a0b93          	addi	s7,s4,-2048
    800048ce:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    800048d2:	e0043783          	ld	a5,-512(s0)
    800048d6:	6388                	ld	a0,0(a5)
  sp = sz;
    800048d8:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    800048da:	4481                	li	s1,0
    ustack[argc] = sp;
    800048dc:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    800048e0:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    800048e4:	cd21                	beqz	a0,8000493c <kexec+0x270>
    sp -= strlen(argv[argc]) + 1;
    800048e6:	dc4fc0ef          	jal	80000eaa <strlen>
    800048ea:	0015079b          	addiw	a5,a0,1
    800048ee:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    800048f2:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    800048f6:	13796563          	bltu	s2,s7,80004a20 <kexec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    800048fa:	e0043d83          	ld	s11,-512(s0)
    800048fe:	000db983          	ld	s3,0(s11)
    80004902:	854e                	mv	a0,s3
    80004904:	da6fc0ef          	jal	80000eaa <strlen>
    80004908:	0015069b          	addiw	a3,a0,1
    8000490c:	864e                	mv	a2,s3
    8000490e:	85ca                	mv	a1,s2
    80004910:	855a                	mv	a0,s6
    80004912:	d6bfc0ef          	jal	8000167c <copyout>
    80004916:	10054763          	bltz	a0,80004a24 <kexec+0x358>
    ustack[argc] = sp;
    8000491a:	00349793          	slli	a5,s1,0x3
    8000491e:	97e6                	add	a5,a5,s9
    80004920:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7ffde488>
  for(argc = 0; argv[argc]; argc++) {
    80004924:	0485                	addi	s1,s1,1
    80004926:	008d8793          	addi	a5,s11,8
    8000492a:	e0f43023          	sd	a5,-512(s0)
    8000492e:	008db503          	ld	a0,8(s11)
    80004932:	c509                	beqz	a0,8000493c <kexec+0x270>
    if(argc >= MAXARG)
    80004934:	fb8499e3          	bne	s1,s8,800048e6 <kexec+0x21a>
  sz = sz1;
    80004938:	89d2                	mv	s3,s4
    8000493a:	b7a5                	j	800048a2 <kexec+0x1d6>
  ustack[argc] = 0;
    8000493c:	00349793          	slli	a5,s1,0x3
    80004940:	f9078793          	addi	a5,a5,-112
    80004944:	97a2                	add	a5,a5,s0
    80004946:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    8000494a:	00349693          	slli	a3,s1,0x3
    8000494e:	06a1                	addi	a3,a3,8
    80004950:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004954:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004958:	89d2                	mv	s3,s4
  if(sp < stackbase)
    8000495a:	f57964e3          	bltu	s2,s7,800048a2 <kexec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    8000495e:	e9040613          	addi	a2,s0,-368
    80004962:	85ca                	mv	a1,s2
    80004964:	855a                	mv	a0,s6
    80004966:	d17fc0ef          	jal	8000167c <copyout>
    8000496a:	f2054ce3          	bltz	a0,800048a2 <kexec+0x1d6>
  p->trapframe->a1 = sp;
    8000496e:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80004972:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004976:	df043783          	ld	a5,-528(s0)
    8000497a:	0007c703          	lbu	a4,0(a5)
    8000497e:	cf11                	beqz	a4,8000499a <kexec+0x2ce>
    80004980:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004982:	02f00693          	li	a3,47
    80004986:	a029                	j	80004990 <kexec+0x2c4>
  for(last=s=path; *s; s++)
    80004988:	0785                	addi	a5,a5,1
    8000498a:	fff7c703          	lbu	a4,-1(a5)
    8000498e:	c711                	beqz	a4,8000499a <kexec+0x2ce>
    if(*s == '/')
    80004990:	fed71ce3          	bne	a4,a3,80004988 <kexec+0x2bc>
      last = s+1;
    80004994:	def43823          	sd	a5,-528(s0)
    80004998:	bfc5                	j	80004988 <kexec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    8000499a:	4641                	li	a2,16
    8000499c:	df043583          	ld	a1,-528(s0)
    800049a0:	158a8513          	addi	a0,s5,344
    800049a4:	cd0fc0ef          	jal	80000e74 <safestrcpy>
  oldpagetable = p->pagetable;
    800049a8:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    800049ac:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    800049b0:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = ulib.c:start()
    800049b4:	058ab783          	ld	a5,88(s5)
    800049b8:	e6843703          	ld	a4,-408(s0)
    800049bc:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    800049be:	058ab783          	ld	a5,88(s5)
    800049c2:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    800049c6:	85ea                	mv	a1,s10
    800049c8:	91cfd0ef          	jal	80001ae4 <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    800049cc:	0004851b          	sext.w	a0,s1
    800049d0:	79fe                	ld	s3,504(sp)
    800049d2:	7a5e                	ld	s4,496(sp)
    800049d4:	7abe                	ld	s5,488(sp)
    800049d6:	7b1e                	ld	s6,480(sp)
    800049d8:	6bfe                	ld	s7,472(sp)
    800049da:	6c5e                	ld	s8,464(sp)
    800049dc:	6cbe                	ld	s9,456(sp)
    800049de:	6d1e                	ld	s10,448(sp)
    800049e0:	7dfa                	ld	s11,440(sp)
    800049e2:	bbb1                	j	8000473e <kexec+0x72>
    800049e4:	7b1e                	ld	s6,480(sp)
    800049e6:	b3a9                	j	80004730 <kexec+0x64>
    800049e8:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    800049ec:	df843583          	ld	a1,-520(s0)
    800049f0:	855a                	mv	a0,s6
    800049f2:	8f2fd0ef          	jal	80001ae4 <proc_freepagetable>
  if(ip){
    800049f6:	79fe                	ld	s3,504(sp)
    800049f8:	7abe                	ld	s5,488(sp)
    800049fa:	7b1e                	ld	s6,480(sp)
    800049fc:	6bfe                	ld	s7,472(sp)
    800049fe:	6c5e                	ld	s8,464(sp)
    80004a00:	6cbe                	ld	s9,456(sp)
    80004a02:	6d1e                	ld	s10,448(sp)
    80004a04:	7dfa                	ld	s11,440(sp)
    80004a06:	b32d                	j	80004730 <kexec+0x64>
    80004a08:	df243c23          	sd	s2,-520(s0)
    80004a0c:	b7c5                	j	800049ec <kexec+0x320>
    80004a0e:	df243c23          	sd	s2,-520(s0)
    80004a12:	bfe9                	j	800049ec <kexec+0x320>
    80004a14:	df243c23          	sd	s2,-520(s0)
    80004a18:	bfd1                	j	800049ec <kexec+0x320>
    80004a1a:	df243c23          	sd	s2,-520(s0)
    80004a1e:	b7f9                	j	800049ec <kexec+0x320>
  sz = sz1;
    80004a20:	89d2                	mv	s3,s4
    80004a22:	b541                	j	800048a2 <kexec+0x1d6>
    80004a24:	89d2                	mv	s3,s4
    80004a26:	bdb5                	j	800048a2 <kexec+0x1d6>

0000000080004a28 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004a28:	7179                	addi	sp,sp,-48
    80004a2a:	f406                	sd	ra,40(sp)
    80004a2c:	f022                	sd	s0,32(sp)
    80004a2e:	ec26                	sd	s1,24(sp)
    80004a30:	e84a                	sd	s2,16(sp)
    80004a32:	1800                	addi	s0,sp,48
    80004a34:	892e                	mv	s2,a1
    80004a36:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004a38:	fdc40593          	addi	a1,s0,-36
    80004a3c:	e37fd0ef          	jal	80002872 <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004a40:	fdc42703          	lw	a4,-36(s0)
    80004a44:	47bd                	li	a5,15
    80004a46:	02e7ea63          	bltu	a5,a4,80004a7a <argfd+0x52>
    80004a4a:	f0dfc0ef          	jal	80001956 <myproc>
    80004a4e:	fdc42703          	lw	a4,-36(s0)
    80004a52:	00371793          	slli	a5,a4,0x3
    80004a56:	0d078793          	addi	a5,a5,208
    80004a5a:	953e                	add	a0,a0,a5
    80004a5c:	611c                	ld	a5,0(a0)
    80004a5e:	c385                	beqz	a5,80004a7e <argfd+0x56>
    return -1;
  if(pfd)
    80004a60:	00090463          	beqz	s2,80004a68 <argfd+0x40>
    *pfd = fd;
    80004a64:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004a68:	4501                	li	a0,0
  if(pf)
    80004a6a:	c091                	beqz	s1,80004a6e <argfd+0x46>
    *pf = f;
    80004a6c:	e09c                	sd	a5,0(s1)
}
    80004a6e:	70a2                	ld	ra,40(sp)
    80004a70:	7402                	ld	s0,32(sp)
    80004a72:	64e2                	ld	s1,24(sp)
    80004a74:	6942                	ld	s2,16(sp)
    80004a76:	6145                	addi	sp,sp,48
    80004a78:	8082                	ret
    return -1;
    80004a7a:	557d                	li	a0,-1
    80004a7c:	bfcd                	j	80004a6e <argfd+0x46>
    80004a7e:	557d                	li	a0,-1
    80004a80:	b7fd                	j	80004a6e <argfd+0x46>

0000000080004a82 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004a82:	1101                	addi	sp,sp,-32
    80004a84:	ec06                	sd	ra,24(sp)
    80004a86:	e822                	sd	s0,16(sp)
    80004a88:	e426                	sd	s1,8(sp)
    80004a8a:	1000                	addi	s0,sp,32
    80004a8c:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004a8e:	ec9fc0ef          	jal	80001956 <myproc>
    80004a92:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004a94:	0d050793          	addi	a5,a0,208
    80004a98:	4501                	li	a0,0
    80004a9a:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004a9c:	6398                	ld	a4,0(a5)
    80004a9e:	cb19                	beqz	a4,80004ab4 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004aa0:	2505                	addiw	a0,a0,1
    80004aa2:	07a1                	addi	a5,a5,8
    80004aa4:	fed51ce3          	bne	a0,a3,80004a9c <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004aa8:	557d                	li	a0,-1
}
    80004aaa:	60e2                	ld	ra,24(sp)
    80004aac:	6442                	ld	s0,16(sp)
    80004aae:	64a2                	ld	s1,8(sp)
    80004ab0:	6105                	addi	sp,sp,32
    80004ab2:	8082                	ret
      p->ofile[fd] = f;
    80004ab4:	00351793          	slli	a5,a0,0x3
    80004ab8:	0d078793          	addi	a5,a5,208
    80004abc:	963e                	add	a2,a2,a5
    80004abe:	e204                	sd	s1,0(a2)
      return fd;
    80004ac0:	b7ed                	j	80004aaa <fdalloc+0x28>

0000000080004ac2 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004ac2:	715d                	addi	sp,sp,-80
    80004ac4:	e486                	sd	ra,72(sp)
    80004ac6:	e0a2                	sd	s0,64(sp)
    80004ac8:	fc26                	sd	s1,56(sp)
    80004aca:	f84a                	sd	s2,48(sp)
    80004acc:	f44e                	sd	s3,40(sp)
    80004ace:	f052                	sd	s4,32(sp)
    80004ad0:	ec56                	sd	s5,24(sp)
    80004ad2:	e85a                	sd	s6,16(sp)
    80004ad4:	0880                	addi	s0,sp,80
    80004ad6:	892e                	mv	s2,a1
    80004ad8:	8a2e                	mv	s4,a1
    80004ada:	8ab2                	mv	s5,a2
    80004adc:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004ade:	fb040593          	addi	a1,s0,-80
    80004ae2:	fb7fe0ef          	jal	80003a98 <nameiparent>
    80004ae6:	84aa                	mv	s1,a0
    80004ae8:	10050763          	beqz	a0,80004bf6 <create+0x134>
    return 0;

  ilock(dp);
    80004aec:	f64fe0ef          	jal	80003250 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004af0:	4601                	li	a2,0
    80004af2:	fb040593          	addi	a1,s0,-80
    80004af6:	8526                	mv	a0,s1
    80004af8:	cf3fe0ef          	jal	800037ea <dirlookup>
    80004afc:	89aa                	mv	s3,a0
    80004afe:	c131                	beqz	a0,80004b42 <create+0x80>
    iunlockput(dp);
    80004b00:	8526                	mv	a0,s1
    80004b02:	95bfe0ef          	jal	8000345c <iunlockput>
    ilock(ip);
    80004b06:	854e                	mv	a0,s3
    80004b08:	f48fe0ef          	jal	80003250 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    80004b0c:	4789                	li	a5,2
    80004b0e:	02f91563          	bne	s2,a5,80004b38 <create+0x76>
    80004b12:	0449d783          	lhu	a5,68(s3)
    80004b16:	37f9                	addiw	a5,a5,-2
    80004b18:	17c2                	slli	a5,a5,0x30
    80004b1a:	93c1                	srli	a5,a5,0x30
    80004b1c:	4705                	li	a4,1
    80004b1e:	00f76d63          	bltu	a4,a5,80004b38 <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80004b22:	854e                	mv	a0,s3
    80004b24:	60a6                	ld	ra,72(sp)
    80004b26:	6406                	ld	s0,64(sp)
    80004b28:	74e2                	ld	s1,56(sp)
    80004b2a:	7942                	ld	s2,48(sp)
    80004b2c:	79a2                	ld	s3,40(sp)
    80004b2e:	7a02                	ld	s4,32(sp)
    80004b30:	6ae2                	ld	s5,24(sp)
    80004b32:	6b42                	ld	s6,16(sp)
    80004b34:	6161                	addi	sp,sp,80
    80004b36:	8082                	ret
    iunlockput(ip);
    80004b38:	854e                	mv	a0,s3
    80004b3a:	923fe0ef          	jal	8000345c <iunlockput>
    return 0;
    80004b3e:	4981                	li	s3,0
    80004b40:	b7cd                	j	80004b22 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80004b42:	85ca                	mv	a1,s2
    80004b44:	4088                	lw	a0,0(s1)
    80004b46:	d9afe0ef          	jal	800030e0 <ialloc>
    80004b4a:	892a                	mv	s2,a0
    80004b4c:	cd15                	beqz	a0,80004b88 <create+0xc6>
  ilock(ip);
    80004b4e:	f02fe0ef          	jal	80003250 <ilock>
  ip->major = major;
    80004b52:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80004b56:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80004b5a:	4785                	li	a5,1
    80004b5c:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004b60:	854a                	mv	a0,s2
    80004b62:	e3afe0ef          	jal	8000319c <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80004b66:	4705                	li	a4,1
    80004b68:	02ea0463          	beq	s4,a4,80004b90 <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    80004b6c:	00492603          	lw	a2,4(s2)
    80004b70:	fb040593          	addi	a1,s0,-80
    80004b74:	8526                	mv	a0,s1
    80004b76:	e5ffe0ef          	jal	800039d4 <dirlink>
    80004b7a:	06054263          	bltz	a0,80004bde <create+0x11c>
  iunlockput(dp);
    80004b7e:	8526                	mv	a0,s1
    80004b80:	8ddfe0ef          	jal	8000345c <iunlockput>
  return ip;
    80004b84:	89ca                	mv	s3,s2
    80004b86:	bf71                	j	80004b22 <create+0x60>
    iunlockput(dp);
    80004b88:	8526                	mv	a0,s1
    80004b8a:	8d3fe0ef          	jal	8000345c <iunlockput>
    return 0;
    80004b8e:	bf51                	j	80004b22 <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    80004b90:	00492603          	lw	a2,4(s2)
    80004b94:	00003597          	auipc	a1,0x3
    80004b98:	a2c58593          	addi	a1,a1,-1492 # 800075c0 <etext+0x5c0>
    80004b9c:	854a                	mv	a0,s2
    80004b9e:	e37fe0ef          	jal	800039d4 <dirlink>
    80004ba2:	02054e63          	bltz	a0,80004bde <create+0x11c>
    80004ba6:	40d0                	lw	a2,4(s1)
    80004ba8:	00003597          	auipc	a1,0x3
    80004bac:	a2058593          	addi	a1,a1,-1504 # 800075c8 <etext+0x5c8>
    80004bb0:	854a                	mv	a0,s2
    80004bb2:	e23fe0ef          	jal	800039d4 <dirlink>
    80004bb6:	02054463          	bltz	a0,80004bde <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    80004bba:	00492603          	lw	a2,4(s2)
    80004bbe:	fb040593          	addi	a1,s0,-80
    80004bc2:	8526                	mv	a0,s1
    80004bc4:	e11fe0ef          	jal	800039d4 <dirlink>
    80004bc8:	00054b63          	bltz	a0,80004bde <create+0x11c>
    dp->nlink++;  // for ".."
    80004bcc:	04a4d783          	lhu	a5,74(s1)
    80004bd0:	2785                	addiw	a5,a5,1
    80004bd2:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004bd6:	8526                	mv	a0,s1
    80004bd8:	dc4fe0ef          	jal	8000319c <iupdate>
    80004bdc:	b74d                	j	80004b7e <create+0xbc>
  ip->nlink = 0;
    80004bde:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    80004be2:	854a                	mv	a0,s2
    80004be4:	db8fe0ef          	jal	8000319c <iupdate>
  iunlockput(ip);
    80004be8:	854a                	mv	a0,s2
    80004bea:	873fe0ef          	jal	8000345c <iunlockput>
  iunlockput(dp);
    80004bee:	8526                	mv	a0,s1
    80004bf0:	86dfe0ef          	jal	8000345c <iunlockput>
  return 0;
    80004bf4:	b73d                	j	80004b22 <create+0x60>
    return 0;
    80004bf6:	89aa                	mv	s3,a0
    80004bf8:	b72d                	j	80004b22 <create+0x60>

0000000080004bfa <sys_dup>:
{
    80004bfa:	7179                	addi	sp,sp,-48
    80004bfc:	f406                	sd	ra,40(sp)
    80004bfe:	f022                	sd	s0,32(sp)
    80004c00:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80004c02:	fd840613          	addi	a2,s0,-40
    80004c06:	4581                	li	a1,0
    80004c08:	4501                	li	a0,0
    80004c0a:	e1fff0ef          	jal	80004a28 <argfd>
    return -1;
    80004c0e:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    80004c10:	02054363          	bltz	a0,80004c36 <sys_dup+0x3c>
    80004c14:	ec26                	sd	s1,24(sp)
    80004c16:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80004c18:	fd843483          	ld	s1,-40(s0)
    80004c1c:	8526                	mv	a0,s1
    80004c1e:	e65ff0ef          	jal	80004a82 <fdalloc>
    80004c22:	892a                	mv	s2,a0
    return -1;
    80004c24:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80004c26:	00054d63          	bltz	a0,80004c40 <sys_dup+0x46>
  filedup(f);
    80004c2a:	8526                	mv	a0,s1
    80004c2c:	c0eff0ef          	jal	8000403a <filedup>
  return fd;
    80004c30:	87ca                	mv	a5,s2
    80004c32:	64e2                	ld	s1,24(sp)
    80004c34:	6942                	ld	s2,16(sp)
}
    80004c36:	853e                	mv	a0,a5
    80004c38:	70a2                	ld	ra,40(sp)
    80004c3a:	7402                	ld	s0,32(sp)
    80004c3c:	6145                	addi	sp,sp,48
    80004c3e:	8082                	ret
    80004c40:	64e2                	ld	s1,24(sp)
    80004c42:	6942                	ld	s2,16(sp)
    80004c44:	bfcd                	j	80004c36 <sys_dup+0x3c>

0000000080004c46 <sys_read>:
{
    80004c46:	7179                	addi	sp,sp,-48
    80004c48:	f406                	sd	ra,40(sp)
    80004c4a:	f022                	sd	s0,32(sp)
    80004c4c:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004c4e:	fd840593          	addi	a1,s0,-40
    80004c52:	4505                	li	a0,1
    80004c54:	c3bfd0ef          	jal	8000288e <argaddr>
  argint(2, &n);
    80004c58:	fe440593          	addi	a1,s0,-28
    80004c5c:	4509                	li	a0,2
    80004c5e:	c15fd0ef          	jal	80002872 <argint>
  if(argfd(0, 0, &f) < 0)
    80004c62:	fe840613          	addi	a2,s0,-24
    80004c66:	4581                	li	a1,0
    80004c68:	4501                	li	a0,0
    80004c6a:	dbfff0ef          	jal	80004a28 <argfd>
    80004c6e:	87aa                	mv	a5,a0
    return -1;
    80004c70:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004c72:	0007ca63          	bltz	a5,80004c86 <sys_read+0x40>
  return fileread(f, p, n);
    80004c76:	fe442603          	lw	a2,-28(s0)
    80004c7a:	fd843583          	ld	a1,-40(s0)
    80004c7e:	fe843503          	ld	a0,-24(s0)
    80004c82:	d22ff0ef          	jal	800041a4 <fileread>
}
    80004c86:	70a2                	ld	ra,40(sp)
    80004c88:	7402                	ld	s0,32(sp)
    80004c8a:	6145                	addi	sp,sp,48
    80004c8c:	8082                	ret

0000000080004c8e <sys_write>:
{
    80004c8e:	7179                	addi	sp,sp,-48
    80004c90:	f406                	sd	ra,40(sp)
    80004c92:	f022                	sd	s0,32(sp)
    80004c94:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    80004c96:	fd840593          	addi	a1,s0,-40
    80004c9a:	4505                	li	a0,1
    80004c9c:	bf3fd0ef          	jal	8000288e <argaddr>
  argint(2, &n);
    80004ca0:	fe440593          	addi	a1,s0,-28
    80004ca4:	4509                	li	a0,2
    80004ca6:	bcdfd0ef          	jal	80002872 <argint>
  if(argfd(0, 0, &f) < 0)
    80004caa:	fe840613          	addi	a2,s0,-24
    80004cae:	4581                	li	a1,0
    80004cb0:	4501                	li	a0,0
    80004cb2:	d77ff0ef          	jal	80004a28 <argfd>
    80004cb6:	87aa                	mv	a5,a0
    return -1;
    80004cb8:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004cba:	0007ca63          	bltz	a5,80004cce <sys_write+0x40>
  return filewrite(f, p, n);
    80004cbe:	fe442603          	lw	a2,-28(s0)
    80004cc2:	fd843583          	ld	a1,-40(s0)
    80004cc6:	fe843503          	ld	a0,-24(s0)
    80004cca:	d9eff0ef          	jal	80004268 <filewrite>
}
    80004cce:	70a2                	ld	ra,40(sp)
    80004cd0:	7402                	ld	s0,32(sp)
    80004cd2:	6145                	addi	sp,sp,48
    80004cd4:	8082                	ret

0000000080004cd6 <sys_close>:
{
    80004cd6:	1101                	addi	sp,sp,-32
    80004cd8:	ec06                	sd	ra,24(sp)
    80004cda:	e822                	sd	s0,16(sp)
    80004cdc:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    80004cde:	fe040613          	addi	a2,s0,-32
    80004ce2:	fec40593          	addi	a1,s0,-20
    80004ce6:	4501                	li	a0,0
    80004ce8:	d41ff0ef          	jal	80004a28 <argfd>
    return -1;
    80004cec:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    80004cee:	02054163          	bltz	a0,80004d10 <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80004cf2:	c65fc0ef          	jal	80001956 <myproc>
    80004cf6:	fec42783          	lw	a5,-20(s0)
    80004cfa:	078e                	slli	a5,a5,0x3
    80004cfc:	0d078793          	addi	a5,a5,208
    80004d00:	953e                	add	a0,a0,a5
    80004d02:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80004d06:	fe043503          	ld	a0,-32(s0)
    80004d0a:	b76ff0ef          	jal	80004080 <fileclose>
  return 0;
    80004d0e:	4781                	li	a5,0
}
    80004d10:	853e                	mv	a0,a5
    80004d12:	60e2                	ld	ra,24(sp)
    80004d14:	6442                	ld	s0,16(sp)
    80004d16:	6105                	addi	sp,sp,32
    80004d18:	8082                	ret

0000000080004d1a <sys_fstat>:
{
    80004d1a:	1101                	addi	sp,sp,-32
    80004d1c:	ec06                	sd	ra,24(sp)
    80004d1e:	e822                	sd	s0,16(sp)
    80004d20:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80004d22:	fe040593          	addi	a1,s0,-32
    80004d26:	4505                	li	a0,1
    80004d28:	b67fd0ef          	jal	8000288e <argaddr>
  if(argfd(0, 0, &f) < 0)
    80004d2c:	fe840613          	addi	a2,s0,-24
    80004d30:	4581                	li	a1,0
    80004d32:	4501                	li	a0,0
    80004d34:	cf5ff0ef          	jal	80004a28 <argfd>
    80004d38:	87aa                	mv	a5,a0
    return -1;
    80004d3a:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80004d3c:	0007c863          	bltz	a5,80004d4c <sys_fstat+0x32>
  return filestat(f, st);
    80004d40:	fe043583          	ld	a1,-32(s0)
    80004d44:	fe843503          	ld	a0,-24(s0)
    80004d48:	bfaff0ef          	jal	80004142 <filestat>
}
    80004d4c:	60e2                	ld	ra,24(sp)
    80004d4e:	6442                	ld	s0,16(sp)
    80004d50:	6105                	addi	sp,sp,32
    80004d52:	8082                	ret

0000000080004d54 <sys_link>:
{
    80004d54:	7169                	addi	sp,sp,-304
    80004d56:	f606                	sd	ra,296(sp)
    80004d58:	f222                	sd	s0,288(sp)
    80004d5a:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004d5c:	08000613          	li	a2,128
    80004d60:	ed040593          	addi	a1,s0,-304
    80004d64:	4501                	li	a0,0
    80004d66:	b45fd0ef          	jal	800028aa <argstr>
    return -1;
    80004d6a:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004d6c:	0c054e63          	bltz	a0,80004e48 <sys_link+0xf4>
    80004d70:	08000613          	li	a2,128
    80004d74:	f5040593          	addi	a1,s0,-176
    80004d78:	4505                	li	a0,1
    80004d7a:	b31fd0ef          	jal	800028aa <argstr>
    return -1;
    80004d7e:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    80004d80:	0c054463          	bltz	a0,80004e48 <sys_link+0xf4>
    80004d84:	ee26                	sd	s1,280(sp)
  begin_op();
    80004d86:	ed7fe0ef          	jal	80003c5c <begin_op>
  if((ip = namei(old)) == 0){
    80004d8a:	ed040513          	addi	a0,s0,-304
    80004d8e:	cf1fe0ef          	jal	80003a7e <namei>
    80004d92:	84aa                	mv	s1,a0
    80004d94:	c53d                	beqz	a0,80004e02 <sys_link+0xae>
  ilock(ip);
    80004d96:	cbafe0ef          	jal	80003250 <ilock>
  if(ip->type == T_DIR){
    80004d9a:	04449703          	lh	a4,68(s1)
    80004d9e:	4785                	li	a5,1
    80004da0:	06f70663          	beq	a4,a5,80004e0c <sys_link+0xb8>
    80004da4:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    80004da6:	04a4d783          	lhu	a5,74(s1)
    80004daa:	2785                	addiw	a5,a5,1
    80004dac:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004db0:	8526                	mv	a0,s1
    80004db2:	beafe0ef          	jal	8000319c <iupdate>
  iunlock(ip);
    80004db6:	8526                	mv	a0,s1
    80004db8:	d46fe0ef          	jal	800032fe <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    80004dbc:	fd040593          	addi	a1,s0,-48
    80004dc0:	f5040513          	addi	a0,s0,-176
    80004dc4:	cd5fe0ef          	jal	80003a98 <nameiparent>
    80004dc8:	892a                	mv	s2,a0
    80004dca:	cd21                	beqz	a0,80004e22 <sys_link+0xce>
  ilock(dp);
    80004dcc:	c84fe0ef          	jal	80003250 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    80004dd0:	854a                	mv	a0,s2
    80004dd2:	00092703          	lw	a4,0(s2)
    80004dd6:	409c                	lw	a5,0(s1)
    80004dd8:	04f71263          	bne	a4,a5,80004e1c <sys_link+0xc8>
    80004ddc:	40d0                	lw	a2,4(s1)
    80004dde:	fd040593          	addi	a1,s0,-48
    80004de2:	bf3fe0ef          	jal	800039d4 <dirlink>
    80004de6:	02054b63          	bltz	a0,80004e1c <sys_link+0xc8>
  iunlockput(dp);
    80004dea:	854a                	mv	a0,s2
    80004dec:	e70fe0ef          	jal	8000345c <iunlockput>
  iput(ip);
    80004df0:	8526                	mv	a0,s1
    80004df2:	de0fe0ef          	jal	800033d2 <iput>
  end_op();
    80004df6:	ed7fe0ef          	jal	80003ccc <end_op>
  return 0;
    80004dfa:	4781                	li	a5,0
    80004dfc:	64f2                	ld	s1,280(sp)
    80004dfe:	6952                	ld	s2,272(sp)
    80004e00:	a0a1                	j	80004e48 <sys_link+0xf4>
    end_op();
    80004e02:	ecbfe0ef          	jal	80003ccc <end_op>
    return -1;
    80004e06:	57fd                	li	a5,-1
    80004e08:	64f2                	ld	s1,280(sp)
    80004e0a:	a83d                	j	80004e48 <sys_link+0xf4>
    iunlockput(ip);
    80004e0c:	8526                	mv	a0,s1
    80004e0e:	e4efe0ef          	jal	8000345c <iunlockput>
    end_op();
    80004e12:	ebbfe0ef          	jal	80003ccc <end_op>
    return -1;
    80004e16:	57fd                	li	a5,-1
    80004e18:	64f2                	ld	s1,280(sp)
    80004e1a:	a03d                	j	80004e48 <sys_link+0xf4>
    iunlockput(dp);
    80004e1c:	854a                	mv	a0,s2
    80004e1e:	e3efe0ef          	jal	8000345c <iunlockput>
  ilock(ip);
    80004e22:	8526                	mv	a0,s1
    80004e24:	c2cfe0ef          	jal	80003250 <ilock>
  ip->nlink--;
    80004e28:	04a4d783          	lhu	a5,74(s1)
    80004e2c:	37fd                	addiw	a5,a5,-1
    80004e2e:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80004e32:	8526                	mv	a0,s1
    80004e34:	b68fe0ef          	jal	8000319c <iupdate>
  iunlockput(ip);
    80004e38:	8526                	mv	a0,s1
    80004e3a:	e22fe0ef          	jal	8000345c <iunlockput>
  end_op();
    80004e3e:	e8ffe0ef          	jal	80003ccc <end_op>
  return -1;
    80004e42:	57fd                	li	a5,-1
    80004e44:	64f2                	ld	s1,280(sp)
    80004e46:	6952                	ld	s2,272(sp)
}
    80004e48:	853e                	mv	a0,a5
    80004e4a:	70b2                	ld	ra,296(sp)
    80004e4c:	7412                	ld	s0,288(sp)
    80004e4e:	6155                	addi	sp,sp,304
    80004e50:	8082                	ret

0000000080004e52 <sys_unlink>:
{
    80004e52:	7151                	addi	sp,sp,-240
    80004e54:	f586                	sd	ra,232(sp)
    80004e56:	f1a2                	sd	s0,224(sp)
    80004e58:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80004e5a:	08000613          	li	a2,128
    80004e5e:	f3040593          	addi	a1,s0,-208
    80004e62:	4501                	li	a0,0
    80004e64:	a47fd0ef          	jal	800028aa <argstr>
    80004e68:	14054d63          	bltz	a0,80004fc2 <sys_unlink+0x170>
    80004e6c:	eda6                	sd	s1,216(sp)
  begin_op();
    80004e6e:	deffe0ef          	jal	80003c5c <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80004e72:	fb040593          	addi	a1,s0,-80
    80004e76:	f3040513          	addi	a0,s0,-208
    80004e7a:	c1ffe0ef          	jal	80003a98 <nameiparent>
    80004e7e:	84aa                	mv	s1,a0
    80004e80:	c955                	beqz	a0,80004f34 <sys_unlink+0xe2>
  ilock(dp);
    80004e82:	bcefe0ef          	jal	80003250 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80004e86:	00002597          	auipc	a1,0x2
    80004e8a:	73a58593          	addi	a1,a1,1850 # 800075c0 <etext+0x5c0>
    80004e8e:	fb040513          	addi	a0,s0,-80
    80004e92:	943fe0ef          	jal	800037d4 <namecmp>
    80004e96:	10050b63          	beqz	a0,80004fac <sys_unlink+0x15a>
    80004e9a:	00002597          	auipc	a1,0x2
    80004e9e:	72e58593          	addi	a1,a1,1838 # 800075c8 <etext+0x5c8>
    80004ea2:	fb040513          	addi	a0,s0,-80
    80004ea6:	92ffe0ef          	jal	800037d4 <namecmp>
    80004eaa:	10050163          	beqz	a0,80004fac <sys_unlink+0x15a>
    80004eae:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    80004eb0:	f2c40613          	addi	a2,s0,-212
    80004eb4:	fb040593          	addi	a1,s0,-80
    80004eb8:	8526                	mv	a0,s1
    80004eba:	931fe0ef          	jal	800037ea <dirlookup>
    80004ebe:	892a                	mv	s2,a0
    80004ec0:	0e050563          	beqz	a0,80004faa <sys_unlink+0x158>
    80004ec4:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    80004ec6:	b8afe0ef          	jal	80003250 <ilock>
  if(ip->nlink < 1)
    80004eca:	04a91783          	lh	a5,74(s2)
    80004ece:	06f05863          	blez	a5,80004f3e <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    80004ed2:	04491703          	lh	a4,68(s2)
    80004ed6:	4785                	li	a5,1
    80004ed8:	06f70963          	beq	a4,a5,80004f4a <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    80004edc:	fc040993          	addi	s3,s0,-64
    80004ee0:	4641                	li	a2,16
    80004ee2:	4581                	li	a1,0
    80004ee4:	854e                	mv	a0,s3
    80004ee6:	e3bfb0ef          	jal	80000d20 <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004eea:	4741                	li	a4,16
    80004eec:	f2c42683          	lw	a3,-212(s0)
    80004ef0:	864e                	mv	a2,s3
    80004ef2:	4581                	li	a1,0
    80004ef4:	8526                	mv	a0,s1
    80004ef6:	fdefe0ef          	jal	800036d4 <writei>
    80004efa:	47c1                	li	a5,16
    80004efc:	08f51863          	bne	a0,a5,80004f8c <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    80004f00:	04491703          	lh	a4,68(s2)
    80004f04:	4785                	li	a5,1
    80004f06:	08f70963          	beq	a4,a5,80004f98 <sys_unlink+0x146>
  iunlockput(dp);
    80004f0a:	8526                	mv	a0,s1
    80004f0c:	d50fe0ef          	jal	8000345c <iunlockput>
  ip->nlink--;
    80004f10:	04a95783          	lhu	a5,74(s2)
    80004f14:	37fd                	addiw	a5,a5,-1
    80004f16:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80004f1a:	854a                	mv	a0,s2
    80004f1c:	a80fe0ef          	jal	8000319c <iupdate>
  iunlockput(ip);
    80004f20:	854a                	mv	a0,s2
    80004f22:	d3afe0ef          	jal	8000345c <iunlockput>
  end_op();
    80004f26:	da7fe0ef          	jal	80003ccc <end_op>
  return 0;
    80004f2a:	4501                	li	a0,0
    80004f2c:	64ee                	ld	s1,216(sp)
    80004f2e:	694e                	ld	s2,208(sp)
    80004f30:	69ae                	ld	s3,200(sp)
    80004f32:	a061                	j	80004fba <sys_unlink+0x168>
    end_op();
    80004f34:	d99fe0ef          	jal	80003ccc <end_op>
    return -1;
    80004f38:	557d                	li	a0,-1
    80004f3a:	64ee                	ld	s1,216(sp)
    80004f3c:	a8bd                	j	80004fba <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    80004f3e:	00002517          	auipc	a0,0x2
    80004f42:	69250513          	addi	a0,a0,1682 # 800075d0 <etext+0x5d0>
    80004f46:	8dffb0ef          	jal	80000824 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004f4a:	04c92703          	lw	a4,76(s2)
    80004f4e:	02000793          	li	a5,32
    80004f52:	f8e7f5e3          	bgeu	a5,a4,80004edc <sys_unlink+0x8a>
    80004f56:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80004f58:	4741                	li	a4,16
    80004f5a:	86ce                	mv	a3,s3
    80004f5c:	f1840613          	addi	a2,s0,-232
    80004f60:	4581                	li	a1,0
    80004f62:	854a                	mv	a0,s2
    80004f64:	e7efe0ef          	jal	800035e2 <readi>
    80004f68:	47c1                	li	a5,16
    80004f6a:	00f51b63          	bne	a0,a5,80004f80 <sys_unlink+0x12e>
    if(de.inum != 0)
    80004f6e:	f1845783          	lhu	a5,-232(s0)
    80004f72:	ebb1                	bnez	a5,80004fc6 <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80004f74:	29c1                	addiw	s3,s3,16
    80004f76:	04c92783          	lw	a5,76(s2)
    80004f7a:	fcf9efe3          	bltu	s3,a5,80004f58 <sys_unlink+0x106>
    80004f7e:	bfb9                	j	80004edc <sys_unlink+0x8a>
      panic("isdirempty: readi");
    80004f80:	00002517          	auipc	a0,0x2
    80004f84:	66850513          	addi	a0,a0,1640 # 800075e8 <etext+0x5e8>
    80004f88:	89dfb0ef          	jal	80000824 <panic>
    panic("unlink: writei");
    80004f8c:	00002517          	auipc	a0,0x2
    80004f90:	67450513          	addi	a0,a0,1652 # 80007600 <etext+0x600>
    80004f94:	891fb0ef          	jal	80000824 <panic>
    dp->nlink--;
    80004f98:	04a4d783          	lhu	a5,74(s1)
    80004f9c:	37fd                	addiw	a5,a5,-1
    80004f9e:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    80004fa2:	8526                	mv	a0,s1
    80004fa4:	9f8fe0ef          	jal	8000319c <iupdate>
    80004fa8:	b78d                	j	80004f0a <sys_unlink+0xb8>
    80004faa:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    80004fac:	8526                	mv	a0,s1
    80004fae:	caefe0ef          	jal	8000345c <iunlockput>
  end_op();
    80004fb2:	d1bfe0ef          	jal	80003ccc <end_op>
  return -1;
    80004fb6:	557d                	li	a0,-1
    80004fb8:	64ee                	ld	s1,216(sp)
}
    80004fba:	70ae                	ld	ra,232(sp)
    80004fbc:	740e                	ld	s0,224(sp)
    80004fbe:	616d                	addi	sp,sp,240
    80004fc0:	8082                	ret
    return -1;
    80004fc2:	557d                	li	a0,-1
    80004fc4:	bfdd                	j	80004fba <sys_unlink+0x168>
    iunlockput(ip);
    80004fc6:	854a                	mv	a0,s2
    80004fc8:	c94fe0ef          	jal	8000345c <iunlockput>
    goto bad;
    80004fcc:	694e                	ld	s2,208(sp)
    80004fce:	69ae                	ld	s3,200(sp)
    80004fd0:	bff1                	j	80004fac <sys_unlink+0x15a>

0000000080004fd2 <sys_open>:

uint64
sys_open(void)
{
    80004fd2:	7131                	addi	sp,sp,-192
    80004fd4:	fd06                	sd	ra,184(sp)
    80004fd6:	f922                	sd	s0,176(sp)
    80004fd8:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    80004fda:	f4c40593          	addi	a1,s0,-180
    80004fde:	4505                	li	a0,1
    80004fe0:	893fd0ef          	jal	80002872 <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004fe4:	08000613          	li	a2,128
    80004fe8:	f5040593          	addi	a1,s0,-176
    80004fec:	4501                	li	a0,0
    80004fee:	8bdfd0ef          	jal	800028aa <argstr>
    80004ff2:	87aa                	mv	a5,a0
    return -1;
    80004ff4:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80004ff6:	0a07c363          	bltz	a5,8000509c <sys_open+0xca>
    80004ffa:	f526                	sd	s1,168(sp)

  begin_op();
    80004ffc:	c61fe0ef          	jal	80003c5c <begin_op>

  if(omode & O_CREATE){
    80005000:	f4c42783          	lw	a5,-180(s0)
    80005004:	2007f793          	andi	a5,a5,512
    80005008:	c3dd                	beqz	a5,800050ae <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    8000500a:	4681                	li	a3,0
    8000500c:	4601                	li	a2,0
    8000500e:	4589                	li	a1,2
    80005010:	f5040513          	addi	a0,s0,-176
    80005014:	aafff0ef          	jal	80004ac2 <create>
    80005018:	84aa                	mv	s1,a0
    if(ip == 0){
    8000501a:	c549                	beqz	a0,800050a4 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    8000501c:	04449703          	lh	a4,68(s1)
    80005020:	478d                	li	a5,3
    80005022:	00f71763          	bne	a4,a5,80005030 <sys_open+0x5e>
    80005026:	0464d703          	lhu	a4,70(s1)
    8000502a:	47a5                	li	a5,9
    8000502c:	0ae7ee63          	bltu	a5,a4,800050e8 <sys_open+0x116>
    80005030:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80005032:	fabfe0ef          	jal	80003fdc <filealloc>
    80005036:	892a                	mv	s2,a0
    80005038:	c561                	beqz	a0,80005100 <sys_open+0x12e>
    8000503a:	ed4e                	sd	s3,152(sp)
    8000503c:	a47ff0ef          	jal	80004a82 <fdalloc>
    80005040:	89aa                	mv	s3,a0
    80005042:	0a054b63          	bltz	a0,800050f8 <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80005046:	04449703          	lh	a4,68(s1)
    8000504a:	478d                	li	a5,3
    8000504c:	0cf70363          	beq	a4,a5,80005112 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    80005050:	4789                	li	a5,2
    80005052:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80005056:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    8000505a:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    8000505e:	f4c42783          	lw	a5,-180(s0)
    80005062:	0017f713          	andi	a4,a5,1
    80005066:	00174713          	xori	a4,a4,1
    8000506a:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000506e:	0037f713          	andi	a4,a5,3
    80005072:	00e03733          	snez	a4,a4
    80005076:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    8000507a:	4007f793          	andi	a5,a5,1024
    8000507e:	c791                	beqz	a5,8000508a <sys_open+0xb8>
    80005080:	04449703          	lh	a4,68(s1)
    80005084:	4789                	li	a5,2
    80005086:	08f70d63          	beq	a4,a5,80005120 <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    8000508a:	8526                	mv	a0,s1
    8000508c:	a72fe0ef          	jal	800032fe <iunlock>
  end_op();
    80005090:	c3dfe0ef          	jal	80003ccc <end_op>

  return fd;
    80005094:	854e                	mv	a0,s3
    80005096:	74aa                	ld	s1,168(sp)
    80005098:	790a                	ld	s2,160(sp)
    8000509a:	69ea                	ld	s3,152(sp)
}
    8000509c:	70ea                	ld	ra,184(sp)
    8000509e:	744a                	ld	s0,176(sp)
    800050a0:	6129                	addi	sp,sp,192
    800050a2:	8082                	ret
      end_op();
    800050a4:	c29fe0ef          	jal	80003ccc <end_op>
      return -1;
    800050a8:	557d                	li	a0,-1
    800050aa:	74aa                	ld	s1,168(sp)
    800050ac:	bfc5                	j	8000509c <sys_open+0xca>
    if((ip = namei(path)) == 0){
    800050ae:	f5040513          	addi	a0,s0,-176
    800050b2:	9cdfe0ef          	jal	80003a7e <namei>
    800050b6:	84aa                	mv	s1,a0
    800050b8:	c11d                	beqz	a0,800050de <sys_open+0x10c>
    ilock(ip);
    800050ba:	996fe0ef          	jal	80003250 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800050be:	04449703          	lh	a4,68(s1)
    800050c2:	4785                	li	a5,1
    800050c4:	f4f71ce3          	bne	a4,a5,8000501c <sys_open+0x4a>
    800050c8:	f4c42783          	lw	a5,-180(s0)
    800050cc:	d3b5                	beqz	a5,80005030 <sys_open+0x5e>
      iunlockput(ip);
    800050ce:	8526                	mv	a0,s1
    800050d0:	b8cfe0ef          	jal	8000345c <iunlockput>
      end_op();
    800050d4:	bf9fe0ef          	jal	80003ccc <end_op>
      return -1;
    800050d8:	557d                	li	a0,-1
    800050da:	74aa                	ld	s1,168(sp)
    800050dc:	b7c1                	j	8000509c <sys_open+0xca>
      end_op();
    800050de:	beffe0ef          	jal	80003ccc <end_op>
      return -1;
    800050e2:	557d                	li	a0,-1
    800050e4:	74aa                	ld	s1,168(sp)
    800050e6:	bf5d                	j	8000509c <sys_open+0xca>
    iunlockput(ip);
    800050e8:	8526                	mv	a0,s1
    800050ea:	b72fe0ef          	jal	8000345c <iunlockput>
    end_op();
    800050ee:	bdffe0ef          	jal	80003ccc <end_op>
    return -1;
    800050f2:	557d                	li	a0,-1
    800050f4:	74aa                	ld	s1,168(sp)
    800050f6:	b75d                	j	8000509c <sys_open+0xca>
      fileclose(f);
    800050f8:	854a                	mv	a0,s2
    800050fa:	f87fe0ef          	jal	80004080 <fileclose>
    800050fe:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    80005100:	8526                	mv	a0,s1
    80005102:	b5afe0ef          	jal	8000345c <iunlockput>
    end_op();
    80005106:	bc7fe0ef          	jal	80003ccc <end_op>
    return -1;
    8000510a:	557d                	li	a0,-1
    8000510c:	74aa                	ld	s1,168(sp)
    8000510e:	790a                	ld	s2,160(sp)
    80005110:	b771                	j	8000509c <sys_open+0xca>
    f->type = FD_DEVICE;
    80005112:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    80005116:	04649783          	lh	a5,70(s1)
    8000511a:	02f91223          	sh	a5,36(s2)
    8000511e:	bf35                	j	8000505a <sys_open+0x88>
    itrunc(ip);
    80005120:	8526                	mv	a0,s1
    80005122:	a1cfe0ef          	jal	8000333e <itrunc>
    80005126:	b795                	j	8000508a <sys_open+0xb8>

0000000080005128 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005128:	7175                	addi	sp,sp,-144
    8000512a:	e506                	sd	ra,136(sp)
    8000512c:	e122                	sd	s0,128(sp)
    8000512e:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    80005130:	b2dfe0ef          	jal	80003c5c <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80005134:	08000613          	li	a2,128
    80005138:	f7040593          	addi	a1,s0,-144
    8000513c:	4501                	li	a0,0
    8000513e:	f6cfd0ef          	jal	800028aa <argstr>
    80005142:	02054363          	bltz	a0,80005168 <sys_mkdir+0x40>
    80005146:	4681                	li	a3,0
    80005148:	4601                	li	a2,0
    8000514a:	4585                	li	a1,1
    8000514c:	f7040513          	addi	a0,s0,-144
    80005150:	973ff0ef          	jal	80004ac2 <create>
    80005154:	c911                	beqz	a0,80005168 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005156:	b06fe0ef          	jal	8000345c <iunlockput>
  end_op();
    8000515a:	b73fe0ef          	jal	80003ccc <end_op>
  return 0;
    8000515e:	4501                	li	a0,0
}
    80005160:	60aa                	ld	ra,136(sp)
    80005162:	640a                	ld	s0,128(sp)
    80005164:	6149                	addi	sp,sp,144
    80005166:	8082                	ret
    end_op();
    80005168:	b65fe0ef          	jal	80003ccc <end_op>
    return -1;
    8000516c:	557d                	li	a0,-1
    8000516e:	bfcd                	j	80005160 <sys_mkdir+0x38>

0000000080005170 <sys_mknod>:

uint64
sys_mknod(void)
{
    80005170:	7135                	addi	sp,sp,-160
    80005172:	ed06                	sd	ra,152(sp)
    80005174:	e922                	sd	s0,144(sp)
    80005176:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005178:	ae5fe0ef          	jal	80003c5c <begin_op>
  argint(1, &major);
    8000517c:	f6c40593          	addi	a1,s0,-148
    80005180:	4505                	li	a0,1
    80005182:	ef0fd0ef          	jal	80002872 <argint>
  argint(2, &minor);
    80005186:	f6840593          	addi	a1,s0,-152
    8000518a:	4509                	li	a0,2
    8000518c:	ee6fd0ef          	jal	80002872 <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    80005190:	08000613          	li	a2,128
    80005194:	f7040593          	addi	a1,s0,-144
    80005198:	4501                	li	a0,0
    8000519a:	f10fd0ef          	jal	800028aa <argstr>
    8000519e:	02054563          	bltz	a0,800051c8 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800051a2:	f6841683          	lh	a3,-152(s0)
    800051a6:	f6c41603          	lh	a2,-148(s0)
    800051aa:	458d                	li	a1,3
    800051ac:	f7040513          	addi	a0,s0,-144
    800051b0:	913ff0ef          	jal	80004ac2 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800051b4:	c911                	beqz	a0,800051c8 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800051b6:	aa6fe0ef          	jal	8000345c <iunlockput>
  end_op();
    800051ba:	b13fe0ef          	jal	80003ccc <end_op>
  return 0;
    800051be:	4501                	li	a0,0
}
    800051c0:	60ea                	ld	ra,152(sp)
    800051c2:	644a                	ld	s0,144(sp)
    800051c4:	610d                	addi	sp,sp,160
    800051c6:	8082                	ret
    end_op();
    800051c8:	b05fe0ef          	jal	80003ccc <end_op>
    return -1;
    800051cc:	557d                	li	a0,-1
    800051ce:	bfcd                	j	800051c0 <sys_mknod+0x50>

00000000800051d0 <sys_chdir>:

uint64
sys_chdir(void)
{
    800051d0:	7135                	addi	sp,sp,-160
    800051d2:	ed06                	sd	ra,152(sp)
    800051d4:	e922                	sd	s0,144(sp)
    800051d6:	e14a                	sd	s2,128(sp)
    800051d8:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800051da:	f7cfc0ef          	jal	80001956 <myproc>
    800051de:	892a                	mv	s2,a0
  
  begin_op();
    800051e0:	a7dfe0ef          	jal	80003c5c <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800051e4:	08000613          	li	a2,128
    800051e8:	f6040593          	addi	a1,s0,-160
    800051ec:	4501                	li	a0,0
    800051ee:	ebcfd0ef          	jal	800028aa <argstr>
    800051f2:	04054363          	bltz	a0,80005238 <sys_chdir+0x68>
    800051f6:	e526                	sd	s1,136(sp)
    800051f8:	f6040513          	addi	a0,s0,-160
    800051fc:	883fe0ef          	jal	80003a7e <namei>
    80005200:	84aa                	mv	s1,a0
    80005202:	c915                	beqz	a0,80005236 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005204:	84cfe0ef          	jal	80003250 <ilock>
  if(ip->type != T_DIR){
    80005208:	04449703          	lh	a4,68(s1)
    8000520c:	4785                	li	a5,1
    8000520e:	02f71963          	bne	a4,a5,80005240 <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005212:	8526                	mv	a0,s1
    80005214:	8eafe0ef          	jal	800032fe <iunlock>
  iput(p->cwd);
    80005218:	15093503          	ld	a0,336(s2)
    8000521c:	9b6fe0ef          	jal	800033d2 <iput>
  end_op();
    80005220:	aadfe0ef          	jal	80003ccc <end_op>
  p->cwd = ip;
    80005224:	14993823          	sd	s1,336(s2)
  return 0;
    80005228:	4501                	li	a0,0
    8000522a:	64aa                	ld	s1,136(sp)
}
    8000522c:	60ea                	ld	ra,152(sp)
    8000522e:	644a                	ld	s0,144(sp)
    80005230:	690a                	ld	s2,128(sp)
    80005232:	610d                	addi	sp,sp,160
    80005234:	8082                	ret
    80005236:	64aa                	ld	s1,136(sp)
    end_op();
    80005238:	a95fe0ef          	jal	80003ccc <end_op>
    return -1;
    8000523c:	557d                	li	a0,-1
    8000523e:	b7fd                	j	8000522c <sys_chdir+0x5c>
    iunlockput(ip);
    80005240:	8526                	mv	a0,s1
    80005242:	a1afe0ef          	jal	8000345c <iunlockput>
    end_op();
    80005246:	a87fe0ef          	jal	80003ccc <end_op>
    return -1;
    8000524a:	557d                	li	a0,-1
    8000524c:	64aa                	ld	s1,136(sp)
    8000524e:	bff9                	j	8000522c <sys_chdir+0x5c>

0000000080005250 <sys_exec>:

uint64
sys_exec(void)
{
    80005250:	7105                	addi	sp,sp,-480
    80005252:	ef86                	sd	ra,472(sp)
    80005254:	eba2                	sd	s0,464(sp)
    80005256:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005258:	e2840593          	addi	a1,s0,-472
    8000525c:	4505                	li	a0,1
    8000525e:	e30fd0ef          	jal	8000288e <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005262:	08000613          	li	a2,128
    80005266:	f3040593          	addi	a1,s0,-208
    8000526a:	4501                	li	a0,0
    8000526c:	e3efd0ef          	jal	800028aa <argstr>
    80005270:	87aa                	mv	a5,a0
    return -1;
    80005272:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005274:	0e07c063          	bltz	a5,80005354 <sys_exec+0x104>
    80005278:	e7a6                	sd	s1,456(sp)
    8000527a:	e3ca                	sd	s2,448(sp)
    8000527c:	ff4e                	sd	s3,440(sp)
    8000527e:	fb52                	sd	s4,432(sp)
    80005280:	f756                	sd	s5,424(sp)
    80005282:	f35a                	sd	s6,416(sp)
    80005284:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    80005286:	e3040a13          	addi	s4,s0,-464
    8000528a:	10000613          	li	a2,256
    8000528e:	4581                	li	a1,0
    80005290:	8552                	mv	a0,s4
    80005292:	a8ffb0ef          	jal	80000d20 <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    80005296:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    80005298:	89d2                	mv	s3,s4
    8000529a:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    8000529c:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800052a0:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    800052a2:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800052a6:	00391513          	slli	a0,s2,0x3
    800052aa:	85d6                	mv	a1,s5
    800052ac:	e2843783          	ld	a5,-472(s0)
    800052b0:	953e                	add	a0,a0,a5
    800052b2:	d36fd0ef          	jal	800027e8 <fetchaddr>
    800052b6:	02054663          	bltz	a0,800052e2 <sys_exec+0x92>
    if(uarg == 0){
    800052ba:	e2043783          	ld	a5,-480(s0)
    800052be:	c7a1                	beqz	a5,80005306 <sys_exec+0xb6>
    argv[i] = kalloc();
    800052c0:	885fb0ef          	jal	80000b44 <kalloc>
    800052c4:	85aa                	mv	a1,a0
    800052c6:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800052ca:	cd01                	beqz	a0,800052e2 <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800052cc:	865a                	mv	a2,s6
    800052ce:	e2043503          	ld	a0,-480(s0)
    800052d2:	d60fd0ef          	jal	80002832 <fetchstr>
    800052d6:	00054663          	bltz	a0,800052e2 <sys_exec+0x92>
    if(i >= NELEM(argv)){
    800052da:	0905                	addi	s2,s2,1
    800052dc:	09a1                	addi	s3,s3,8
    800052de:	fd7914e3          	bne	s2,s7,800052a6 <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800052e2:	100a0a13          	addi	s4,s4,256
    800052e6:	6088                	ld	a0,0(s1)
    800052e8:	cd31                	beqz	a0,80005344 <sys_exec+0xf4>
    kfree(argv[i]);
    800052ea:	f72fb0ef          	jal	80000a5c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800052ee:	04a1                	addi	s1,s1,8
    800052f0:	ff449be3          	bne	s1,s4,800052e6 <sys_exec+0x96>
  return -1;
    800052f4:	557d                	li	a0,-1
    800052f6:	64be                	ld	s1,456(sp)
    800052f8:	691e                	ld	s2,448(sp)
    800052fa:	79fa                	ld	s3,440(sp)
    800052fc:	7a5a                	ld	s4,432(sp)
    800052fe:	7aba                	ld	s5,424(sp)
    80005300:	7b1a                	ld	s6,416(sp)
    80005302:	6bfa                	ld	s7,408(sp)
    80005304:	a881                	j	80005354 <sys_exec+0x104>
      argv[i] = 0;
    80005306:	0009079b          	sext.w	a5,s2
    8000530a:	e3040593          	addi	a1,s0,-464
    8000530e:	078e                	slli	a5,a5,0x3
    80005310:	97ae                	add	a5,a5,a1
    80005312:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    80005316:	f3040513          	addi	a0,s0,-208
    8000531a:	bb2ff0ef          	jal	800046cc <kexec>
    8000531e:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    80005320:	100a0a13          	addi	s4,s4,256
    80005324:	6088                	ld	a0,0(s1)
    80005326:	c511                	beqz	a0,80005332 <sys_exec+0xe2>
    kfree(argv[i]);
    80005328:	f34fb0ef          	jal	80000a5c <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000532c:	04a1                	addi	s1,s1,8
    8000532e:	ff449be3          	bne	s1,s4,80005324 <sys_exec+0xd4>
  return ret;
    80005332:	854a                	mv	a0,s2
    80005334:	64be                	ld	s1,456(sp)
    80005336:	691e                	ld	s2,448(sp)
    80005338:	79fa                	ld	s3,440(sp)
    8000533a:	7a5a                	ld	s4,432(sp)
    8000533c:	7aba                	ld	s5,424(sp)
    8000533e:	7b1a                	ld	s6,416(sp)
    80005340:	6bfa                	ld	s7,408(sp)
    80005342:	a809                	j	80005354 <sys_exec+0x104>
  return -1;
    80005344:	557d                	li	a0,-1
    80005346:	64be                	ld	s1,456(sp)
    80005348:	691e                	ld	s2,448(sp)
    8000534a:	79fa                	ld	s3,440(sp)
    8000534c:	7a5a                	ld	s4,432(sp)
    8000534e:	7aba                	ld	s5,424(sp)
    80005350:	7b1a                	ld	s6,416(sp)
    80005352:	6bfa                	ld	s7,408(sp)
}
    80005354:	60fe                	ld	ra,472(sp)
    80005356:	645e                	ld	s0,464(sp)
    80005358:	613d                	addi	sp,sp,480
    8000535a:	8082                	ret

000000008000535c <sys_pipe>:

uint64
sys_pipe(void)
{
    8000535c:	7139                	addi	sp,sp,-64
    8000535e:	fc06                	sd	ra,56(sp)
    80005360:	f822                	sd	s0,48(sp)
    80005362:	f426                	sd	s1,40(sp)
    80005364:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005366:	df0fc0ef          	jal	80001956 <myproc>
    8000536a:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000536c:	fd840593          	addi	a1,s0,-40
    80005370:	4501                	li	a0,0
    80005372:	d1cfd0ef          	jal	8000288e <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005376:	fc840593          	addi	a1,s0,-56
    8000537a:	fd040513          	addi	a0,s0,-48
    8000537e:	81eff0ef          	jal	8000439c <pipealloc>
    return -1;
    80005382:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005384:	0a054763          	bltz	a0,80005432 <sys_pipe+0xd6>
  fd0 = -1;
    80005388:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    8000538c:	fd043503          	ld	a0,-48(s0)
    80005390:	ef2ff0ef          	jal	80004a82 <fdalloc>
    80005394:	fca42223          	sw	a0,-60(s0)
    80005398:	08054463          	bltz	a0,80005420 <sys_pipe+0xc4>
    8000539c:	fc843503          	ld	a0,-56(s0)
    800053a0:	ee2ff0ef          	jal	80004a82 <fdalloc>
    800053a4:	fca42023          	sw	a0,-64(s0)
    800053a8:	06054263          	bltz	a0,8000540c <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800053ac:	4691                	li	a3,4
    800053ae:	fc440613          	addi	a2,s0,-60
    800053b2:	fd843583          	ld	a1,-40(s0)
    800053b6:	68a8                	ld	a0,80(s1)
    800053b8:	ac4fc0ef          	jal	8000167c <copyout>
    800053bc:	00054e63          	bltz	a0,800053d8 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800053c0:	4691                	li	a3,4
    800053c2:	fc040613          	addi	a2,s0,-64
    800053c6:	fd843583          	ld	a1,-40(s0)
    800053ca:	95b6                	add	a1,a1,a3
    800053cc:	68a8                	ld	a0,80(s1)
    800053ce:	aaefc0ef          	jal	8000167c <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800053d2:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800053d4:	04055f63          	bgez	a0,80005432 <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    800053d8:	fc442783          	lw	a5,-60(s0)
    800053dc:	078e                	slli	a5,a5,0x3
    800053de:	0d078793          	addi	a5,a5,208
    800053e2:	97a6                	add	a5,a5,s1
    800053e4:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800053e8:	fc042783          	lw	a5,-64(s0)
    800053ec:	078e                	slli	a5,a5,0x3
    800053ee:	0d078793          	addi	a5,a5,208
    800053f2:	97a6                	add	a5,a5,s1
    800053f4:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    800053f8:	fd043503          	ld	a0,-48(s0)
    800053fc:	c85fe0ef          	jal	80004080 <fileclose>
    fileclose(wf);
    80005400:	fc843503          	ld	a0,-56(s0)
    80005404:	c7dfe0ef          	jal	80004080 <fileclose>
    return -1;
    80005408:	57fd                	li	a5,-1
    8000540a:	a025                	j	80005432 <sys_pipe+0xd6>
    if(fd0 >= 0)
    8000540c:	fc442783          	lw	a5,-60(s0)
    80005410:	0007c863          	bltz	a5,80005420 <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    80005414:	078e                	slli	a5,a5,0x3
    80005416:	0d078793          	addi	a5,a5,208
    8000541a:	97a6                	add	a5,a5,s1
    8000541c:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005420:	fd043503          	ld	a0,-48(s0)
    80005424:	c5dfe0ef          	jal	80004080 <fileclose>
    fileclose(wf);
    80005428:	fc843503          	ld	a0,-56(s0)
    8000542c:	c55fe0ef          	jal	80004080 <fileclose>
    return -1;
    80005430:	57fd                	li	a5,-1
}
    80005432:	853e                	mv	a0,a5
    80005434:	70e2                	ld	ra,56(sp)
    80005436:	7442                	ld	s0,48(sp)
    80005438:	74a2                	ld	s1,40(sp)
    8000543a:	6121                	addi	sp,sp,64
    8000543c:	8082                	ret
	...

0000000080005440 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005440:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005442:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005444:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005446:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005448:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000544a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000544c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000544e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005450:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005452:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005454:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005456:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005458:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000545a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000545c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000545e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005460:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005462:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005464:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005466:	a90fd0ef          	jal	800026f6 <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    8000546a:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000546c:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000546e:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005470:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005472:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005474:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005476:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005478:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    8000547a:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000547c:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000547e:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    80005480:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005482:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005484:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005486:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005488:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    8000548a:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000548c:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000548e:	10200073          	sret
    80005492:	00000013          	nop
    80005496:	00000013          	nop
    8000549a:	00000013          	nop

000000008000549e <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    8000549e:	1141                	addi	sp,sp,-16
    800054a0:	e406                	sd	ra,8(sp)
    800054a2:	e022                	sd	s0,0(sp)
    800054a4:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    800054a6:	0c000737          	lui	a4,0xc000
    800054aa:	4785                	li	a5,1
    800054ac:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    800054ae:	c35c                	sw	a5,4(a4)
}
    800054b0:	60a2                	ld	ra,8(sp)
    800054b2:	6402                	ld	s0,0(sp)
    800054b4:	0141                	addi	sp,sp,16
    800054b6:	8082                	ret

00000000800054b8 <plicinithart>:

void
plicinithart(void)
{
    800054b8:	1141                	addi	sp,sp,-16
    800054ba:	e406                	sd	ra,8(sp)
    800054bc:	e022                	sd	s0,0(sp)
    800054be:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800054c0:	c62fc0ef          	jal	80001922 <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800054c4:	0085171b          	slliw	a4,a0,0x8
    800054c8:	0c0027b7          	lui	a5,0xc002
    800054cc:	97ba                	add	a5,a5,a4
    800054ce:	40200713          	li	a4,1026
    800054d2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800054d6:	00d5151b          	slliw	a0,a0,0xd
    800054da:	0c2017b7          	lui	a5,0xc201
    800054de:	97aa                	add	a5,a5,a0
    800054e0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800054e4:	60a2                	ld	ra,8(sp)
    800054e6:	6402                	ld	s0,0(sp)
    800054e8:	0141                	addi	sp,sp,16
    800054ea:	8082                	ret

00000000800054ec <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800054ec:	1141                	addi	sp,sp,-16
    800054ee:	e406                	sd	ra,8(sp)
    800054f0:	e022                	sd	s0,0(sp)
    800054f2:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800054f4:	c2efc0ef          	jal	80001922 <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    800054f8:	00d5151b          	slliw	a0,a0,0xd
    800054fc:	0c2017b7          	lui	a5,0xc201
    80005500:	97aa                	add	a5,a5,a0
  return irq;
}
    80005502:	43c8                	lw	a0,4(a5)
    80005504:	60a2                	ld	ra,8(sp)
    80005506:	6402                	ld	s0,0(sp)
    80005508:	0141                	addi	sp,sp,16
    8000550a:	8082                	ret

000000008000550c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    8000550c:	1101                	addi	sp,sp,-32
    8000550e:	ec06                	sd	ra,24(sp)
    80005510:	e822                	sd	s0,16(sp)
    80005512:	e426                	sd	s1,8(sp)
    80005514:	1000                	addi	s0,sp,32
    80005516:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005518:	c0afc0ef          	jal	80001922 <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    8000551c:	00d5179b          	slliw	a5,a0,0xd
    80005520:	0c201737          	lui	a4,0xc201
    80005524:	97ba                	add	a5,a5,a4
    80005526:	c3c4                	sw	s1,4(a5)
}
    80005528:	60e2                	ld	ra,24(sp)
    8000552a:	6442                	ld	s0,16(sp)
    8000552c:	64a2                	ld	s1,8(sp)
    8000552e:	6105                	addi	sp,sp,32
    80005530:	8082                	ret

0000000080005532 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005532:	1141                	addi	sp,sp,-16
    80005534:	e406                	sd	ra,8(sp)
    80005536:	e022                	sd	s0,0(sp)
    80005538:	0800                	addi	s0,sp,16
  if(i >= NUM)
    8000553a:	479d                	li	a5,7
    8000553c:	04a7ca63          	blt	a5,a0,80005590 <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005540:	0001b797          	auipc	a5,0x1b
    80005544:	4f878793          	addi	a5,a5,1272 # 80020a38 <disk>
    80005548:	97aa                	add	a5,a5,a0
    8000554a:	0187c783          	lbu	a5,24(a5)
    8000554e:	e7b9                	bnez	a5,8000559c <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005550:	00451693          	slli	a3,a0,0x4
    80005554:	0001b797          	auipc	a5,0x1b
    80005558:	4e478793          	addi	a5,a5,1252 # 80020a38 <disk>
    8000555c:	6398                	ld	a4,0(a5)
    8000555e:	9736                	add	a4,a4,a3
    80005560:	00073023          	sd	zero,0(a4) # c201000 <_entry-0x73dff000>
  disk.desc[i].len = 0;
    80005564:	6398                	ld	a4,0(a5)
    80005566:	9736                	add	a4,a4,a3
    80005568:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    8000556c:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005570:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005574:	97aa                	add	a5,a5,a0
    80005576:	4705                	li	a4,1
    80005578:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    8000557c:	0001b517          	auipc	a0,0x1b
    80005580:	4d450513          	addi	a0,a0,1236 # 80020a50 <disk+0x18>
    80005584:	a2ffc0ef          	jal	80001fb2 <wakeup>
}
    80005588:	60a2                	ld	ra,8(sp)
    8000558a:	6402                	ld	s0,0(sp)
    8000558c:	0141                	addi	sp,sp,16
    8000558e:	8082                	ret
    panic("free_desc 1");
    80005590:	00002517          	auipc	a0,0x2
    80005594:	08050513          	addi	a0,a0,128 # 80007610 <etext+0x610>
    80005598:	a8cfb0ef          	jal	80000824 <panic>
    panic("free_desc 2");
    8000559c:	00002517          	auipc	a0,0x2
    800055a0:	08450513          	addi	a0,a0,132 # 80007620 <etext+0x620>
    800055a4:	a80fb0ef          	jal	80000824 <panic>

00000000800055a8 <virtio_disk_init>:
{
    800055a8:	1101                	addi	sp,sp,-32
    800055aa:	ec06                	sd	ra,24(sp)
    800055ac:	e822                	sd	s0,16(sp)
    800055ae:	e426                	sd	s1,8(sp)
    800055b0:	e04a                	sd	s2,0(sp)
    800055b2:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    800055b4:	00002597          	auipc	a1,0x2
    800055b8:	07c58593          	addi	a1,a1,124 # 80007630 <etext+0x630>
    800055bc:	0001b517          	auipc	a0,0x1b
    800055c0:	5a450513          	addi	a0,a0,1444 # 80020b60 <disk+0x128>
    800055c4:	e02fb0ef          	jal	80000bc6 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800055c8:	100017b7          	lui	a5,0x10001
    800055cc:	4398                	lw	a4,0(a5)
    800055ce:	2701                	sext.w	a4,a4
    800055d0:	747277b7          	lui	a5,0x74727
    800055d4:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    800055d8:	14f71863          	bne	a4,a5,80005728 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800055dc:	100017b7          	lui	a5,0x10001
    800055e0:	43dc                	lw	a5,4(a5)
    800055e2:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    800055e4:	4709                	li	a4,2
    800055e6:	14e79163          	bne	a5,a4,80005728 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800055ea:	100017b7          	lui	a5,0x10001
    800055ee:	479c                	lw	a5,8(a5)
    800055f0:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    800055f2:	12e79b63          	bne	a5,a4,80005728 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    800055f6:	100017b7          	lui	a5,0x10001
    800055fa:	47d8                	lw	a4,12(a5)
    800055fc:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    800055fe:	554d47b7          	lui	a5,0x554d4
    80005602:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005606:	12f71163          	bne	a4,a5,80005728 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    8000560a:	100017b7          	lui	a5,0x10001
    8000560e:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005612:	4705                	li	a4,1
    80005614:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005616:	470d                	li	a4,3
    80005618:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    8000561a:	10001737          	lui	a4,0x10001
    8000561e:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005620:	c7ffe6b7          	lui	a3,0xc7ffe
    80005624:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47fddbe7>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005628:	8f75                	and	a4,a4,a3
    8000562a:	100016b7          	lui	a3,0x10001
    8000562e:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005630:	472d                	li	a4,11
    80005632:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005634:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005638:	439c                	lw	a5,0(a5)
    8000563a:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    8000563e:	8ba1                	andi	a5,a5,8
    80005640:	0e078a63          	beqz	a5,80005734 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005644:	100017b7          	lui	a5,0x10001
    80005648:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    8000564c:	43fc                	lw	a5,68(a5)
    8000564e:	2781                	sext.w	a5,a5
    80005650:	0e079863          	bnez	a5,80005740 <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005654:	100017b7          	lui	a5,0x10001
    80005658:	5bdc                	lw	a5,52(a5)
    8000565a:	2781                	sext.w	a5,a5
  if(max == 0)
    8000565c:	0e078863          	beqz	a5,8000574c <virtio_disk_init+0x1a4>
  if(max < NUM)
    80005660:	471d                	li	a4,7
    80005662:	0ef77b63          	bgeu	a4,a5,80005758 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80005666:	cdefb0ef          	jal	80000b44 <kalloc>
    8000566a:	0001b497          	auipc	s1,0x1b
    8000566e:	3ce48493          	addi	s1,s1,974 # 80020a38 <disk>
    80005672:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80005674:	cd0fb0ef          	jal	80000b44 <kalloc>
    80005678:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    8000567a:	ccafb0ef          	jal	80000b44 <kalloc>
    8000567e:	87aa                	mv	a5,a0
    80005680:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80005682:	6088                	ld	a0,0(s1)
    80005684:	0e050063          	beqz	a0,80005764 <virtio_disk_init+0x1bc>
    80005688:	0001b717          	auipc	a4,0x1b
    8000568c:	3b873703          	ld	a4,952(a4) # 80020a40 <disk+0x8>
    80005690:	cb71                	beqz	a4,80005764 <virtio_disk_init+0x1bc>
    80005692:	cbe9                	beqz	a5,80005764 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80005694:	6605                	lui	a2,0x1
    80005696:	4581                	li	a1,0
    80005698:	e88fb0ef          	jal	80000d20 <memset>
  memset(disk.avail, 0, PGSIZE);
    8000569c:	0001b497          	auipc	s1,0x1b
    800056a0:	39c48493          	addi	s1,s1,924 # 80020a38 <disk>
    800056a4:	6605                	lui	a2,0x1
    800056a6:	4581                	li	a1,0
    800056a8:	6488                	ld	a0,8(s1)
    800056aa:	e76fb0ef          	jal	80000d20 <memset>
  memset(disk.used, 0, PGSIZE);
    800056ae:	6605                	lui	a2,0x1
    800056b0:	4581                	li	a1,0
    800056b2:	6888                	ld	a0,16(s1)
    800056b4:	e6cfb0ef          	jal	80000d20 <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    800056b8:	100017b7          	lui	a5,0x10001
    800056bc:	4721                	li	a4,8
    800056be:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    800056c0:	4098                	lw	a4,0(s1)
    800056c2:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    800056c6:	40d8                	lw	a4,4(s1)
    800056c8:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    800056cc:	649c                	ld	a5,8(s1)
    800056ce:	0007869b          	sext.w	a3,a5
    800056d2:	10001737          	lui	a4,0x10001
    800056d6:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    800056da:	9781                	srai	a5,a5,0x20
    800056dc:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    800056e0:	689c                	ld	a5,16(s1)
    800056e2:	0007869b          	sext.w	a3,a5
    800056e6:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    800056ea:	9781                	srai	a5,a5,0x20
    800056ec:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    800056f0:	4785                	li	a5,1
    800056f2:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    800056f4:	00f48c23          	sb	a5,24(s1)
    800056f8:	00f48ca3          	sb	a5,25(s1)
    800056fc:	00f48d23          	sb	a5,26(s1)
    80005700:	00f48da3          	sb	a5,27(s1)
    80005704:	00f48e23          	sb	a5,28(s1)
    80005708:	00f48ea3          	sb	a5,29(s1)
    8000570c:	00f48f23          	sb	a5,30(s1)
    80005710:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    80005714:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    80005718:	07272823          	sw	s2,112(a4)
}
    8000571c:	60e2                	ld	ra,24(sp)
    8000571e:	6442                	ld	s0,16(sp)
    80005720:	64a2                	ld	s1,8(sp)
    80005722:	6902                	ld	s2,0(sp)
    80005724:	6105                	addi	sp,sp,32
    80005726:	8082                	ret
    panic("could not find virtio disk");
    80005728:	00002517          	auipc	a0,0x2
    8000572c:	f1850513          	addi	a0,a0,-232 # 80007640 <etext+0x640>
    80005730:	8f4fb0ef          	jal	80000824 <panic>
    panic("virtio disk FEATURES_OK unset");
    80005734:	00002517          	auipc	a0,0x2
    80005738:	f2c50513          	addi	a0,a0,-212 # 80007660 <etext+0x660>
    8000573c:	8e8fb0ef          	jal	80000824 <panic>
    panic("virtio disk should not be ready");
    80005740:	00002517          	auipc	a0,0x2
    80005744:	f4050513          	addi	a0,a0,-192 # 80007680 <etext+0x680>
    80005748:	8dcfb0ef          	jal	80000824 <panic>
    panic("virtio disk has no queue 0");
    8000574c:	00002517          	auipc	a0,0x2
    80005750:	f5450513          	addi	a0,a0,-172 # 800076a0 <etext+0x6a0>
    80005754:	8d0fb0ef          	jal	80000824 <panic>
    panic("virtio disk max queue too short");
    80005758:	00002517          	auipc	a0,0x2
    8000575c:	f6850513          	addi	a0,a0,-152 # 800076c0 <etext+0x6c0>
    80005760:	8c4fb0ef          	jal	80000824 <panic>
    panic("virtio disk kalloc");
    80005764:	00002517          	auipc	a0,0x2
    80005768:	f7c50513          	addi	a0,a0,-132 # 800076e0 <etext+0x6e0>
    8000576c:	8b8fb0ef          	jal	80000824 <panic>

0000000080005770 <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    80005770:	711d                	addi	sp,sp,-96
    80005772:	ec86                	sd	ra,88(sp)
    80005774:	e8a2                	sd	s0,80(sp)
    80005776:	e4a6                	sd	s1,72(sp)
    80005778:	e0ca                	sd	s2,64(sp)
    8000577a:	fc4e                	sd	s3,56(sp)
    8000577c:	f852                	sd	s4,48(sp)
    8000577e:	f456                	sd	s5,40(sp)
    80005780:	f05a                	sd	s6,32(sp)
    80005782:	ec5e                	sd	s7,24(sp)
    80005784:	e862                	sd	s8,16(sp)
    80005786:	1080                	addi	s0,sp,96
    80005788:	89aa                	mv	s3,a0
    8000578a:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    8000578c:	00c52b83          	lw	s7,12(a0)
    80005790:	001b9b9b          	slliw	s7,s7,0x1
    80005794:	1b82                	slli	s7,s7,0x20
    80005796:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    8000579a:	0001b517          	auipc	a0,0x1b
    8000579e:	3c650513          	addi	a0,a0,966 # 80020b60 <disk+0x128>
    800057a2:	caefb0ef          	jal	80000c50 <acquire>
  for(int i = 0; i < NUM; i++){
    800057a6:	44a1                	li	s1,8
      disk.free[i] = 0;
    800057a8:	0001ba97          	auipc	s5,0x1b
    800057ac:	290a8a93          	addi	s5,s5,656 # 80020a38 <disk>
  for(int i = 0; i < 3; i++){
    800057b0:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    800057b2:	5c7d                	li	s8,-1
    800057b4:	a095                	j	80005818 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    800057b6:	00fa8733          	add	a4,s5,a5
    800057ba:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    800057be:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    800057c0:	0207c563          	bltz	a5,800057ea <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    800057c4:	2905                	addiw	s2,s2,1
    800057c6:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    800057c8:	05490c63          	beq	s2,s4,80005820 <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    800057cc:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    800057ce:	0001b717          	auipc	a4,0x1b
    800057d2:	26a70713          	addi	a4,a4,618 # 80020a38 <disk>
    800057d6:	4781                	li	a5,0
    if(disk.free[i]){
    800057d8:	01874683          	lbu	a3,24(a4)
    800057dc:	fee9                	bnez	a3,800057b6 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    800057de:	2785                	addiw	a5,a5,1
    800057e0:	0705                	addi	a4,a4,1
    800057e2:	fe979be3          	bne	a5,s1,800057d8 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    800057e6:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    800057ea:	01205d63          	blez	s2,80005804 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800057ee:	fa042503          	lw	a0,-96(s0)
    800057f2:	d41ff0ef          	jal	80005532 <free_desc>
      for(int j = 0; j < i; j++)
    800057f6:	4785                	li	a5,1
    800057f8:	0127d663          	bge	a5,s2,80005804 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    800057fc:	fa442503          	lw	a0,-92(s0)
    80005800:	d33ff0ef          	jal	80005532 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80005804:	0001b597          	auipc	a1,0x1b
    80005808:	35c58593          	addi	a1,a1,860 # 80020b60 <disk+0x128>
    8000580c:	0001b517          	auipc	a0,0x1b
    80005810:	24450513          	addi	a0,a0,580 # 80020a50 <disk+0x18>
    80005814:	f52fc0ef          	jal	80001f66 <sleep>
  for(int i = 0; i < 3; i++){
    80005818:	fa040613          	addi	a2,s0,-96
    8000581c:	4901                	li	s2,0
    8000581e:	b77d                	j	800057cc <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    80005820:	fa042503          	lw	a0,-96(s0)
    80005824:	00451693          	slli	a3,a0,0x4

  if(write)
    80005828:	0001b797          	auipc	a5,0x1b
    8000582c:	21078793          	addi	a5,a5,528 # 80020a38 <disk>
    80005830:	00451713          	slli	a4,a0,0x4
    80005834:	0a070713          	addi	a4,a4,160
    80005838:	973e                	add	a4,a4,a5
    8000583a:	01603633          	snez	a2,s6
    8000583e:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    80005840:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    80005844:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    80005848:	6398                	ld	a4,0(a5)
    8000584a:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    8000584c:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    80005850:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    80005852:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    80005854:	6390                	ld	a2,0(a5)
    80005856:	00d60833          	add	a6,a2,a3
    8000585a:	4741                	li	a4,16
    8000585c:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    80005860:	4585                	li	a1,1
    80005862:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    80005866:	fa442703          	lw	a4,-92(s0)
    8000586a:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    8000586e:	0712                	slli	a4,a4,0x4
    80005870:	963a                	add	a2,a2,a4
    80005872:	05898813          	addi	a6,s3,88
    80005876:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    8000587a:	0007b883          	ld	a7,0(a5)
    8000587e:	9746                	add	a4,a4,a7
    80005880:	40000613          	li	a2,1024
    80005884:	c710                	sw	a2,8(a4)
  if(write)
    80005886:	001b3613          	seqz	a2,s6
    8000588a:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    8000588e:	8e4d                	or	a2,a2,a1
    80005890:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80005894:	fa842603          	lw	a2,-88(s0)
    80005898:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    8000589c:	00451813          	slli	a6,a0,0x4
    800058a0:	02080813          	addi	a6,a6,32
    800058a4:	983e                	add	a6,a6,a5
    800058a6:	577d                	li	a4,-1
    800058a8:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    800058ac:	0612                	slli	a2,a2,0x4
    800058ae:	98b2                	add	a7,a7,a2
    800058b0:	03068713          	addi	a4,a3,48
    800058b4:	973e                	add	a4,a4,a5
    800058b6:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    800058ba:	6398                	ld	a4,0(a5)
    800058bc:	9732                	add	a4,a4,a2
    800058be:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    800058c0:	4689                	li	a3,2
    800058c2:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    800058c6:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    800058ca:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    800058ce:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    800058d2:	6794                	ld	a3,8(a5)
    800058d4:	0026d703          	lhu	a4,2(a3)
    800058d8:	8b1d                	andi	a4,a4,7
    800058da:	0706                	slli	a4,a4,0x1
    800058dc:	96ba                	add	a3,a3,a4
    800058de:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    800058e2:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    800058e6:	6798                	ld	a4,8(a5)
    800058e8:	00275783          	lhu	a5,2(a4)
    800058ec:	2785                	addiw	a5,a5,1
    800058ee:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    800058f2:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    800058f6:	100017b7          	lui	a5,0x10001
    800058fa:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    800058fe:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80005902:	0001b917          	auipc	s2,0x1b
    80005906:	25e90913          	addi	s2,s2,606 # 80020b60 <disk+0x128>
  while(b->disk == 1) {
    8000590a:	84ae                	mv	s1,a1
    8000590c:	00b79a63          	bne	a5,a1,80005920 <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    80005910:	85ca                	mv	a1,s2
    80005912:	854e                	mv	a0,s3
    80005914:	e52fc0ef          	jal	80001f66 <sleep>
  while(b->disk == 1) {
    80005918:	0049a783          	lw	a5,4(s3)
    8000591c:	fe978ae3          	beq	a5,s1,80005910 <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    80005920:	fa042903          	lw	s2,-96(s0)
    80005924:	00491713          	slli	a4,s2,0x4
    80005928:	02070713          	addi	a4,a4,32
    8000592c:	0001b797          	auipc	a5,0x1b
    80005930:	10c78793          	addi	a5,a5,268 # 80020a38 <disk>
    80005934:	97ba                	add	a5,a5,a4
    80005936:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    8000593a:	0001b997          	auipc	s3,0x1b
    8000593e:	0fe98993          	addi	s3,s3,254 # 80020a38 <disk>
    80005942:	00491713          	slli	a4,s2,0x4
    80005946:	0009b783          	ld	a5,0(s3)
    8000594a:	97ba                	add	a5,a5,a4
    8000594c:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    80005950:	854a                	mv	a0,s2
    80005952:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    80005956:	bddff0ef          	jal	80005532 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    8000595a:	8885                	andi	s1,s1,1
    8000595c:	f0fd                	bnez	s1,80005942 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    8000595e:	0001b517          	auipc	a0,0x1b
    80005962:	20250513          	addi	a0,a0,514 # 80020b60 <disk+0x128>
    80005966:	b7efb0ef          	jal	80000ce4 <release>
}
    8000596a:	60e6                	ld	ra,88(sp)
    8000596c:	6446                	ld	s0,80(sp)
    8000596e:	64a6                	ld	s1,72(sp)
    80005970:	6906                	ld	s2,64(sp)
    80005972:	79e2                	ld	s3,56(sp)
    80005974:	7a42                	ld	s4,48(sp)
    80005976:	7aa2                	ld	s5,40(sp)
    80005978:	7b02                	ld	s6,32(sp)
    8000597a:	6be2                	ld	s7,24(sp)
    8000597c:	6c42                	ld	s8,16(sp)
    8000597e:	6125                	addi	sp,sp,96
    80005980:	8082                	ret

0000000080005982 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80005982:	1101                	addi	sp,sp,-32
    80005984:	ec06                	sd	ra,24(sp)
    80005986:	e822                	sd	s0,16(sp)
    80005988:	e426                	sd	s1,8(sp)
    8000598a:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    8000598c:	0001b497          	auipc	s1,0x1b
    80005990:	0ac48493          	addi	s1,s1,172 # 80020a38 <disk>
    80005994:	0001b517          	auipc	a0,0x1b
    80005998:	1cc50513          	addi	a0,a0,460 # 80020b60 <disk+0x128>
    8000599c:	ab4fb0ef          	jal	80000c50 <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    800059a0:	100017b7          	lui	a5,0x10001
    800059a4:	53bc                	lw	a5,96(a5)
    800059a6:	8b8d                	andi	a5,a5,3
    800059a8:	10001737          	lui	a4,0x10001
    800059ac:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    800059ae:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    800059b2:	689c                	ld	a5,16(s1)
    800059b4:	0204d703          	lhu	a4,32(s1)
    800059b8:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    800059bc:	04f70863          	beq	a4,a5,80005a0c <virtio_disk_intr+0x8a>
    __sync_synchronize();
    800059c0:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    800059c4:	6898                	ld	a4,16(s1)
    800059c6:	0204d783          	lhu	a5,32(s1)
    800059ca:	8b9d                	andi	a5,a5,7
    800059cc:	078e                	slli	a5,a5,0x3
    800059ce:	97ba                	add	a5,a5,a4
    800059d0:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    800059d2:	00479713          	slli	a4,a5,0x4
    800059d6:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    800059da:	9726                	add	a4,a4,s1
    800059dc:	01074703          	lbu	a4,16(a4)
    800059e0:	e329                	bnez	a4,80005a22 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    800059e2:	0792                	slli	a5,a5,0x4
    800059e4:	02078793          	addi	a5,a5,32
    800059e8:	97a6                	add	a5,a5,s1
    800059ea:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    800059ec:	00052223          	sw	zero,4(a0)
    wakeup(b);
    800059f0:	dc2fc0ef          	jal	80001fb2 <wakeup>

    disk.used_idx += 1;
    800059f4:	0204d783          	lhu	a5,32(s1)
    800059f8:	2785                	addiw	a5,a5,1
    800059fa:	17c2                	slli	a5,a5,0x30
    800059fc:	93c1                	srli	a5,a5,0x30
    800059fe:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80005a02:	6898                	ld	a4,16(s1)
    80005a04:	00275703          	lhu	a4,2(a4)
    80005a08:	faf71ce3          	bne	a4,a5,800059c0 <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    80005a0c:	0001b517          	auipc	a0,0x1b
    80005a10:	15450513          	addi	a0,a0,340 # 80020b60 <disk+0x128>
    80005a14:	ad0fb0ef          	jal	80000ce4 <release>
}
    80005a18:	60e2                	ld	ra,24(sp)
    80005a1a:	6442                	ld	s0,16(sp)
    80005a1c:	64a2                	ld	s1,8(sp)
    80005a1e:	6105                	addi	sp,sp,32
    80005a20:	8082                	ret
      panic("virtio_disk_intr status");
    80005a22:	00002517          	auipc	a0,0x2
    80005a26:	cd650513          	addi	a0,a0,-810 # 800076f8 <etext+0x6f8>
    80005a2a:	dfbfa0ef          	jal	80000824 <panic>
	...

0000000080006000 <_trampoline>:
    80006000:	14051073          	csrw	sscratch,a0
    80006004:	02000537          	lui	a0,0x2000
    80006008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000600a:	0536                	slli	a0,a0,0xd
    8000600c:	02153423          	sd	ra,40(a0)
    80006010:	02253823          	sd	sp,48(a0)
    80006014:	02353c23          	sd	gp,56(a0)
    80006018:	04453023          	sd	tp,64(a0)
    8000601c:	04553423          	sd	t0,72(a0)
    80006020:	04653823          	sd	t1,80(a0)
    80006024:	04753c23          	sd	t2,88(a0)
    80006028:	f120                	sd	s0,96(a0)
    8000602a:	f524                	sd	s1,104(a0)
    8000602c:	fd2c                	sd	a1,120(a0)
    8000602e:	e150                	sd	a2,128(a0)
    80006030:	e554                	sd	a3,136(a0)
    80006032:	e958                	sd	a4,144(a0)
    80006034:	ed5c                	sd	a5,152(a0)
    80006036:	0b053023          	sd	a6,160(a0)
    8000603a:	0b153423          	sd	a7,168(a0)
    8000603e:	0b253823          	sd	s2,176(a0)
    80006042:	0b353c23          	sd	s3,184(a0)
    80006046:	0d453023          	sd	s4,192(a0)
    8000604a:	0d553423          	sd	s5,200(a0)
    8000604e:	0d653823          	sd	s6,208(a0)
    80006052:	0d753c23          	sd	s7,216(a0)
    80006056:	0f853023          	sd	s8,224(a0)
    8000605a:	0f953423          	sd	s9,232(a0)
    8000605e:	0fa53823          	sd	s10,240(a0)
    80006062:	0fb53c23          	sd	s11,248(a0)
    80006066:	11c53023          	sd	t3,256(a0)
    8000606a:	11d53423          	sd	t4,264(a0)
    8000606e:	11e53823          	sd	t5,272(a0)
    80006072:	11f53c23          	sd	t6,280(a0)
    80006076:	140022f3          	csrr	t0,sscratch
    8000607a:	06553823          	sd	t0,112(a0)
    8000607e:	00853103          	ld	sp,8(a0)
    80006082:	02053203          	ld	tp,32(a0)
    80006086:	01053283          	ld	t0,16(a0)
    8000608a:	00053303          	ld	t1,0(a0)
    8000608e:	12000073          	sfence.vma
    80006092:	18031073          	csrw	satp,t1
    80006096:	12000073          	sfence.vma
    8000609a:	9282                	jalr	t0

000000008000609c <userret>:
    8000609c:	12000073          	sfence.vma
    800060a0:	18051073          	csrw	satp,a0
    800060a4:	12000073          	sfence.vma
    800060a8:	02000537          	lui	a0,0x2000
    800060ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800060ae:	0536                	slli	a0,a0,0xd
    800060b0:	02853083          	ld	ra,40(a0)
    800060b4:	03053103          	ld	sp,48(a0)
    800060b8:	03853183          	ld	gp,56(a0)
    800060bc:	04053203          	ld	tp,64(a0)
    800060c0:	04853283          	ld	t0,72(a0)
    800060c4:	05053303          	ld	t1,80(a0)
    800060c8:	05853383          	ld	t2,88(a0)
    800060cc:	7120                	ld	s0,96(a0)
    800060ce:	7524                	ld	s1,104(a0)
    800060d0:	7d2c                	ld	a1,120(a0)
    800060d2:	6150                	ld	a2,128(a0)
    800060d4:	6554                	ld	a3,136(a0)
    800060d6:	6958                	ld	a4,144(a0)
    800060d8:	6d5c                	ld	a5,152(a0)
    800060da:	0a053803          	ld	a6,160(a0)
    800060de:	0a853883          	ld	a7,168(a0)
    800060e2:	0b053903          	ld	s2,176(a0)
    800060e6:	0b853983          	ld	s3,184(a0)
    800060ea:	0c053a03          	ld	s4,192(a0)
    800060ee:	0c853a83          	ld	s5,200(a0)
    800060f2:	0d053b03          	ld	s6,208(a0)
    800060f6:	0d853b83          	ld	s7,216(a0)
    800060fa:	0e053c03          	ld	s8,224(a0)
    800060fe:	0e853c83          	ld	s9,232(a0)
    80006102:	0f053d03          	ld	s10,240(a0)
    80006106:	0f853d83          	ld	s11,248(a0)
    8000610a:	10053e03          	ld	t3,256(a0)
    8000610e:	10853e83          	ld	t4,264(a0)
    80006112:	11053f03          	ld	t5,272(a0)
    80006116:	11853f83          	ld	t6,280(a0)
    8000611a:	7928                	ld	a0,112(a0)
    8000611c:	10200073          	sret
	...
